/*      */ package antlr.actions.java;
/*      */ 
/*      */ import antlr.ActionTransInfo;
/*      */ import antlr.ByteBuffer;
/*      */ import antlr.CharBuffer;
/*      */ import antlr.CharScanner;
/*      */ import antlr.CharStreamException;
/*      */ import antlr.CharStreamIOException;
/*      */ import antlr.CodeGenerator;
/*      */ import antlr.InputBuffer;
/*      */ import antlr.LexerSharedInputState;
/*      */ import antlr.NoViableAltForCharException;
/*      */ import antlr.RecognitionException;
/*      */ import antlr.RuleBlock;
/*      */ import antlr.Token;
/*      */ import antlr.TokenStream;
/*      */ import antlr.TokenStreamException;
/*      */ import antlr.TokenStreamIOException;
/*      */ import antlr.TokenStreamRecognitionException;
/*      */ import antlr.Tool;
/*      */ import antlr.collections.impl.BitSet;
/*      */ import antlr.collections.impl.Vector;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ActionLexer
/*      */   extends CharScanner
/*      */   implements ActionLexerTokenTypes, TokenStream
/*      */ {
/*      */   protected RuleBlock currentRule;
/*      */   protected CodeGenerator generator;
/*   59 */   protected int lineOffset = 0;
/*      */   
/*      */   private Tool antlrTool;
/*      */   
/*      */   ActionTransInfo transInfo;
/*      */ 
/*      */   
/*      */   public ActionLexer(String paramString, RuleBlock paramRuleBlock, CodeGenerator paramCodeGenerator, ActionTransInfo paramActionTransInfo) {
/*   67 */     this(new StringReader(paramString));
/*   68 */     this.currentRule = paramRuleBlock;
/*   69 */     this.generator = paramCodeGenerator;
/*   70 */     this.transInfo = paramActionTransInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLineOffset(int paramInt) {
/*   75 */     setLine(paramInt);
/*      */   }
/*      */   
/*      */   public void setTool(Tool paramTool) {
/*   79 */     this.antlrTool = paramTool;
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportError(RecognitionException paramRecognitionException) {
/*   84 */     this.antlrTool.error("Syntax error in action: " + paramRecognitionException, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportError(String paramString) {
/*   89 */     this.antlrTool.error(paramString, getFilename(), getLine(), getColumn());
/*      */   }
/*      */ 
/*      */   
/*      */   public void reportWarning(String paramString) {
/*   94 */     if (getFilename() == null) {
/*   95 */       this.antlrTool.warning(paramString);
/*      */     } else {
/*      */       
/*   98 */       this.antlrTool.warning(paramString, getFilename(), getLine(), getColumn());
/*      */     } 
/*      */   }
/*      */   public ActionLexer(InputStream paramInputStream) {
/*  102 */     this((InputBuffer)new ByteBuffer(paramInputStream));
/*      */   }
/*      */   public ActionLexer(Reader paramReader) {
/*  105 */     this((InputBuffer)new CharBuffer(paramReader));
/*      */   }
/*      */   public ActionLexer(InputBuffer paramInputBuffer) {
/*  108 */     this(new LexerSharedInputState(paramInputBuffer));
/*      */   }
/*      */   public ActionLexer(LexerSharedInputState paramLexerSharedInputState) {
/*  111 */     super(paramLexerSharedInputState);
/*  112 */     this.caseSensitiveLiterals = true;
/*  113 */     setCaseSensitive(true);
/*  114 */     this.literals = new Hashtable();
/*      */   }
/*      */   
/*      */   public Token nextToken() throws TokenStreamException {
/*  118 */     Token token = null;
/*      */     
/*      */     while (true) {
/*  121 */       Object object = null;
/*  122 */       int i = 0;
/*  123 */       resetText();
/*      */       
/*      */       try {
/*  126 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ')
/*  127 */         { mACTION(true);
/*  128 */           token = this._returnToken;
/*      */            }
/*      */         
/*  131 */         else if (LA(1) == Character.MAX_VALUE) { uponEOF(); this._returnToken = makeToken(1); }
/*  132 */         else { throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */         
/*  135 */         if (this._returnToken == null)
/*  136 */           continue;  i = this._returnToken.getType();
/*  137 */         this._returnToken.setType(i);
/*  138 */         return this._returnToken;
/*      */       }
/*  140 */       catch (RecognitionException recognitionException) {
/*  141 */         throw new TokenStreamRecognitionException(recognitionException);
/*      */       
/*      */       }
/*  144 */       catch (CharStreamException charStreamException) {
/*  145 */         if (charStreamException instanceof CharStreamIOException) {
/*  146 */           throw new TokenStreamIOException(((CharStreamIOException)charStreamException).io);
/*      */         }
/*      */         
/*  149 */         throw new TokenStreamException(charStreamException.getMessage());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void mACTION(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  156 */     Token token = null; int i = this.text.length();
/*  157 */     byte b1 = 4;
/*      */ 
/*      */ 
/*      */     
/*  161 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  164 */       switch (LA(1)) {
/*      */         
/*      */         case '#':
/*  167 */           mAST_ITEM(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '$':
/*  172 */           mTEXT_ITEM(false);
/*      */           break;
/*      */         
/*      */         default:
/*  176 */           if (_tokenSet_0.member(LA(1))) {
/*  177 */             mSTUFF(false);
/*      */             break;
/*      */           } 
/*  180 */           if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  183 */       b2++;
/*      */     } 
/*      */     
/*  186 */     if (paramBoolean && token == null && b1 != -1) {
/*  187 */       token = makeToken(b1);
/*  188 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  190 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSTUFF(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  194 */     Token token = null; int i = this.text.length();
/*  195 */     byte b = 5;
/*      */ 
/*      */     
/*  198 */     switch (LA(1)) {
/*      */       
/*      */       case '"':
/*  201 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/*  206 */         mCHAR(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\n':
/*  211 */         match('\n');
/*  212 */         newline();
/*      */         break;
/*      */       
/*      */       default:
/*  216 */         if (LA(1) == '/' && (LA(2) == '*' || LA(2) == '/')) {
/*  217 */           mCOMMENT(false); break;
/*      */         } 
/*  219 */         if (LA(1) == '\r' && LA(2) == '\n') {
/*  220 */           match("\r\n");
/*  221 */           newline(); break;
/*      */         } 
/*  223 */         if (LA(1) == '/' && _tokenSet_1.member(LA(2))) {
/*  224 */           match('/');
/*      */           
/*  226 */           match(_tokenSet_1);
/*      */           break;
/*      */         } 
/*  229 */         if (LA(1) == '\r') {
/*  230 */           match('\r');
/*  231 */           newline(); break;
/*      */         } 
/*  233 */         if (_tokenSet_2.member(LA(1))) {
/*      */           
/*  235 */           match(_tokenSet_2);
/*      */           
/*      */           break;
/*      */         } 
/*  239 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  242 */     if (paramBoolean && token == null && b != -1) {
/*  243 */       token = makeToken(b);
/*  244 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  246 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  250 */     Token token1 = null; int i = this.text.length();
/*  251 */     byte b = 6;
/*      */     
/*  253 */     Token token2 = null;
/*  254 */     Token token3 = null;
/*  255 */     Token token4 = null;
/*      */     
/*  257 */     if (LA(1) == '#' && LA(2) == '(') {
/*  258 */       int j = this.text.length();
/*  259 */       match('#');
/*  260 */       this.text.setLength(j);
/*  261 */       mTREE(true);
/*  262 */       token2 = this._returnToken;
/*      */     }
/*  264 */     else if (LA(1) == '#' && _tokenSet_3.member(LA(2))) {
/*  265 */       int j = this.text.length();
/*  266 */       match('#');
/*  267 */       this.text.setLength(j);
/*  268 */       mID(true);
/*  269 */       token3 = this._returnToken;
/*      */       
/*  271 */       String str1 = token3.getText();
/*  272 */       String str2 = this.generator.mapTreeId(str1, this.transInfo);
/*  273 */       if (str2 != null) {
/*  274 */         this.text.setLength(i); this.text.append(str2);
/*      */       } 
/*      */ 
/*      */       
/*  278 */       if (_tokenSet_4.member(LA(1))) {
/*  279 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  286 */       if (LA(1) == '=') {
/*  287 */         mVAR_ASSIGN(false);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  294 */     else if (LA(1) == '#' && LA(2) == '[') {
/*  295 */       int j = this.text.length();
/*  296 */       match('#');
/*  297 */       this.text.setLength(j);
/*  298 */       mAST_CONSTRUCTOR(true);
/*  299 */       token4 = this._returnToken;
/*      */     }
/*  301 */     else if (LA(1) == '#' && LA(2) == '#') {
/*  302 */       match("##");
/*      */       
/*  304 */       String str = this.currentRule.getRuleName() + "_AST"; this.text.setLength(i); this.text.append(str);
/*  305 */       if (this.transInfo != null) {
/*  306 */         this.transInfo.refRuleRoot = str;
/*      */       }
/*      */ 
/*      */       
/*  310 */       if (_tokenSet_4.member(LA(1))) {
/*  311 */         mWS(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  318 */       if (LA(1) == '=') {
/*  319 */         mVAR_ASSIGN(false);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  327 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  330 */     if (paramBoolean && token1 == null && b != -1) {
/*  331 */       token1 = makeToken(b);
/*  332 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  334 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ITEM(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  338 */     Token token1 = null; int i = this.text.length();
/*  339 */     byte b = 7;
/*      */     
/*  341 */     Token token2 = null;
/*  342 */     Token token3 = null;
/*  343 */     Token token4 = null;
/*  344 */     Token token5 = null;
/*  345 */     Token token6 = null;
/*  346 */     Token token7 = null;
/*      */     
/*  348 */     if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'O') {
/*  349 */       match("$FOLLOW");
/*      */       
/*  351 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  353 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  356 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  365 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  369 */         match('(');
/*  370 */         mTEXT_ARG(true);
/*  371 */         token6 = this._returnToken;
/*  372 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  379 */       String str1 = this.currentRule.getRuleName();
/*  380 */       if (token6 != null) {
/*  381 */         str1 = token6.getText();
/*      */       }
/*  383 */       String str2 = this.generator.getFOLLOWBitSet(str1, 1);
/*      */       
/*  385 */       if (str2 == null) {
/*  386 */         reportError("$FOLLOW(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  390 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  394 */     else if (LA(1) == '$' && LA(2) == 'F' && LA(3) == 'I') {
/*  395 */       match("$FIRST");
/*      */       
/*  397 */       if (_tokenSet_5.member(LA(1)) && _tokenSet_6.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */         
/*  399 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  402 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  411 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  415 */         match('(');
/*  416 */         mTEXT_ARG(true);
/*  417 */         token7 = this._returnToken;
/*  418 */         match(')');
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  425 */       String str1 = this.currentRule.getRuleName();
/*  426 */       if (token7 != null) {
/*  427 */         str1 = token7.getText();
/*      */       }
/*  429 */       String str2 = this.generator.getFIRSTBitSet(str1, 1);
/*      */       
/*  431 */       if (str2 == null) {
/*  432 */         reportError("$FIRST(" + str1 + ")" + ": unknown rule or bad lookahead computation");
/*      */       }
/*      */       else {
/*      */         
/*  436 */         this.text.setLength(i); this.text.append(str2);
/*      */       }
/*      */     
/*      */     }
/*  440 */     else if (LA(1) == '$' && LA(2) == 'a') {
/*  441 */       match("$append");
/*      */       
/*  443 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  446 */           mWS(false);
/*      */           break;
/*      */ 
/*      */         
/*      */         case '(':
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/*  455 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  459 */       match('(');
/*  460 */       mTEXT_ARG(true);
/*  461 */       token2 = this._returnToken;
/*  462 */       match(')');
/*      */       
/*  464 */       String str = "text.append(" + token2.getText() + ")";
/*  465 */       this.text.setLength(i); this.text.append(str);
/*      */     
/*      */     }
/*  468 */     else if (LA(1) == '$' && LA(2) == 's') {
/*  469 */       match("$set");
/*      */       
/*  471 */       if (LA(1) == 'T' && LA(2) == 'e') {
/*  472 */         match("Text");
/*      */         
/*  474 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  477 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  486 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  490 */         match('(');
/*  491 */         mTEXT_ARG(true);
/*  492 */         token3 = this._returnToken;
/*  493 */         match(')');
/*      */ 
/*      */         
/*  496 */         String str = "text.setLength(_begin); text.append(" + token3.getText() + ")";
/*  497 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  500 */       else if (LA(1) == 'T' && LA(2) == 'o') {
/*  501 */         match("Token");
/*      */         
/*  503 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  506 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  515 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  519 */         match('(');
/*  520 */         mTEXT_ARG(true);
/*  521 */         token4 = this._returnToken;
/*  522 */         match(')');
/*      */         
/*  524 */         String str = "_token = " + token4.getText();
/*  525 */         this.text.setLength(i); this.text.append(str);
/*      */       
/*      */       }
/*  528 */       else if (LA(1) == 'T' && LA(2) == 'y') {
/*  529 */         match("Type");
/*      */         
/*  531 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*  534 */             mWS(false);
/*      */             break;
/*      */ 
/*      */           
/*      */           case '(':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  543 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/*  547 */         match('(');
/*  548 */         mTEXT_ARG(true);
/*  549 */         token5 = this._returnToken;
/*  550 */         match(')');
/*      */         
/*  552 */         String str = "_ttype = " + token5.getText();
/*  553 */         this.text.setLength(i); this.text.append(str);
/*      */       }
/*      */       else {
/*      */         
/*  557 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  562 */     else if (LA(1) == '$' && LA(2) == 'g') {
/*  563 */       match("$getText");
/*      */       
/*  565 */       this.text.setLength(i); this.text.append("new String(text.getBuffer(),_begin,text.length()-_begin)");
/*      */     }
/*      */     else {
/*      */       
/*  569 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  572 */     if (paramBoolean && token1 == null && b != -1) {
/*  573 */       token1 = makeToken(b);
/*  574 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  576 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mCOMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  580 */     Token token = null; int i = this.text.length();
/*  581 */     byte b = 19;
/*      */ 
/*      */     
/*  584 */     if (LA(1) == '/' && LA(2) == '/') {
/*  585 */       mSL_COMMENT(false);
/*      */     }
/*  587 */     else if (LA(1) == '/' && LA(2) == '*') {
/*  588 */       mML_COMMENT(false);
/*      */     } else {
/*      */       
/*  591 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/*  594 */     if (paramBoolean && token == null && b != -1) {
/*  595 */       token = makeToken(b);
/*  596 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  598 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSTRING(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  602 */     Token token = null; int i = this.text.length();
/*  603 */     byte b = 23;
/*      */ 
/*      */     
/*  606 */     match('"');
/*      */ 
/*      */     
/*      */     while (true) {
/*  610 */       while (LA(1) == '\\') {
/*  611 */         mESC(false);
/*      */       }
/*  613 */       if (_tokenSet_7.member(LA(1))) {
/*  614 */         matchNot('"');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/*  622 */     match('"');
/*  623 */     if (paramBoolean && token == null && b != -1) {
/*  624 */       token = makeToken(b);
/*  625 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  627 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mCHAR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  631 */     Token token = null; int i = this.text.length();
/*  632 */     byte b = 22;
/*      */ 
/*      */     
/*  635 */     match('\'');
/*      */     
/*  637 */     if (LA(1) == '\\') {
/*  638 */       mESC(false);
/*      */     }
/*  640 */     else if (_tokenSet_8.member(LA(1))) {
/*  641 */       matchNot('\'');
/*      */     } else {
/*      */       
/*  644 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/*  648 */     match('\'');
/*  649 */     if (paramBoolean && token == null && b != -1) {
/*  650 */       token = makeToken(b);
/*  651 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  653 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  657 */     Token token1 = null; int i = this.text.length();
/*  658 */     byte b = 8;
/*      */     
/*  660 */     Token token2 = null;
/*  661 */     Token token3 = null;
/*      */     
/*  663 */     StringBuffer stringBuffer = new StringBuffer();
/*  664 */     boolean bool = false;
/*  665 */     Vector vector = new Vector(10);
/*      */ 
/*      */     
/*  668 */     int j = this.text.length();
/*  669 */     match('(');
/*  670 */     this.text.setLength(j);
/*      */     
/*  672 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  675 */         j = this.text.length();
/*  676 */         mWS(false);
/*  677 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/*  700 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/*  704 */     j = this.text.length();
/*  705 */     mTREE_ELEMENT(true);
/*  706 */     this.text.setLength(j);
/*  707 */     token2 = this._returnToken;
/*  708 */     vector.appendElement(token2.getText());
/*      */     
/*  710 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  713 */         j = this.text.length();
/*  714 */         mWS(false);
/*  715 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ')':
/*      */       case ',':
/*      */         break;
/*      */       
/*      */       default:
/*  724 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  731 */     while (LA(1) == ',') {
/*  732 */       j = this.text.length();
/*  733 */       match(',');
/*  734 */       this.text.setLength(j);
/*      */       
/*  736 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  739 */           j = this.text.length();
/*  740 */           mWS(false);
/*  741 */           this.text.setLength(j); break;
/*      */         case '"': case '#': case '(': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/*  764 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/*  768 */       j = this.text.length();
/*  769 */       mTREE_ELEMENT(true);
/*  770 */       this.text.setLength(j);
/*  771 */       token3 = this._returnToken;
/*  772 */       vector.appendElement(token3.getText());
/*      */       
/*  774 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/*  777 */           j = this.text.length();
/*  778 */           mWS(false);
/*  779 */           this.text.setLength(j);
/*      */           continue;
/*      */ 
/*      */         
/*      */         case ')':
/*      */         case ',':
/*      */           continue; }
/*      */ 
/*      */       
/*  788 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  799 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(vector));
/*  800 */     j = this.text.length();
/*  801 */     match(')');
/*  802 */     this.text.setLength(j);
/*  803 */     if (paramBoolean && token1 == null && b != -1) {
/*  804 */       token1 = makeToken(b);
/*  805 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  807 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mID(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  811 */     Token token = null; int i = this.text.length();
/*  812 */     byte b = 17;
/*      */ 
/*      */ 
/*      */     
/*  816 */     switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*  825 */         matchRange('a', 'z'); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */       case 'R':
/*      */       case 'S':
/*      */       case 'T':
/*      */       case 'U':
/*      */       case 'V':
/*      */       case 'W':
/*      */       case 'X':
/*      */       case 'Y':
/*      */       case 'Z':
/*  836 */         matchRange('A', 'Z');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '_':
/*  841 */         match('_');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/*  846 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  853 */     while (_tokenSet_9.member(LA(1))) {
/*      */       
/*  855 */       switch (LA(1)) { case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': case 'n': case 'o': case 'p': case 'q': case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*  864 */           matchRange('a', 'z'); continue;
/*      */         case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q':
/*      */         case 'R':
/*      */         case 'S':
/*      */         case 'T':
/*      */         case 'U':
/*      */         case 'V':
/*      */         case 'W':
/*      */         case 'X':
/*      */         case 'Y':
/*      */         case 'Z':
/*  875 */           matchRange('A', 'Z'); continue;
/*      */         case '0': case '1': case '2': case '3': case '4':
/*      */         case '5':
/*      */         case '6':
/*      */         case '7':
/*      */         case '8':
/*      */         case '9':
/*  882 */           matchRange('0', '9');
/*      */           continue;
/*      */ 
/*      */         
/*      */         case '_':
/*  887 */           match('_');
/*      */           continue; }
/*      */ 
/*      */ 
/*      */       
/*  892 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  903 */     if (paramBoolean && token == null && b != -1) {
/*  904 */       token = makeToken(b);
/*  905 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  907 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mWS(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  911 */     Token token = null; int i = this.text.length();
/*  912 */     byte b1 = 28;
/*      */ 
/*      */ 
/*      */     
/*  916 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/*  919 */       if (LA(1) == '\r' && LA(2) == '\n') {
/*  920 */         match('\r');
/*  921 */         match('\n');
/*  922 */         newline();
/*      */       }
/*  924 */       else if (LA(1) == ' ') {
/*  925 */         match(' ');
/*      */       }
/*  927 */       else if (LA(1) == '\t') {
/*  928 */         match('\t');
/*      */       }
/*  930 */       else if (LA(1) == '\r') {
/*  931 */         match('\r');
/*  932 */         newline();
/*      */       }
/*  934 */       else if (LA(1) == '\n') {
/*  935 */         match('\n');
/*  936 */         newline();
/*      */       } else {
/*      */         
/*  939 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/*  942 */       b2++;
/*      */     } 
/*      */     
/*  945 */     if (paramBoolean && token == null && b1 != -1) {
/*  946 */       token = makeToken(b1);
/*  947 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  949 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mVAR_ASSIGN(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  953 */     Token token = null; int i = this.text.length();
/*  954 */     byte b = 18;
/*      */ 
/*      */     
/*  957 */     match('=');
/*      */ 
/*      */ 
/*      */     
/*  961 */     if (LA(1) != '=' && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/*  962 */       this.transInfo.assignToRoot = true;
/*      */     }
/*      */     
/*  965 */     if (paramBoolean && token == null && b != -1) {
/*  966 */       token = makeToken(b);
/*  967 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/*  969 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mAST_CONSTRUCTOR(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*  973 */     Token token1 = null; int i = this.text.length();
/*  974 */     byte b = 10;
/*      */     
/*  976 */     Token token2 = null;
/*  977 */     Token token3 = null;
/*  978 */     Token token4 = null;
/*      */     
/*  980 */     int j = this.text.length();
/*  981 */     match('[');
/*  982 */     this.text.setLength(j);
/*      */     
/*  984 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  987 */         j = this.text.length();
/*  988 */         mWS(false);
/*  989 */         this.text.setLength(j); break;
/*      */       case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1014 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */     
/* 1018 */     j = this.text.length();
/* 1019 */     mAST_CTOR_ELEMENT(true);
/* 1020 */     this.text.setLength(j);
/* 1021 */     token2 = this._returnToken;
/*      */     
/* 1023 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1026 */         j = this.text.length();
/* 1027 */         mWS(false);
/* 1028 */         this.text.setLength(j);
/*      */         break;
/*      */ 
/*      */       
/*      */       case ',':
/*      */       case ']':
/*      */         break;
/*      */       
/*      */       default:
/* 1037 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1042 */     if (LA(1) == ',' && _tokenSet_10.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1043 */       j = this.text.length();
/* 1044 */       match(',');
/* 1045 */       this.text.setLength(j);
/*      */       
/* 1047 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1050 */           j = this.text.length();
/* 1051 */           mWS(false);
/* 1052 */           this.text.setLength(j); break;
/*      */         case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */         case 'f':
/*      */         case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/* 1077 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/* 1081 */       j = this.text.length();
/* 1082 */       mAST_CTOR_ELEMENT(true);
/* 1083 */       this.text.setLength(j);
/* 1084 */       token3 = this._returnToken;
/*      */       
/* 1086 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1089 */           j = this.text.length();
/* 1090 */           mWS(false);
/* 1091 */           this.text.setLength(j);
/*      */           break;
/*      */ 
/*      */         
/*      */         case ',':
/*      */         case ']':
/*      */           break;
/*      */         
/*      */         default:
/* 1100 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1105 */     } else if (LA(1) != ',' && LA(1) != ']') {
/*      */ 
/*      */       
/* 1108 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1113 */     switch (LA(1)) {
/*      */       
/*      */       case ',':
/* 1116 */         j = this.text.length();
/* 1117 */         match(',');
/* 1118 */         this.text.setLength(j);
/*      */         
/* 1120 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1123 */             j = this.text.length();
/* 1124 */             mWS(false);
/* 1125 */             this.text.setLength(j); break;
/*      */           case '"': case '#': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */           case 'f':
/*      */           case 'g':
/*      */           case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/*      */             break;
/*      */           default:
/* 1150 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1154 */         j = this.text.length();
/* 1155 */         mAST_CTOR_ELEMENT(true);
/* 1156 */         this.text.setLength(j);
/* 1157 */         token4 = this._returnToken;
/*      */         
/* 1159 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1162 */             j = this.text.length();
/* 1163 */             mWS(false);
/* 1164 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ']':
/*      */             break; }
/*      */ 
/*      */ 
/*      */         
/* 1173 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case ']':
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1185 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1189 */     j = this.text.length();
/* 1190 */     match(']');
/* 1191 */     this.text.setLength(j);
/*      */     
/* 1193 */     String str = token2.getText();
/* 1194 */     if (token3 != null) {
/* 1195 */       str = str + "," + token3.getText();
/*      */     }
/* 1197 */     if (token4 != null) {
/* 1198 */       str = str + "," + token4.getText();
/*      */     }
/* 1200 */     this.text.setLength(i); this.text.append(this.generator.getASTCreateString(null, str));
/*      */     
/* 1202 */     if (paramBoolean && token1 == null && b != -1) {
/* 1203 */       token1 = makeToken(b);
/* 1204 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1206 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1210 */     Token token = null; int i = this.text.length();
/* 1211 */     byte b1 = 13;
/*      */ 
/*      */ 
/*      */     
/* 1215 */     switch (LA(1)) { case '\t': case '\n':
/*      */       case '\r':
/*      */       case ' ':
/* 1218 */         mWS(false); break;
/*      */       case '"': case '$': case '\'': case '+': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 1243 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1248 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1251 */       if (_tokenSet_11.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1252 */         mTEXT_ARG_ELEMENT(false);
/*      */         
/* 1254 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_12.member(LA(2))) {
/* 1255 */           mWS(false);
/*      */         }
/* 1257 */         else if (!_tokenSet_12.member(LA(1))) {
/*      */ 
/*      */           
/* 1260 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1266 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1269 */       b2++;
/*      */     } 
/*      */     
/* 1272 */     if (paramBoolean && token == null && b1 != -1) {
/* 1273 */       token = makeToken(b1);
/* 1274 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1276 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTREE_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1280 */     Token token1 = null; int i = this.text.length();
/* 1281 */     byte b = 9;
/*      */     
/* 1283 */     Token token2 = null;
/*      */ 
/*      */     
/* 1286 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1289 */         mTREE(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '[':
/* 1294 */         mAST_CONSTRUCTOR(false); break;
/*      */       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1312 */         mID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1317 */         mSTRING(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1321 */         if (LA(1) == '#' && LA(2) == '(') {
/* 1322 */           int j = this.text.length();
/* 1323 */           match('#');
/* 1324 */           this.text.setLength(j);
/* 1325 */           mTREE(false); break;
/*      */         } 
/* 1327 */         if (LA(1) == '#' && LA(2) == '[') {
/* 1328 */           int j = this.text.length();
/* 1329 */           match('#');
/* 1330 */           this.text.setLength(j);
/* 1331 */           mAST_CONSTRUCTOR(false); break;
/*      */         } 
/* 1333 */         if (LA(1) == '#' && _tokenSet_3.member(LA(2))) {
/* 1334 */           int j = this.text.length();
/* 1335 */           match('#');
/* 1336 */           this.text.setLength(j);
/* 1337 */           boolean bool = mID_ELEMENT(true);
/* 1338 */           token2 = this._returnToken;
/*      */           
/* 1340 */           if (!bool) {
/*      */             
/* 1342 */             String str = this.generator.mapTreeId(token2.getText(), null);
/* 1343 */             this.text.setLength(i); this.text.append(str);
/*      */           } 
/*      */           break;
/*      */         } 
/* 1347 */         if (LA(1) == '#' && LA(2) == '#') {
/* 1348 */           match("##");
/* 1349 */           String str = this.currentRule.getRuleName() + "_AST"; this.text.setLength(i); this.text.append(str);
/*      */           break;
/*      */         } 
/* 1352 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1355 */     if (paramBoolean && token1 == null && b != -1) {
/* 1356 */       token1 = makeToken(b);
/* 1357 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1359 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final boolean mID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/*      */     String str;
/* 1366 */     boolean bool = false;
/* 1367 */     Token token1 = null; int i = this.text.length();
/* 1368 */     byte b1 = 12;
/*      */     
/* 1370 */     Token token2 = null;
/*      */     
/* 1372 */     mID(true);
/* 1373 */     token2 = this._returnToken;
/*      */     
/* 1375 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_13.member(LA(2))) {
/* 1376 */       int k = this.text.length();
/* 1377 */       mWS(false);
/* 1378 */       this.text.setLength(k);
/*      */     }
/* 1380 */     else if (!_tokenSet_13.member(LA(1))) {
/*      */ 
/*      */       
/* 1383 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1388 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1391 */         match('(');
/*      */         
/* 1393 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_14.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1394 */           int k = this.text.length();
/* 1395 */           mWS(false);
/* 1396 */           this.text.setLength(k);
/*      */         }
/* 1398 */         else if (!_tokenSet_14.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 1401 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1406 */         switch (LA(1)) { case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h':
/*      */           case 'i':
/*      */           case 'j':
/*      */           case 'k':
/*      */           case 'l':
/*      */           case 'm':
/*      */           case 'n':
/*      */           case 'o':
/*      */           case 'p':
/*      */           case 'q':
/*      */           case 'r':
/*      */           case 's':
/*      */           case 't':
/*      */           case 'u':
/*      */           case 'v':
/*      */           case 'w':
/*      */           case 'x':
/*      */           case 'y':
/*      */           case 'z':
/* 1425 */             mARG(false);
/*      */ 
/*      */ 
/*      */             
/* 1429 */             while (LA(1) == ',') {
/* 1430 */               int k; match(',');
/*      */               
/* 1432 */               switch (LA(1)) { case '\t': case '\n':
/*      */                 case '\r':
/*      */                 case ' ':
/* 1435 */                   k = this.text.length();
/* 1436 */                   mWS(false);
/* 1437 */                   this.text.setLength(k); break;
/*      */                 case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */                 case 'f':
/*      */                 case 'g':
/*      */                 case 'h':
/*      */                 case 'i':
/*      */                 case 'j':
/*      */                 case 'k':
/*      */                 case 'l':
/*      */                 case 'm':
/*      */                 case 'n':
/*      */                 case 'o':
/*      */                 case 'p':
/*      */                 case 'q':
/*      */                 case 'r':
/*      */                 case 's':
/*      */                 case 't':
/*      */                 case 'u':
/*      */                 case 'v':
/*      */                 case 'w':
/*      */                 case 'x':
/*      */                 case 'y':
/*      */                 case 'z':
/*      */                   break;
/*      */                 default:
/* 1462 */                   throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */               
/* 1466 */               mARG(false);
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case '\t':
/*      */           case '\n':
/*      */           case '\r':
/*      */           case ' ':
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 1483 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1488 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1491 */             j = this.text.length();
/* 1492 */             mWS(false);
/* 1493 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1502 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1506 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 1512 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 1515 */           if (LA(1) == '[') {
/* 1516 */             match('[');
/*      */             
/* 1518 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1521 */                 j = this.text.length();
/* 1522 */                 mWS(false);
/* 1523 */                 this.text.setLength(j); break;
/*      */               case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */               case 'f':
/*      */               case 'g':
/*      */               case 'h':
/*      */               case 'i':
/*      */               case 'j':
/*      */               case 'k':
/*      */               case 'l':
/*      */               case 'm':
/*      */               case 'n':
/*      */               case 'o':
/*      */               case 'p':
/*      */               case 'q':
/*      */               case 'r':
/*      */               case 's':
/*      */               case 't':
/*      */               case 'u':
/*      */               case 'v':
/*      */               case 'w':
/*      */               case 'x':
/*      */               case 'y':
/*      */               case 'z':
/*      */                 break;
/*      */               default:
/* 1548 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1552 */             mARG(false);
/*      */             
/* 1554 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1557 */                 j = this.text.length();
/* 1558 */                 mWS(false);
/* 1559 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 1568 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 1572 */             match(']');
/*      */           } else {
/*      */             
/* 1575 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 1578 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 1585 */         match('.');
/* 1586 */         mID_ELEMENT(false); break;
/*      */       case '\t': case '\n': case '\r': case ' ': case ')': case '*':
/*      */       case '+':
/*      */       case ',':
/*      */       case '-':
/*      */       case '/':
/*      */       case '=':
/*      */       case ']':
/* 1594 */         bool = true;
/* 1595 */         str = this.generator.mapTreeId(token2.getText(), this.transInfo);
/* 1596 */         this.text.setLength(i); this.text.append(str);
/*      */ 
/*      */         
/* 1599 */         if (_tokenSet_15.member(LA(1)) && _tokenSet_16.member(LA(2)) && this.transInfo != null && this.transInfo.refRuleRoot != null) {
/*      */           
/* 1601 */           switch (LA(1)) { case '\t': case '\n':
/*      */             case '\r':
/*      */             case ' ':
/* 1604 */               mWS(false);
/*      */               break;
/*      */ 
/*      */             
/*      */             case '=':
/*      */               break;
/*      */ 
/*      */             
/*      */             default:
/* 1613 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */           
/* 1617 */           mVAR_ASSIGN(false); break;
/*      */         } 
/* 1619 */         if (_tokenSet_17.member(LA(1))) {
/*      */           break;
/*      */         }
/* 1622 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 1630 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 1634 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 1635 */       token1 = makeToken(b1);
/* 1636 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1638 */     this._returnToken = token1;
/* 1639 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void mAST_CTOR_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1646 */     Token token = null; int i = this.text.length();
/* 1647 */     byte b = 11;
/*      */ 
/*      */     
/* 1650 */     if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1651 */       mSTRING(false);
/*      */     }
/* 1653 */     else if (_tokenSet_18.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 1654 */       mTREE_ELEMENT(false);
/*      */     }
/* 1656 */     else if (LA(1) >= '0' && LA(1) <= '9') {
/* 1657 */       mINT(false);
/*      */     } else {
/*      */       
/* 1660 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */     
/* 1663 */     if (paramBoolean && token == null && b != -1) {
/* 1664 */       token = makeToken(b);
/* 1665 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1667 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mINT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1671 */     Token token = null; int i = this.text.length();
/* 1672 */     byte b1 = 26;
/*      */ 
/*      */ 
/*      */     
/* 1676 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 1679 */       if (LA(1) >= '0' && LA(1) <= '9') {
/* 1680 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 1683 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 1686 */       b2++;
/*      */     } 
/*      */     
/* 1689 */     if (paramBoolean && token == null && b1 != -1) {
/* 1690 */       token = makeToken(b1);
/* 1691 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1693 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mARG(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1697 */     Token token = null; int i = this.text.length();
/* 1698 */     byte b = 16;
/*      */ 
/*      */ 
/*      */     
/* 1702 */     switch (LA(1)) {
/*      */       
/*      */       case '\'':
/* 1705 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1712 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */       
/*      */       default:
/* 1716 */         if (_tokenSet_18.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1717 */           mTREE_ELEMENT(false); break;
/*      */         } 
/* 1719 */         if (LA(1) == '"' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1720 */           mSTRING(false);
/*      */           break;
/*      */         } 
/* 1723 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1730 */     while (_tokenSet_19.member(LA(1)) && _tokenSet_20.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/*      */       
/* 1732 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1735 */           mWS(false);
/*      */           break;
/*      */         
/*      */         case '*':
/*      */         case '+':
/*      */         case '-':
/*      */         case '/':
/*      */           break;
/*      */         default:
/* 1744 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1749 */       switch (LA(1)) {
/*      */         
/*      */         case '+':
/* 1752 */           match('+');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '-':
/* 1757 */           match('-');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '*':
/* 1762 */           match('*');
/*      */           break;
/*      */ 
/*      */         
/*      */         case '/':
/* 1767 */           match('/');
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1772 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1777 */       switch (LA(1)) { case '\t': case '\n':
/*      */         case '\r':
/*      */         case ' ':
/* 1780 */           mWS(false); break;
/*      */         case '"': case '#': case '\'': case '(': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '[': case '_': case 'a': case 'b': case 'c': case 'd': case 'e':
/*      */         case 'f':
/*      */         case 'g':
/*      */         case 'h':
/*      */         case 'i':
/*      */         case 'j':
/*      */         case 'k':
/*      */         case 'l':
/*      */         case 'm':
/*      */         case 'n':
/*      */         case 'o':
/*      */         case 'p':
/*      */         case 'q':
/*      */         case 'r':
/*      */         case 's':
/*      */         case 't':
/*      */         case 'u':
/*      */         case 'v':
/*      */         case 'w':
/*      */         case 'x':
/*      */         case 'y':
/*      */         case 'z':
/*      */           break;
/*      */         default:
/* 1805 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */       
/* 1809 */       mARG(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1817 */     if (paramBoolean && token == null && b != -1) {
/* 1818 */       token = makeToken(b);
/* 1819 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1821 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mTEXT_ARG_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 1825 */     Token token = null; int i = this.text.length();
/* 1826 */     byte b = 14;
/*      */ 
/*      */     
/* 1829 */     switch (LA(1)) { case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case '_': case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': case 'h': case 'i': case 'j': case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/* 1845 */         mTEXT_ARG_ID_ELEMENT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 1850 */         mSTRING(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 1855 */         mCHAR(false); break;
/*      */       case '0': case '1': case '2': case '3': case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/*      */       case '8':
/*      */       case '9':
/* 1862 */         mINT_OR_FLOAT(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '$':
/* 1867 */         mTEXT_ITEM(false);
/*      */         break;
/*      */ 
/*      */       
/*      */       case '+':
/* 1872 */         match('+');
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 1877 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */     
/* 1880 */     if (paramBoolean && token == null && b != -1) {
/* 1881 */       token = makeToken(b);
/* 1882 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 1884 */     this._returnToken = token;
/*      */   } protected final void mTEXT_ARG_ID_ELEMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/*      */     int j;
/*      */     byte b2;
/* 1888 */     Token token1 = null; int i = this.text.length();
/* 1889 */     byte b1 = 15;
/*      */     
/* 1891 */     Token token2 = null;
/*      */     
/* 1893 */     mID(true);
/* 1894 */     token2 = this._returnToken;
/*      */     
/* 1896 */     if (_tokenSet_4.member(LA(1)) && _tokenSet_21.member(LA(2))) {
/* 1897 */       int k = this.text.length();
/* 1898 */       mWS(false);
/* 1899 */       this.text.setLength(k);
/*      */     }
/* 1901 */     else if (!_tokenSet_21.member(LA(1))) {
/*      */ 
/*      */       
/* 1904 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1909 */     switch (LA(1)) {
/*      */       
/*      */       case '(':
/* 1912 */         match('(');
/*      */         
/* 1914 */         if (_tokenSet_4.member(LA(1)) && _tokenSet_22.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1915 */           int k = this.text.length();
/* 1916 */           mWS(false);
/* 1917 */           this.text.setLength(k);
/*      */         }
/* 1919 */         else if (!_tokenSet_22.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ') {
/*      */ 
/*      */           
/* 1922 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1929 */         while (_tokenSet_23.member(LA(1)) && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1930 */           mTEXT_ARG(false);
/*      */ 
/*      */ 
/*      */           
/* 1934 */           while (LA(1) == ',') {
/* 1935 */             match(',');
/* 1936 */             mTEXT_ARG(false);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1952 */         switch (LA(1)) { case '\t': case '\n':
/*      */           case '\r':
/*      */           case ' ':
/* 1955 */             j = this.text.length();
/* 1956 */             mWS(false);
/* 1957 */             this.text.setLength(j);
/*      */             break;
/*      */ 
/*      */           
/*      */           case ')':
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 1966 */             throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */         
/* 1970 */         match(')');
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '[':
/* 1976 */         b2 = 0;
/*      */         
/*      */         while (true) {
/* 1979 */           if (LA(1) == '[') {
/* 1980 */             match('[');
/*      */             
/* 1982 */             if (_tokenSet_4.member(LA(1)) && _tokenSet_23.member(LA(2)) && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 1983 */               j = this.text.length();
/* 1984 */               mWS(false);
/* 1985 */               this.text.setLength(j);
/*      */             }
/* 1987 */             else if (!_tokenSet_23.member(LA(1)) || LA(2) < '\003' || LA(2) > 'ÿ' || LA(3) < '\003' || LA(3) > 'ÿ') {
/*      */ 
/*      */               
/* 1990 */               throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */             } 
/*      */ 
/*      */             
/* 1994 */             mTEXT_ARG(false);
/*      */             
/* 1996 */             switch (LA(1)) { case '\t': case '\n':
/*      */               case '\r':
/*      */               case ' ':
/* 1999 */                 j = this.text.length();
/* 2000 */                 mWS(false);
/* 2001 */                 this.text.setLength(j);
/*      */                 break;
/*      */ 
/*      */               
/*      */               case ']':
/*      */                 break;
/*      */ 
/*      */               
/*      */               default:
/* 2010 */                 throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn()); }
/*      */ 
/*      */ 
/*      */             
/* 2014 */             match(']');
/*      */           } else {
/*      */             
/* 2017 */             if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */           } 
/*      */           
/* 2020 */           b2++;
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case '.':
/* 2027 */         match('.');
/* 2028 */         mTEXT_ARG_ID_ELEMENT(false); break;
/*      */       case '\t': case '\n': case '\r': case ' ': case '"': case '$': case '\'': case ')': case '+': case ',': case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9': case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': case 'W': case 'X': case 'Y': case 'Z': case ']': case '_': case 'a': case 'b': case 'c':
/*      */       case 'd':
/*      */       case 'e':
/*      */       case 'f':
/*      */       case 'g':
/*      */       case 'h':
/*      */       case 'i':
/*      */       case 'j':
/*      */       case 'k':
/*      */       case 'l':
/*      */       case 'm':
/*      */       case 'n':
/*      */       case 'o':
/*      */       case 'p':
/*      */       case 'q':
/*      */       case 'r':
/*      */       case 's':
/*      */       case 't':
/*      */       case 'u':
/*      */       case 'v':
/*      */       case 'w':
/*      */       case 'x':
/*      */       case 'y':
/*      */       case 'z':
/*      */         break;
/*      */       default:
/* 2055 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2059 */     if (paramBoolean && token1 == null && b1 != -1) {
/* 2060 */       token1 = makeToken(b1);
/* 2061 */       token1.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2063 */     this._returnToken = token1;
/*      */   }
/*      */   
/*      */   protected final void mINT_OR_FLOAT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2067 */     Token token = null; int i = this.text.length();
/* 2068 */     byte b1 = 27;
/*      */ 
/*      */ 
/*      */     
/* 2072 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 2075 */       if (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_24.member(LA(2))) {
/* 2076 */         mDIGIT(false);
/*      */       } else {
/*      */         
/* 2079 */         if (b2 >= 1) break;  throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */       } 
/*      */       
/* 2082 */       b2++;
/*      */     } 
/*      */ 
/*      */     
/* 2086 */     if (LA(1) == 'L' && _tokenSet_25.member(LA(2))) {
/* 2087 */       match('L');
/*      */     }
/* 2089 */     else if (LA(1) == 'l' && _tokenSet_25.member(LA(2))) {
/* 2090 */       match('l');
/*      */     }
/* 2092 */     else if (LA(1) == '.') {
/* 2093 */       match('.');
/*      */ 
/*      */ 
/*      */       
/* 2097 */       while (LA(1) >= '0' && LA(1) <= '9' && _tokenSet_25.member(LA(2))) {
/* 2098 */         mDIGIT(false);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2107 */     else if (!_tokenSet_25.member(LA(1))) {
/*      */ 
/*      */       
/* 2110 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2114 */     if (paramBoolean && token == null && b1 != -1) {
/* 2115 */       token = makeToken(b1);
/* 2116 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2118 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mSL_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2122 */     Token token = null; int i = this.text.length();
/* 2123 */     byte b = 20;
/*      */ 
/*      */     
/* 2126 */     match("//");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2131 */     while (LA(1) != '\n' && LA(1) != '\r' && 
/* 2132 */       LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2133 */       matchNot('￿');
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2142 */     if (LA(1) == '\r' && LA(2) == '\n') {
/* 2143 */       match("\r\n");
/*      */     }
/* 2145 */     else if (LA(1) == '\n') {
/* 2146 */       match('\n');
/*      */     }
/* 2148 */     else if (LA(1) == '\r') {
/* 2149 */       match('\r');
/*      */     } else {
/*      */       
/* 2152 */       throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2156 */     newline();
/* 2157 */     if (paramBoolean && token == null && b != -1) {
/* 2158 */       token = makeToken(b);
/* 2159 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2161 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mML_COMMENT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2165 */     Token token = null; int i = this.text.length();
/* 2166 */     byte b = 21;
/*      */ 
/*      */     
/* 2169 */     match("/*");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2174 */     while (LA(1) != '*' || LA(2) != '/') {
/* 2175 */       if (LA(1) == '\r' && LA(2) == '\n' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2176 */         match('\r');
/* 2177 */         match('\n');
/* 2178 */         newline(); continue;
/*      */       } 
/* 2180 */       if (LA(1) == '\r' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2181 */         match('\r');
/* 2182 */         newline(); continue;
/*      */       } 
/* 2184 */       if (LA(1) == '\n' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2185 */         match('\n');
/* 2186 */         newline(); continue;
/*      */       } 
/* 2188 */       if (LA(1) >= '\003' && LA(1) <= 'ÿ' && LA(2) >= '\003' && LA(2) <= 'ÿ' && LA(3) >= '\003' && LA(3) <= 'ÿ') {
/* 2189 */         matchNot('￿');
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*      */       break;
/*      */     } 
/*      */     
/* 2197 */     match("*/");
/* 2198 */     if (paramBoolean && token == null && b != -1) {
/* 2199 */       token = makeToken(b);
/* 2200 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2202 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mESC(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2206 */     Token token = null; int i = this.text.length();
/* 2207 */     byte b = 24;
/*      */ 
/*      */     
/* 2210 */     match('\\');
/*      */     
/* 2212 */     switch (LA(1)) {
/*      */       
/*      */       case 'n':
/* 2215 */         match('n');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'r':
/* 2220 */         match('r');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 't':
/* 2225 */         match('t');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'b':
/* 2230 */         match('b');
/*      */         break;
/*      */ 
/*      */       
/*      */       case 'f':
/* 2235 */         match('f');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '"':
/* 2240 */         match('"');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\'':
/* 2245 */         match('\'');
/*      */         break;
/*      */ 
/*      */       
/*      */       case '\\':
/* 2250 */         match('\\');
/*      */         break;
/*      */       case '0':
/*      */       case '1':
/*      */       case '2':
/*      */       case '3':
/* 2256 */         matchRange('0', '3');
/*      */ 
/*      */         
/* 2259 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2260 */           mDIGIT(false);
/*      */           
/* 2262 */           if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2263 */             mDIGIT(false); break;
/*      */           } 
/* 2265 */           if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */             break;
/*      */           }
/* 2268 */           throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2273 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2276 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case '4':
/*      */       case '5':
/*      */       case '6':
/*      */       case '7':
/* 2285 */         matchRange('4', '7');
/*      */ 
/*      */         
/* 2288 */         if (LA(1) >= '0' && LA(1) <= '9' && LA(2) >= '\003' && LA(2) <= 'ÿ') {
/* 2289 */           mDIGIT(false); break;
/*      */         } 
/* 2291 */         if (LA(1) >= '\003' && LA(1) <= 'ÿ') {
/*      */           break;
/*      */         }
/* 2294 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 2302 */         throw new NoViableAltForCharException(LA(1), getFilename(), getLine(), getColumn());
/*      */     } 
/*      */ 
/*      */     
/* 2306 */     if (paramBoolean && token == null && b != -1) {
/* 2307 */       token = makeToken(b);
/* 2308 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2310 */     this._returnToken = token;
/*      */   }
/*      */   
/*      */   protected final void mDIGIT(boolean paramBoolean) throws RecognitionException, CharStreamException, TokenStreamException {
/* 2314 */     Token token = null; int i = this.text.length();
/* 2315 */     byte b = 25;
/*      */ 
/*      */     
/* 2318 */     matchRange('0', '9');
/* 2319 */     if (paramBoolean && token == null && b != -1) {
/* 2320 */       token = makeToken(b);
/* 2321 */       token.setText(new String(this.text.getBuffer(), i, this.text.length() - i));
/*      */     } 
/* 2323 */     this._returnToken = token;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final long[] mk_tokenSet_0() {
/* 2328 */     long[] arrayOfLong = new long[8];
/* 2329 */     arrayOfLong[0] = -103079215112L;
/* 2330 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2331 */      return arrayOfLong;
/*      */   }
/* 2333 */   public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
/*      */   private static final long[] mk_tokenSet_1() {
/* 2335 */     long[] arrayOfLong = new long[8];
/* 2336 */     arrayOfLong[0] = -145135534866440L;
/* 2337 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2338 */      return arrayOfLong;
/*      */   }
/* 2340 */   public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
/*      */   private static final long[] mk_tokenSet_2() {
/* 2342 */     long[] arrayOfLong = new long[8];
/* 2343 */     arrayOfLong[0] = -141407503262728L;
/* 2344 */     for (byte b = 1; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2345 */      return arrayOfLong;
/*      */   }
/* 2347 */   public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
/*      */   private static final long[] mk_tokenSet_3() {
/* 2349 */     return new long[] { 0L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2352 */   public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
/*      */   private static final long[] mk_tokenSet_4() {
/* 2354 */     return new long[] { 4294977024L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2357 */   public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
/*      */   private static final long[] mk_tokenSet_5() {
/* 2359 */     return new long[] { 1103806604800L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2362 */   public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
/*      */   private static final long[] mk_tokenSet_6() {
/* 2364 */     return new long[] { 287959436729787904L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2367 */   public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
/*      */   private static final long[] mk_tokenSet_7() {
/* 2369 */     long[] arrayOfLong = new long[8];
/* 2370 */     arrayOfLong[0] = -17179869192L;
/* 2371 */     arrayOfLong[1] = -268435457L;
/* 2372 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2373 */      return arrayOfLong;
/*      */   }
/* 2375 */   public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
/*      */   private static final long[] mk_tokenSet_8() {
/* 2377 */     long[] arrayOfLong = new long[8];
/* 2378 */     arrayOfLong[0] = -549755813896L;
/* 2379 */     arrayOfLong[1] = -268435457L;
/* 2380 */     for (byte b = 2; b <= 3; ) { arrayOfLong[b] = -1L; b++; }
/* 2381 */      return arrayOfLong;
/*      */   }
/* 2383 */   public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
/*      */   private static final long[] mk_tokenSet_9() {
/* 2385 */     return new long[] { 287948901175001088L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2388 */   public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
/*      */   private static final long[] mk_tokenSet_10() {
/* 2390 */     return new long[] { 287950056521213440L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2393 */   public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
/*      */   private static final long[] mk_tokenSet_11() {
/* 2395 */     return new long[] { 287958332923183104L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2398 */   public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
/*      */   private static final long[] mk_tokenSet_12() {
/* 2400 */     return new long[] { 287978128427460096L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2403 */   public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
/*      */   private static final long[] mk_tokenSet_13() {
/* 2405 */     return new long[] { 2306123388973753856L, 671088640L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2408 */   public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
/*      */   private static final long[] mk_tokenSet_14() {
/* 2410 */     return new long[] { 287952805300282880L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2413 */   public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
/*      */   private static final long[] mk_tokenSet_15() {
/* 2415 */     return new long[] { 2305843013508670976L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2418 */   public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
/*      */   private static final long[] mk_tokenSet_16() {
/* 2420 */     return new long[] { 2306051920717948416L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2423 */   public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
/*      */   private static final long[] mk_tokenSet_17() {
/* 2425 */     return new long[] { 208911504254464L, 536870912L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2428 */   public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
/*      */   private static final long[] mk_tokenSet_18() {
/* 2430 */     return new long[] { 1151051235328L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2433 */   public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
/*      */   private static final long[] mk_tokenSet_19() {
/* 2435 */     return new long[] { 189120294954496L, 0L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2438 */   public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
/*      */   private static final long[] mk_tokenSet_20() {
/* 2440 */     return new long[] { 288139722277004800L, 576460746129407998L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2443 */   public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
/*      */   private static final long[] mk_tokenSet_21() {
/* 2445 */     return new long[] { 288049596683265536L, 576460746666278910L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2448 */   public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
/*      */   private static final long[] mk_tokenSet_22() {
/* 2450 */     return new long[] { 287960536241415680L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2453 */   public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
/*      */   private static final long[] mk_tokenSet_23() {
/* 2455 */     return new long[] { 287958337218160128L, 576460745995190270L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2458 */   public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
/*      */   private static final long[] mk_tokenSet_24() {
/* 2460 */     return new long[] { 288228817078593024L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2463 */   public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
/*      */   private static final long[] mk_tokenSet_25() {
/* 2465 */     return new long[] { 288158448334415360L, 576460746532061182L, 0L, 0L, 0L };
/*      */   }
/*      */   
/* 2468 */   public static final BitSet _tokenSet_25 = new BitSet(mk_tokenSet_25());
/*      */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\actions\java\ActionLexer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */