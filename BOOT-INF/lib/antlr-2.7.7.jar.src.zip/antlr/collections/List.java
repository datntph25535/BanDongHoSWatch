package antlr.collections;

import java.util.Enumeration;
import java.util.NoSuchElementException;

public interface List {
  void add(Object paramObject);
  
  void append(Object paramObject);
  
  Object elementAt(int paramInt) throws NoSuchElementException;
  
  Enumeration elements();
  
  boolean includes(Object paramObject);
  
  int length();
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\collections\List.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */