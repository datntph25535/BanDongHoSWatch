/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.AST;
/*     */ import antlr.collections.ASTEnumeration;
/*     */ import antlr.collections.impl.ASTEnumerator;
/*     */ import antlr.collections.impl.Vector;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseAST
/*     */   implements AST, Serializable
/*     */ {
/*     */   protected BaseAST down;
/*     */   protected BaseAST right;
/*     */   private static boolean verboseStringConversion = false;
/*  49 */   private static String[] tokenNames = null;
/*     */ 
/*     */   
/*     */   public void addChild(AST paramAST) {
/*  53 */     if (paramAST == null)
/*  54 */       return;  BaseAST baseAST = this.down;
/*  55 */     if (baseAST != null) {
/*  56 */       while (baseAST.right != null) {
/*  57 */         baseAST = baseAST.right;
/*     */       }
/*  59 */       baseAST.right = (BaseAST)paramAST;
/*     */     } else {
/*     */       
/*  62 */       this.down = (BaseAST)paramAST;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfChildren() {
/*  68 */     BaseAST baseAST = this.down;
/*  69 */     byte b = 0;
/*  70 */     if (baseAST != null) {
/*  71 */       b = 1;
/*  72 */       while (baseAST.right != null) {
/*  73 */         baseAST = baseAST.right;
/*  74 */         b++;
/*     */       } 
/*  76 */       return b;
/*     */     } 
/*  78 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void doWorkForFindAll(AST paramAST1, Vector paramVector, AST paramAST2, boolean paramBoolean) {
/*  87 */     for (AST aST = paramAST1; aST != null; aST = aST.getNextSibling()) {
/*     */       
/*  89 */       if ((paramBoolean && aST.equalsTreePartial(paramAST2)) || (!paramBoolean && aST.equalsTree(paramAST2)))
/*     */       {
/*  91 */         paramVector.appendElement(aST);
/*     */       }
/*     */       
/*  94 */       if (aST.getFirstChild() != null) {
/*  95 */         doWorkForFindAll(aST.getFirstChild(), paramVector, paramAST2, paramBoolean);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(AST paramAST) {
/* 102 */     if (paramAST == null) return false; 
/* 103 */     if ((getText() == null && paramAST.getText() != null) || (getText() != null && paramAST.getText() == null))
/*     */     {
/*     */       
/* 106 */       return false;
/*     */     }
/* 108 */     if (getText() == null && paramAST.getText() == null) {
/* 109 */       return (getType() == paramAST.getType());
/*     */     }
/* 111 */     return (getText().equals(paramAST.getText()) && getType() == paramAST.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsList(AST paramAST) {
/* 122 */     if (paramAST == null) {
/* 123 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 127 */     AST aST = this;
/* 128 */     for (; aST != null && paramAST != null; 
/* 129 */       aST = aST.getNextSibling(), paramAST = paramAST.getNextSibling()) {
/*     */ 
/*     */       
/* 132 */       if (!aST.equals(paramAST)) {
/* 133 */         return false;
/*     */       }
/*     */       
/* 136 */       if (aST.getFirstChild() != null) {
/* 137 */         if (!aST.getFirstChild().equalsList(paramAST.getFirstChild())) {
/* 138 */           return false;
/*     */         
/*     */         }
/*     */       }
/* 142 */       else if (paramAST.getFirstChild() != null) {
/* 143 */         return false;
/*     */       } 
/*     */     } 
/* 146 */     if (aST == null && paramAST == null) {
/* 147 */       return true;
/*     */     }
/*     */     
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsListPartial(AST paramAST) {
/* 160 */     if (paramAST == null) {
/* 161 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 165 */     AST aST = this;
/* 166 */     for (; aST != null && paramAST != null; 
/* 167 */       aST = aST.getNextSibling(), paramAST = paramAST.getNextSibling()) {
/*     */       
/* 169 */       if (!aST.equals(paramAST)) return false;
/*     */       
/* 171 */       if (aST.getFirstChild() != null && 
/* 172 */         !aST.getFirstChild().equalsListPartial(paramAST.getFirstChild())) return false;
/*     */     
/*     */     } 
/* 175 */     if (aST == null && paramAST != null)
/*     */     {
/* 177 */       return false;
/*     */     }
/*     */     
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsTree(AST paramAST) {
/* 188 */     if (!equals(paramAST)) return false;
/*     */     
/* 190 */     if (getFirstChild() != null) {
/* 191 */       if (!getFirstChild().equalsList(paramAST.getFirstChild())) return false;
/*     */     
/*     */     }
/* 194 */     else if (paramAST.getFirstChild() != null) {
/* 195 */       return false;
/*     */     } 
/* 197 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsTreePartial(AST paramAST) {
/* 205 */     if (paramAST == null) {
/* 206 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 210 */     if (!equals(paramAST)) return false;
/*     */     
/* 212 */     if (getFirstChild() != null && 
/* 213 */       !getFirstChild().equalsListPartial(paramAST.getFirstChild())) return false;
/*     */     
/* 215 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTEnumeration findAll(AST paramAST) {
/* 223 */     Vector vector = new Vector(10);
/*     */ 
/*     */ 
/*     */     
/* 227 */     if (paramAST == null) {
/* 228 */       return null;
/*     */     }
/*     */     
/* 231 */     doWorkForFindAll(this, vector, paramAST, false);
/*     */     
/* 233 */     return (ASTEnumeration)new ASTEnumerator(vector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTEnumeration findAllPartial(AST paramAST) {
/* 241 */     Vector vector = new Vector(10);
/*     */ 
/*     */ 
/*     */     
/* 245 */     if (paramAST == null) {
/* 246 */       return null;
/*     */     }
/*     */     
/* 249 */     doWorkForFindAll(this, vector, paramAST, true);
/*     */     
/* 251 */     return (ASTEnumeration)new ASTEnumerator(vector);
/*     */   }
/*     */ 
/*     */   
/*     */   public AST getFirstChild() {
/* 256 */     return this.down;
/*     */   }
/*     */ 
/*     */   
/*     */   public AST getNextSibling() {
/* 261 */     return this.right;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 266 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 271 */     return 0;
/*     */   }
/*     */   
/*     */   public int getLine() {
/* 275 */     return 0;
/*     */   }
/*     */   
/*     */   public int getColumn() {
/* 279 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void initialize(int paramInt, String paramString);
/*     */   
/*     */   public abstract void initialize(AST paramAST);
/*     */   
/*     */   public abstract void initialize(Token paramToken);
/*     */   
/*     */   public void removeChildren() {
/* 290 */     this.down = null;
/*     */   }
/*     */   
/*     */   public void setFirstChild(AST paramAST) {
/* 294 */     this.down = (BaseAST)paramAST;
/*     */   }
/*     */   
/*     */   public void setNextSibling(AST paramAST) {
/* 298 */     this.right = (BaseAST)paramAST;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String paramString) {}
/*     */ 
/*     */   
/*     */   public void setType(int paramInt) {}
/*     */ 
/*     */   
/*     */   public static void setVerboseStringConversion(boolean paramBoolean, String[] paramArrayOfString) {
/* 310 */     verboseStringConversion = paramBoolean;
/* 311 */     tokenNames = paramArrayOfString;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String[] getTokenNames() {
/* 316 */     return tokenNames;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 320 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 322 */     if (verboseStringConversion && getText() != null && !getText().equalsIgnoreCase(tokenNames[getType()]) && !getText().equalsIgnoreCase(StringUtils.stripFrontBack(tokenNames[getType()], "\"", "\""))) {
/*     */ 
/*     */ 
/*     */       
/* 326 */       stringBuffer.append('[');
/* 327 */       stringBuffer.append(getText());
/* 328 */       stringBuffer.append(",<");
/* 329 */       stringBuffer.append(tokenNames[getType()]);
/* 330 */       stringBuffer.append(">]");
/* 331 */       return stringBuffer.toString();
/*     */     } 
/* 333 */     return getText();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringList() {
/* 338 */     BaseAST baseAST = this;
/* 339 */     String str = "";
/* 340 */     if (baseAST.getFirstChild() != null) str = str + " ("; 
/* 341 */     str = str + " " + toString();
/* 342 */     if (baseAST.getFirstChild() != null) {
/* 343 */       str = str + ((BaseAST)baseAST.getFirstChild()).toStringList();
/*     */     }
/* 345 */     if (baseAST.getFirstChild() != null) str = str + " )"; 
/* 346 */     if (baseAST.getNextSibling() != null) {
/* 347 */       str = str + ((BaseAST)baseAST.getNextSibling()).toStringList();
/*     */     }
/* 349 */     return str;
/*     */   }
/*     */   
/*     */   public String toStringTree() {
/* 353 */     BaseAST baseAST = this;
/* 354 */     String str = "";
/* 355 */     if (baseAST.getFirstChild() != null) str = str + " ("; 
/* 356 */     str = str + " " + toString();
/* 357 */     if (baseAST.getFirstChild() != null) {
/* 358 */       str = str + ((BaseAST)baseAST.getFirstChild()).toStringList();
/*     */     }
/* 360 */     if (baseAST.getFirstChild() != null) str = str + " )"; 
/* 361 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String decode(String paramString) {
/* 366 */     StringBuffer stringBuffer = new StringBuffer();
/* 367 */     for (byte b = 0; b < paramString.length(); b++) {
/* 368 */       char c = paramString.charAt(b);
/* 369 */       if (c == '&') {
/* 370 */         char c1 = paramString.charAt(b + 1);
/* 371 */         char c2 = paramString.charAt(b + 2);
/* 372 */         char c3 = paramString.charAt(b + 3);
/* 373 */         char c4 = paramString.charAt(b + 4);
/* 374 */         char c5 = paramString.charAt(b + 5);
/*     */         
/* 376 */         if (c1 == 'a' && c2 == 'm' && c3 == 'p' && c4 == ';') {
/* 377 */           stringBuffer.append("&");
/* 378 */           b += 5;
/*     */         }
/* 380 */         else if (c1 == 'l' && c2 == 't' && c3 == ';') {
/* 381 */           stringBuffer.append("<");
/* 382 */           b += 4;
/*     */         }
/* 384 */         else if (c1 == 'g' && c2 == 't' && c3 == ';') {
/* 385 */           stringBuffer.append(">");
/* 386 */           b += 4;
/*     */         }
/* 388 */         else if (c1 == 'q' && c2 == 'u' && c3 == 'o' && c4 == 't' && c5 == ';') {
/*     */           
/* 390 */           stringBuffer.append("\"");
/* 391 */           b += 6;
/*     */         }
/* 393 */         else if (c1 == 'a' && c2 == 'p' && c3 == 'o' && c4 == 's' && c5 == ';') {
/*     */           
/* 395 */           stringBuffer.append("'");
/* 396 */           b += 6;
/*     */         } else {
/*     */           
/* 399 */           stringBuffer.append("&");
/*     */         } 
/*     */       } else {
/* 402 */         stringBuffer.append(c);
/*     */       } 
/* 404 */     }  return new String(stringBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String encode(String paramString) {
/* 409 */     StringBuffer stringBuffer = new StringBuffer();
/* 410 */     for (byte b = 0; b < paramString.length(); b++) {
/* 411 */       char c = paramString.charAt(b);
/* 412 */       switch (c) {
/*     */         
/*     */         case '&':
/* 415 */           stringBuffer.append("&amp;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '<':
/* 420 */           stringBuffer.append("&lt;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '>':
/* 425 */           stringBuffer.append("&gt;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '"':
/* 430 */           stringBuffer.append("&quot;");
/*     */           break;
/*     */ 
/*     */         
/*     */         case '\'':
/* 435 */           stringBuffer.append("&apos;");
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 440 */           stringBuffer.append(c);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 445 */     return new String(stringBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void xmlSerializeNode(Writer paramWriter) throws IOException {
/* 450 */     StringBuffer stringBuffer = new StringBuffer(100);
/* 451 */     stringBuffer.append("<");
/* 452 */     stringBuffer.append(getClass().getName() + " ");
/* 453 */     stringBuffer.append("text=\"" + encode(getText()) + "\" type=\"" + getType() + "\"/>");
/*     */     
/* 455 */     paramWriter.write(stringBuffer.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void xmlSerializeRootOpen(Writer paramWriter) throws IOException {
/* 460 */     StringBuffer stringBuffer = new StringBuffer(100);
/* 461 */     stringBuffer.append("<");
/* 462 */     stringBuffer.append(getClass().getName() + " ");
/* 463 */     stringBuffer.append("text=\"" + encode(getText()) + "\" type=\"" + getType() + "\">\n");
/*     */     
/* 465 */     paramWriter.write(stringBuffer.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   public void xmlSerializeRootClose(Writer paramWriter) throws IOException {
/* 470 */     paramWriter.write("</" + getClass().getName() + ">\n");
/*     */   }
/*     */ 
/*     */   
/*     */   public void xmlSerialize(Writer paramWriter) throws IOException {
/* 475 */     BaseAST baseAST = this;
/* 476 */     for (; baseAST != null; 
/* 477 */       aST = baseAST.getNextSibling()) {
/* 478 */       AST aST; if (baseAST.getFirstChild() == null) {
/*     */         
/* 480 */         baseAST.xmlSerializeNode(paramWriter);
/*     */       } else {
/*     */         
/* 483 */         baseAST.xmlSerializeRootOpen(paramWriter);
/*     */ 
/*     */         
/* 486 */         ((BaseAST)baseAST.getFirstChild()).xmlSerialize(paramWriter);
/*     */ 
/*     */         
/* 489 */         baseAST.xmlSerializeRootClose(paramWriter);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\BaseAST.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */