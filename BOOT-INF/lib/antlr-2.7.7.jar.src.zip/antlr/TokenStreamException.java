/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TokenStreamException
/*    */   extends ANTLRException
/*    */ {
/*    */   public TokenStreamException() {}
/*    */   
/*    */   public TokenStreamException(String paramString) {
/* 18 */     super(paramString);
/*    */   }
/*    */   
/*    */   public TokenStreamException(String paramString, Throwable paramThrowable) {
/* 22 */     super(paramString, paramThrowable);
/*    */   }
/*    */   
/*    */   public TokenStreamException(Throwable paramThrowable) {
/* 26 */     super(paramThrowable);
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\TokenStreamException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */