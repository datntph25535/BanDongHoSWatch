/*    */ package antlr;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TokenStreamIOException
/*    */   extends TokenStreamException
/*    */ {
/*    */   public IOException io;
/*    */   
/*    */   public TokenStreamIOException(IOException paramIOException) {
/* 23 */     super(paramIOException.getMessage());
/* 24 */     this.io = paramIOException;
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\TokenStreamIOException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */