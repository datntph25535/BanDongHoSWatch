/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JavaBlockFinishingInfo
/*    */ {
/*    */   String postscript;
/*    */   boolean generatedSwitch;
/*    */   boolean generatedAnIf;
/*    */   boolean needAnErrorClause;
/*    */   
/*    */   public JavaBlockFinishingInfo() {
/* 23 */     this.postscript = null;
/* 24 */     this.generatedSwitch = false;
/* 25 */     this.needAnErrorClause = true;
/*    */   }
/*    */   
/*    */   public JavaBlockFinishingInfo(String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 29 */     this.postscript = paramString;
/* 30 */     this.generatedSwitch = paramBoolean1;
/* 31 */     this.generatedAnIf = paramBoolean2;
/* 32 */     this.needAnErrorClause = paramBoolean3;
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\JavaBlockFinishingInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */