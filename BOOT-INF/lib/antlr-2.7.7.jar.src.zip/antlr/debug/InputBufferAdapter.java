package antlr.debug;

public abstract class InputBufferAdapter implements InputBufferListener {
  public void doneParsing(TraceEvent paramTraceEvent) {}
  
  public void inputBufferConsume(InputBufferEvent paramInputBufferEvent) {}
  
  public void inputBufferLA(InputBufferEvent paramInputBufferEvent) {}
  
  public void inputBufferMark(InputBufferEvent paramInputBufferEvent) {}
  
  public void inputBufferRewind(InputBufferEvent paramInputBufferEvent) {}
  
  public void refresh() {}
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\InputBufferAdapter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */