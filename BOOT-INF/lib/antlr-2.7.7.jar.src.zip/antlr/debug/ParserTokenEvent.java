/*    */ package antlr.debug;
/*    */ 
/*    */ public class ParserTokenEvent extends Event {
/*    */   private int value;
/*    */   private int amount;
/*  6 */   public static int LA = 0;
/*  7 */   public static int CONSUME = 1;
/*    */ 
/*    */   
/*    */   public ParserTokenEvent(Object paramObject) {
/* 11 */     super(paramObject);
/*    */   }
/*    */   
/*    */   public ParserTokenEvent(Object paramObject, int paramInt1, int paramInt2, int paramInt3) {
/* 15 */     super(paramObject);
/* 16 */     setValues(paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */   public int getAmount() {
/* 19 */     return this.amount;
/*    */   }
/*    */   public int getValue() {
/* 22 */     return this.value;
/*    */   }
/*    */   void setAmount(int paramInt) {
/* 25 */     this.amount = paramInt;
/*    */   }
/*    */   void setValue(int paramInt) {
/* 28 */     this.value = paramInt;
/*    */   }
/*    */   
/*    */   void setValues(int paramInt1, int paramInt2, int paramInt3) {
/* 32 */     setValues(paramInt1);
/* 33 */     setAmount(paramInt2);
/* 34 */     setValue(paramInt3);
/*    */   }
/*    */   public String toString() {
/* 37 */     if (getType() == LA) {
/* 38 */       return "ParserTokenEvent [LA," + getAmount() + "," + getValue() + "]";
/*    */     }
/*    */     
/* 41 */     return "ParserTokenEvent [consume,1," + getValue() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\ParserTokenEvent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */