/*    */ package antlr.debug;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputBufferEventSupport
/*    */ {
/*    */   private Object source;
/*    */   private Vector inputBufferListeners;
/*    */   private InputBufferEvent inputBufferEvent;
/*    */   protected static final int CONSUME = 0;
/*    */   protected static final int LA = 1;
/*    */   protected static final int MARK = 2;
/*    */   protected static final int REWIND = 3;
/*    */   
/*    */   public InputBufferEventSupport(Object paramObject) {
/* 18 */     this.inputBufferEvent = new InputBufferEvent(paramObject);
/* 19 */     this.source = paramObject;
/*    */   }
/*    */   public void addInputBufferListener(InputBufferListener paramInputBufferListener) {
/* 22 */     if (this.inputBufferListeners == null) this.inputBufferListeners = new Vector(); 
/* 23 */     this.inputBufferListeners.addElement(paramInputBufferListener);
/*    */   }
/*    */   public void fireConsume(char paramChar) {
/* 26 */     this.inputBufferEvent.setValues(0, paramChar, 0);
/* 27 */     fireEvents(0, this.inputBufferListeners);
/*    */   }
/*    */   public void fireEvent(int paramInt, ListenerBase paramListenerBase) {
/* 30 */     switch (paramInt) { case 0:
/* 31 */         ((InputBufferListener)paramListenerBase).inputBufferConsume(this.inputBufferEvent); return;
/* 32 */       case 1: ((InputBufferListener)paramListenerBase).inputBufferLA(this.inputBufferEvent); return;
/* 33 */       case 2: ((InputBufferListener)paramListenerBase).inputBufferMark(this.inputBufferEvent); return;
/* 34 */       case 3: ((InputBufferListener)paramListenerBase).inputBufferRewind(this.inputBufferEvent); return; }
/*    */     
/* 36 */     throw new IllegalArgumentException("bad type " + paramInt + " for fireEvent()");
/*    */   }
/*    */   
/*    */   public void fireEvents(int paramInt, Vector paramVector) {
/* 40 */     Vector vector = null;
/* 41 */     ListenerBase listenerBase = null;
/*    */     
/* 43 */     synchronized (this) {
/* 44 */       if (paramVector == null)
/* 45 */         return;  vector = (Vector)paramVector.clone();
/*    */     } 
/*    */     
/* 48 */     if (vector != null)
/* 49 */       for (byte b = 0; b < vector.size(); b++) {
/* 50 */         listenerBase = vector.elementAt(b);
/* 51 */         fireEvent(paramInt, listenerBase);
/*    */       }  
/*    */   }
/*    */   public void fireLA(char paramChar, int paramInt) {
/* 55 */     this.inputBufferEvent.setValues(1, paramChar, paramInt);
/* 56 */     fireEvents(1, this.inputBufferListeners);
/*    */   }
/*    */   public void fireMark(int paramInt) {
/* 59 */     this.inputBufferEvent.setValues(2, ' ', paramInt);
/* 60 */     fireEvents(2, this.inputBufferListeners);
/*    */   }
/*    */   public void fireRewind(int paramInt) {
/* 63 */     this.inputBufferEvent.setValues(3, ' ', paramInt);
/* 64 */     fireEvents(3, this.inputBufferListeners);
/*    */   }
/*    */   public Vector getInputBufferListeners() {
/* 67 */     return this.inputBufferListeners;
/*    */   }
/*    */   protected void refresh(Vector paramVector) {
/*    */     Vector vector;
/* 71 */     synchronized (paramVector) {
/* 72 */       vector = (Vector)paramVector.clone();
/*    */     } 
/* 74 */     if (vector != null)
/* 75 */       for (byte b = 0; b < vector.size(); b++)
/* 76 */         ((ListenerBase)vector.elementAt(b)).refresh();  
/*    */   }
/*    */   public void refreshListeners() {
/* 79 */     refresh(this.inputBufferListeners);
/*    */   }
/*    */   public void removeInputBufferListener(InputBufferListener paramInputBufferListener) {
/* 82 */     if (this.inputBufferListeners != null)
/* 83 */       this.inputBufferListeners.removeElement(paramInputBufferListener); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\InputBufferEventSupport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */