/*    */ package antlr.debug;
/*    */ 
/*    */ public class MessageEvent extends Event {
/*    */   private String text;
/*  5 */   public static int WARNING = 0;
/*  6 */   public static int ERROR = 1;
/*    */ 
/*    */   
/*    */   public MessageEvent(Object paramObject) {
/* 10 */     super(paramObject);
/*    */   }
/*    */   public MessageEvent(Object paramObject, int paramInt, String paramString) {
/* 13 */     super(paramObject);
/* 14 */     setValues(paramInt, paramString);
/*    */   }
/*    */   public String getText() {
/* 17 */     return this.text;
/*    */   }
/*    */   void setText(String paramString) {
/* 20 */     this.text = paramString;
/*    */   }
/*    */   
/*    */   void setValues(int paramInt, String paramString) {
/* 24 */     setValues(paramInt);
/* 25 */     setText(paramString);
/*    */   }
/*    */   public String toString() {
/* 28 */     return "ParserMessageEvent [" + ((getType() == WARNING) ? "warning," : "error,") + getText() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\MessageEvent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */