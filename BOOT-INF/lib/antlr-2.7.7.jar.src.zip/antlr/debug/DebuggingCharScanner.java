/*     */ package antlr.debug;
/*     */ import antlr.CharStreamException;
/*     */ import antlr.InputBuffer;
/*     */ import antlr.LexerSharedInputState;
/*     */ import antlr.MismatchedCharException;
/*     */ import antlr.collections.impl.BitSet;
/*     */ 
/*     */ public abstract class DebuggingCharScanner extends CharScanner implements DebuggingParser {
/*   9 */   private ParserEventSupport parserEventSupport = new ParserEventSupport(this);
/*     */   
/*     */   private boolean _notDebugMode = false;
/*     */   protected String[] ruleNames;
/*     */   protected String[] semPredNames;
/*     */   
/*     */   public DebuggingCharScanner(InputBuffer paramInputBuffer) {
/*  16 */     super(paramInputBuffer);
/*     */   }
/*     */   public DebuggingCharScanner(LexerSharedInputState paramLexerSharedInputState) {
/*  19 */     super(paramLexerSharedInputState);
/*     */   }
/*     */   public void addMessageListener(MessageListener paramMessageListener) {
/*  22 */     this.parserEventSupport.addMessageListener(paramMessageListener);
/*     */   }
/*     */   public void addNewLineListener(NewLineListener paramNewLineListener) {
/*  25 */     this.parserEventSupport.addNewLineListener(paramNewLineListener);
/*     */   }
/*     */   public void addParserListener(ParserListener paramParserListener) {
/*  28 */     this.parserEventSupport.addParserListener(paramParserListener);
/*     */   }
/*     */   public void addParserMatchListener(ParserMatchListener paramParserMatchListener) {
/*  31 */     this.parserEventSupport.addParserMatchListener(paramParserMatchListener);
/*     */   }
/*     */   public void addParserTokenListener(ParserTokenListener paramParserTokenListener) {
/*  34 */     this.parserEventSupport.addParserTokenListener(paramParserTokenListener);
/*     */   }
/*     */   public void addSemanticPredicateListener(SemanticPredicateListener paramSemanticPredicateListener) {
/*  37 */     this.parserEventSupport.addSemanticPredicateListener(paramSemanticPredicateListener);
/*     */   }
/*     */   public void addSyntacticPredicateListener(SyntacticPredicateListener paramSyntacticPredicateListener) {
/*  40 */     this.parserEventSupport.addSyntacticPredicateListener(paramSyntacticPredicateListener);
/*     */   }
/*     */   public void addTraceListener(TraceListener paramTraceListener) {
/*  43 */     this.parserEventSupport.addTraceListener(paramTraceListener);
/*     */   }
/*     */   public void consume() throws CharStreamException {
/*  46 */     int i = -99; try {
/*  47 */       i = LA(1);
/*  48 */     } catch (CharStreamException charStreamException) {}
/*  49 */     super.consume();
/*  50 */     this.parserEventSupport.fireConsume(i);
/*     */   }
/*     */   protected void fireEnterRule(int paramInt1, int paramInt2) {
/*  53 */     if (isDebugMode())
/*  54 */       this.parserEventSupport.fireEnterRule(paramInt1, this.inputState.guessing, paramInt2); 
/*     */   }
/*     */   protected void fireExitRule(int paramInt1, int paramInt2) {
/*  57 */     if (isDebugMode())
/*  58 */       this.parserEventSupport.fireExitRule(paramInt1, this.inputState.guessing, paramInt2); 
/*     */   }
/*     */   protected boolean fireSemanticPredicateEvaluated(int paramInt1, int paramInt2, boolean paramBoolean) {
/*  61 */     if (isDebugMode()) {
/*  62 */       return this.parserEventSupport.fireSemanticPredicateEvaluated(paramInt1, paramInt2, paramBoolean, this.inputState.guessing);
/*     */     }
/*  64 */     return paramBoolean;
/*     */   }
/*     */   protected void fireSyntacticPredicateFailed() {
/*  67 */     if (isDebugMode())
/*  68 */       this.parserEventSupport.fireSyntacticPredicateFailed(this.inputState.guessing); 
/*     */   }
/*     */   protected void fireSyntacticPredicateStarted() {
/*  71 */     if (isDebugMode())
/*  72 */       this.parserEventSupport.fireSyntacticPredicateStarted(this.inputState.guessing); 
/*     */   }
/*     */   protected void fireSyntacticPredicateSucceeded() {
/*  75 */     if (isDebugMode())
/*  76 */       this.parserEventSupport.fireSyntacticPredicateSucceeded(this.inputState.guessing); 
/*     */   }
/*     */   public String getRuleName(int paramInt) {
/*  79 */     return this.ruleNames[paramInt];
/*     */   }
/*     */   public String getSemPredName(int paramInt) {
/*  82 */     return this.semPredNames[paramInt];
/*     */   } public synchronized void goToSleep() {
/*     */     try {
/*  85 */       wait();
/*  86 */     } catch (InterruptedException interruptedException) {}
/*     */   }
/*     */   public boolean isDebugMode() {
/*  89 */     return !this._notDebugMode;
/*     */   }
/*     */   public char LA(int paramInt) throws CharStreamException {
/*  92 */     char c = super.LA(paramInt);
/*  93 */     this.parserEventSupport.fireLA(paramInt, c);
/*  94 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Token makeToken(int paramInt) {
/* 111 */     return super.makeToken(paramInt);
/*     */   }
/*     */   public void match(char paramChar) throws MismatchedCharException, CharStreamException {
/* 114 */     char c = LA(1);
/*     */     try {
/* 116 */       super.match(paramChar);
/* 117 */       this.parserEventSupport.fireMatch(paramChar, this.inputState.guessing);
/*     */     }
/* 119 */     catch (MismatchedCharException mismatchedCharException) {
/* 120 */       if (this.inputState.guessing == 0)
/* 121 */         this.parserEventSupport.fireMismatch(c, paramChar, this.inputState.guessing); 
/* 122 */       throw mismatchedCharException;
/*     */     } 
/*     */   }
/*     */   public void match(BitSet paramBitSet) throws MismatchedCharException, CharStreamException {
/* 126 */     String str = this.text.toString();
/* 127 */     char c = LA(1);
/*     */     try {
/* 129 */       super.match(paramBitSet);
/* 130 */       this.parserEventSupport.fireMatch(c, paramBitSet, str, this.inputState.guessing);
/*     */     }
/* 132 */     catch (MismatchedCharException mismatchedCharException) {
/* 133 */       if (this.inputState.guessing == 0)
/* 134 */         this.parserEventSupport.fireMismatch(c, paramBitSet, str, this.inputState.guessing); 
/* 135 */       throw mismatchedCharException;
/*     */     } 
/*     */   }
/*     */   public void match(String paramString) throws MismatchedCharException, CharStreamException {
/* 139 */     StringBuffer stringBuffer = new StringBuffer("");
/* 140 */     int i = paramString.length();
/*     */     
/*     */     try {
/* 143 */       for (byte b = 1; b <= i; b++) {
/* 144 */         stringBuffer.append(super.LA(b));
/*     */       }
/*     */     }
/* 147 */     catch (Exception exception) {}
/*     */     
/*     */     try {
/* 150 */       super.match(paramString);
/* 151 */       this.parserEventSupport.fireMatch(paramString, this.inputState.guessing);
/*     */     }
/* 153 */     catch (MismatchedCharException mismatchedCharException) {
/* 154 */       if (this.inputState.guessing == 0)
/* 155 */         this.parserEventSupport.fireMismatch(stringBuffer.toString(), paramString, this.inputState.guessing); 
/* 156 */       throw mismatchedCharException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void matchNot(char paramChar) throws MismatchedCharException, CharStreamException {
/* 161 */     char c = LA(1);
/*     */     try {
/* 163 */       super.matchNot(paramChar);
/* 164 */       this.parserEventSupport.fireMatchNot(c, paramChar, this.inputState.guessing);
/*     */     }
/* 166 */     catch (MismatchedCharException mismatchedCharException) {
/* 167 */       if (this.inputState.guessing == 0)
/* 168 */         this.parserEventSupport.fireMismatchNot(c, paramChar, this.inputState.guessing); 
/* 169 */       throw mismatchedCharException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void matchRange(char paramChar1, char paramChar2) throws MismatchedCharException, CharStreamException {
/* 174 */     char c = LA(1);
/*     */     try {
/* 176 */       super.matchRange(paramChar1, paramChar2);
/* 177 */       this.parserEventSupport.fireMatch(c, "" + paramChar1 + paramChar2, this.inputState.guessing);
/*     */     }
/* 179 */     catch (MismatchedCharException mismatchedCharException) {
/* 180 */       if (this.inputState.guessing == 0)
/* 181 */         this.parserEventSupport.fireMismatch(c, "" + paramChar1 + paramChar2, this.inputState.guessing); 
/* 182 */       throw mismatchedCharException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void newline() {
/* 187 */     super.newline();
/* 188 */     this.parserEventSupport.fireNewLine(getLine());
/*     */   }
/*     */   public void removeMessageListener(MessageListener paramMessageListener) {
/* 191 */     this.parserEventSupport.removeMessageListener(paramMessageListener);
/*     */   }
/*     */   public void removeNewLineListener(NewLineListener paramNewLineListener) {
/* 194 */     this.parserEventSupport.removeNewLineListener(paramNewLineListener);
/*     */   }
/*     */   public void removeParserListener(ParserListener paramParserListener) {
/* 197 */     this.parserEventSupport.removeParserListener(paramParserListener);
/*     */   }
/*     */   public void removeParserMatchListener(ParserMatchListener paramParserMatchListener) {
/* 200 */     this.parserEventSupport.removeParserMatchListener(paramParserMatchListener);
/*     */   }
/*     */   public void removeParserTokenListener(ParserTokenListener paramParserTokenListener) {
/* 203 */     this.parserEventSupport.removeParserTokenListener(paramParserTokenListener);
/*     */   }
/*     */   public void removeSemanticPredicateListener(SemanticPredicateListener paramSemanticPredicateListener) {
/* 206 */     this.parserEventSupport.removeSemanticPredicateListener(paramSemanticPredicateListener);
/*     */   }
/*     */   public void removeSyntacticPredicateListener(SyntacticPredicateListener paramSyntacticPredicateListener) {
/* 209 */     this.parserEventSupport.removeSyntacticPredicateListener(paramSyntacticPredicateListener);
/*     */   }
/*     */   public void removeTraceListener(TraceListener paramTraceListener) {
/* 212 */     this.parserEventSupport.removeTraceListener(paramTraceListener);
/*     */   }
/*     */   
/*     */   public void reportError(MismatchedCharException paramMismatchedCharException) {
/* 216 */     this.parserEventSupport.fireReportError((Exception)paramMismatchedCharException);
/* 217 */     reportError((RecognitionException)paramMismatchedCharException);
/*     */   }
/*     */   
/*     */   public void reportError(String paramString) {
/* 221 */     this.parserEventSupport.fireReportError(paramString);
/* 222 */     super.reportError(paramString);
/*     */   }
/*     */   
/*     */   public void reportWarning(String paramString) {
/* 226 */     this.parserEventSupport.fireReportWarning(paramString);
/* 227 */     super.reportWarning(paramString);
/*     */   }
/*     */   public void setDebugMode(boolean paramBoolean) {
/* 230 */     this._notDebugMode = !paramBoolean;
/*     */   }
/*     */   public void setupDebugging() {}
/*     */   
/*     */   public synchronized void wakeUp() {
/* 235 */     notify();
/*     */   }
/*     */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\DebuggingCharScanner.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */