package antlr.debug;

public interface InputBufferListener extends ListenerBase {
  void inputBufferConsume(InputBufferEvent paramInputBufferEvent);
  
  void inputBufferLA(InputBufferEvent paramInputBufferEvent);
  
  void inputBufferMark(InputBufferEvent paramInputBufferEvent);
  
  void inputBufferRewind(InputBufferEvent paramInputBufferEvent);
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\InputBufferListener.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */