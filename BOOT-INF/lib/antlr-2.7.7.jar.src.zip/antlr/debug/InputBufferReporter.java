/*    */ package antlr.debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputBufferReporter
/*    */   implements InputBufferListener
/*    */ {
/*    */   public void doneParsing(TraceEvent paramTraceEvent) {}
/*    */   
/*    */   public void inputBufferChanged(InputBufferEvent paramInputBufferEvent) {
/* 12 */     System.out.println(paramInputBufferEvent);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void inputBufferConsume(InputBufferEvent paramInputBufferEvent) {
/* 18 */     System.out.println(paramInputBufferEvent);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void inputBufferLA(InputBufferEvent paramInputBufferEvent) {
/* 24 */     System.out.println(paramInputBufferEvent);
/*    */   }
/*    */   public void inputBufferMark(InputBufferEvent paramInputBufferEvent) {
/* 27 */     System.out.println(paramInputBufferEvent);
/*    */   }
/*    */   public void inputBufferRewind(InputBufferEvent paramInputBufferEvent) {
/* 30 */     System.out.println(paramInputBufferEvent);
/*    */   }
/*    */   
/*    */   public void refresh() {}
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\debug\InputBufferReporter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */