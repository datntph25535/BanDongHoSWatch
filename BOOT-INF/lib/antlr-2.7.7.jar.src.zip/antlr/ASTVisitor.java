package antlr;

import antlr.collections.AST;

public interface ASTVisitor {
  void visit(AST paramAST);
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ASTVisitor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */