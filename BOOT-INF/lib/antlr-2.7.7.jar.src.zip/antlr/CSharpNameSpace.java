/*    */ package antlr;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CSharpNameSpace
/*    */   extends NameSpace
/*    */ {
/*    */   public CSharpNameSpace(String paramString) {
/* 39 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void emitDeclarations(PrintWriter paramPrintWriter) {
/* 46 */     paramPrintWriter.println("namespace " + getName());
/* 47 */     paramPrintWriter.println("{");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void emitClosures(PrintWriter paramPrintWriter) {
/* 54 */     paramPrintWriter.println("}");
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CSharpNameSpace.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */