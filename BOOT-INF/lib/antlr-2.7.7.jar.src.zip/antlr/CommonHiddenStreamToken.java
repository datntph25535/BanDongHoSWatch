/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonHiddenStreamToken
/*    */   extends CommonToken
/*    */ {
/*    */   protected CommonHiddenStreamToken hiddenBefore;
/*    */   protected CommonHiddenStreamToken hiddenAfter;
/*    */   
/*    */   public CommonHiddenStreamToken() {}
/*    */   
/*    */   public CommonHiddenStreamToken(int paramInt, String paramString) {
/* 19 */     super(paramInt, paramString);
/*    */   }
/*    */   
/*    */   public CommonHiddenStreamToken(String paramString) {
/* 23 */     super(paramString);
/*    */   }
/*    */   
/*    */   public CommonHiddenStreamToken getHiddenAfter() {
/* 27 */     return this.hiddenAfter;
/*    */   }
/*    */   
/*    */   public CommonHiddenStreamToken getHiddenBefore() {
/* 31 */     return this.hiddenBefore;
/*    */   }
/*    */   
/*    */   protected void setHiddenAfter(CommonHiddenStreamToken paramCommonHiddenStreamToken) {
/* 35 */     this.hiddenAfter = paramCommonHiddenStreamToken;
/*    */   }
/*    */   
/*    */   protected void setHiddenBefore(CommonHiddenStreamToken paramCommonHiddenStreamToken) {
/* 39 */     this.hiddenBefore = paramCommonHiddenStreamToken;
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CommonHiddenStreamToken.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */