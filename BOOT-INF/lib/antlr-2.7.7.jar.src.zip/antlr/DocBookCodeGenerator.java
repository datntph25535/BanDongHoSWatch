/*     */ package antlr;
/*     */ 
/*     */ import antlr.collections.impl.Vector;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DocBookCodeGenerator
/*     */   extends CodeGenerator
/*     */ {
/*  25 */   protected int syntacticPredLevel = 0;
/*     */ 
/*     */   
/*     */   protected boolean doingLexRules = false;
/*     */   
/*     */   protected boolean firstElementInAlt;
/*     */   
/*  32 */   protected AlternativeElement prevAltElem = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DocBookCodeGenerator() {
/*  40 */     this.charFormatter = new JavaCharFormatter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String HTMLEncode(String paramString) {
/*  48 */     StringBuffer stringBuffer = new StringBuffer(); byte b;
/*     */     int i;
/*  50 */     for (b = 0, i = paramString.length(); b < i; b++) {
/*  51 */       char c = paramString.charAt(b);
/*  52 */       if (c == '&') {
/*  53 */         stringBuffer.append("&amp;");
/*  54 */       } else if (c == '"') {
/*  55 */         stringBuffer.append("&quot;");
/*  56 */       } else if (c == '\'') {
/*  57 */         stringBuffer.append("&#039;");
/*  58 */       } else if (c == '<') {
/*  59 */         stringBuffer.append("&lt;");
/*  60 */       } else if (c == '>') {
/*  61 */         stringBuffer.append("&gt;");
/*     */       } else {
/*  63 */         stringBuffer.append(c);
/*     */       } 
/*  65 */     }  return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String QuoteForId(String paramString) {
/*  73 */     StringBuffer stringBuffer = new StringBuffer(); byte b;
/*     */     int i;
/*  75 */     for (b = 0, i = paramString.length(); b < i; b++) {
/*  76 */       char c = paramString.charAt(b);
/*  77 */       if (c == '_') {
/*  78 */         stringBuffer.append(".");
/*     */       } else {
/*  80 */         stringBuffer.append(c);
/*     */       } 
/*  82 */     }  return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen() {
/*     */     try {
/*  89 */       Enumeration enumeration = this.behavior.grammars.elements();
/*  90 */       while (enumeration.hasMoreElements()) {
/*  91 */         Grammar grammar = enumeration.nextElement();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  98 */         grammar.setCodeGenerator(this);
/*     */ 
/*     */         
/* 101 */         grammar.generate();
/*     */         
/* 103 */         if (this.antlrTool.hasError()) {
/* 104 */           this.antlrTool.fatalError("Exiting due to errors.");
/*     */         
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 110 */     catch (IOException iOException) {
/* 111 */       this.antlrTool.reportException(iOException, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(ActionElement paramActionElement) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(AlternativeBlock paramAlternativeBlock) {
/* 126 */     genGenericBlock(paramAlternativeBlock, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(BlockEndElement paramBlockEndElement) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(CharLiteralElement paramCharLiteralElement) {
/* 142 */     if (paramCharLiteralElement.not) {
/* 143 */       _print("~");
/*     */     }
/* 145 */     _print(HTMLEncode(paramCharLiteralElement.atomText) + " ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(CharRangeElement paramCharRangeElement) {
/* 152 */     print(paramCharRangeElement.beginText + ".." + paramCharRangeElement.endText + " ");
/*     */   }
/*     */ 
/*     */   
/*     */   public void gen(LexerGrammar paramLexerGrammar) throws IOException {
/* 157 */     setGrammar(paramLexerGrammar);
/* 158 */     this.antlrTool.reportProgress("Generating " + this.grammar.getClassName() + ".sgml");
/* 159 */     this.currentOutput = this.antlrTool.openOutputFile(this.grammar.getClassName() + ".sgml");
/*     */     
/* 161 */     this.tabs = 0;
/* 162 */     this.doingLexRules = true;
/*     */ 
/*     */     
/* 165 */     genHeader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     println("");
/*     */ 
/*     */     
/* 175 */     if (this.grammar.comment != null) {
/* 176 */       _println(HTMLEncode(this.grammar.comment));
/*     */     }
/*     */     
/* 179 */     println("<para>Definition of lexer " + this.grammar.getClassName() + ", which is a subclass of " + this.grammar.getSuperClass() + ".</para>");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     genNextToken();
/*     */ 
/*     */ 
/*     */     
/* 216 */     Enumeration enumeration = this.grammar.rules.elements();
/* 217 */     while (enumeration.hasMoreElements()) {
/* 218 */       RuleSymbol ruleSymbol = enumeration.nextElement();
/* 219 */       if (!ruleSymbol.id.equals("mnextToken")) {
/* 220 */         genRule(ruleSymbol);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 225 */     this.currentOutput.close();
/* 226 */     this.currentOutput = null;
/* 227 */     this.doingLexRules = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(OneOrMoreBlock paramOneOrMoreBlock) {
/* 234 */     genGenericBlock(paramOneOrMoreBlock, "+");
/*     */   }
/*     */ 
/*     */   
/*     */   public void gen(ParserGrammar paramParserGrammar) throws IOException {
/* 239 */     setGrammar(paramParserGrammar);
/*     */     
/* 241 */     this.antlrTool.reportProgress("Generating " + this.grammar.getClassName() + ".sgml");
/* 242 */     this.currentOutput = this.antlrTool.openOutputFile(this.grammar.getClassName() + ".sgml");
/*     */     
/* 244 */     this.tabs = 0;
/*     */ 
/*     */     
/* 247 */     genHeader();
/*     */ 
/*     */     
/* 250 */     println("");
/*     */ 
/*     */     
/* 253 */     if (this.grammar.comment != null) {
/* 254 */       _println(HTMLEncode(this.grammar.comment));
/*     */     }
/*     */     
/* 257 */     println("<para>Definition of parser " + this.grammar.getClassName() + ", which is a subclass of " + this.grammar.getSuperClass() + ".</para>");
/*     */ 
/*     */     
/* 260 */     Enumeration enumeration = this.grammar.rules.elements();
/* 261 */     while (enumeration.hasMoreElements()) {
/* 262 */       println("");
/*     */       
/* 264 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/*     */       
/* 266 */       if (grammarSymbol instanceof RuleSymbol) {
/* 267 */         genRule((RuleSymbol)grammarSymbol);
/*     */       }
/*     */     } 
/* 270 */     this.tabs--;
/* 271 */     println("");
/*     */     
/* 273 */     genTail();
/*     */ 
/*     */     
/* 276 */     this.currentOutput.close();
/* 277 */     this.currentOutput = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(RuleRefElement paramRuleRefElement) {
/* 284 */     RuleSymbol ruleSymbol = (RuleSymbol)this.grammar.getSymbol(paramRuleRefElement.targetRule);
/*     */ 
/*     */     
/* 287 */     _print("<link linkend=\"" + QuoteForId(paramRuleRefElement.targetRule) + "\">");
/* 288 */     _print(paramRuleRefElement.targetRule);
/* 289 */     _print("</link>");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 294 */     _print(" ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(StringLiteralElement paramStringLiteralElement) {
/* 301 */     if (paramStringLiteralElement.not) {
/* 302 */       _print("~");
/*     */     }
/* 304 */     _print(HTMLEncode(paramStringLiteralElement.atomText));
/* 305 */     _print(" ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(TokenRangeElement paramTokenRangeElement) {
/* 312 */     print(paramTokenRangeElement.beginText + ".." + paramTokenRangeElement.endText + " ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(TokenRefElement paramTokenRefElement) {
/* 319 */     if (paramTokenRefElement.not) {
/* 320 */       _print("~");
/*     */     }
/* 322 */     _print(paramTokenRefElement.atomText);
/* 323 */     _print(" ");
/*     */   }
/*     */   
/*     */   public void gen(TreeElement paramTreeElement) {
/* 327 */     print(paramTreeElement + " ");
/*     */   }
/*     */ 
/*     */   
/*     */   public void gen(TreeWalkerGrammar paramTreeWalkerGrammar) throws IOException {
/* 332 */     setGrammar(paramTreeWalkerGrammar);
/*     */     
/* 334 */     this.antlrTool.reportProgress("Generating " + this.grammar.getClassName() + ".sgml");
/* 335 */     this.currentOutput = this.antlrTool.openOutputFile(this.grammar.getClassName() + ".sgml");
/*     */ 
/*     */     
/* 338 */     this.tabs = 0;
/*     */ 
/*     */     
/* 341 */     genHeader();
/*     */ 
/*     */     
/* 344 */     println("");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     println("");
/*     */ 
/*     */     
/* 356 */     if (this.grammar.comment != null) {
/* 357 */       _println(HTMLEncode(this.grammar.comment));
/*     */     }
/*     */     
/* 360 */     println("<para>Definition of tree parser " + this.grammar.getClassName() + ", which is a subclass of " + this.grammar.getSuperClass() + ".</para>");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 372 */     println("");
/*     */     
/* 374 */     this.tabs++;
/*     */ 
/*     */     
/* 377 */     Enumeration enumeration = this.grammar.rules.elements();
/* 378 */     while (enumeration.hasMoreElements()) {
/* 379 */       println("");
/*     */       
/* 381 */       GrammarSymbol grammarSymbol = enumeration.nextElement();
/*     */       
/* 383 */       if (grammarSymbol instanceof RuleSymbol) {
/* 384 */         genRule((RuleSymbol)grammarSymbol);
/*     */       }
/*     */     } 
/* 387 */     this.tabs--;
/* 388 */     println("");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 395 */     this.currentOutput.close();
/* 396 */     this.currentOutput = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(WildcardElement paramWildcardElement) {
/* 406 */     _print(". ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(ZeroOrMoreBlock paramZeroOrMoreBlock) {
/* 413 */     genGenericBlock(paramZeroOrMoreBlock, "*");
/*     */   }
/*     */   
/*     */   protected void genAlt(Alternative paramAlternative) {
/* 417 */     if (paramAlternative.getTreeSpecifier() != null) {
/* 418 */       _print(paramAlternative.getTreeSpecifier().getText());
/*     */     }
/* 420 */     this.prevAltElem = null;
/* 421 */     AlternativeElement alternativeElement = paramAlternative.head;
/* 422 */     for (; !(alternativeElement instanceof BlockEndElement); 
/* 423 */       alternativeElement = alternativeElement.next) {
/* 424 */       alternativeElement.generate();
/* 425 */       this.firstElementInAlt = false;
/* 426 */       this.prevAltElem = alternativeElement;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void genCommonBlock(AlternativeBlock paramAlternativeBlock) {
/* 447 */     if (paramAlternativeBlock.alternatives.size() > 1)
/* 448 */       println("<itemizedlist mark=\"none\">"); 
/* 449 */     for (byte b = 0; b < paramAlternativeBlock.alternatives.size(); b++) {
/* 450 */       Alternative alternative = paramAlternativeBlock.getAlternativeAt(b);
/* 451 */       AlternativeElement alternativeElement = alternative.head;
/*     */       
/* 453 */       if (paramAlternativeBlock.alternatives.size() > 1) {
/* 454 */         print("<listitem><para>");
/*     */       }
/*     */       
/* 457 */       if (b > 0 && paramAlternativeBlock.alternatives.size() > 1) {
/* 458 */         _print("| ");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 463 */       boolean bool = this.firstElementInAlt;
/* 464 */       this.firstElementInAlt = true;
/* 465 */       this.tabs++;
/*     */       
/* 467 */       genAlt(alternative);
/* 468 */       this.tabs--;
/* 469 */       this.firstElementInAlt = bool;
/* 470 */       if (paramAlternativeBlock.alternatives.size() > 1)
/* 471 */         _println("</para></listitem>"); 
/*     */     } 
/* 473 */     if (paramAlternativeBlock.alternatives.size() > 1) {
/* 474 */       println("</itemizedlist>");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void genFollowSetForRuleBlock(RuleBlock paramRuleBlock) {
/* 482 */     Lookahead lookahead = this.grammar.theLLkAnalyzer.FOLLOW(1, paramRuleBlock.endNode);
/* 483 */     printSet(this.grammar.maxk, 1, lookahead);
/*     */   }
/*     */   
/*     */   protected void genGenericBlock(AlternativeBlock paramAlternativeBlock, String paramString) {
/* 487 */     if (paramAlternativeBlock.alternatives.size() > 1) {
/*     */       
/* 489 */       _println("");
/* 490 */       if (!this.firstElementInAlt) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 496 */         _println("(");
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 506 */         _print("(");
/*     */       } 
/*     */     } else {
/*     */       
/* 510 */       _print("( ");
/*     */     } 
/*     */ 
/*     */     
/* 514 */     genCommonBlock(paramAlternativeBlock);
/* 515 */     if (paramAlternativeBlock.alternatives.size() > 1) {
/* 516 */       _println("");
/* 517 */       print(")" + paramString + " ");
/*     */       
/* 519 */       if (!(paramAlternativeBlock.next instanceof BlockEndElement)) {
/* 520 */         _println("");
/* 521 */         print("");
/*     */       } 
/*     */     } else {
/*     */       
/* 525 */       _print(")" + paramString + " ");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void genHeader() {
/* 531 */     println("<?xml version=\"1.0\" standalone=\"no\"?>");
/* 532 */     println("<!DOCTYPE book PUBLIC \"-//OASIS//DTD DocBook V3.1//EN\">");
/* 533 */     println("<book lang=\"en\">");
/* 534 */     println("<bookinfo>");
/* 535 */     println("<title>Grammar " + this.grammar.getClassName() + "</title>");
/* 536 */     println("  <author>");
/* 537 */     println("    <firstname></firstname>");
/* 538 */     println("    <othername></othername>");
/* 539 */     println("    <surname></surname>");
/* 540 */     println("    <affiliation>");
/* 541 */     println("     <address>");
/* 542 */     println("     <email></email>");
/* 543 */     println("     </address>");
/* 544 */     println("    </affiliation>");
/* 545 */     println("  </author>");
/* 546 */     println("  <othercredit>");
/* 547 */     println("    <contrib>");
/* 548 */     println("    Generated by <ulink url=\"http://www.ANTLR.org/\">ANTLR</ulink>" + Tool.version);
/* 549 */     println("    from " + this.antlrTool.grammarFile);
/* 550 */     println("    </contrib>");
/* 551 */     println("  </othercredit>");
/* 552 */     println("  <pubdate></pubdate>");
/* 553 */     println("  <abstract>");
/* 554 */     println("  <para>");
/* 555 */     println("  </para>");
/* 556 */     println("  </abstract>");
/* 557 */     println("</bookinfo>");
/* 558 */     println("<chapter>");
/* 559 */     println("<title></title>");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void genLookaheadSetForAlt(Alternative paramAlternative) {
/* 564 */     if (this.doingLexRules && paramAlternative.cache[1].containsEpsilon()) {
/* 565 */       println("MATCHES ALL");
/*     */       return;
/*     */     } 
/* 568 */     int i = paramAlternative.lookaheadDepth;
/* 569 */     if (i == Integer.MAX_VALUE)
/*     */     {
/*     */       
/* 572 */       i = this.grammar.maxk;
/*     */     }
/* 574 */     for (byte b = 1; b <= i; b++) {
/* 575 */       Lookahead lookahead = paramAlternative.cache[b];
/* 576 */       printSet(i, b, lookahead);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void genLookaheadSetForBlock(AlternativeBlock paramAlternativeBlock) {
/* 586 */     int i = 0; byte b;
/* 587 */     for (b = 0; b < paramAlternativeBlock.alternatives.size(); b++) {
/* 588 */       Alternative alternative = paramAlternativeBlock.getAlternativeAt(b);
/* 589 */       if (alternative.lookaheadDepth == Integer.MAX_VALUE) {
/* 590 */         i = this.grammar.maxk;
/*     */         break;
/*     */       } 
/* 593 */       if (i < alternative.lookaheadDepth) {
/* 594 */         i = alternative.lookaheadDepth;
/*     */       }
/*     */     } 
/*     */     
/* 598 */     for (b = 1; b <= i; b++) {
/* 599 */       Lookahead lookahead = this.grammar.theLLkAnalyzer.look(b, paramAlternativeBlock);
/* 600 */       printSet(i, b, lookahead);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void genNextToken() {
/* 609 */     println("");
/* 610 */     println("/** Lexer nextToken rule:");
/* 611 */     println(" *  The lexer nextToken rule is synthesized from all of the user-defined");
/* 612 */     println(" *  lexer rules.  It logically consists of one big alternative block with");
/* 613 */     println(" *  each user-defined rule being an alternative.");
/* 614 */     println(" */");
/*     */ 
/*     */ 
/*     */     
/* 618 */     RuleBlock ruleBlock = MakeGrammar.createNextTokenRule(this.grammar, this.grammar.rules, "nextToken");
/*     */ 
/*     */     
/* 621 */     RuleSymbol ruleSymbol = new RuleSymbol("mnextToken");
/* 622 */     ruleSymbol.setDefined();
/* 623 */     ruleSymbol.setBlock(ruleBlock);
/* 624 */     ruleSymbol.access = "private";
/* 625 */     this.grammar.define(ruleSymbol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 638 */     genCommonBlock(ruleBlock);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void genRule(RuleSymbol paramRuleSymbol) {
/* 645 */     if (paramRuleSymbol == null || !paramRuleSymbol.isDefined())
/* 646 */       return;  println("");
/*     */     
/* 648 */     if (paramRuleSymbol.access.length() != 0 && 
/* 649 */       !paramRuleSymbol.access.equals("public")) {
/* 650 */       _print("<para>" + paramRuleSymbol.access + " </para>");
/*     */     }
/*     */ 
/*     */     
/* 654 */     println("<section id=\"" + QuoteForId(paramRuleSymbol.getId()) + "\">");
/* 655 */     println("<title>" + paramRuleSymbol.getId() + "</title>");
/* 656 */     if (paramRuleSymbol.comment != null) {
/* 657 */       _println("<para>" + HTMLEncode(paramRuleSymbol.comment) + "</para>");
/*     */     }
/* 659 */     println("<para>");
/*     */ 
/*     */     
/* 662 */     RuleBlock ruleBlock = paramRuleSymbol.getBlock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 674 */     _println("");
/* 675 */     print(paramRuleSymbol.getId() + ":\t");
/* 676 */     this.tabs++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 682 */     genCommonBlock(ruleBlock);
/*     */     
/* 684 */     _println("");
/*     */     
/* 686 */     this.tabs--;
/* 687 */     _println("</para>");
/* 688 */     _println("</section><!-- section \"" + paramRuleSymbol.getId() + "\" -->");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void genSynPred(SynPredBlock paramSynPredBlock) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void genTail() {
/* 700 */     println("</chapter>");
/* 701 */     println("</book>");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void genTokenTypes(TokenManager paramTokenManager) throws IOException {
/* 707 */     this.antlrTool.reportProgress("Generating " + paramTokenManager.getName() + TokenTypesFileSuffix + TokenTypesFileExt);
/* 708 */     this.currentOutput = this.antlrTool.openOutputFile(paramTokenManager.getName() + TokenTypesFileSuffix + TokenTypesFileExt);
/*     */     
/* 710 */     this.tabs = 0;
/*     */ 
/*     */     
/* 713 */     genHeader();
/*     */ 
/*     */ 
/*     */     
/* 717 */     println("");
/* 718 */     println("*** Tokens used by the parser");
/* 719 */     println("This is a list of the token numeric values and the corresponding");
/* 720 */     println("token identifiers.  Some tokens are literals, and because of that");
/* 721 */     println("they have no identifiers.  Literals are double-quoted.");
/* 722 */     this.tabs++;
/*     */ 
/*     */     
/* 725 */     Vector vector = paramTokenManager.getVocabulary();
/* 726 */     for (byte b = 4; b < vector.size(); b++) {
/* 727 */       String str = (String)vector.elementAt(b);
/* 728 */       if (str != null) {
/* 729 */         println(str + " = " + b);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 734 */     this.tabs--;
/* 735 */     println("*** End of tokens used by the parser");
/*     */ 
/*     */     
/* 738 */     this.currentOutput.close();
/* 739 */     this.currentOutput = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String processActionForSpecialSymbols(String paramString, int paramInt, RuleBlock paramRuleBlock, ActionTransInfo paramActionTransInfo) {
/* 747 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getASTCreateString(Vector paramVector) {
/* 754 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getASTCreateString(GrammarAtom paramGrammarAtom, String paramString) {
/* 761 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mapTreeId(String paramString, ActionTransInfo paramActionTransInfo) {
/* 771 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printSet(int paramInt1, int paramInt2, Lookahead paramLookahead) {
/* 780 */     byte b1 = 5;
/*     */     
/* 782 */     int[] arrayOfInt = paramLookahead.fset.toArray();
/*     */     
/* 784 */     if (paramInt1 != 1) {
/* 785 */       print("k==" + paramInt2 + ": {");
/*     */     } else {
/*     */       
/* 788 */       print("{ ");
/*     */     } 
/* 790 */     if (arrayOfInt.length > b1) {
/* 791 */       _println("");
/* 792 */       this.tabs++;
/* 793 */       print("");
/*     */     } 
/*     */     
/* 796 */     byte b2 = 0;
/* 797 */     for (byte b3 = 0; b3 < arrayOfInt.length; b3++) {
/* 798 */       b2++;
/* 799 */       if (b2 > b1) {
/* 800 */         _println("");
/* 801 */         print("");
/* 802 */         b2 = 0;
/*     */       } 
/* 804 */       if (this.doingLexRules) {
/* 805 */         _print(this.charFormatter.literalChar(arrayOfInt[b3]));
/*     */       } else {
/*     */         
/* 808 */         _print((String)this.grammar.tokenManager.getVocabulary().elementAt(arrayOfInt[b3]));
/*     */       } 
/* 810 */       if (b3 != arrayOfInt.length - 1) {
/* 811 */         _print(", ");
/*     */       }
/*     */     } 
/*     */     
/* 815 */     if (arrayOfInt.length > b1) {
/* 816 */       _println("");
/* 817 */       this.tabs--;
/* 818 */       print("");
/*     */     } 
/* 820 */     _println(" }");
/*     */   }
/*     */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\DocBookCodeGenerator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */