package antlr;

public interface CharFormatter {
  String escapeChar(int paramInt, boolean paramBoolean);
  
  String escapeString(String paramString);
  
  String literalChar(int paramInt);
  
  String literalString(String paramString);
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\CharFormatter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */