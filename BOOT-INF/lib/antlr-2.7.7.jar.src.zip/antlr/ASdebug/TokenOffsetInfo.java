/*    */ package antlr.ASdebug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TokenOffsetInfo
/*    */ {
/*    */   public final int beginOffset;
/*    */   public final int length;
/*    */   
/*    */   public TokenOffsetInfo(int paramInt1, int paramInt2) {
/* 14 */     this.beginOffset = paramInt1;
/* 15 */     this.length = paramInt2;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getEndOffset() {
/* 20 */     return this.beginOffset + this.length - 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\ASdebug\TokenOffsetInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */