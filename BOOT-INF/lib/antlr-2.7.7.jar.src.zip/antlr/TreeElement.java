/*    */ package antlr;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TreeElement
/*    */   extends AlternativeBlock
/*    */ {
/*    */   GrammarAtom root;
/*    */   
/*    */   public TreeElement(Grammar paramGrammar, Token paramToken) {
/* 15 */     super(paramGrammar, paramToken, false);
/*    */   }
/*    */   
/*    */   public void generate() {
/* 19 */     this.grammar.generator.gen(this);
/*    */   }
/*    */   
/*    */   public Lookahead look(int paramInt) {
/* 23 */     return this.grammar.theLLkAnalyzer.look(paramInt, this);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 27 */     String str = " #(" + this.root;
/* 28 */     Alternative alternative = (Alternative)this.alternatives.elementAt(0);
/* 29 */     AlternativeElement alternativeElement = alternative.head;
/* 30 */     while (alternativeElement != null) {
/* 31 */       str = str + alternativeElement;
/* 32 */       alternativeElement = alternativeElement.next;
/*    */     } 
/* 34 */     return str + " )";
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\antlr-2.7.7.jar!\antlr\TreeElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */