/*    */ package org.springframework.boot.jarmode.layertools;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MissingValueException
/*    */   extends RuntimeException
/*    */ {
/*    */   private final String optionName;
/*    */   
/*    */   MissingValueException(String optionName) {
/* 29 */     this.optionName = optionName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 34 */     return "--" + this.optionName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\spring-boot-jarmode-layertools-2.4.6.jar!\org\springframework\boot\jarmode\layertools\MissingValueException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */