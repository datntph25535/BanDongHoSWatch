/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.JarURLConnection;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.file.Paths;
/*     */ import java.security.CodeSource;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.jar.JarFile;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Context
/*     */ {
/*     */   private final File jarFile;
/*     */   private final File workingDir;
/*     */   private final String relativeDir;
/*     */   
/*     */   Context() {
/*  49 */     this(getSourceJarFile(), Paths.get(".", new String[0]).toAbsolutePath().normalize().toFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Context(File jarFile, File workingDir) {
/*  58 */     Assert.state((jarFile != null && jarFile.isFile() && jarFile.exists() && jarFile
/*  59 */         .getName().toLowerCase().endsWith(".jar")), "Unable to find source JAR");
/*  60 */     this.jarFile = jarFile;
/*  61 */     this.workingDir = workingDir;
/*  62 */     this.relativeDir = deduceRelativeDir(jarFile.getParentFile(), this.workingDir);
/*     */   }
/*     */   
/*     */   private static File getSourceJarFile() {
/*     */     try {
/*  67 */       ProtectionDomain domain = Context.class.getProtectionDomain();
/*  68 */       CodeSource codeSource = (domain != null) ? domain.getCodeSource() : null;
/*  69 */       URL location = (codeSource != null) ? codeSource.getLocation() : null;
/*  70 */       File source = (location != null) ? findSource(location) : null;
/*  71 */       if (source != null && source.exists()) {
/*  72 */         return source.getAbsoluteFile();
/*     */       }
/*  74 */       return null;
/*     */     }
/*  76 */     catch (Exception ex) {
/*  77 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static File findSource(URL location) throws IOException, URISyntaxException {
/*  82 */     URLConnection connection = location.openConnection();
/*  83 */     if (connection instanceof JarURLConnection) {
/*  84 */       return getRootJarFile(((JarURLConnection)connection).getJarFile());
/*     */     }
/*  86 */     return new File(location.toURI());
/*     */   }
/*     */   
/*     */   private static File getRootJarFile(JarFile jarFile) {
/*  90 */     String name = jarFile.getName();
/*  91 */     int separator = name.indexOf("!/");
/*  92 */     if (separator > 0) {
/*  93 */       name = name.substring(0, separator);
/*     */     }
/*  95 */     return new File(name);
/*     */   }
/*     */   
/*     */   private String deduceRelativeDir(File sourceDirectory, File workingDir) {
/*  99 */     String sourcePath = sourceDirectory.getAbsolutePath();
/* 100 */     String workingPath = workingDir.getAbsolutePath();
/* 101 */     if (sourcePath.equals(workingPath) || !sourcePath.startsWith(workingPath)) {
/* 102 */       return null;
/*     */     }
/* 104 */     String relativePath = sourcePath.substring(workingPath.length() + 1);
/* 105 */     return !relativePath.isEmpty() ? relativePath : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getJarFile() {
/* 113 */     return this.jarFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getWorkingDir() {
/* 121 */     return this.workingDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getRelativeJarDir() {
/* 130 */     return this.relativeDir;
/*     */   }
/*     */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\spring-boot-jarmode-layertools-2.4.6.jar!\org\springframework\boot\jarmode\layertools\Context.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */