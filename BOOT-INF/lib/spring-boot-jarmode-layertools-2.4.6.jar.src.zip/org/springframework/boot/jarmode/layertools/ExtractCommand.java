/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.file.Files;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExtractCommand
/*     */   extends Command
/*     */ {
/*  40 */   static final Command.Option DESTINATION_OPTION = Command.Option.of("destination", "string", "The destination to extract files to");
/*     */   
/*     */   private final Context context;
/*     */   
/*     */   private final Layers layers;
/*     */   
/*     */   ExtractCommand(Context context) {
/*  47 */     this(context, Layers.get(context));
/*     */   }
/*     */   
/*     */   ExtractCommand(Context context, Layers layers) {
/*  51 */     super("extract", "Extracts layers from the jar for image creation", Command.Options.of(new Command.Option[] { DESTINATION_OPTION
/*  52 */           }, ), Command.Parameters.of(new String[] { "[<layer>...]" }));
/*  53 */     this.context = context;
/*  54 */     this.layers = layers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void run(Map<Command.Option, String> options, List<String> parameters) {
/*     */     try {
/*  61 */       File destination = options.containsKey(DESTINATION_OPTION) ? new File(options.get(DESTINATION_OPTION)) : this.context.getWorkingDir();
/*  62 */       for (String layer : this.layers) {
/*  63 */         if (parameters.isEmpty() || parameters.contains(layer)) {
/*  64 */           mkDirs(new File(destination, layer));
/*     */         }
/*     */       } 
/*  67 */       try (ZipInputStream zip = new ZipInputStream(new FileInputStream(this.context.getJarFile()))) {
/*  68 */         ZipEntry entry = zip.getNextEntry();
/*  69 */         Assert.state((entry != null), "File '" + this.context.getJarFile().toString() + "' is not compatible with layertools; ensure jar file is valid and launch script is not enabled");
/*     */         
/*  71 */         while (entry != null) {
/*  72 */           if (!entry.isDirectory()) {
/*  73 */             String layer = this.layers.getLayer(entry);
/*  74 */             if (parameters.isEmpty() || parameters.contains(layer)) {
/*  75 */               write(zip, entry, new File(destination, layer));
/*     */             }
/*     */           } 
/*  78 */           entry = zip.getNextEntry();
/*     */         }
/*     */       
/*     */       } 
/*  82 */     } catch (IOException ex) {
/*  83 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void write(ZipInputStream zip, ZipEntry entry, File destination) throws IOException {
/*  88 */     String canonicalOutputPath = destination.getCanonicalPath() + File.separator;
/*  89 */     File file = new File(destination, entry.getName());
/*  90 */     String canonicalEntryPath = file.getCanonicalPath();
/*  91 */     Assert.state(canonicalEntryPath.startsWith(canonicalOutputPath), () -> "Entry '" + entry.getName() + "' would be written to '" + canonicalEntryPath + "'. This is outside the output location of '" + canonicalOutputPath + "'. Verify the contents of your archive.");
/*     */ 
/*     */ 
/*     */     
/*  95 */     mkParentDirs(file);
/*  96 */     try (OutputStream out = new FileOutputStream(file)) {
/*  97 */       StreamUtils.copy(zip, out);
/*     */     } 
/*  99 */     Files.setAttribute(file.toPath(), "creationTime", entry.getCreationTime(), new java.nio.file.LinkOption[0]);
/*     */   }
/*     */   
/*     */   private void mkParentDirs(File file) throws IOException {
/* 103 */     mkDirs(file.getParentFile());
/*     */   }
/*     */   
/*     */   private void mkDirs(File file) throws IOException {
/* 107 */     if (!file.exists() && !file.mkdirs())
/* 108 */       throw new IOException("Unable to create directory " + file); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\spring-boot-jarmode-layertools-2.4.6.jar!\org\springframework\boot\jarmode\layertools\ExtractCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */