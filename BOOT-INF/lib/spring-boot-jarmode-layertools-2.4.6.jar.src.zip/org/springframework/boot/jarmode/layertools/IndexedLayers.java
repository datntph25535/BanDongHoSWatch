/*     */ package org.springframework.boot.jarmode.layertools;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IndexedLayers
/*     */   implements Layers
/*     */ {
/*  44 */   private final Map<String, List<String>> layers = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   IndexedLayers(String indexFile) {
/*  48 */     String[] lines = (String[])Arrays.<String>stream(indexFile.split("\n")).map(line -> line.replace("\r", "")).filter(StringUtils::hasText).toArray(x$0 -> new String[x$0]);
/*  49 */     List<String> contents = null;
/*  50 */     for (String line : lines) {
/*  51 */       if (line.startsWith("- ")) {
/*  52 */         contents = new ArrayList<>();
/*  53 */         this.layers.put(line.substring(3, line.length() - 2), contents);
/*     */       }
/*  55 */       else if (line.startsWith("  - ")) {
/*  56 */         contents.add(line.substring(5, line.length() - 1));
/*     */       } else {
/*     */         
/*  59 */         throw new IllegalStateException("Layer index file is malformed");
/*     */       } 
/*     */     } 
/*  62 */     Assert.state(!this.layers.isEmpty(), "Empty layer index file loaded");
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String> iterator() {
/*  67 */     return this.layers.keySet().iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLayer(ZipEntry entry) {
/*  72 */     return getLayer(entry.getName());
/*     */   }
/*     */   
/*     */   private String getLayer(String name) {
/*  76 */     for (Map.Entry<String, List<String>> entry : this.layers.entrySet()) {
/*  77 */       for (String candidate : entry.getValue()) {
/*  78 */         if (candidate.equals(name) || (candidate.endsWith("/") && name.startsWith(candidate))) {
/*  79 */           return entry.getKey();
/*     */         }
/*     */       } 
/*     */     } 
/*  83 */     throw new IllegalStateException("No layer defined in index for file '" + name + "'");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static IndexedLayers get(Context context) {
/*     */     try {
/*  94 */       try (JarFile jarFile = new JarFile(context.getJarFile())) {
/*  95 */         ZipEntry entry = jarFile.getEntry("BOOT-INF/layers.idx");
/*  96 */         if (entry != null) {
/*  97 */           String indexFile = StreamUtils.copyToString(jarFile.getInputStream(entry), StandardCharsets.UTF_8);
/*  98 */           return new IndexedLayers(indexFile);
/*     */         } 
/*     */       } 
/* 101 */       return null;
/*     */     }
/* 103 */     catch (FileNotFoundException|java.nio.file.NoSuchFileException ex) {
/* 104 */       return null;
/*     */     }
/* 106 */     catch (IOException ex) {
/* 107 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\spring-boot-jarmode-layertools-2.4.6.jar!\org\springframework\boot\jarmode\layertools\IndexedLayers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */