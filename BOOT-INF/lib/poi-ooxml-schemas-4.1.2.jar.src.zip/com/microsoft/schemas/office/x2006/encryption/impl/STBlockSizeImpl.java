package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STBlockSize;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;

public class STBlockSizeImpl extends JavaIntHolderEx implements STBlockSize {
  private static final long serialVersionUID = 1L;
  
  public STBlockSizeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STBlockSizeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\x2006\encryption\impl\STBlockSizeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */