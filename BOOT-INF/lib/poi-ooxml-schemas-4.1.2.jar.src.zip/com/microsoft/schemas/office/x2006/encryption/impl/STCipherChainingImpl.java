package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STCipherChaining;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STCipherChainingImpl extends JavaStringEnumerationHolderEx implements STCipherChaining {
  private static final long serialVersionUID = 1L;
  
  public STCipherChainingImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STCipherChainingImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\x2006\encryption\impl\STCipherChainingImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */