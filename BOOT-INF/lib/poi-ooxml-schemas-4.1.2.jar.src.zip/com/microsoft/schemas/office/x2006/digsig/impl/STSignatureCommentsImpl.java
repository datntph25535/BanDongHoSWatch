package com.microsoft.schemas.office.x2006.digsig.impl;

import com.microsoft.schemas.office.x2006.digsig.STSignatureComments;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringHolderEx;

public class STSignatureCommentsImpl extends JavaStringHolderEx implements STSignatureComments {
  private static final long serialVersionUID = 1L;
  
  public STSignatureCommentsImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STSignatureCommentsImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\x2006\digsig\impl\STSignatureCommentsImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */