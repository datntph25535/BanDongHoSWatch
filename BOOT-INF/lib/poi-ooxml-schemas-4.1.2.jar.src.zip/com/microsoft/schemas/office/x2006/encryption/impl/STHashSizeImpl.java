package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STHashSize;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;

public class STHashSizeImpl extends JavaIntHolderEx implements STHashSize {
  private static final long serialVersionUID = 1L;
  
  public STHashSizeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STHashSizeImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\x2006\encryption\impl\STHashSizeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */