package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.CTEncryption;
import com.microsoft.schemas.office.x2006.encryption.EncryptionDocument;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class EncryptionDocumentImpl extends XmlComplexContentImpl implements EncryptionDocument {
  private static final long serialVersionUID = 1L;
  
  private static final QName ENCRYPTION$0 = new QName("http://schemas.microsoft.com/office/2006/encryption", "encryption");
  
  public EncryptionDocumentImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTEncryption getEncryption() {
    synchronized (monitor()) {
      check_orphaned();
      CTEncryption cTEncryption = null;
      cTEncryption = (CTEncryption)get_store().find_element_user(ENCRYPTION$0, 0);
      if (cTEncryption == null)
        return null; 
      return cTEncryption;
    } 
  }
  
  public void setEncryption(CTEncryption paramCTEncryption) {
    generatedSetterHelperImpl((XmlObject)paramCTEncryption, ENCRYPTION$0, 0, (short)1);
  }
  
  public CTEncryption addNewEncryption() {
    synchronized (monitor()) {
      check_orphaned();
      CTEncryption cTEncryption = null;
      cTEncryption = (CTEncryption)get_store().add_element_user(ENCRYPTION$0);
      return cTEncryption;
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\x2006\encryption\impl\EncryptionDocumentImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */