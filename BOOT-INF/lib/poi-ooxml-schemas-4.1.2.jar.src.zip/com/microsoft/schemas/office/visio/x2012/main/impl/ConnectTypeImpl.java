package com.microsoft.schemas.office.visio.x2012.main.impl;

import com.microsoft.schemas.office.visio.x2012.main.ConnectType;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlInt;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.XmlUnsignedInt;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class ConnectTypeImpl extends XmlComplexContentImpl implements ConnectType {
  private static final long serialVersionUID = 1L;
  
  private static final QName FROMSHEET$0 = new QName("", "FromSheet");
  
  private static final QName FROMCELL$2 = new QName("", "FromCell");
  
  private static final QName FROMPART$4 = new QName("", "FromPart");
  
  private static final QName TOSHEET$6 = new QName("", "ToSheet");
  
  private static final QName TOCELL$8 = new QName("", "ToCell");
  
  private static final QName TOPART$10 = new QName("", "ToPart");
  
  public ConnectTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public long getFromSheet() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(FROMSHEET$0);
      if (simpleValue == null)
        return 0L; 
      return simpleValue.getLongValue();
    } 
  }
  
  public XmlUnsignedInt xgetFromSheet() {
    synchronized (monitor()) {
      check_orphaned();
      XmlUnsignedInt xmlUnsignedInt = null;
      xmlUnsignedInt = (XmlUnsignedInt)get_store().find_attribute_user(FROMSHEET$0);
      return xmlUnsignedInt;
    } 
  }
  
  public void setFromSheet(long paramLong) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(FROMSHEET$0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(FROMSHEET$0); 
      simpleValue.setLongValue(paramLong);
    } 
  }
  
  public void xsetFromSheet(XmlUnsignedInt paramXmlUnsignedInt) {
    synchronized (monitor()) {
      check_orphaned();
      XmlUnsignedInt xmlUnsignedInt = null;
      xmlUnsignedInt = (XmlUnsignedInt)get_store().find_attribute_user(FROMSHEET$0);
      if (xmlUnsignedInt == null)
        xmlUnsignedInt = (XmlUnsignedInt)get_store().add_attribute_user(FROMSHEET$0); 
      xmlUnsignedInt.set((XmlObject)paramXmlUnsignedInt);
    } 
  }
  
  public String getFromCell() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(FROMCELL$2);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlString xgetFromCell() {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_attribute_user(FROMCELL$2);
      return xmlString;
    } 
  }
  
  public boolean isSetFromCell() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(FROMCELL$2) != null);
    } 
  }
  
  public void setFromCell(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(FROMCELL$2);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(FROMCELL$2); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetFromCell(XmlString paramXmlString) {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_attribute_user(FROMCELL$2);
      if (xmlString == null)
        xmlString = (XmlString)get_store().add_attribute_user(FROMCELL$2); 
      xmlString.set((XmlObject)paramXmlString);
    } 
  }
  
  public void unsetFromCell() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(FROMCELL$2);
    } 
  }
  
  public int getFromPart() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(FROMPART$4);
      if (simpleValue == null)
        return 0; 
      return simpleValue.getIntValue();
    } 
  }
  
  public XmlInt xgetFromPart() {
    synchronized (monitor()) {
      check_orphaned();
      XmlInt xmlInt = null;
      xmlInt = (XmlInt)get_store().find_attribute_user(FROMPART$4);
      return xmlInt;
    } 
  }
  
  public boolean isSetFromPart() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(FROMPART$4) != null);
    } 
  }
  
  public void setFromPart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(FROMPART$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(FROMPART$4); 
      simpleValue.setIntValue(paramInt);
    } 
  }
  
  public void xsetFromPart(XmlInt paramXmlInt) {
    synchronized (monitor()) {
      check_orphaned();
      XmlInt xmlInt = null;
      xmlInt = (XmlInt)get_store().find_attribute_user(FROMPART$4);
      if (xmlInt == null)
        xmlInt = (XmlInt)get_store().add_attribute_user(FROMPART$4); 
      xmlInt.set((XmlObject)paramXmlInt);
    } 
  }
  
  public void unsetFromPart() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(FROMPART$4);
    } 
  }
  
  public long getToSheet() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TOSHEET$6);
      if (simpleValue == null)
        return 0L; 
      return simpleValue.getLongValue();
    } 
  }
  
  public XmlUnsignedInt xgetToSheet() {
    synchronized (monitor()) {
      check_orphaned();
      XmlUnsignedInt xmlUnsignedInt = null;
      xmlUnsignedInt = (XmlUnsignedInt)get_store().find_attribute_user(TOSHEET$6);
      return xmlUnsignedInt;
    } 
  }
  
  public void setToSheet(long paramLong) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TOSHEET$6);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(TOSHEET$6); 
      simpleValue.setLongValue(paramLong);
    } 
  }
  
  public void xsetToSheet(XmlUnsignedInt paramXmlUnsignedInt) {
    synchronized (monitor()) {
      check_orphaned();
      XmlUnsignedInt xmlUnsignedInt = null;
      xmlUnsignedInt = (XmlUnsignedInt)get_store().find_attribute_user(TOSHEET$6);
      if (xmlUnsignedInt == null)
        xmlUnsignedInt = (XmlUnsignedInt)get_store().add_attribute_user(TOSHEET$6); 
      xmlUnsignedInt.set((XmlObject)paramXmlUnsignedInt);
    } 
  }
  
  public String getToCell() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TOCELL$8);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlString xgetToCell() {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_attribute_user(TOCELL$8);
      return xmlString;
    } 
  }
  
  public boolean isSetToCell() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(TOCELL$8) != null);
    } 
  }
  
  public void setToCell(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TOCELL$8);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(TOCELL$8); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetToCell(XmlString paramXmlString) {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_attribute_user(TOCELL$8);
      if (xmlString == null)
        xmlString = (XmlString)get_store().add_attribute_user(TOCELL$8); 
      xmlString.set((XmlObject)paramXmlString);
    } 
  }
  
  public void unsetToCell() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(TOCELL$8);
    } 
  }
  
  public int getToPart() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TOPART$10);
      if (simpleValue == null)
        return 0; 
      return simpleValue.getIntValue();
    } 
  }
  
  public XmlInt xgetToPart() {
    synchronized (monitor()) {
      check_orphaned();
      XmlInt xmlInt = null;
      xmlInt = (XmlInt)get_store().find_attribute_user(TOPART$10);
      return xmlInt;
    } 
  }
  
  public boolean isSetToPart() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(TOPART$10) != null);
    } 
  }
  
  public void setToPart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TOPART$10);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(TOPART$10); 
      simpleValue.setIntValue(paramInt);
    } 
  }
  
  public void xsetToPart(XmlInt paramXmlInt) {
    synchronized (monitor()) {
      check_orphaned();
      XmlInt xmlInt = null;
      xmlInt = (XmlInt)get_store().find_attribute_user(TOPART$10);
      if (xmlInt == null)
        xmlInt = (XmlInt)get_store().add_attribute_user(TOPART$10); 
      xmlInt.set((XmlObject)paramXmlInt);
    } 
  }
  
  public void unsetToPart() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(TOPART$10);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\visio\x2012\main\impl\ConnectTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */