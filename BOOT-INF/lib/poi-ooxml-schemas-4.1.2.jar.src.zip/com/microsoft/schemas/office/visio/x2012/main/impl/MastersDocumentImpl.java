package com.microsoft.schemas.office.visio.x2012.main.impl;

import com.microsoft.schemas.office.visio.x2012.main.MastersDocument;
import com.microsoft.schemas.office.visio.x2012.main.MastersType;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class MastersDocumentImpl extends XmlComplexContentImpl implements MastersDocument {
  private static final long serialVersionUID = 1L;
  
  private static final QName MASTERS$0 = new QName("http://schemas.microsoft.com/office/visio/2012/main", "Masters");
  
  public MastersDocumentImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public MastersType getMasters() {
    synchronized (monitor()) {
      check_orphaned();
      MastersType mastersType = null;
      mastersType = (MastersType)get_store().find_element_user(MASTERS$0, 0);
      if (mastersType == null)
        return null; 
      return mastersType;
    } 
  }
  
  public void setMasters(MastersType paramMastersType) {
    generatedSetterHelperImpl((XmlObject)paramMastersType, MASTERS$0, 0, (short)1);
  }
  
  public MastersType addNewMasters() {
    synchronized (monitor()) {
      check_orphaned();
      MastersType mastersType = null;
      mastersType = (MastersType)get_store().add_element_user(MASTERS$0);
      return mastersType;
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\visio\x2012\main\impl\MastersDocumentImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */