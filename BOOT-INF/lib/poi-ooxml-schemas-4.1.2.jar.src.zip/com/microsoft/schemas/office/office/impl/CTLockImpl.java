package com.microsoft.schemas.office.office.impl;

import com.microsoft.schemas.office.office.CTLock;
import com.microsoft.schemas.office.office.STTrueFalse;
import com.microsoft.schemas.vml.STExt;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.StringEnumAbstractBase;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class CTLockImpl extends XmlComplexContentImpl implements CTLock {
  private static final long serialVersionUID = 1L;
  
  private static final QName EXT$0 = new QName("urn:schemas-microsoft-com:vml", "ext");
  
  private static final QName POSITION$2 = new QName("", "position");
  
  private static final QName SELECTION$4 = new QName("", "selection");
  
  private static final QName GROUPING$6 = new QName("", "grouping");
  
  private static final QName UNGROUPING$8 = new QName("", "ungrouping");
  
  private static final QName ROTATION$10 = new QName("", "rotation");
  
  private static final QName CROPPING$12 = new QName("", "cropping");
  
  private static final QName VERTICIES$14 = new QName("", "verticies");
  
  private static final QName ADJUSTHANDLES$16 = new QName("", "adjusthandles");
  
  private static final QName TEXT$18 = new QName("", "text");
  
  private static final QName ASPECTRATIO$20 = new QName("", "aspectratio");
  
  private static final QName SHAPETYPE$22 = new QName("", "shapetype");
  
  public CTLockImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public STExt.Enum getExt() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(EXT$0);
      if (simpleValue == null)
        return null; 
      return (STExt.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STExt xgetExt() {
    synchronized (monitor()) {
      check_orphaned();
      STExt sTExt = null;
      sTExt = (STExt)get_store().find_attribute_user(EXT$0);
      return sTExt;
    } 
  }
  
  public boolean isSetExt() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(EXT$0) != null);
    } 
  }
  
  public void setExt(STExt.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(EXT$0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(EXT$0); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetExt(STExt paramSTExt) {
    synchronized (monitor()) {
      check_orphaned();
      STExt sTExt = null;
      sTExt = (STExt)get_store().find_attribute_user(EXT$0);
      if (sTExt == null)
        sTExt = (STExt)get_store().add_attribute_user(EXT$0); 
      sTExt.set((XmlObject)paramSTExt);
    } 
  }
  
  public void unsetExt() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(EXT$0);
    } 
  }
  
  public STTrueFalse.Enum getPosition() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(POSITION$2);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetPosition() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(POSITION$2);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetPosition() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(POSITION$2) != null);
    } 
  }
  
  public void setPosition(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(POSITION$2);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(POSITION$2); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetPosition(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(POSITION$2);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(POSITION$2); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetPosition() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(POSITION$2);
    } 
  }
  
  public STTrueFalse.Enum getSelection() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(SELECTION$4);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetSelection() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(SELECTION$4);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetSelection() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(SELECTION$4) != null);
    } 
  }
  
  public void setSelection(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(SELECTION$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(SELECTION$4); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetSelection(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(SELECTION$4);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(SELECTION$4); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetSelection() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(SELECTION$4);
    } 
  }
  
  public STTrueFalse.Enum getGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(GROUPING$6);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(GROUPING$6);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(GROUPING$6) != null);
    } 
  }
  
  public void setGrouping(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(GROUPING$6);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(GROUPING$6); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetGrouping(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(GROUPING$6);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(GROUPING$6); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(GROUPING$6);
    } 
  }
  
  public STTrueFalse.Enum getUngrouping() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(UNGROUPING$8);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetUngrouping() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(UNGROUPING$8);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetUngrouping() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(UNGROUPING$8) != null);
    } 
  }
  
  public void setUngrouping(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(UNGROUPING$8);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(UNGROUPING$8); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetUngrouping(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(UNGROUPING$8);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(UNGROUPING$8); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetUngrouping() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(UNGROUPING$8);
    } 
  }
  
  public STTrueFalse.Enum getRotation() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ROTATION$10);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetRotation() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(ROTATION$10);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetRotation() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ROTATION$10) != null);
    } 
  }
  
  public void setRotation(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ROTATION$10);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ROTATION$10); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetRotation(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(ROTATION$10);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(ROTATION$10); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetRotation() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ROTATION$10);
    } 
  }
  
  public STTrueFalse.Enum getCropping() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(CROPPING$12);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetCropping() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(CROPPING$12);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetCropping() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(CROPPING$12) != null);
    } 
  }
  
  public void setCropping(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(CROPPING$12);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(CROPPING$12); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetCropping(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(CROPPING$12);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(CROPPING$12); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetCropping() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(CROPPING$12);
    } 
  }
  
  public STTrueFalse.Enum getVerticies() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(VERTICIES$14);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetVerticies() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(VERTICIES$14);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetVerticies() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(VERTICIES$14) != null);
    } 
  }
  
  public void setVerticies(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(VERTICIES$14);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(VERTICIES$14); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetVerticies(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(VERTICIES$14);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(VERTICIES$14); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetVerticies() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(VERTICIES$14);
    } 
  }
  
  public STTrueFalse.Enum getAdjusthandles() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ADJUSTHANDLES$16);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetAdjusthandles() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(ADJUSTHANDLES$16);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetAdjusthandles() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ADJUSTHANDLES$16) != null);
    } 
  }
  
  public void setAdjusthandles(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ADJUSTHANDLES$16);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ADJUSTHANDLES$16); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetAdjusthandles(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(ADJUSTHANDLES$16);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(ADJUSTHANDLES$16); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetAdjusthandles() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ADJUSTHANDLES$16);
    } 
  }
  
  public STTrueFalse.Enum getText() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TEXT$18);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetText() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(TEXT$18);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetText() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(TEXT$18) != null);
    } 
  }
  
  public void setText(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TEXT$18);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(TEXT$18); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetText(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(TEXT$18);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(TEXT$18); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetText() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(TEXT$18);
    } 
  }
  
  public STTrueFalse.Enum getAspectratio() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ASPECTRATIO$20);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetAspectratio() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(ASPECTRATIO$20);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetAspectratio() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ASPECTRATIO$20) != null);
    } 
  }
  
  public void setAspectratio(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ASPECTRATIO$20);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ASPECTRATIO$20); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetAspectratio(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(ASPECTRATIO$20);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(ASPECTRATIO$20); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetAspectratio() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ASPECTRATIO$20);
    } 
  }
  
  public STTrueFalse.Enum getShapetype() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(SHAPETYPE$22);
      if (simpleValue == null)
        return null; 
      return (STTrueFalse.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STTrueFalse xgetShapetype() {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(SHAPETYPE$22);
      return sTTrueFalse;
    } 
  }
  
  public boolean isSetShapetype() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(SHAPETYPE$22) != null);
    } 
  }
  
  public void setShapetype(STTrueFalse.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(SHAPETYPE$22);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(SHAPETYPE$22); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetShapetype(STTrueFalse paramSTTrueFalse) {
    synchronized (monitor()) {
      check_orphaned();
      STTrueFalse sTTrueFalse = null;
      sTTrueFalse = (STTrueFalse)get_store().find_attribute_user(SHAPETYPE$22);
      if (sTTrueFalse == null)
        sTTrueFalse = (STTrueFalse)get_store().add_attribute_user(SHAPETYPE$22); 
      sTTrueFalse.set((XmlObject)paramSTTrueFalse);
    } 
  }
  
  public void unsetShapetype() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(SHAPETYPE$22);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\office\impl\CTLockImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */