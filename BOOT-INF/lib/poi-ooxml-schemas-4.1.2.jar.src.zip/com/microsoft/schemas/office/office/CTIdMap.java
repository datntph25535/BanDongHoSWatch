package com.microsoft.schemas.office.office;

import com.microsoft.schemas.vml.STExt;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTIdMap extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTIdMap.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctidmap63fatype");
  
  STExt.Enum getExt();
  
  STExt xgetExt();
  
  boolean isSetExt();
  
  void setExt(STExt.Enum paramEnum);
  
  void xsetExt(STExt paramSTExt);
  
  void unsetExt();
  
  String getData();
  
  XmlString xgetData();
  
  boolean isSetData();
  
  void setData(String paramString);
  
  void xsetData(XmlString paramXmlString);
  
  void unsetData();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTIdMap.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTIdMap newInstance() {
      return (CTIdMap)getTypeLoader().newInstance(CTIdMap.type, null);
    }
    
    public static CTIdMap newInstance(XmlOptions param1XmlOptions) {
      return (CTIdMap)getTypeLoader().newInstance(CTIdMap.type, param1XmlOptions);
    }
    
    public static CTIdMap parse(String param1String) throws XmlException {
      return (CTIdMap)getTypeLoader().parse(param1String, CTIdMap.type, null);
    }
    
    public static CTIdMap parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTIdMap)getTypeLoader().parse(param1String, CTIdMap.type, param1XmlOptions);
    }
    
    public static CTIdMap parse(File param1File) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1File, CTIdMap.type, null);
    }
    
    public static CTIdMap parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1File, CTIdMap.type, param1XmlOptions);
    }
    
    public static CTIdMap parse(URL param1URL) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1URL, CTIdMap.type, null);
    }
    
    public static CTIdMap parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1URL, CTIdMap.type, param1XmlOptions);
    }
    
    public static CTIdMap parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1InputStream, CTIdMap.type, null);
    }
    
    public static CTIdMap parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1InputStream, CTIdMap.type, param1XmlOptions);
    }
    
    public static CTIdMap parse(Reader param1Reader) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1Reader, CTIdMap.type, null);
    }
    
    public static CTIdMap parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTIdMap)getTypeLoader().parse(param1Reader, CTIdMap.type, param1XmlOptions);
    }
    
    public static CTIdMap parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTIdMap)getTypeLoader().parse(param1XMLStreamReader, CTIdMap.type, null);
    }
    
    public static CTIdMap parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTIdMap)getTypeLoader().parse(param1XMLStreamReader, CTIdMap.type, param1XmlOptions);
    }
    
    public static CTIdMap parse(Node param1Node) throws XmlException {
      return (CTIdMap)getTypeLoader().parse(param1Node, CTIdMap.type, null);
    }
    
    public static CTIdMap parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTIdMap)getTypeLoader().parse(param1Node, CTIdMap.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTIdMap parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTIdMap)getTypeLoader().parse(param1XMLInputStream, CTIdMap.type, null);
    }
    
    @Deprecated
    public static CTIdMap parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTIdMap)getTypeLoader().parse(param1XMLInputStream, CTIdMap.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTIdMap.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTIdMap.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\office\office\CTIdMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */