package com.microsoft.schemas.vml.impl;

import com.microsoft.schemas.vml.CTF;
import com.microsoft.schemas.vml.CTFormulas;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class CTFormulasImpl extends XmlComplexContentImpl implements CTFormulas {
  private static final long serialVersionUID = 1L;
  
  private static final QName F$0 = new QName("urn:schemas-microsoft-com:vml", "f");
  
  public CTFormulasImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTF> getFList() {
    synchronized (monitor()) {
      check_orphaned();
      final class FList extends AbstractList<CTF> {
        public CTF get(int param1Int) {
          return CTFormulasImpl.this.getFArray(param1Int);
        }
        
        public CTF set(int param1Int, CTF param1CTF) {
          CTF cTF = CTFormulasImpl.this.getFArray(param1Int);
          CTFormulasImpl.this.setFArray(param1Int, param1CTF);
          return cTF;
        }
        
        public void add(int param1Int, CTF param1CTF) {
          CTFormulasImpl.this.insertNewF(param1Int).set((XmlObject)param1CTF);
        }
        
        public CTF remove(int param1Int) {
          CTF cTF = CTFormulasImpl.this.getFArray(param1Int);
          CTFormulasImpl.this.removeF(param1Int);
          return cTF;
        }
        
        public int size() {
          return CTFormulasImpl.this.sizeOfFArray();
        }
      };
      return new FList();
    } 
  }
  
  @Deprecated
  public CTF[] getFArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(F$0, arrayList);
      CTF[] arrayOfCTF = new CTF[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTF);
      return arrayOfCTF;
    } 
  }
  
  public CTF getFArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTF cTF = null;
      cTF = (CTF)get_store().find_element_user(F$0, paramInt);
      if (cTF == null)
        throw new IndexOutOfBoundsException(); 
      return cTF;
    } 
  }
  
  public int sizeOfFArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(F$0);
    } 
  }
  
  public void setFArray(CTF[] paramArrayOfCTF) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTF, F$0);
  }
  
  public void setFArray(int paramInt, CTF paramCTF) {
    generatedSetterHelperImpl((XmlObject)paramCTF, F$0, paramInt, (short)2);
  }
  
  public CTF insertNewF(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTF cTF = null;
      cTF = (CTF)get_store().insert_element_user(F$0, paramInt);
      return cTF;
    } 
  }
  
  public CTF addNewF() {
    synchronized (monitor()) {
      check_orphaned();
      CTF cTF = null;
      cTF = (CTF)get_store().add_element_user(F$0);
      return cTF;
    } 
  }
  
  public void removeF(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(F$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\vml\impl\CTFormulasImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */