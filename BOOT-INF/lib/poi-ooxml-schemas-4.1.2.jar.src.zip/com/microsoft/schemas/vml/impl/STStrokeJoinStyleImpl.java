package com.microsoft.schemas.vml.impl;

import com.microsoft.schemas.vml.STStrokeJoinStyle;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STStrokeJoinStyleImpl extends JavaStringEnumerationHolderEx implements STStrokeJoinStyle {
  private static final long serialVersionUID = 1L;
  
  public STStrokeJoinStyleImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STStrokeJoinStyleImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\vml\impl\STStrokeJoinStyleImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */