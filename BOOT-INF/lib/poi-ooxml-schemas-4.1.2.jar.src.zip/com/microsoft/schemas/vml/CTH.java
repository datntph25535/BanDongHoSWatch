package com.microsoft.schemas.vml;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTH extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTH.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("cth4cbctype");
  
  String getPosition();
  
  XmlString xgetPosition();
  
  boolean isSetPosition();
  
  void setPosition(String paramString);
  
  void xsetPosition(XmlString paramXmlString);
  
  void unsetPosition();
  
  String getPolar();
  
  XmlString xgetPolar();
  
  boolean isSetPolar();
  
  void setPolar(String paramString);
  
  void xsetPolar(XmlString paramXmlString);
  
  void unsetPolar();
  
  String getMap();
  
  XmlString xgetMap();
  
  boolean isSetMap();
  
  void setMap(String paramString);
  
  void xsetMap(XmlString paramXmlString);
  
  void unsetMap();
  
  STTrueFalse.Enum getInvx();
  
  STTrueFalse xgetInvx();
  
  boolean isSetInvx();
  
  void setInvx(STTrueFalse.Enum paramEnum);
  
  void xsetInvx(STTrueFalse paramSTTrueFalse);
  
  void unsetInvx();
  
  STTrueFalse.Enum getInvy();
  
  STTrueFalse xgetInvy();
  
  boolean isSetInvy();
  
  void setInvy(STTrueFalse.Enum paramEnum);
  
  void xsetInvy(STTrueFalse paramSTTrueFalse);
  
  void unsetInvy();
  
  STTrueFalseBlank$Enum getSwitch();
  
  STTrueFalseBlank xgetSwitch();
  
  boolean isSetSwitch();
  
  void setSwitch(STTrueFalseBlank$Enum paramSTTrueFalseBlank$Enum);
  
  void xsetSwitch(STTrueFalseBlank paramSTTrueFalseBlank);
  
  void unsetSwitch();
  
  String getXrange();
  
  XmlString xgetXrange();
  
  boolean isSetXrange();
  
  void setXrange(String paramString);
  
  void xsetXrange(XmlString paramXmlString);
  
  void unsetXrange();
  
  String getYrange();
  
  XmlString xgetYrange();
  
  boolean isSetYrange();
  
  void setYrange(String paramString);
  
  void xsetYrange(XmlString paramXmlString);
  
  void unsetYrange();
  
  String getRadiusrange();
  
  XmlString xgetRadiusrange();
  
  boolean isSetRadiusrange();
  
  void setRadiusrange(String paramString);
  
  void xsetRadiusrange(XmlString paramXmlString);
  
  void unsetRadiusrange();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTH.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTH newInstance() {
      return (CTH)getTypeLoader().newInstance(CTH.type, null);
    }
    
    public static CTH newInstance(XmlOptions param1XmlOptions) {
      return (CTH)getTypeLoader().newInstance(CTH.type, param1XmlOptions);
    }
    
    public static CTH parse(String param1String) throws XmlException {
      return (CTH)getTypeLoader().parse(param1String, CTH.type, null);
    }
    
    public static CTH parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTH)getTypeLoader().parse(param1String, CTH.type, param1XmlOptions);
    }
    
    public static CTH parse(File param1File) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1File, CTH.type, null);
    }
    
    public static CTH parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1File, CTH.type, param1XmlOptions);
    }
    
    public static CTH parse(URL param1URL) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1URL, CTH.type, null);
    }
    
    public static CTH parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1URL, CTH.type, param1XmlOptions);
    }
    
    public static CTH parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1InputStream, CTH.type, null);
    }
    
    public static CTH parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1InputStream, CTH.type, param1XmlOptions);
    }
    
    public static CTH parse(Reader param1Reader) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1Reader, CTH.type, null);
    }
    
    public static CTH parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTH)getTypeLoader().parse(param1Reader, CTH.type, param1XmlOptions);
    }
    
    public static CTH parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTH)getTypeLoader().parse(param1XMLStreamReader, CTH.type, null);
    }
    
    public static CTH parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTH)getTypeLoader().parse(param1XMLStreamReader, CTH.type, param1XmlOptions);
    }
    
    public static CTH parse(Node param1Node) throws XmlException {
      return (CTH)getTypeLoader().parse(param1Node, CTH.type, null);
    }
    
    public static CTH parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTH)getTypeLoader().parse(param1Node, CTH.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTH parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTH)getTypeLoader().parse(param1XMLInputStream, CTH.type, null);
    }
    
    @Deprecated
    public static CTH parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTH)getTypeLoader().parse(param1XMLInputStream, CTH.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTH.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTH.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\vml\CTH.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */