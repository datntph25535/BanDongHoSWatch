package com.microsoft.schemas.vml;

import com.microsoft.schemas.office.excel.CTClientData;
import com.microsoft.schemas.office.office.CTCallout;
import com.microsoft.schemas.office.office.CTClipPath;
import com.microsoft.schemas.office.office.CTExtrusion;
import com.microsoft.schemas.office.office.CTLock;
import com.microsoft.schemas.office.office.CTSignatureLine;
import com.microsoft.schemas.office.office.CTSkew;
import com.microsoft.schemas.office.office.STBWMode;
import com.microsoft.schemas.office.office.STConnectorType;
import com.microsoft.schemas.office.office.STHrAlign;
import com.microsoft.schemas.office.office.STInsetMode;
import com.microsoft.schemas.office.office.STTrueFalse;
import com.microsoft.schemas.office.office.STTrueFalseBlank;
import com.microsoft.schemas.office.powerpoint.CTRel;
import com.microsoft.schemas.office.word.CTAnchorLock;
import com.microsoft.schemas.office.word.CTBorder;
import com.microsoft.schemas.office.word.CTWrap;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.math.BigInteger;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlFloat;
import org.apache.xmlbeans.XmlInteger;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTRect extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTRect.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctrectf6e2type");
  
  List<CTPath> getPathList();
  
  @Deprecated
  CTPath[] getPathArray();
  
  CTPath getPathArray(int paramInt);
  
  int sizeOfPathArray();
  
  void setPathArray(CTPath[] paramArrayOfCTPath);
  
  void setPathArray(int paramInt, CTPath paramCTPath);
  
  CTPath insertNewPath(int paramInt);
  
  CTPath addNewPath();
  
  void removePath(int paramInt);
  
  List<CTFormulas> getFormulasList();
  
  @Deprecated
  CTFormulas[] getFormulasArray();
  
  CTFormulas getFormulasArray(int paramInt);
  
  int sizeOfFormulasArray();
  
  void setFormulasArray(CTFormulas[] paramArrayOfCTFormulas);
  
  void setFormulasArray(int paramInt, CTFormulas paramCTFormulas);
  
  CTFormulas insertNewFormulas(int paramInt);
  
  CTFormulas addNewFormulas();
  
  void removeFormulas(int paramInt);
  
  List<CTHandles> getHandlesList();
  
  @Deprecated
  CTHandles[] getHandlesArray();
  
  CTHandles getHandlesArray(int paramInt);
  
  int sizeOfHandlesArray();
  
  void setHandlesArray(CTHandles[] paramArrayOfCTHandles);
  
  void setHandlesArray(int paramInt, CTHandles paramCTHandles);
  
  CTHandles insertNewHandles(int paramInt);
  
  CTHandles addNewHandles();
  
  void removeHandles(int paramInt);
  
  List<CTFill> getFillList();
  
  @Deprecated
  CTFill[] getFillArray();
  
  CTFill getFillArray(int paramInt);
  
  int sizeOfFillArray();
  
  void setFillArray(CTFill[] paramArrayOfCTFill);
  
  void setFillArray(int paramInt, CTFill paramCTFill);
  
  CTFill insertNewFill(int paramInt);
  
  CTFill addNewFill();
  
  void removeFill(int paramInt);
  
  List<CTStroke> getStrokeList();
  
  @Deprecated
  CTStroke[] getStrokeArray();
  
  CTStroke getStrokeArray(int paramInt);
  
  int sizeOfStrokeArray();
  
  void setStrokeArray(CTStroke[] paramArrayOfCTStroke);
  
  void setStrokeArray(int paramInt, CTStroke paramCTStroke);
  
  CTStroke insertNewStroke(int paramInt);
  
  CTStroke addNewStroke();
  
  void removeStroke(int paramInt);
  
  List<CTShadow> getShadowList();
  
  @Deprecated
  CTShadow[] getShadowArray();
  
  CTShadow getShadowArray(int paramInt);
  
  int sizeOfShadowArray();
  
  void setShadowArray(CTShadow[] paramArrayOfCTShadow);
  
  void setShadowArray(int paramInt, CTShadow paramCTShadow);
  
  CTShadow insertNewShadow(int paramInt);
  
  CTShadow addNewShadow();
  
  void removeShadow(int paramInt);
  
  List<CTTextbox> getTextboxList();
  
  @Deprecated
  CTTextbox[] getTextboxArray();
  
  CTTextbox getTextboxArray(int paramInt);
  
  int sizeOfTextboxArray();
  
  void setTextboxArray(CTTextbox[] paramArrayOfCTTextbox);
  
  void setTextboxArray(int paramInt, CTTextbox paramCTTextbox);
  
  CTTextbox insertNewTextbox(int paramInt);
  
  CTTextbox addNewTextbox();
  
  void removeTextbox(int paramInt);
  
  List<CTTextPath> getTextpathList();
  
  @Deprecated
  CTTextPath[] getTextpathArray();
  
  CTTextPath getTextpathArray(int paramInt);
  
  int sizeOfTextpathArray();
  
  void setTextpathArray(CTTextPath[] paramArrayOfCTTextPath);
  
  void setTextpathArray(int paramInt, CTTextPath paramCTTextPath);
  
  CTTextPath insertNewTextpath(int paramInt);
  
  CTTextPath addNewTextpath();
  
  void removeTextpath(int paramInt);
  
  List<CTImageData> getImagedataList();
  
  @Deprecated
  CTImageData[] getImagedataArray();
  
  CTImageData getImagedataArray(int paramInt);
  
  int sizeOfImagedataArray();
  
  void setImagedataArray(CTImageData[] paramArrayOfCTImageData);
  
  void setImagedataArray(int paramInt, CTImageData paramCTImageData);
  
  CTImageData insertNewImagedata(int paramInt);
  
  CTImageData addNewImagedata();
  
  void removeImagedata(int paramInt);
  
  List<CTSkew> getSkewList();
  
  @Deprecated
  CTSkew[] getSkewArray();
  
  CTSkew getSkewArray(int paramInt);
  
  int sizeOfSkewArray();
  
  void setSkewArray(CTSkew[] paramArrayOfCTSkew);
  
  void setSkewArray(int paramInt, CTSkew paramCTSkew);
  
  CTSkew insertNewSkew(int paramInt);
  
  CTSkew addNewSkew();
  
  void removeSkew(int paramInt);
  
  List<CTExtrusion> getExtrusionList();
  
  @Deprecated
  CTExtrusion[] getExtrusionArray();
  
  CTExtrusion getExtrusionArray(int paramInt);
  
  int sizeOfExtrusionArray();
  
  void setExtrusionArray(CTExtrusion[] paramArrayOfCTExtrusion);
  
  void setExtrusionArray(int paramInt, CTExtrusion paramCTExtrusion);
  
  CTExtrusion insertNewExtrusion(int paramInt);
  
  CTExtrusion addNewExtrusion();
  
  void removeExtrusion(int paramInt);
  
  List<CTCallout> getCalloutList();
  
  @Deprecated
  CTCallout[] getCalloutArray();
  
  CTCallout getCalloutArray(int paramInt);
  
  int sizeOfCalloutArray();
  
  void setCalloutArray(CTCallout[] paramArrayOfCTCallout);
  
  void setCalloutArray(int paramInt, CTCallout paramCTCallout);
  
  CTCallout insertNewCallout(int paramInt);
  
  CTCallout addNewCallout();
  
  void removeCallout(int paramInt);
  
  List<CTLock> getLockList();
  
  @Deprecated
  CTLock[] getLockArray();
  
  CTLock getLockArray(int paramInt);
  
  int sizeOfLockArray();
  
  void setLockArray(CTLock[] paramArrayOfCTLock);
  
  void setLockArray(int paramInt, CTLock paramCTLock);
  
  CTLock insertNewLock(int paramInt);
  
  CTLock addNewLock();
  
  void removeLock(int paramInt);
  
  List<CTClipPath> getClippathList();
  
  @Deprecated
  CTClipPath[] getClippathArray();
  
  CTClipPath getClippathArray(int paramInt);
  
  int sizeOfClippathArray();
  
  void setClippathArray(CTClipPath[] paramArrayOfCTClipPath);
  
  void setClippathArray(int paramInt, CTClipPath paramCTClipPath);
  
  CTClipPath insertNewClippath(int paramInt);
  
  CTClipPath addNewClippath();
  
  void removeClippath(int paramInt);
  
  List<CTSignatureLine> getSignaturelineList();
  
  @Deprecated
  CTSignatureLine[] getSignaturelineArray();
  
  CTSignatureLine getSignaturelineArray(int paramInt);
  
  int sizeOfSignaturelineArray();
  
  void setSignaturelineArray(CTSignatureLine[] paramArrayOfCTSignatureLine);
  
  void setSignaturelineArray(int paramInt, CTSignatureLine paramCTSignatureLine);
  
  CTSignatureLine insertNewSignatureline(int paramInt);
  
  CTSignatureLine addNewSignatureline();
  
  void removeSignatureline(int paramInt);
  
  List<CTWrap> getWrapList();
  
  @Deprecated
  CTWrap[] getWrapArray();
  
  CTWrap getWrapArray(int paramInt);
  
  int sizeOfWrapArray();
  
  void setWrapArray(CTWrap[] paramArrayOfCTWrap);
  
  void setWrapArray(int paramInt, CTWrap paramCTWrap);
  
  CTWrap insertNewWrap(int paramInt);
  
  CTWrap addNewWrap();
  
  void removeWrap(int paramInt);
  
  List<CTAnchorLock> getAnchorlockList();
  
  @Deprecated
  CTAnchorLock[] getAnchorlockArray();
  
  CTAnchorLock getAnchorlockArray(int paramInt);
  
  int sizeOfAnchorlockArray();
  
  void setAnchorlockArray(CTAnchorLock[] paramArrayOfCTAnchorLock);
  
  void setAnchorlockArray(int paramInt, CTAnchorLock paramCTAnchorLock);
  
  CTAnchorLock insertNewAnchorlock(int paramInt);
  
  CTAnchorLock addNewAnchorlock();
  
  void removeAnchorlock(int paramInt);
  
  List<CTBorder> getBordertopList();
  
  @Deprecated
  CTBorder[] getBordertopArray();
  
  CTBorder getBordertopArray(int paramInt);
  
  int sizeOfBordertopArray();
  
  void setBordertopArray(CTBorder[] paramArrayOfCTBorder);
  
  void setBordertopArray(int paramInt, CTBorder paramCTBorder);
  
  CTBorder insertNewBordertop(int paramInt);
  
  CTBorder addNewBordertop();
  
  void removeBordertop(int paramInt);
  
  List<CTBorder> getBorderbottomList();
  
  @Deprecated
  CTBorder[] getBorderbottomArray();
  
  CTBorder getBorderbottomArray(int paramInt);
  
  int sizeOfBorderbottomArray();
  
  void setBorderbottomArray(CTBorder[] paramArrayOfCTBorder);
  
  void setBorderbottomArray(int paramInt, CTBorder paramCTBorder);
  
  CTBorder insertNewBorderbottom(int paramInt);
  
  CTBorder addNewBorderbottom();
  
  void removeBorderbottom(int paramInt);
  
  List<CTBorder> getBorderleftList();
  
  @Deprecated
  CTBorder[] getBorderleftArray();
  
  CTBorder getBorderleftArray(int paramInt);
  
  int sizeOfBorderleftArray();
  
  void setBorderleftArray(CTBorder[] paramArrayOfCTBorder);
  
  void setBorderleftArray(int paramInt, CTBorder paramCTBorder);
  
  CTBorder insertNewBorderleft(int paramInt);
  
  CTBorder addNewBorderleft();
  
  void removeBorderleft(int paramInt);
  
  List<CTBorder> getBorderrightList();
  
  @Deprecated
  CTBorder[] getBorderrightArray();
  
  CTBorder getBorderrightArray(int paramInt);
  
  int sizeOfBorderrightArray();
  
  void setBorderrightArray(CTBorder[] paramArrayOfCTBorder);
  
  void setBorderrightArray(int paramInt, CTBorder paramCTBorder);
  
  CTBorder insertNewBorderright(int paramInt);
  
  CTBorder addNewBorderright();
  
  void removeBorderright(int paramInt);
  
  List<CTClientData> getClientDataList();
  
  @Deprecated
  CTClientData[] getClientDataArray();
  
  CTClientData getClientDataArray(int paramInt);
  
  int sizeOfClientDataArray();
  
  void setClientDataArray(CTClientData[] paramArrayOfCTClientData);
  
  void setClientDataArray(int paramInt, CTClientData paramCTClientData);
  
  CTClientData insertNewClientData(int paramInt);
  
  CTClientData addNewClientData();
  
  void removeClientData(int paramInt);
  
  List<CTRel> getTextdataList();
  
  @Deprecated
  CTRel[] getTextdataArray();
  
  CTRel getTextdataArray(int paramInt);
  
  int sizeOfTextdataArray();
  
  void setTextdataArray(CTRel[] paramArrayOfCTRel);
  
  void setTextdataArray(int paramInt, CTRel paramCTRel);
  
  CTRel insertNewTextdata(int paramInt);
  
  CTRel addNewTextdata();
  
  void removeTextdata(int paramInt);
  
  String getId();
  
  XmlString xgetId();
  
  boolean isSetId();
  
  void setId(String paramString);
  
  void xsetId(XmlString paramXmlString);
  
  void unsetId();
  
  String getStyle();
  
  XmlString xgetStyle();
  
  boolean isSetStyle();
  
  void setStyle(String paramString);
  
  void xsetStyle(XmlString paramXmlString);
  
  void unsetStyle();
  
  String getHref();
  
  XmlString xgetHref();
  
  boolean isSetHref();
  
  void setHref(String paramString);
  
  void xsetHref(XmlString paramXmlString);
  
  void unsetHref();
  
  String getTarget();
  
  XmlString xgetTarget();
  
  boolean isSetTarget();
  
  void setTarget(String paramString);
  
  void xsetTarget(XmlString paramXmlString);
  
  void unsetTarget();
  
  String getClass1();
  
  XmlString xgetClass1();
  
  boolean isSetClass1();
  
  void setClass1(String paramString);
  
  void xsetClass1(XmlString paramXmlString);
  
  void unsetClass1();
  
  String getTitle();
  
  XmlString xgetTitle();
  
  boolean isSetTitle();
  
  void setTitle(String paramString);
  
  void xsetTitle(XmlString paramXmlString);
  
  void unsetTitle();
  
  String getAlt();
  
  XmlString xgetAlt();
  
  boolean isSetAlt();
  
  void setAlt(String paramString);
  
  void xsetAlt(XmlString paramXmlString);
  
  void unsetAlt();
  
  String getCoordsize();
  
  XmlString xgetCoordsize();
  
  boolean isSetCoordsize();
  
  void setCoordsize(String paramString);
  
  void xsetCoordsize(XmlString paramXmlString);
  
  void unsetCoordsize();
  
  String getCoordorigin();
  
  XmlString xgetCoordorigin();
  
  boolean isSetCoordorigin();
  
  void setCoordorigin(String paramString);
  
  void xsetCoordorigin(XmlString paramXmlString);
  
  void unsetCoordorigin();
  
  String getWrapcoords();
  
  XmlString xgetWrapcoords();
  
  boolean isSetWrapcoords();
  
  void setWrapcoords(String paramString);
  
  void xsetWrapcoords(XmlString paramXmlString);
  
  void unsetWrapcoords();
  
  STTrueFalse.Enum getPrint();
  
  STTrueFalse xgetPrint();
  
  boolean isSetPrint();
  
  void setPrint(STTrueFalse.Enum paramEnum);
  
  void xsetPrint(STTrueFalse paramSTTrueFalse);
  
  void unsetPrint();
  
  String getSpid();
  
  XmlString xgetSpid();
  
  boolean isSetSpid();
  
  void setSpid(String paramString);
  
  void xsetSpid(XmlString paramXmlString);
  
  void unsetSpid();
  
  STTrueFalse.Enum getOned();
  
  STTrueFalse xgetOned();
  
  boolean isSetOned();
  
  void setOned(STTrueFalse.Enum paramEnum);
  
  void xsetOned(STTrueFalse paramSTTrueFalse);
  
  void unsetOned();
  
  BigInteger getRegroupid();
  
  XmlInteger xgetRegroupid();
  
  boolean isSetRegroupid();
  
  void setRegroupid(BigInteger paramBigInteger);
  
  void xsetRegroupid(XmlInteger paramXmlInteger);
  
  void unsetRegroupid();
  
  STTrueFalse.Enum getDoubleclicknotify();
  
  STTrueFalse xgetDoubleclicknotify();
  
  boolean isSetDoubleclicknotify();
  
  void setDoubleclicknotify(STTrueFalse.Enum paramEnum);
  
  void xsetDoubleclicknotify(STTrueFalse paramSTTrueFalse);
  
  void unsetDoubleclicknotify();
  
  STTrueFalse.Enum getButton();
  
  STTrueFalse xgetButton();
  
  boolean isSetButton();
  
  void setButton(STTrueFalse.Enum paramEnum);
  
  void xsetButton(STTrueFalse paramSTTrueFalse);
  
  void unsetButton();
  
  STTrueFalse.Enum getUserhidden();
  
  STTrueFalse xgetUserhidden();
  
  boolean isSetUserhidden();
  
  void setUserhidden(STTrueFalse.Enum paramEnum);
  
  void xsetUserhidden(STTrueFalse paramSTTrueFalse);
  
  void unsetUserhidden();
  
  STTrueFalse.Enum getBullet();
  
  STTrueFalse xgetBullet();
  
  boolean isSetBullet();
  
  void setBullet(STTrueFalse.Enum paramEnum);
  
  void xsetBullet(STTrueFalse paramSTTrueFalse);
  
  void unsetBullet();
  
  STTrueFalse.Enum getHr();
  
  STTrueFalse xgetHr();
  
  boolean isSetHr();
  
  void setHr(STTrueFalse.Enum paramEnum);
  
  void xsetHr(STTrueFalse paramSTTrueFalse);
  
  void unsetHr();
  
  STTrueFalse.Enum getHrstd();
  
  STTrueFalse xgetHrstd();
  
  boolean isSetHrstd();
  
  void setHrstd(STTrueFalse.Enum paramEnum);
  
  void xsetHrstd(STTrueFalse paramSTTrueFalse);
  
  void unsetHrstd();
  
  STTrueFalse.Enum getHrnoshade();
  
  STTrueFalse xgetHrnoshade();
  
  boolean isSetHrnoshade();
  
  void setHrnoshade(STTrueFalse.Enum paramEnum);
  
  void xsetHrnoshade(STTrueFalse paramSTTrueFalse);
  
  void unsetHrnoshade();
  
  float getHrpct();
  
  XmlFloat xgetHrpct();
  
  boolean isSetHrpct();
  
  void setHrpct(float paramFloat);
  
  void xsetHrpct(XmlFloat paramXmlFloat);
  
  void unsetHrpct();
  
  STHrAlign.Enum getHralign();
  
  STHrAlign xgetHralign();
  
  boolean isSetHralign();
  
  void setHralign(STHrAlign.Enum paramEnum);
  
  void xsetHralign(STHrAlign paramSTHrAlign);
  
  void unsetHralign();
  
  STTrueFalse.Enum getAllowincell();
  
  STTrueFalse xgetAllowincell();
  
  boolean isSetAllowincell();
  
  void setAllowincell(STTrueFalse.Enum paramEnum);
  
  void xsetAllowincell(STTrueFalse paramSTTrueFalse);
  
  void unsetAllowincell();
  
  STTrueFalse.Enum getAllowoverlap();
  
  STTrueFalse xgetAllowoverlap();
  
  boolean isSetAllowoverlap();
  
  void setAllowoverlap(STTrueFalse.Enum paramEnum);
  
  void xsetAllowoverlap(STTrueFalse paramSTTrueFalse);
  
  void unsetAllowoverlap();
  
  STTrueFalse.Enum getUserdrawn();
  
  STTrueFalse xgetUserdrawn();
  
  boolean isSetUserdrawn();
  
  void setUserdrawn(STTrueFalse.Enum paramEnum);
  
  void xsetUserdrawn(STTrueFalse paramSTTrueFalse);
  
  void unsetUserdrawn();
  
  String getBordertopcolor();
  
  XmlString xgetBordertopcolor();
  
  boolean isSetBordertopcolor();
  
  void setBordertopcolor(String paramString);
  
  void xsetBordertopcolor(XmlString paramXmlString);
  
  void unsetBordertopcolor();
  
  String getBorderleftcolor();
  
  XmlString xgetBorderleftcolor();
  
  boolean isSetBorderleftcolor();
  
  void setBorderleftcolor(String paramString);
  
  void xsetBorderleftcolor(XmlString paramXmlString);
  
  void unsetBorderleftcolor();
  
  String getBorderbottomcolor();
  
  XmlString xgetBorderbottomcolor();
  
  boolean isSetBorderbottomcolor();
  
  void setBorderbottomcolor(String paramString);
  
  void xsetBorderbottomcolor(XmlString paramXmlString);
  
  void unsetBorderbottomcolor();
  
  String getBorderrightcolor();
  
  XmlString xgetBorderrightcolor();
  
  boolean isSetBorderrightcolor();
  
  void setBorderrightcolor(String paramString);
  
  void xsetBorderrightcolor(XmlString paramXmlString);
  
  void unsetBorderrightcolor();
  
  BigInteger getDgmlayout();
  
  XmlInteger xgetDgmlayout();
  
  boolean isSetDgmlayout();
  
  void setDgmlayout(BigInteger paramBigInteger);
  
  void xsetDgmlayout(XmlInteger paramXmlInteger);
  
  void unsetDgmlayout();
  
  BigInteger getDgmnodekind();
  
  XmlInteger xgetDgmnodekind();
  
  boolean isSetDgmnodekind();
  
  void setDgmnodekind(BigInteger paramBigInteger);
  
  void xsetDgmnodekind(XmlInteger paramXmlInteger);
  
  void unsetDgmnodekind();
  
  BigInteger getDgmlayoutmru();
  
  XmlInteger xgetDgmlayoutmru();
  
  boolean isSetDgmlayoutmru();
  
  void setDgmlayoutmru(BigInteger paramBigInteger);
  
  void xsetDgmlayoutmru(XmlInteger paramXmlInteger);
  
  void unsetDgmlayoutmru();
  
  STInsetMode.Enum getInsetmode();
  
  STInsetMode xgetInsetmode();
  
  boolean isSetInsetmode();
  
  void setInsetmode(STInsetMode.Enum paramEnum);
  
  void xsetInsetmode(STInsetMode paramSTInsetMode);
  
  void unsetInsetmode();
  
  String getChromakey();
  
  STColorType xgetChromakey();
  
  boolean isSetChromakey();
  
  void setChromakey(String paramString);
  
  void xsetChromakey(STColorType paramSTColorType);
  
  void unsetChromakey();
  
  STTrueFalse.Enum getFilled();
  
  STTrueFalse xgetFilled();
  
  boolean isSetFilled();
  
  void setFilled(STTrueFalse.Enum paramEnum);
  
  void xsetFilled(STTrueFalse paramSTTrueFalse);
  
  void unsetFilled();
  
  String getFillcolor();
  
  STColorType xgetFillcolor();
  
  boolean isSetFillcolor();
  
  void setFillcolor(String paramString);
  
  void xsetFillcolor(STColorType paramSTColorType);
  
  void unsetFillcolor();
  
  String getOpacity();
  
  XmlString xgetOpacity();
  
  boolean isSetOpacity();
  
  void setOpacity(String paramString);
  
  void xsetOpacity(XmlString paramXmlString);
  
  void unsetOpacity();
  
  STTrueFalse.Enum getStroked();
  
  STTrueFalse xgetStroked();
  
  boolean isSetStroked();
  
  void setStroked(STTrueFalse.Enum paramEnum);
  
  void xsetStroked(STTrueFalse paramSTTrueFalse);
  
  void unsetStroked();
  
  String getStrokecolor();
  
  STColorType xgetStrokecolor();
  
  boolean isSetStrokecolor();
  
  void setStrokecolor(String paramString);
  
  void xsetStrokecolor(STColorType paramSTColorType);
  
  void unsetStrokecolor();
  
  String getStrokeweight();
  
  XmlString xgetStrokeweight();
  
  boolean isSetStrokeweight();
  
  void setStrokeweight(String paramString);
  
  void xsetStrokeweight(XmlString paramXmlString);
  
  void unsetStrokeweight();
  
  STTrueFalse.Enum getInsetpen();
  
  STTrueFalse xgetInsetpen();
  
  boolean isSetInsetpen();
  
  void setInsetpen(STTrueFalse.Enum paramEnum);
  
  void xsetInsetpen(STTrueFalse paramSTTrueFalse);
  
  void unsetInsetpen();
  
  float getSpt();
  
  XmlFloat xgetSpt();
  
  boolean isSetSpt();
  
  void setSpt(float paramFloat);
  
  void xsetSpt(XmlFloat paramXmlFloat);
  
  void unsetSpt();
  
  STConnectorType.Enum getConnectortype();
  
  STConnectorType xgetConnectortype();
  
  boolean isSetConnectortype();
  
  void setConnectortype(STConnectorType.Enum paramEnum);
  
  void xsetConnectortype(STConnectorType paramSTConnectorType);
  
  void unsetConnectortype();
  
  STBWMode.Enum getBwmode();
  
  STBWMode xgetBwmode();
  
  boolean isSetBwmode();
  
  void setBwmode(STBWMode.Enum paramEnum);
  
  void xsetBwmode(STBWMode paramSTBWMode);
  
  void unsetBwmode();
  
  STBWMode.Enum getBwpure();
  
  STBWMode xgetBwpure();
  
  boolean isSetBwpure();
  
  void setBwpure(STBWMode.Enum paramEnum);
  
  void xsetBwpure(STBWMode paramSTBWMode);
  
  void unsetBwpure();
  
  STBWMode.Enum getBwnormal();
  
  STBWMode xgetBwnormal();
  
  boolean isSetBwnormal();
  
  void setBwnormal(STBWMode.Enum paramEnum);
  
  void xsetBwnormal(STBWMode paramSTBWMode);
  
  void unsetBwnormal();
  
  STTrueFalse.Enum getForcedash();
  
  STTrueFalse xgetForcedash();
  
  boolean isSetForcedash();
  
  void setForcedash(STTrueFalse.Enum paramEnum);
  
  void xsetForcedash(STTrueFalse paramSTTrueFalse);
  
  void unsetForcedash();
  
  STTrueFalse.Enum getOleicon();
  
  STTrueFalse xgetOleicon();
  
  boolean isSetOleicon();
  
  void setOleicon(STTrueFalse.Enum paramEnum);
  
  void xsetOleicon(STTrueFalse paramSTTrueFalse);
  
  void unsetOleicon();
  
  STTrueFalseBlank.Enum getOle();
  
  STTrueFalseBlank xgetOle();
  
  boolean isSetOle();
  
  void setOle(STTrueFalseBlank.Enum paramEnum);
  
  void xsetOle(STTrueFalseBlank paramSTTrueFalseBlank);
  
  void unsetOle();
  
  STTrueFalse.Enum getPreferrelative();
  
  STTrueFalse xgetPreferrelative();
  
  boolean isSetPreferrelative();
  
  void setPreferrelative(STTrueFalse.Enum paramEnum);
  
  void xsetPreferrelative(STTrueFalse paramSTTrueFalse);
  
  void unsetPreferrelative();
  
  STTrueFalse.Enum getCliptowrap();
  
  STTrueFalse xgetCliptowrap();
  
  boolean isSetCliptowrap();
  
  void setCliptowrap(STTrueFalse.Enum paramEnum);
  
  void xsetCliptowrap(STTrueFalse paramSTTrueFalse);
  
  void unsetCliptowrap();
  
  STTrueFalse.Enum getClip();
  
  STTrueFalse xgetClip();
  
  boolean isSetClip();
  
  void setClip(STTrueFalse.Enum paramEnum);
  
  void xsetClip(STTrueFalse paramSTTrueFalse);
  
  void unsetClip();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTRect.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTRect newInstance() {
      return (CTRect)getTypeLoader().newInstance(CTRect.type, null);
    }
    
    public static CTRect newInstance(XmlOptions param1XmlOptions) {
      return (CTRect)getTypeLoader().newInstance(CTRect.type, param1XmlOptions);
    }
    
    public static CTRect parse(String param1String) throws XmlException {
      return (CTRect)getTypeLoader().parse(param1String, CTRect.type, null);
    }
    
    public static CTRect parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRect)getTypeLoader().parse(param1String, CTRect.type, param1XmlOptions);
    }
    
    public static CTRect parse(File param1File) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1File, CTRect.type, null);
    }
    
    public static CTRect parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1File, CTRect.type, param1XmlOptions);
    }
    
    public static CTRect parse(URL param1URL) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1URL, CTRect.type, null);
    }
    
    public static CTRect parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1URL, CTRect.type, param1XmlOptions);
    }
    
    public static CTRect parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1InputStream, CTRect.type, null);
    }
    
    public static CTRect parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1InputStream, CTRect.type, param1XmlOptions);
    }
    
    public static CTRect parse(Reader param1Reader) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1Reader, CTRect.type, null);
    }
    
    public static CTRect parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRect)getTypeLoader().parse(param1Reader, CTRect.type, param1XmlOptions);
    }
    
    public static CTRect parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTRect)getTypeLoader().parse(param1XMLStreamReader, CTRect.type, null);
    }
    
    public static CTRect parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRect)getTypeLoader().parse(param1XMLStreamReader, CTRect.type, param1XmlOptions);
    }
    
    public static CTRect parse(Node param1Node) throws XmlException {
      return (CTRect)getTypeLoader().parse(param1Node, CTRect.type, null);
    }
    
    public static CTRect parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRect)getTypeLoader().parse(param1Node, CTRect.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTRect parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTRect)getTypeLoader().parse(param1XMLInputStream, CTRect.type, null);
    }
    
    @Deprecated
    public static CTRect parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTRect)getTypeLoader().parse(param1XMLInputStream, CTRect.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTRect.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTRect.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\vml\CTRect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */