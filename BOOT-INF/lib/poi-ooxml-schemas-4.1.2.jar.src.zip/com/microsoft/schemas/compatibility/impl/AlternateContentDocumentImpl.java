package com.microsoft.schemas.compatibility.impl;

import com.microsoft.schemas.compatibility.AlternateContentDocument;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class AlternateContentDocumentImpl extends XmlComplexContentImpl implements AlternateContentDocument {
  private static final long serialVersionUID = 1L;
  
  private static final QName ALTERNATECONTENT$0 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "AlternateContent");
  
  public AlternateContentDocumentImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public AlternateContentDocument.AlternateContent getAlternateContent() {
    synchronized (monitor()) {
      check_orphaned();
      AlternateContentDocument.AlternateContent alternateContent = null;
      alternateContent = (AlternateContentDocument.AlternateContent)get_store().find_element_user(ALTERNATECONTENT$0, 0);
      if (alternateContent == null)
        return null; 
      return alternateContent;
    } 
  }
  
  public void setAlternateContent(AlternateContentDocument.AlternateContent paramAlternateContent) {
    generatedSetterHelperImpl((XmlObject)paramAlternateContent, ALTERNATECONTENT$0, 0, (short)1);
  }
  
  public AlternateContentDocument.AlternateContent addNewAlternateContent() {
    synchronized (monitor()) {
      check_orphaned();
      AlternateContentDocument.AlternateContent alternateContent = null;
      alternateContent = (AlternateContentDocument.AlternateContent)get_store().add_element_user(ALTERNATECONTENT$0);
      return alternateContent;
    } 
  }
  
  public static class AlternateContentImpl extends XmlComplexContentImpl implements AlternateContentDocument.AlternateContent {
    private static final long serialVersionUID = 1L;
    
    private static final QName CHOICE$0 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "Choice");
    
    private static final QName FALLBACK$2 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "Fallback");
    
    private static final QName IGNORABLE$4 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "Ignorable");
    
    private static final QName MUSTUNDERSTAND$6 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "MustUnderstand");
    
    private static final QName PROCESSCONTENT$8 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "ProcessContent");
    
    public AlternateContentImpl(SchemaType param1SchemaType) {
      super(param1SchemaType);
    }
    
    public List<AlternateContentDocument.AlternateContent.Choice> getChoiceList() {
      synchronized (monitor()) {
        check_orphaned();
        final class ChoiceList extends AbstractList<AlternateContentDocument.AlternateContent.Choice> {
          public AlternateContentDocument.AlternateContent.Choice get(int param2Int) {
            return AlternateContentDocumentImpl.AlternateContentImpl.this.getChoiceArray(param2Int);
          }
          
          public AlternateContentDocument.AlternateContent.Choice set(int param2Int, AlternateContentDocument.AlternateContent.Choice param2Choice) {
            AlternateContentDocument.AlternateContent.Choice choice = AlternateContentDocumentImpl.AlternateContentImpl.this.getChoiceArray(param2Int);
            AlternateContentDocumentImpl.AlternateContentImpl.this.setChoiceArray(param2Int, param2Choice);
            return choice;
          }
          
          public void add(int param2Int, AlternateContentDocument.AlternateContent.Choice param2Choice) {
            AlternateContentDocumentImpl.AlternateContentImpl.this.insertNewChoice(param2Int).set((XmlObject)param2Choice);
          }
          
          public AlternateContentDocument.AlternateContent.Choice remove(int param2Int) {
            AlternateContentDocument.AlternateContent.Choice choice = AlternateContentDocumentImpl.AlternateContentImpl.this.getChoiceArray(param2Int);
            AlternateContentDocumentImpl.AlternateContentImpl.this.removeChoice(param2Int);
            return choice;
          }
          
          public int size() {
            return AlternateContentDocumentImpl.AlternateContentImpl.this.sizeOfChoiceArray();
          }
        };
        return new ChoiceList();
      } 
    }
    
    @Deprecated
    public AlternateContentDocument.AlternateContent.Choice[] getChoiceArray() {
      synchronized (monitor()) {
        check_orphaned();
        ArrayList arrayList = new ArrayList();
        get_store().find_all_element_users(CHOICE$0, arrayList);
        AlternateContentDocument.AlternateContent.Choice[] arrayOfChoice = new AlternateContentDocument.AlternateContent.Choice[arrayList.size()];
        arrayList.toArray((Object[])arrayOfChoice);
        return arrayOfChoice;
      } 
    }
    
    public AlternateContentDocument.AlternateContent.Choice getChoiceArray(int param1Int) {
      synchronized (monitor()) {
        check_orphaned();
        AlternateContentDocument.AlternateContent.Choice choice = null;
        choice = (AlternateContentDocument.AlternateContent.Choice)get_store().find_element_user(CHOICE$0, param1Int);
        if (choice == null)
          throw new IndexOutOfBoundsException(); 
        return choice;
      } 
    }
    
    public int sizeOfChoiceArray() {
      synchronized (monitor()) {
        check_orphaned();
        return get_store().count_elements(CHOICE$0);
      } 
    }
    
    public void setChoiceArray(AlternateContentDocument.AlternateContent.Choice[] param1ArrayOfChoice) {
      check_orphaned();
      arraySetterHelper((XmlObject[])param1ArrayOfChoice, CHOICE$0);
    }
    
    public void setChoiceArray(int param1Int, AlternateContentDocument.AlternateContent.Choice param1Choice) {
      generatedSetterHelperImpl((XmlObject)param1Choice, CHOICE$0, param1Int, (short)2);
    }
    
    public AlternateContentDocument.AlternateContent.Choice insertNewChoice(int param1Int) {
      synchronized (monitor()) {
        check_orphaned();
        AlternateContentDocument.AlternateContent.Choice choice = null;
        choice = (AlternateContentDocument.AlternateContent.Choice)get_store().insert_element_user(CHOICE$0, param1Int);
        return choice;
      } 
    }
    
    public AlternateContentDocument.AlternateContent.Choice addNewChoice() {
      synchronized (monitor()) {
        check_orphaned();
        AlternateContentDocument.AlternateContent.Choice choice = null;
        choice = (AlternateContentDocument.AlternateContent.Choice)get_store().add_element_user(CHOICE$0);
        return choice;
      } 
    }
    
    public void removeChoice(int param1Int) {
      synchronized (monitor()) {
        check_orphaned();
        get_store().remove_element(CHOICE$0, param1Int);
      } 
    }
    
    public AlternateContentDocument.AlternateContent.Fallback getFallback() {
      synchronized (monitor()) {
        check_orphaned();
        AlternateContentDocument.AlternateContent.Fallback fallback = null;
        fallback = (AlternateContentDocument.AlternateContent.Fallback)get_store().find_element_user(FALLBACK$2, 0);
        if (fallback == null)
          return null; 
        return fallback;
      } 
    }
    
    public boolean isSetFallback() {
      synchronized (monitor()) {
        check_orphaned();
        return (get_store().count_elements(FALLBACK$2) != 0);
      } 
    }
    
    public void setFallback(AlternateContentDocument.AlternateContent.Fallback param1Fallback) {
      generatedSetterHelperImpl((XmlObject)param1Fallback, FALLBACK$2, 0, (short)1);
    }
    
    public AlternateContentDocument.AlternateContent.Fallback addNewFallback() {
      synchronized (monitor()) {
        check_orphaned();
        AlternateContentDocument.AlternateContent.Fallback fallback = null;
        fallback = (AlternateContentDocument.AlternateContent.Fallback)get_store().add_element_user(FALLBACK$2);
        return fallback;
      } 
    }
    
    public void unsetFallback() {
      synchronized (monitor()) {
        check_orphaned();
        get_store().remove_element(FALLBACK$2, 0);
      } 
    }
    
    public String getIgnorable() {
      synchronized (monitor()) {
        check_orphaned();
        SimpleValue simpleValue = null;
        simpleValue = (SimpleValue)get_store().find_attribute_user(IGNORABLE$4);
        if (simpleValue == null)
          return null; 
        return simpleValue.getStringValue();
      } 
    }
    
    public XmlString xgetIgnorable() {
      synchronized (monitor()) {
        check_orphaned();
        XmlString xmlString = null;
        xmlString = (XmlString)get_store().find_attribute_user(IGNORABLE$4);
        return xmlString;
      } 
    }
    
    public boolean isSetIgnorable() {
      synchronized (monitor()) {
        check_orphaned();
        return (get_store().find_attribute_user(IGNORABLE$4) != null);
      } 
    }
    
    public void setIgnorable(String param1String) {
      synchronized (monitor()) {
        check_orphaned();
        SimpleValue simpleValue = null;
        simpleValue = (SimpleValue)get_store().find_attribute_user(IGNORABLE$4);
        if (simpleValue == null)
          simpleValue = (SimpleValue)get_store().add_attribute_user(IGNORABLE$4); 
        simpleValue.setStringValue(param1String);
      } 
    }
    
    public void xsetIgnorable(XmlString param1XmlString) {
      synchronized (monitor()) {
        check_orphaned();
        XmlString xmlString = null;
        xmlString = (XmlString)get_store().find_attribute_user(IGNORABLE$4);
        if (xmlString == null)
          xmlString = (XmlString)get_store().add_attribute_user(IGNORABLE$4); 
        xmlString.set((XmlObject)param1XmlString);
      } 
    }
    
    public void unsetIgnorable() {
      synchronized (monitor()) {
        check_orphaned();
        get_store().remove_attribute(IGNORABLE$4);
      } 
    }
    
    public String getMustUnderstand() {
      synchronized (monitor()) {
        check_orphaned();
        SimpleValue simpleValue = null;
        simpleValue = (SimpleValue)get_store().find_attribute_user(MUSTUNDERSTAND$6);
        if (simpleValue == null)
          return null; 
        return simpleValue.getStringValue();
      } 
    }
    
    public XmlString xgetMustUnderstand() {
      synchronized (monitor()) {
        check_orphaned();
        XmlString xmlString = null;
        xmlString = (XmlString)get_store().find_attribute_user(MUSTUNDERSTAND$6);
        return xmlString;
      } 
    }
    
    public boolean isSetMustUnderstand() {
      synchronized (monitor()) {
        check_orphaned();
        return (get_store().find_attribute_user(MUSTUNDERSTAND$6) != null);
      } 
    }
    
    public void setMustUnderstand(String param1String) {
      synchronized (monitor()) {
        check_orphaned();
        SimpleValue simpleValue = null;
        simpleValue = (SimpleValue)get_store().find_attribute_user(MUSTUNDERSTAND$6);
        if (simpleValue == null)
          simpleValue = (SimpleValue)get_store().add_attribute_user(MUSTUNDERSTAND$6); 
        simpleValue.setStringValue(param1String);
      } 
    }
    
    public void xsetMustUnderstand(XmlString param1XmlString) {
      synchronized (monitor()) {
        check_orphaned();
        XmlString xmlString = null;
        xmlString = (XmlString)get_store().find_attribute_user(MUSTUNDERSTAND$6);
        if (xmlString == null)
          xmlString = (XmlString)get_store().add_attribute_user(MUSTUNDERSTAND$6); 
        xmlString.set((XmlObject)param1XmlString);
      } 
    }
    
    public void unsetMustUnderstand() {
      synchronized (monitor()) {
        check_orphaned();
        get_store().remove_attribute(MUSTUNDERSTAND$6);
      } 
    }
    
    public String getProcessContent() {
      synchronized (monitor()) {
        check_orphaned();
        SimpleValue simpleValue = null;
        simpleValue = (SimpleValue)get_store().find_attribute_user(PROCESSCONTENT$8);
        if (simpleValue == null)
          return null; 
        return simpleValue.getStringValue();
      } 
    }
    
    public XmlString xgetProcessContent() {
      synchronized (monitor()) {
        check_orphaned();
        XmlString xmlString = null;
        xmlString = (XmlString)get_store().find_attribute_user(PROCESSCONTENT$8);
        return xmlString;
      } 
    }
    
    public boolean isSetProcessContent() {
      synchronized (monitor()) {
        check_orphaned();
        return (get_store().find_attribute_user(PROCESSCONTENT$8) != null);
      } 
    }
    
    public void setProcessContent(String param1String) {
      synchronized (monitor()) {
        check_orphaned();
        SimpleValue simpleValue = null;
        simpleValue = (SimpleValue)get_store().find_attribute_user(PROCESSCONTENT$8);
        if (simpleValue == null)
          simpleValue = (SimpleValue)get_store().add_attribute_user(PROCESSCONTENT$8); 
        simpleValue.setStringValue(param1String);
      } 
    }
    
    public void xsetProcessContent(XmlString param1XmlString) {
      synchronized (monitor()) {
        check_orphaned();
        XmlString xmlString = null;
        xmlString = (XmlString)get_store().find_attribute_user(PROCESSCONTENT$8);
        if (xmlString == null)
          xmlString = (XmlString)get_store().add_attribute_user(PROCESSCONTENT$8); 
        xmlString.set((XmlObject)param1XmlString);
      } 
    }
    
    public void unsetProcessContent() {
      synchronized (monitor()) {
        check_orphaned();
        get_store().remove_attribute(PROCESSCONTENT$8);
      } 
    }
    
    public static class FallbackImpl extends XmlComplexContentImpl implements AlternateContentDocument.AlternateContent.Fallback {
      private static final long serialVersionUID = 1L;
      
      private static final QName IGNORABLE$0 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "Ignorable");
      
      private static final QName MUSTUNDERSTAND$2 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "MustUnderstand");
      
      private static final QName PROCESSCONTENT$4 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "ProcessContent");
      
      public FallbackImpl(SchemaType param2SchemaType) {
        super(param2SchemaType);
      }
      
      public String getIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(IGNORABLE$0);
          if (simpleValue == null)
            return null; 
          return simpleValue.getStringValue();
        } 
      }
      
      public XmlString xgetIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(IGNORABLE$0);
          return xmlString;
        } 
      }
      
      public boolean isSetIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          return (get_store().find_attribute_user(IGNORABLE$0) != null);
        } 
      }
      
      public void setIgnorable(String param2String) {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(IGNORABLE$0);
          if (simpleValue == null)
            simpleValue = (SimpleValue)get_store().add_attribute_user(IGNORABLE$0); 
          simpleValue.setStringValue(param2String);
        } 
      }
      
      public void xsetIgnorable(XmlString param2XmlString) {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(IGNORABLE$0);
          if (xmlString == null)
            xmlString = (XmlString)get_store().add_attribute_user(IGNORABLE$0); 
          xmlString.set((XmlObject)param2XmlString);
        } 
      }
      
      public void unsetIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          get_store().remove_attribute(IGNORABLE$0);
        } 
      }
      
      public String getMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(MUSTUNDERSTAND$2);
          if (simpleValue == null)
            return null; 
          return simpleValue.getStringValue();
        } 
      }
      
      public XmlString xgetMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(MUSTUNDERSTAND$2);
          return xmlString;
        } 
      }
      
      public boolean isSetMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          return (get_store().find_attribute_user(MUSTUNDERSTAND$2) != null);
        } 
      }
      
      public void setMustUnderstand(String param2String) {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(MUSTUNDERSTAND$2);
          if (simpleValue == null)
            simpleValue = (SimpleValue)get_store().add_attribute_user(MUSTUNDERSTAND$2); 
          simpleValue.setStringValue(param2String);
        } 
      }
      
      public void xsetMustUnderstand(XmlString param2XmlString) {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(MUSTUNDERSTAND$2);
          if (xmlString == null)
            xmlString = (XmlString)get_store().add_attribute_user(MUSTUNDERSTAND$2); 
          xmlString.set((XmlObject)param2XmlString);
        } 
      }
      
      public void unsetMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          get_store().remove_attribute(MUSTUNDERSTAND$2);
        } 
      }
      
      public String getProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(PROCESSCONTENT$4);
          if (simpleValue == null)
            return null; 
          return simpleValue.getStringValue();
        } 
      }
      
      public XmlString xgetProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(PROCESSCONTENT$4);
          return xmlString;
        } 
      }
      
      public boolean isSetProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          return (get_store().find_attribute_user(PROCESSCONTENT$4) != null);
        } 
      }
      
      public void setProcessContent(String param2String) {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(PROCESSCONTENT$4);
          if (simpleValue == null)
            simpleValue = (SimpleValue)get_store().add_attribute_user(PROCESSCONTENT$4); 
          simpleValue.setStringValue(param2String);
        } 
      }
      
      public void xsetProcessContent(XmlString param2XmlString) {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(PROCESSCONTENT$4);
          if (xmlString == null)
            xmlString = (XmlString)get_store().add_attribute_user(PROCESSCONTENT$4); 
          xmlString.set((XmlObject)param2XmlString);
        } 
      }
      
      public void unsetProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          get_store().remove_attribute(PROCESSCONTENT$4);
        } 
      }
    }
    
    public static class ChoiceImpl extends XmlComplexContentImpl implements AlternateContentDocument.AlternateContent.Choice {
      private static final long serialVersionUID = 1L;
      
      private static final QName REQUIRES$0 = new QName("", "Requires");
      
      private static final QName IGNORABLE$2 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "Ignorable");
      
      private static final QName MUSTUNDERSTAND$4 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "MustUnderstand");
      
      private static final QName PROCESSCONTENT$6 = new QName("http://schemas.openxmlformats.org/markup-compatibility/2006", "ProcessContent");
      
      public ChoiceImpl(SchemaType param2SchemaType) {
        super(param2SchemaType);
      }
      
      public String getRequires() {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(REQUIRES$0);
          if (simpleValue == null)
            return null; 
          return simpleValue.getStringValue();
        } 
      }
      
      public XmlString xgetRequires() {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(REQUIRES$0);
          return xmlString;
        } 
      }
      
      public void setRequires(String param2String) {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(REQUIRES$0);
          if (simpleValue == null)
            simpleValue = (SimpleValue)get_store().add_attribute_user(REQUIRES$0); 
          simpleValue.setStringValue(param2String);
        } 
      }
      
      public void xsetRequires(XmlString param2XmlString) {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(REQUIRES$0);
          if (xmlString == null)
            xmlString = (XmlString)get_store().add_attribute_user(REQUIRES$0); 
          xmlString.set((XmlObject)param2XmlString);
        } 
      }
      
      public String getIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(IGNORABLE$2);
          if (simpleValue == null)
            return null; 
          return simpleValue.getStringValue();
        } 
      }
      
      public XmlString xgetIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(IGNORABLE$2);
          return xmlString;
        } 
      }
      
      public boolean isSetIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          return (get_store().find_attribute_user(IGNORABLE$2) != null);
        } 
      }
      
      public void setIgnorable(String param2String) {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(IGNORABLE$2);
          if (simpleValue == null)
            simpleValue = (SimpleValue)get_store().add_attribute_user(IGNORABLE$2); 
          simpleValue.setStringValue(param2String);
        } 
      }
      
      public void xsetIgnorable(XmlString param2XmlString) {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(IGNORABLE$2);
          if (xmlString == null)
            xmlString = (XmlString)get_store().add_attribute_user(IGNORABLE$2); 
          xmlString.set((XmlObject)param2XmlString);
        } 
      }
      
      public void unsetIgnorable() {
        synchronized (monitor()) {
          check_orphaned();
          get_store().remove_attribute(IGNORABLE$2);
        } 
      }
      
      public String getMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(MUSTUNDERSTAND$4);
          if (simpleValue == null)
            return null; 
          return simpleValue.getStringValue();
        } 
      }
      
      public XmlString xgetMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(MUSTUNDERSTAND$4);
          return xmlString;
        } 
      }
      
      public boolean isSetMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          return (get_store().find_attribute_user(MUSTUNDERSTAND$4) != null);
        } 
      }
      
      public void setMustUnderstand(String param2String) {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(MUSTUNDERSTAND$4);
          if (simpleValue == null)
            simpleValue = (SimpleValue)get_store().add_attribute_user(MUSTUNDERSTAND$4); 
          simpleValue.setStringValue(param2String);
        } 
      }
      
      public void xsetMustUnderstand(XmlString param2XmlString) {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(MUSTUNDERSTAND$4);
          if (xmlString == null)
            xmlString = (XmlString)get_store().add_attribute_user(MUSTUNDERSTAND$4); 
          xmlString.set((XmlObject)param2XmlString);
        } 
      }
      
      public void unsetMustUnderstand() {
        synchronized (monitor()) {
          check_orphaned();
          get_store().remove_attribute(MUSTUNDERSTAND$4);
        } 
      }
      
      public String getProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(PROCESSCONTENT$6);
          if (simpleValue == null)
            return null; 
          return simpleValue.getStringValue();
        } 
      }
      
      public XmlString xgetProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(PROCESSCONTENT$6);
          return xmlString;
        } 
      }
      
      public boolean isSetProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          return (get_store().find_attribute_user(PROCESSCONTENT$6) != null);
        } 
      }
      
      public void setProcessContent(String param2String) {
        synchronized (monitor()) {
          check_orphaned();
          SimpleValue simpleValue = null;
          simpleValue = (SimpleValue)get_store().find_attribute_user(PROCESSCONTENT$6);
          if (simpleValue == null)
            simpleValue = (SimpleValue)get_store().add_attribute_user(PROCESSCONTENT$6); 
          simpleValue.setStringValue(param2String);
        } 
      }
      
      public void xsetProcessContent(XmlString param2XmlString) {
        synchronized (monitor()) {
          check_orphaned();
          XmlString xmlString = null;
          xmlString = (XmlString)get_store().find_attribute_user(PROCESSCONTENT$6);
          if (xmlString == null)
            xmlString = (XmlString)get_store().add_attribute_user(PROCESSCONTENT$6); 
          xmlString.set((XmlObject)param2XmlString);
        } 
      }
      
      public void unsetProcessContent() {
        synchronized (monitor()) {
          check_orphaned();
          get_store().remove_attribute(PROCESSCONTENT$6);
        } 
      }
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\com\microsoft\schemas\compatibility\impl\AlternateContentDocumentImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */