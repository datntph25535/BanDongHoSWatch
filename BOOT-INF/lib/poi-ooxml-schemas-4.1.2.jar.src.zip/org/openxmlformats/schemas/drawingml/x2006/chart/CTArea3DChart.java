package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTArea3DChart extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTArea3DChart.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctarea3dchart4c26type");
  
  CTGrouping getGrouping();
  
  boolean isSetGrouping();
  
  void setGrouping(CTGrouping paramCTGrouping);
  
  CTGrouping addNewGrouping();
  
  void unsetGrouping();
  
  CTBoolean getVaryColors();
  
  boolean isSetVaryColors();
  
  void setVaryColors(CTBoolean paramCTBoolean);
  
  CTBoolean addNewVaryColors();
  
  void unsetVaryColors();
  
  List<CTAreaSer> getSerList();
  
  @Deprecated
  CTAreaSer[] getSerArray();
  
  CTAreaSer getSerArray(int paramInt);
  
  int sizeOfSerArray();
  
  void setSerArray(CTAreaSer[] paramArrayOfCTAreaSer);
  
  void setSerArray(int paramInt, CTAreaSer paramCTAreaSer);
  
  CTAreaSer insertNewSer(int paramInt);
  
  CTAreaSer addNewSer();
  
  void removeSer(int paramInt);
  
  CTDLbls getDLbls();
  
  boolean isSetDLbls();
  
  void setDLbls(CTDLbls paramCTDLbls);
  
  CTDLbls addNewDLbls();
  
  void unsetDLbls();
  
  CTChartLines getDropLines();
  
  boolean isSetDropLines();
  
  void setDropLines(CTChartLines paramCTChartLines);
  
  CTChartLines addNewDropLines();
  
  void unsetDropLines();
  
  CTGapAmount getGapDepth();
  
  boolean isSetGapDepth();
  
  void setGapDepth(CTGapAmount paramCTGapAmount);
  
  CTGapAmount addNewGapDepth();
  
  void unsetGapDepth();
  
  List<CTUnsignedInt> getAxIdList();
  
  @Deprecated
  CTUnsignedInt[] getAxIdArray();
  
  CTUnsignedInt getAxIdArray(int paramInt);
  
  int sizeOfAxIdArray();
  
  void setAxIdArray(CTUnsignedInt[] paramArrayOfCTUnsignedInt);
  
  void setAxIdArray(int paramInt, CTUnsignedInt paramCTUnsignedInt);
  
  CTUnsignedInt insertNewAxId(int paramInt);
  
  CTUnsignedInt addNewAxId();
  
  void removeAxId(int paramInt);
  
  CTExtensionList getExtLst();
  
  boolean isSetExtLst();
  
  void setExtLst(CTExtensionList paramCTExtensionList);
  
  CTExtensionList addNewExtLst();
  
  void unsetExtLst();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTArea3DChart.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTArea3DChart newInstance() {
      return (CTArea3DChart)getTypeLoader().newInstance(CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart newInstance(XmlOptions param1XmlOptions) {
      return (CTArea3DChart)getTypeLoader().newInstance(CTArea3DChart.type, param1XmlOptions);
    }
    
    public static CTArea3DChart parse(String param1String) throws XmlException {
      return (CTArea3DChart)getTypeLoader().parse(param1String, CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTArea3DChart)getTypeLoader().parse(param1String, CTArea3DChart.type, param1XmlOptions);
    }
    
    public static CTArea3DChart parse(File param1File) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1File, CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1File, CTArea3DChart.type, param1XmlOptions);
    }
    
    public static CTArea3DChart parse(URL param1URL) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1URL, CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1URL, CTArea3DChart.type, param1XmlOptions);
    }
    
    public static CTArea3DChart parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1InputStream, CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1InputStream, CTArea3DChart.type, param1XmlOptions);
    }
    
    public static CTArea3DChart parse(Reader param1Reader) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1Reader, CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTArea3DChart)getTypeLoader().parse(param1Reader, CTArea3DChart.type, param1XmlOptions);
    }
    
    public static CTArea3DChart parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTArea3DChart)getTypeLoader().parse(param1XMLStreamReader, CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTArea3DChart)getTypeLoader().parse(param1XMLStreamReader, CTArea3DChart.type, param1XmlOptions);
    }
    
    public static CTArea3DChart parse(Node param1Node) throws XmlException {
      return (CTArea3DChart)getTypeLoader().parse(param1Node, CTArea3DChart.type, null);
    }
    
    public static CTArea3DChart parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTArea3DChart)getTypeLoader().parse(param1Node, CTArea3DChart.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTArea3DChart parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTArea3DChart)getTypeLoader().parse(param1XMLInputStream, CTArea3DChart.type, null);
    }
    
    @Deprecated
    public static CTArea3DChart parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTArea3DChart)getTypeLoader().parse(param1XMLInputStream, CTArea3DChart.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTArea3DChart.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTArea3DChart.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTArea3DChart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */