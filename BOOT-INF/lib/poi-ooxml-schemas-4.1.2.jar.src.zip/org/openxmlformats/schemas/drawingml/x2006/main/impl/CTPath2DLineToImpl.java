package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAdjPoint2D;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPath2DLineTo;

public class CTPath2DLineToImpl extends XmlComplexContentImpl implements CTPath2DLineTo {
  private static final long serialVersionUID = 1L;
  
  private static final QName PT$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "pt");
  
  public CTPath2DLineToImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTAdjPoint2D getPt() {
    synchronized (monitor()) {
      check_orphaned();
      CTAdjPoint2D cTAdjPoint2D = null;
      cTAdjPoint2D = (CTAdjPoint2D)get_store().find_element_user(PT$0, 0);
      if (cTAdjPoint2D == null)
        return null; 
      return cTAdjPoint2D;
    } 
  }
  
  public void setPt(CTAdjPoint2D paramCTAdjPoint2D) {
    generatedSetterHelperImpl((XmlObject)paramCTAdjPoint2D, PT$0, 0, (short)1);
  }
  
  public CTAdjPoint2D addNewPt() {
    synchronized (monitor()) {
      check_orphaned();
      CTAdjPoint2D cTAdjPoint2D = null;
      cTAdjPoint2D = (CTAdjPoint2D)get_store().add_element_user(PT$0);
      return cTAdjPoint2D;
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTPath2DLineToImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */