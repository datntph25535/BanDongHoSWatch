package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTDashStop;
import org.openxmlformats.schemas.drawingml.x2006.main.CTDashStopList;

public class CTDashStopListImpl extends XmlComplexContentImpl implements CTDashStopList {
  private static final long serialVersionUID = 1L;
  
  private static final QName DS$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "ds");
  
  public CTDashStopListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTDashStop> getDsList() {
    synchronized (monitor()) {
      check_orphaned();
      final class DsList extends AbstractList<CTDashStop> {
        public CTDashStop get(int param1Int) {
          return CTDashStopListImpl.this.getDsArray(param1Int);
        }
        
        public CTDashStop set(int param1Int, CTDashStop param1CTDashStop) {
          CTDashStop cTDashStop = CTDashStopListImpl.this.getDsArray(param1Int);
          CTDashStopListImpl.this.setDsArray(param1Int, param1CTDashStop);
          return cTDashStop;
        }
        
        public void add(int param1Int, CTDashStop param1CTDashStop) {
          CTDashStopListImpl.this.insertNewDs(param1Int).set((XmlObject)param1CTDashStop);
        }
        
        public CTDashStop remove(int param1Int) {
          CTDashStop cTDashStop = CTDashStopListImpl.this.getDsArray(param1Int);
          CTDashStopListImpl.this.removeDs(param1Int);
          return cTDashStop;
        }
        
        public int size() {
          return CTDashStopListImpl.this.sizeOfDsArray();
        }
      };
      return new DsList();
    } 
  }
  
  @Deprecated
  public CTDashStop[] getDsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(DS$0, arrayList);
      CTDashStop[] arrayOfCTDashStop = new CTDashStop[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTDashStop);
      return arrayOfCTDashStop;
    } 
  }
  
  public CTDashStop getDsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDashStop cTDashStop = null;
      cTDashStop = (CTDashStop)get_store().find_element_user(DS$0, paramInt);
      if (cTDashStop == null)
        throw new IndexOutOfBoundsException(); 
      return cTDashStop;
    } 
  }
  
  public int sizeOfDsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(DS$0);
    } 
  }
  
  public void setDsArray(CTDashStop[] paramArrayOfCTDashStop) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTDashStop, DS$0);
  }
  
  public void setDsArray(int paramInt, CTDashStop paramCTDashStop) {
    generatedSetterHelperImpl((XmlObject)paramCTDashStop, DS$0, paramInt, (short)2);
  }
  
  public CTDashStop insertNewDs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDashStop cTDashStop = null;
      cTDashStop = (CTDashStop)get_store().insert_element_user(DS$0, paramInt);
      return cTDashStop;
    } 
  }
  
  public CTDashStop addNewDs() {
    synchronized (monitor()) {
      check_orphaned();
      CTDashStop cTDashStop = null;
      cTDashStop = (CTDashStop)get_store().add_element_user(DS$0);
      return cTDashStop;
    } 
  }
  
  public void removeDs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DS$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTDashStopListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */