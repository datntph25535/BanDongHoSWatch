package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTArea3DChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTAreaChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBar3DChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBubbleChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTCatAx;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDTable;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDateAx;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDoughnutChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLayout;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLine3DChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLineChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTOfPieChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPie3DChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPieChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPlotArea;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTRadarChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTScatterChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSerAx;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTStockChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSurface3DChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSurfaceChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTValAx;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;

public class CTPlotAreaImpl extends XmlComplexContentImpl implements CTPlotArea {
  private static final long serialVersionUID = 1L;
  
  private static final QName LAYOUT$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "layout");
  
  private static final QName AREACHART$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "areaChart");
  
  private static final QName AREA3DCHART$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "area3DChart");
  
  private static final QName LINECHART$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "lineChart");
  
  private static final QName LINE3DCHART$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "line3DChart");
  
  private static final QName STOCKCHART$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "stockChart");
  
  private static final QName RADARCHART$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "radarChart");
  
  private static final QName SCATTERCHART$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "scatterChart");
  
  private static final QName PIECHART$16 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "pieChart");
  
  private static final QName PIE3DCHART$18 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "pie3DChart");
  
  private static final QName DOUGHNUTCHART$20 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "doughnutChart");
  
  private static final QName BARCHART$22 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "barChart");
  
  private static final QName BAR3DCHART$24 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "bar3DChart");
  
  private static final QName OFPIECHART$26 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "ofPieChart");
  
  private static final QName SURFACECHART$28 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "surfaceChart");
  
  private static final QName SURFACE3DCHART$30 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "surface3DChart");
  
  private static final QName BUBBLECHART$32 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "bubbleChart");
  
  private static final QName VALAX$34 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "valAx");
  
  private static final QName CATAX$36 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "catAx");
  
  private static final QName DATEAX$38 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dateAx");
  
  private static final QName SERAX$40 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "serAx");
  
  private static final QName DTABLE$42 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dTable");
  
  private static final QName SPPR$44 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName EXTLST$46 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTPlotAreaImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTLayout getLayout() {
    synchronized (monitor()) {
      check_orphaned();
      CTLayout cTLayout = null;
      cTLayout = (CTLayout)get_store().find_element_user(LAYOUT$0, 0);
      if (cTLayout == null)
        return null; 
      return cTLayout;
    } 
  }
  
  public boolean isSetLayout() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(LAYOUT$0) != 0);
    } 
  }
  
  public void setLayout(CTLayout paramCTLayout) {
    generatedSetterHelperImpl((XmlObject)paramCTLayout, LAYOUT$0, 0, (short)1);
  }
  
  public CTLayout addNewLayout() {
    synchronized (monitor()) {
      check_orphaned();
      CTLayout cTLayout = null;
      cTLayout = (CTLayout)get_store().add_element_user(LAYOUT$0);
      return cTLayout;
    } 
  }
  
  public void unsetLayout() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LAYOUT$0, 0);
    } 
  }
  
  public List<CTAreaChart> getAreaChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AreaChartList extends AbstractList<CTAreaChart> {
        public CTAreaChart get(int param1Int) {
          return CTPlotAreaImpl.this.getAreaChartArray(param1Int);
        }
        
        public CTAreaChart set(int param1Int, CTAreaChart param1CTAreaChart) {
          CTAreaChart cTAreaChart = CTPlotAreaImpl.this.getAreaChartArray(param1Int);
          CTPlotAreaImpl.this.setAreaChartArray(param1Int, param1CTAreaChart);
          return cTAreaChart;
        }
        
        public void add(int param1Int, CTAreaChart param1CTAreaChart) {
          CTPlotAreaImpl.this.insertNewAreaChart(param1Int).set((XmlObject)param1CTAreaChart);
        }
        
        public CTAreaChart remove(int param1Int) {
          CTAreaChart cTAreaChart = CTPlotAreaImpl.this.getAreaChartArray(param1Int);
          CTPlotAreaImpl.this.removeAreaChart(param1Int);
          return cTAreaChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfAreaChartArray();
        }
      };
      return new AreaChartList();
    } 
  }
  
  @Deprecated
  public CTAreaChart[] getAreaChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(AREACHART$2, arrayList);
      CTAreaChart[] arrayOfCTAreaChart = new CTAreaChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAreaChart);
      return arrayOfCTAreaChart;
    } 
  }
  
  public CTAreaChart getAreaChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAreaChart cTAreaChart = null;
      cTAreaChart = (CTAreaChart)get_store().find_element_user(AREACHART$2, paramInt);
      if (cTAreaChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTAreaChart;
    } 
  }
  
  public int sizeOfAreaChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(AREACHART$2);
    } 
  }
  
  public void setAreaChartArray(CTAreaChart[] paramArrayOfCTAreaChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAreaChart, AREACHART$2);
  }
  
  public void setAreaChartArray(int paramInt, CTAreaChart paramCTAreaChart) {
    generatedSetterHelperImpl((XmlObject)paramCTAreaChart, AREACHART$2, paramInt, (short)2);
  }
  
  public CTAreaChart insertNewAreaChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAreaChart cTAreaChart = null;
      cTAreaChart = (CTAreaChart)get_store().insert_element_user(AREACHART$2, paramInt);
      return cTAreaChart;
    } 
  }
  
  public CTAreaChart addNewAreaChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTAreaChart cTAreaChart = null;
      cTAreaChart = (CTAreaChart)get_store().add_element_user(AREACHART$2);
      return cTAreaChart;
    } 
  }
  
  public void removeAreaChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(AREACHART$2, paramInt);
    } 
  }
  
  public List<CTArea3DChart> getArea3DChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class Area3DChartList extends AbstractList<CTArea3DChart> {
        public CTArea3DChart get(int param1Int) {
          return CTPlotAreaImpl.this.getArea3DChartArray(param1Int);
        }
        
        public CTArea3DChart set(int param1Int, CTArea3DChart param1CTArea3DChart) {
          CTArea3DChart cTArea3DChart = CTPlotAreaImpl.this.getArea3DChartArray(param1Int);
          CTPlotAreaImpl.this.setArea3DChartArray(param1Int, param1CTArea3DChart);
          return cTArea3DChart;
        }
        
        public void add(int param1Int, CTArea3DChart param1CTArea3DChart) {
          CTPlotAreaImpl.this.insertNewArea3DChart(param1Int).set((XmlObject)param1CTArea3DChart);
        }
        
        public CTArea3DChart remove(int param1Int) {
          CTArea3DChart cTArea3DChart = CTPlotAreaImpl.this.getArea3DChartArray(param1Int);
          CTPlotAreaImpl.this.removeArea3DChart(param1Int);
          return cTArea3DChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfArea3DChartArray();
        }
      };
      return new Area3DChartList();
    } 
  }
  
  @Deprecated
  public CTArea3DChart[] getArea3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(AREA3DCHART$4, arrayList);
      CTArea3DChart[] arrayOfCTArea3DChart = new CTArea3DChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTArea3DChart);
      return arrayOfCTArea3DChart;
    } 
  }
  
  public CTArea3DChart getArea3DChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTArea3DChart cTArea3DChart = null;
      cTArea3DChart = (CTArea3DChart)get_store().find_element_user(AREA3DCHART$4, paramInt);
      if (cTArea3DChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTArea3DChart;
    } 
  }
  
  public int sizeOfArea3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(AREA3DCHART$4);
    } 
  }
  
  public void setArea3DChartArray(CTArea3DChart[] paramArrayOfCTArea3DChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTArea3DChart, AREA3DCHART$4);
  }
  
  public void setArea3DChartArray(int paramInt, CTArea3DChart paramCTArea3DChart) {
    generatedSetterHelperImpl((XmlObject)paramCTArea3DChart, AREA3DCHART$4, paramInt, (short)2);
  }
  
  public CTArea3DChart insertNewArea3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTArea3DChart cTArea3DChart = null;
      cTArea3DChart = (CTArea3DChart)get_store().insert_element_user(AREA3DCHART$4, paramInt);
      return cTArea3DChart;
    } 
  }
  
  public CTArea3DChart addNewArea3DChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTArea3DChart cTArea3DChart = null;
      cTArea3DChart = (CTArea3DChart)get_store().add_element_user(AREA3DCHART$4);
      return cTArea3DChart;
    } 
  }
  
  public void removeArea3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(AREA3DCHART$4, paramInt);
    } 
  }
  
  public List<CTLineChart> getLineChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class LineChartList extends AbstractList<CTLineChart> {
        public CTLineChart get(int param1Int) {
          return CTPlotAreaImpl.this.getLineChartArray(param1Int);
        }
        
        public CTLineChart set(int param1Int, CTLineChart param1CTLineChart) {
          CTLineChart cTLineChart = CTPlotAreaImpl.this.getLineChartArray(param1Int);
          CTPlotAreaImpl.this.setLineChartArray(param1Int, param1CTLineChart);
          return cTLineChart;
        }
        
        public void add(int param1Int, CTLineChart param1CTLineChart) {
          CTPlotAreaImpl.this.insertNewLineChart(param1Int).set((XmlObject)param1CTLineChart);
        }
        
        public CTLineChart remove(int param1Int) {
          CTLineChart cTLineChart = CTPlotAreaImpl.this.getLineChartArray(param1Int);
          CTPlotAreaImpl.this.removeLineChart(param1Int);
          return cTLineChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfLineChartArray();
        }
      };
      return new LineChartList();
    } 
  }
  
  @Deprecated
  public CTLineChart[] getLineChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(LINECHART$6, arrayList);
      CTLineChart[] arrayOfCTLineChart = new CTLineChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTLineChart);
      return arrayOfCTLineChart;
    } 
  }
  
  public CTLineChart getLineChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLineChart cTLineChart = null;
      cTLineChart = (CTLineChart)get_store().find_element_user(LINECHART$6, paramInt);
      if (cTLineChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTLineChart;
    } 
  }
  
  public int sizeOfLineChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(LINECHART$6);
    } 
  }
  
  public void setLineChartArray(CTLineChart[] paramArrayOfCTLineChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTLineChart, LINECHART$6);
  }
  
  public void setLineChartArray(int paramInt, CTLineChart paramCTLineChart) {
    generatedSetterHelperImpl((XmlObject)paramCTLineChart, LINECHART$6, paramInt, (short)2);
  }
  
  public CTLineChart insertNewLineChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLineChart cTLineChart = null;
      cTLineChart = (CTLineChart)get_store().insert_element_user(LINECHART$6, paramInt);
      return cTLineChart;
    } 
  }
  
  public CTLineChart addNewLineChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTLineChart cTLineChart = null;
      cTLineChart = (CTLineChart)get_store().add_element_user(LINECHART$6);
      return cTLineChart;
    } 
  }
  
  public void removeLineChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LINECHART$6, paramInt);
    } 
  }
  
  public List<CTLine3DChart> getLine3DChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class Line3DChartList extends AbstractList<CTLine3DChart> {
        public CTLine3DChart get(int param1Int) {
          return CTPlotAreaImpl.this.getLine3DChartArray(param1Int);
        }
        
        public CTLine3DChart set(int param1Int, CTLine3DChart param1CTLine3DChart) {
          CTLine3DChart cTLine3DChart = CTPlotAreaImpl.this.getLine3DChartArray(param1Int);
          CTPlotAreaImpl.this.setLine3DChartArray(param1Int, param1CTLine3DChart);
          return cTLine3DChart;
        }
        
        public void add(int param1Int, CTLine3DChart param1CTLine3DChart) {
          CTPlotAreaImpl.this.insertNewLine3DChart(param1Int).set((XmlObject)param1CTLine3DChart);
        }
        
        public CTLine3DChart remove(int param1Int) {
          CTLine3DChart cTLine3DChart = CTPlotAreaImpl.this.getLine3DChartArray(param1Int);
          CTPlotAreaImpl.this.removeLine3DChart(param1Int);
          return cTLine3DChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfLine3DChartArray();
        }
      };
      return new Line3DChartList();
    } 
  }
  
  @Deprecated
  public CTLine3DChart[] getLine3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(LINE3DCHART$8, arrayList);
      CTLine3DChart[] arrayOfCTLine3DChart = new CTLine3DChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTLine3DChart);
      return arrayOfCTLine3DChart;
    } 
  }
  
  public CTLine3DChart getLine3DChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLine3DChart cTLine3DChart = null;
      cTLine3DChart = (CTLine3DChart)get_store().find_element_user(LINE3DCHART$8, paramInt);
      if (cTLine3DChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTLine3DChart;
    } 
  }
  
  public int sizeOfLine3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(LINE3DCHART$8);
    } 
  }
  
  public void setLine3DChartArray(CTLine3DChart[] paramArrayOfCTLine3DChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTLine3DChart, LINE3DCHART$8);
  }
  
  public void setLine3DChartArray(int paramInt, CTLine3DChart paramCTLine3DChart) {
    generatedSetterHelperImpl((XmlObject)paramCTLine3DChart, LINE3DCHART$8, paramInt, (short)2);
  }
  
  public CTLine3DChart insertNewLine3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLine3DChart cTLine3DChart = null;
      cTLine3DChart = (CTLine3DChart)get_store().insert_element_user(LINE3DCHART$8, paramInt);
      return cTLine3DChart;
    } 
  }
  
  public CTLine3DChart addNewLine3DChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTLine3DChart cTLine3DChart = null;
      cTLine3DChart = (CTLine3DChart)get_store().add_element_user(LINE3DCHART$8);
      return cTLine3DChart;
    } 
  }
  
  public void removeLine3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LINE3DCHART$8, paramInt);
    } 
  }
  
  public List<CTStockChart> getStockChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class StockChartList extends AbstractList<CTStockChart> {
        public CTStockChart get(int param1Int) {
          return CTPlotAreaImpl.this.getStockChartArray(param1Int);
        }
        
        public CTStockChart set(int param1Int, CTStockChart param1CTStockChart) {
          CTStockChart cTStockChart = CTPlotAreaImpl.this.getStockChartArray(param1Int);
          CTPlotAreaImpl.this.setStockChartArray(param1Int, param1CTStockChart);
          return cTStockChart;
        }
        
        public void add(int param1Int, CTStockChart param1CTStockChart) {
          CTPlotAreaImpl.this.insertNewStockChart(param1Int).set((XmlObject)param1CTStockChart);
        }
        
        public CTStockChart remove(int param1Int) {
          CTStockChart cTStockChart = CTPlotAreaImpl.this.getStockChartArray(param1Int);
          CTPlotAreaImpl.this.removeStockChart(param1Int);
          return cTStockChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfStockChartArray();
        }
      };
      return new StockChartList();
    } 
  }
  
  @Deprecated
  public CTStockChart[] getStockChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(STOCKCHART$10, arrayList);
      CTStockChart[] arrayOfCTStockChart = new CTStockChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTStockChart);
      return arrayOfCTStockChart;
    } 
  }
  
  public CTStockChart getStockChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTStockChart cTStockChart = null;
      cTStockChart = (CTStockChart)get_store().find_element_user(STOCKCHART$10, paramInt);
      if (cTStockChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTStockChart;
    } 
  }
  
  public int sizeOfStockChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(STOCKCHART$10);
    } 
  }
  
  public void setStockChartArray(CTStockChart[] paramArrayOfCTStockChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTStockChart, STOCKCHART$10);
  }
  
  public void setStockChartArray(int paramInt, CTStockChart paramCTStockChart) {
    generatedSetterHelperImpl((XmlObject)paramCTStockChart, STOCKCHART$10, paramInt, (short)2);
  }
  
  public CTStockChart insertNewStockChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTStockChart cTStockChart = null;
      cTStockChart = (CTStockChart)get_store().insert_element_user(STOCKCHART$10, paramInt);
      return cTStockChart;
    } 
  }
  
  public CTStockChart addNewStockChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTStockChart cTStockChart = null;
      cTStockChart = (CTStockChart)get_store().add_element_user(STOCKCHART$10);
      return cTStockChart;
    } 
  }
  
  public void removeStockChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(STOCKCHART$10, paramInt);
    } 
  }
  
  public List<CTRadarChart> getRadarChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class RadarChartList extends AbstractList<CTRadarChart> {
        public CTRadarChart get(int param1Int) {
          return CTPlotAreaImpl.this.getRadarChartArray(param1Int);
        }
        
        public CTRadarChart set(int param1Int, CTRadarChart param1CTRadarChart) {
          CTRadarChart cTRadarChart = CTPlotAreaImpl.this.getRadarChartArray(param1Int);
          CTPlotAreaImpl.this.setRadarChartArray(param1Int, param1CTRadarChart);
          return cTRadarChart;
        }
        
        public void add(int param1Int, CTRadarChart param1CTRadarChart) {
          CTPlotAreaImpl.this.insertNewRadarChart(param1Int).set((XmlObject)param1CTRadarChart);
        }
        
        public CTRadarChart remove(int param1Int) {
          CTRadarChart cTRadarChart = CTPlotAreaImpl.this.getRadarChartArray(param1Int);
          CTPlotAreaImpl.this.removeRadarChart(param1Int);
          return cTRadarChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfRadarChartArray();
        }
      };
      return new RadarChartList();
    } 
  }
  
  @Deprecated
  public CTRadarChart[] getRadarChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(RADARCHART$12, arrayList);
      CTRadarChart[] arrayOfCTRadarChart = new CTRadarChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTRadarChart);
      return arrayOfCTRadarChart;
    } 
  }
  
  public CTRadarChart getRadarChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarChart cTRadarChart = null;
      cTRadarChart = (CTRadarChart)get_store().find_element_user(RADARCHART$12, paramInt);
      if (cTRadarChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTRadarChart;
    } 
  }
  
  public int sizeOfRadarChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(RADARCHART$12);
    } 
  }
  
  public void setRadarChartArray(CTRadarChart[] paramArrayOfCTRadarChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTRadarChart, RADARCHART$12);
  }
  
  public void setRadarChartArray(int paramInt, CTRadarChart paramCTRadarChart) {
    generatedSetterHelperImpl((XmlObject)paramCTRadarChart, RADARCHART$12, paramInt, (short)2);
  }
  
  public CTRadarChart insertNewRadarChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarChart cTRadarChart = null;
      cTRadarChart = (CTRadarChart)get_store().insert_element_user(RADARCHART$12, paramInt);
      return cTRadarChart;
    } 
  }
  
  public CTRadarChart addNewRadarChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarChart cTRadarChart = null;
      cTRadarChart = (CTRadarChart)get_store().add_element_user(RADARCHART$12);
      return cTRadarChart;
    } 
  }
  
  public void removeRadarChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(RADARCHART$12, paramInt);
    } 
  }
  
  public List<CTScatterChart> getScatterChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ScatterChartList extends AbstractList<CTScatterChart> {
        public CTScatterChart get(int param1Int) {
          return CTPlotAreaImpl.this.getScatterChartArray(param1Int);
        }
        
        public CTScatterChart set(int param1Int, CTScatterChart param1CTScatterChart) {
          CTScatterChart cTScatterChart = CTPlotAreaImpl.this.getScatterChartArray(param1Int);
          CTPlotAreaImpl.this.setScatterChartArray(param1Int, param1CTScatterChart);
          return cTScatterChart;
        }
        
        public void add(int param1Int, CTScatterChart param1CTScatterChart) {
          CTPlotAreaImpl.this.insertNewScatterChart(param1Int).set((XmlObject)param1CTScatterChart);
        }
        
        public CTScatterChart remove(int param1Int) {
          CTScatterChart cTScatterChart = CTPlotAreaImpl.this.getScatterChartArray(param1Int);
          CTPlotAreaImpl.this.removeScatterChart(param1Int);
          return cTScatterChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfScatterChartArray();
        }
      };
      return new ScatterChartList();
    } 
  }
  
  @Deprecated
  public CTScatterChart[] getScatterChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SCATTERCHART$14, arrayList);
      CTScatterChart[] arrayOfCTScatterChart = new CTScatterChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTScatterChart);
      return arrayOfCTScatterChart;
    } 
  }
  
  public CTScatterChart getScatterChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTScatterChart cTScatterChart = null;
      cTScatterChart = (CTScatterChart)get_store().find_element_user(SCATTERCHART$14, paramInt);
      if (cTScatterChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTScatterChart;
    } 
  }
  
  public int sizeOfScatterChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SCATTERCHART$14);
    } 
  }
  
  public void setScatterChartArray(CTScatterChart[] paramArrayOfCTScatterChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTScatterChart, SCATTERCHART$14);
  }
  
  public void setScatterChartArray(int paramInt, CTScatterChart paramCTScatterChart) {
    generatedSetterHelperImpl((XmlObject)paramCTScatterChart, SCATTERCHART$14, paramInt, (short)2);
  }
  
  public CTScatterChart insertNewScatterChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTScatterChart cTScatterChart = null;
      cTScatterChart = (CTScatterChart)get_store().insert_element_user(SCATTERCHART$14, paramInt);
      return cTScatterChart;
    } 
  }
  
  public CTScatterChart addNewScatterChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTScatterChart cTScatterChart = null;
      cTScatterChart = (CTScatterChart)get_store().add_element_user(SCATTERCHART$14);
      return cTScatterChart;
    } 
  }
  
  public void removeScatterChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SCATTERCHART$14, paramInt);
    } 
  }
  
  public List<CTPieChart> getPieChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class PieChartList extends AbstractList<CTPieChart> {
        public CTPieChart get(int param1Int) {
          return CTPlotAreaImpl.this.getPieChartArray(param1Int);
        }
        
        public CTPieChart set(int param1Int, CTPieChart param1CTPieChart) {
          CTPieChart cTPieChart = CTPlotAreaImpl.this.getPieChartArray(param1Int);
          CTPlotAreaImpl.this.setPieChartArray(param1Int, param1CTPieChart);
          return cTPieChart;
        }
        
        public void add(int param1Int, CTPieChart param1CTPieChart) {
          CTPlotAreaImpl.this.insertNewPieChart(param1Int).set((XmlObject)param1CTPieChart);
        }
        
        public CTPieChart remove(int param1Int) {
          CTPieChart cTPieChart = CTPlotAreaImpl.this.getPieChartArray(param1Int);
          CTPlotAreaImpl.this.removePieChart(param1Int);
          return cTPieChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfPieChartArray();
        }
      };
      return new PieChartList();
    } 
  }
  
  @Deprecated
  public CTPieChart[] getPieChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(PIECHART$16, arrayList);
      CTPieChart[] arrayOfCTPieChart = new CTPieChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTPieChart);
      return arrayOfCTPieChart;
    } 
  }
  
  public CTPieChart getPieChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPieChart cTPieChart = null;
      cTPieChart = (CTPieChart)get_store().find_element_user(PIECHART$16, paramInt);
      if (cTPieChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTPieChart;
    } 
  }
  
  public int sizeOfPieChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(PIECHART$16);
    } 
  }
  
  public void setPieChartArray(CTPieChart[] paramArrayOfCTPieChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTPieChart, PIECHART$16);
  }
  
  public void setPieChartArray(int paramInt, CTPieChart paramCTPieChart) {
    generatedSetterHelperImpl((XmlObject)paramCTPieChart, PIECHART$16, paramInt, (short)2);
  }
  
  public CTPieChart insertNewPieChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPieChart cTPieChart = null;
      cTPieChart = (CTPieChart)get_store().insert_element_user(PIECHART$16, paramInt);
      return cTPieChart;
    } 
  }
  
  public CTPieChart addNewPieChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTPieChart cTPieChart = null;
      cTPieChart = (CTPieChart)get_store().add_element_user(PIECHART$16);
      return cTPieChart;
    } 
  }
  
  public void removePieChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PIECHART$16, paramInt);
    } 
  }
  
  public List<CTPie3DChart> getPie3DChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class Pie3DChartList extends AbstractList<CTPie3DChart> {
        public CTPie3DChart get(int param1Int) {
          return CTPlotAreaImpl.this.getPie3DChartArray(param1Int);
        }
        
        public CTPie3DChart set(int param1Int, CTPie3DChart param1CTPie3DChart) {
          CTPie3DChart cTPie3DChart = CTPlotAreaImpl.this.getPie3DChartArray(param1Int);
          CTPlotAreaImpl.this.setPie3DChartArray(param1Int, param1CTPie3DChart);
          return cTPie3DChart;
        }
        
        public void add(int param1Int, CTPie3DChart param1CTPie3DChart) {
          CTPlotAreaImpl.this.insertNewPie3DChart(param1Int).set((XmlObject)param1CTPie3DChart);
        }
        
        public CTPie3DChart remove(int param1Int) {
          CTPie3DChart cTPie3DChart = CTPlotAreaImpl.this.getPie3DChartArray(param1Int);
          CTPlotAreaImpl.this.removePie3DChart(param1Int);
          return cTPie3DChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfPie3DChartArray();
        }
      };
      return new Pie3DChartList();
    } 
  }
  
  @Deprecated
  public CTPie3DChart[] getPie3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(PIE3DCHART$18, arrayList);
      CTPie3DChart[] arrayOfCTPie3DChart = new CTPie3DChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTPie3DChart);
      return arrayOfCTPie3DChart;
    } 
  }
  
  public CTPie3DChart getPie3DChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPie3DChart cTPie3DChart = null;
      cTPie3DChart = (CTPie3DChart)get_store().find_element_user(PIE3DCHART$18, paramInt);
      if (cTPie3DChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTPie3DChart;
    } 
  }
  
  public int sizeOfPie3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(PIE3DCHART$18);
    } 
  }
  
  public void setPie3DChartArray(CTPie3DChart[] paramArrayOfCTPie3DChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTPie3DChart, PIE3DCHART$18);
  }
  
  public void setPie3DChartArray(int paramInt, CTPie3DChart paramCTPie3DChart) {
    generatedSetterHelperImpl((XmlObject)paramCTPie3DChart, PIE3DCHART$18, paramInt, (short)2);
  }
  
  public CTPie3DChart insertNewPie3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPie3DChart cTPie3DChart = null;
      cTPie3DChart = (CTPie3DChart)get_store().insert_element_user(PIE3DCHART$18, paramInt);
      return cTPie3DChart;
    } 
  }
  
  public CTPie3DChart addNewPie3DChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTPie3DChart cTPie3DChart = null;
      cTPie3DChart = (CTPie3DChart)get_store().add_element_user(PIE3DCHART$18);
      return cTPie3DChart;
    } 
  }
  
  public void removePie3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PIE3DCHART$18, paramInt);
    } 
  }
  
  public List<CTDoughnutChart> getDoughnutChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class DoughnutChartList extends AbstractList<CTDoughnutChart> {
        public CTDoughnutChart get(int param1Int) {
          return CTPlotAreaImpl.this.getDoughnutChartArray(param1Int);
        }
        
        public CTDoughnutChart set(int param1Int, CTDoughnutChart param1CTDoughnutChart) {
          CTDoughnutChart cTDoughnutChart = CTPlotAreaImpl.this.getDoughnutChartArray(param1Int);
          CTPlotAreaImpl.this.setDoughnutChartArray(param1Int, param1CTDoughnutChart);
          return cTDoughnutChart;
        }
        
        public void add(int param1Int, CTDoughnutChart param1CTDoughnutChart) {
          CTPlotAreaImpl.this.insertNewDoughnutChart(param1Int).set((XmlObject)param1CTDoughnutChart);
        }
        
        public CTDoughnutChart remove(int param1Int) {
          CTDoughnutChart cTDoughnutChart = CTPlotAreaImpl.this.getDoughnutChartArray(param1Int);
          CTPlotAreaImpl.this.removeDoughnutChart(param1Int);
          return cTDoughnutChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfDoughnutChartArray();
        }
      };
      return new DoughnutChartList();
    } 
  }
  
  @Deprecated
  public CTDoughnutChart[] getDoughnutChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(DOUGHNUTCHART$20, arrayList);
      CTDoughnutChart[] arrayOfCTDoughnutChart = new CTDoughnutChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTDoughnutChart);
      return arrayOfCTDoughnutChart;
    } 
  }
  
  public CTDoughnutChart getDoughnutChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDoughnutChart cTDoughnutChart = null;
      cTDoughnutChart = (CTDoughnutChart)get_store().find_element_user(DOUGHNUTCHART$20, paramInt);
      if (cTDoughnutChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTDoughnutChart;
    } 
  }
  
  public int sizeOfDoughnutChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(DOUGHNUTCHART$20);
    } 
  }
  
  public void setDoughnutChartArray(CTDoughnutChart[] paramArrayOfCTDoughnutChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTDoughnutChart, DOUGHNUTCHART$20);
  }
  
  public void setDoughnutChartArray(int paramInt, CTDoughnutChart paramCTDoughnutChart) {
    generatedSetterHelperImpl((XmlObject)paramCTDoughnutChart, DOUGHNUTCHART$20, paramInt, (short)2);
  }
  
  public CTDoughnutChart insertNewDoughnutChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDoughnutChart cTDoughnutChart = null;
      cTDoughnutChart = (CTDoughnutChart)get_store().insert_element_user(DOUGHNUTCHART$20, paramInt);
      return cTDoughnutChart;
    } 
  }
  
  public CTDoughnutChart addNewDoughnutChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTDoughnutChart cTDoughnutChart = null;
      cTDoughnutChart = (CTDoughnutChart)get_store().add_element_user(DOUGHNUTCHART$20);
      return cTDoughnutChart;
    } 
  }
  
  public void removeDoughnutChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DOUGHNUTCHART$20, paramInt);
    } 
  }
  
  public List<CTBarChart> getBarChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class BarChartList extends AbstractList<CTBarChart> {
        public CTBarChart get(int param1Int) {
          return CTPlotAreaImpl.this.getBarChartArray(param1Int);
        }
        
        public CTBarChart set(int param1Int, CTBarChart param1CTBarChart) {
          CTBarChart cTBarChart = CTPlotAreaImpl.this.getBarChartArray(param1Int);
          CTPlotAreaImpl.this.setBarChartArray(param1Int, param1CTBarChart);
          return cTBarChart;
        }
        
        public void add(int param1Int, CTBarChart param1CTBarChart) {
          CTPlotAreaImpl.this.insertNewBarChart(param1Int).set((XmlObject)param1CTBarChart);
        }
        
        public CTBarChart remove(int param1Int) {
          CTBarChart cTBarChart = CTPlotAreaImpl.this.getBarChartArray(param1Int);
          CTPlotAreaImpl.this.removeBarChart(param1Int);
          return cTBarChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfBarChartArray();
        }
      };
      return new BarChartList();
    } 
  }
  
  @Deprecated
  public CTBarChart[] getBarChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(BARCHART$22, arrayList);
      CTBarChart[] arrayOfCTBarChart = new CTBarChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBarChart);
      return arrayOfCTBarChart;
    } 
  }
  
  public CTBarChart getBarChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBarChart cTBarChart = null;
      cTBarChart = (CTBarChart)get_store().find_element_user(BARCHART$22, paramInt);
      if (cTBarChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTBarChart;
    } 
  }
  
  public int sizeOfBarChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(BARCHART$22);
    } 
  }
  
  public void setBarChartArray(CTBarChart[] paramArrayOfCTBarChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBarChart, BARCHART$22);
  }
  
  public void setBarChartArray(int paramInt, CTBarChart paramCTBarChart) {
    generatedSetterHelperImpl((XmlObject)paramCTBarChart, BARCHART$22, paramInt, (short)2);
  }
  
  public CTBarChart insertNewBarChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBarChart cTBarChart = null;
      cTBarChart = (CTBarChart)get_store().insert_element_user(BARCHART$22, paramInt);
      return cTBarChart;
    } 
  }
  
  public CTBarChart addNewBarChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTBarChart cTBarChart = null;
      cTBarChart = (CTBarChart)get_store().add_element_user(BARCHART$22);
      return cTBarChart;
    } 
  }
  
  public void removeBarChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BARCHART$22, paramInt);
    } 
  }
  
  public List<CTBar3DChart> getBar3DChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class Bar3DChartList extends AbstractList<CTBar3DChart> {
        public CTBar3DChart get(int param1Int) {
          return CTPlotAreaImpl.this.getBar3DChartArray(param1Int);
        }
        
        public CTBar3DChart set(int param1Int, CTBar3DChart param1CTBar3DChart) {
          CTBar3DChart cTBar3DChart = CTPlotAreaImpl.this.getBar3DChartArray(param1Int);
          CTPlotAreaImpl.this.setBar3DChartArray(param1Int, param1CTBar3DChart);
          return cTBar3DChart;
        }
        
        public void add(int param1Int, CTBar3DChart param1CTBar3DChart) {
          CTPlotAreaImpl.this.insertNewBar3DChart(param1Int).set((XmlObject)param1CTBar3DChart);
        }
        
        public CTBar3DChart remove(int param1Int) {
          CTBar3DChart cTBar3DChart = CTPlotAreaImpl.this.getBar3DChartArray(param1Int);
          CTPlotAreaImpl.this.removeBar3DChart(param1Int);
          return cTBar3DChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfBar3DChartArray();
        }
      };
      return new Bar3DChartList();
    } 
  }
  
  @Deprecated
  public CTBar3DChart[] getBar3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(BAR3DCHART$24, arrayList);
      CTBar3DChart[] arrayOfCTBar3DChart = new CTBar3DChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBar3DChart);
      return arrayOfCTBar3DChart;
    } 
  }
  
  public CTBar3DChart getBar3DChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBar3DChart cTBar3DChart = null;
      cTBar3DChart = (CTBar3DChart)get_store().find_element_user(BAR3DCHART$24, paramInt);
      if (cTBar3DChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTBar3DChart;
    } 
  }
  
  public int sizeOfBar3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(BAR3DCHART$24);
    } 
  }
  
  public void setBar3DChartArray(CTBar3DChart[] paramArrayOfCTBar3DChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBar3DChart, BAR3DCHART$24);
  }
  
  public void setBar3DChartArray(int paramInt, CTBar3DChart paramCTBar3DChart) {
    generatedSetterHelperImpl((XmlObject)paramCTBar3DChart, BAR3DCHART$24, paramInt, (short)2);
  }
  
  public CTBar3DChart insertNewBar3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBar3DChart cTBar3DChart = null;
      cTBar3DChart = (CTBar3DChart)get_store().insert_element_user(BAR3DCHART$24, paramInt);
      return cTBar3DChart;
    } 
  }
  
  public CTBar3DChart addNewBar3DChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTBar3DChart cTBar3DChart = null;
      cTBar3DChart = (CTBar3DChart)get_store().add_element_user(BAR3DCHART$24);
      return cTBar3DChart;
    } 
  }
  
  public void removeBar3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BAR3DCHART$24, paramInt);
    } 
  }
  
  public List<CTOfPieChart> getOfPieChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class OfPieChartList extends AbstractList<CTOfPieChart> {
        public CTOfPieChart get(int param1Int) {
          return CTPlotAreaImpl.this.getOfPieChartArray(param1Int);
        }
        
        public CTOfPieChart set(int param1Int, CTOfPieChart param1CTOfPieChart) {
          CTOfPieChart cTOfPieChart = CTPlotAreaImpl.this.getOfPieChartArray(param1Int);
          CTPlotAreaImpl.this.setOfPieChartArray(param1Int, param1CTOfPieChart);
          return cTOfPieChart;
        }
        
        public void add(int param1Int, CTOfPieChart param1CTOfPieChart) {
          CTPlotAreaImpl.this.insertNewOfPieChart(param1Int).set((XmlObject)param1CTOfPieChart);
        }
        
        public CTOfPieChart remove(int param1Int) {
          CTOfPieChart cTOfPieChart = CTPlotAreaImpl.this.getOfPieChartArray(param1Int);
          CTPlotAreaImpl.this.removeOfPieChart(param1Int);
          return cTOfPieChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfOfPieChartArray();
        }
      };
      return new OfPieChartList();
    } 
  }
  
  @Deprecated
  public CTOfPieChart[] getOfPieChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(OFPIECHART$26, arrayList);
      CTOfPieChart[] arrayOfCTOfPieChart = new CTOfPieChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTOfPieChart);
      return arrayOfCTOfPieChart;
    } 
  }
  
  public CTOfPieChart getOfPieChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTOfPieChart cTOfPieChart = null;
      cTOfPieChart = (CTOfPieChart)get_store().find_element_user(OFPIECHART$26, paramInt);
      if (cTOfPieChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTOfPieChart;
    } 
  }
  
  public int sizeOfOfPieChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(OFPIECHART$26);
    } 
  }
  
  public void setOfPieChartArray(CTOfPieChart[] paramArrayOfCTOfPieChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTOfPieChart, OFPIECHART$26);
  }
  
  public void setOfPieChartArray(int paramInt, CTOfPieChart paramCTOfPieChart) {
    generatedSetterHelperImpl((XmlObject)paramCTOfPieChart, OFPIECHART$26, paramInt, (short)2);
  }
  
  public CTOfPieChart insertNewOfPieChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTOfPieChart cTOfPieChart = null;
      cTOfPieChart = (CTOfPieChart)get_store().insert_element_user(OFPIECHART$26, paramInt);
      return cTOfPieChart;
    } 
  }
  
  public CTOfPieChart addNewOfPieChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTOfPieChart cTOfPieChart = null;
      cTOfPieChart = (CTOfPieChart)get_store().add_element_user(OFPIECHART$26);
      return cTOfPieChart;
    } 
  }
  
  public void removeOfPieChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OFPIECHART$26, paramInt);
    } 
  }
  
  public List<CTSurfaceChart> getSurfaceChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SurfaceChartList extends AbstractList<CTSurfaceChart> {
        public CTSurfaceChart get(int param1Int) {
          return CTPlotAreaImpl.this.getSurfaceChartArray(param1Int);
        }
        
        public CTSurfaceChart set(int param1Int, CTSurfaceChart param1CTSurfaceChart) {
          CTSurfaceChart cTSurfaceChart = CTPlotAreaImpl.this.getSurfaceChartArray(param1Int);
          CTPlotAreaImpl.this.setSurfaceChartArray(param1Int, param1CTSurfaceChart);
          return cTSurfaceChart;
        }
        
        public void add(int param1Int, CTSurfaceChart param1CTSurfaceChart) {
          CTPlotAreaImpl.this.insertNewSurfaceChart(param1Int).set((XmlObject)param1CTSurfaceChart);
        }
        
        public CTSurfaceChart remove(int param1Int) {
          CTSurfaceChart cTSurfaceChart = CTPlotAreaImpl.this.getSurfaceChartArray(param1Int);
          CTPlotAreaImpl.this.removeSurfaceChart(param1Int);
          return cTSurfaceChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfSurfaceChartArray();
        }
      };
      return new SurfaceChartList();
    } 
  }
  
  @Deprecated
  public CTSurfaceChart[] getSurfaceChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SURFACECHART$28, arrayList);
      CTSurfaceChart[] arrayOfCTSurfaceChart = new CTSurfaceChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSurfaceChart);
      return arrayOfCTSurfaceChart;
    } 
  }
  
  public CTSurfaceChart getSurfaceChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSurfaceChart cTSurfaceChart = null;
      cTSurfaceChart = (CTSurfaceChart)get_store().find_element_user(SURFACECHART$28, paramInt);
      if (cTSurfaceChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTSurfaceChart;
    } 
  }
  
  public int sizeOfSurfaceChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SURFACECHART$28);
    } 
  }
  
  public void setSurfaceChartArray(CTSurfaceChart[] paramArrayOfCTSurfaceChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSurfaceChart, SURFACECHART$28);
  }
  
  public void setSurfaceChartArray(int paramInt, CTSurfaceChart paramCTSurfaceChart) {
    generatedSetterHelperImpl((XmlObject)paramCTSurfaceChart, SURFACECHART$28, paramInt, (short)2);
  }
  
  public CTSurfaceChart insertNewSurfaceChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSurfaceChart cTSurfaceChart = null;
      cTSurfaceChart = (CTSurfaceChart)get_store().insert_element_user(SURFACECHART$28, paramInt);
      return cTSurfaceChart;
    } 
  }
  
  public CTSurfaceChart addNewSurfaceChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTSurfaceChart cTSurfaceChart = null;
      cTSurfaceChart = (CTSurfaceChart)get_store().add_element_user(SURFACECHART$28);
      return cTSurfaceChart;
    } 
  }
  
  public void removeSurfaceChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SURFACECHART$28, paramInt);
    } 
  }
  
  public List<CTSurface3DChart> getSurface3DChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class Surface3DChartList extends AbstractList<CTSurface3DChart> {
        public CTSurface3DChart get(int param1Int) {
          return CTPlotAreaImpl.this.getSurface3DChartArray(param1Int);
        }
        
        public CTSurface3DChart set(int param1Int, CTSurface3DChart param1CTSurface3DChart) {
          CTSurface3DChart cTSurface3DChart = CTPlotAreaImpl.this.getSurface3DChartArray(param1Int);
          CTPlotAreaImpl.this.setSurface3DChartArray(param1Int, param1CTSurface3DChart);
          return cTSurface3DChart;
        }
        
        public void add(int param1Int, CTSurface3DChart param1CTSurface3DChart) {
          CTPlotAreaImpl.this.insertNewSurface3DChart(param1Int).set((XmlObject)param1CTSurface3DChart);
        }
        
        public CTSurface3DChart remove(int param1Int) {
          CTSurface3DChart cTSurface3DChart = CTPlotAreaImpl.this.getSurface3DChartArray(param1Int);
          CTPlotAreaImpl.this.removeSurface3DChart(param1Int);
          return cTSurface3DChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfSurface3DChartArray();
        }
      };
      return new Surface3DChartList();
    } 
  }
  
  @Deprecated
  public CTSurface3DChart[] getSurface3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SURFACE3DCHART$30, arrayList);
      CTSurface3DChart[] arrayOfCTSurface3DChart = new CTSurface3DChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSurface3DChart);
      return arrayOfCTSurface3DChart;
    } 
  }
  
  public CTSurface3DChart getSurface3DChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSurface3DChart cTSurface3DChart = null;
      cTSurface3DChart = (CTSurface3DChart)get_store().find_element_user(SURFACE3DCHART$30, paramInt);
      if (cTSurface3DChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTSurface3DChart;
    } 
  }
  
  public int sizeOfSurface3DChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SURFACE3DCHART$30);
    } 
  }
  
  public void setSurface3DChartArray(CTSurface3DChart[] paramArrayOfCTSurface3DChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSurface3DChart, SURFACE3DCHART$30);
  }
  
  public void setSurface3DChartArray(int paramInt, CTSurface3DChart paramCTSurface3DChart) {
    generatedSetterHelperImpl((XmlObject)paramCTSurface3DChart, SURFACE3DCHART$30, paramInt, (short)2);
  }
  
  public CTSurface3DChart insertNewSurface3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSurface3DChart cTSurface3DChart = null;
      cTSurface3DChart = (CTSurface3DChart)get_store().insert_element_user(SURFACE3DCHART$30, paramInt);
      return cTSurface3DChart;
    } 
  }
  
  public CTSurface3DChart addNewSurface3DChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTSurface3DChart cTSurface3DChart = null;
      cTSurface3DChart = (CTSurface3DChart)get_store().add_element_user(SURFACE3DCHART$30);
      return cTSurface3DChart;
    } 
  }
  
  public void removeSurface3DChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SURFACE3DCHART$30, paramInt);
    } 
  }
  
  public List<CTBubbleChart> getBubbleChartList() {
    synchronized (monitor()) {
      check_orphaned();
      final class BubbleChartList extends AbstractList<CTBubbleChart> {
        public CTBubbleChart get(int param1Int) {
          return CTPlotAreaImpl.this.getBubbleChartArray(param1Int);
        }
        
        public CTBubbleChart set(int param1Int, CTBubbleChart param1CTBubbleChart) {
          CTBubbleChart cTBubbleChart = CTPlotAreaImpl.this.getBubbleChartArray(param1Int);
          CTPlotAreaImpl.this.setBubbleChartArray(param1Int, param1CTBubbleChart);
          return cTBubbleChart;
        }
        
        public void add(int param1Int, CTBubbleChart param1CTBubbleChart) {
          CTPlotAreaImpl.this.insertNewBubbleChart(param1Int).set((XmlObject)param1CTBubbleChart);
        }
        
        public CTBubbleChart remove(int param1Int) {
          CTBubbleChart cTBubbleChart = CTPlotAreaImpl.this.getBubbleChartArray(param1Int);
          CTPlotAreaImpl.this.removeBubbleChart(param1Int);
          return cTBubbleChart;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfBubbleChartArray();
        }
      };
      return new BubbleChartList();
    } 
  }
  
  @Deprecated
  public CTBubbleChart[] getBubbleChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(BUBBLECHART$32, arrayList);
      CTBubbleChart[] arrayOfCTBubbleChart = new CTBubbleChart[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBubbleChart);
      return arrayOfCTBubbleChart;
    } 
  }
  
  public CTBubbleChart getBubbleChartArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBubbleChart cTBubbleChart = null;
      cTBubbleChart = (CTBubbleChart)get_store().find_element_user(BUBBLECHART$32, paramInt);
      if (cTBubbleChart == null)
        throw new IndexOutOfBoundsException(); 
      return cTBubbleChart;
    } 
  }
  
  public int sizeOfBubbleChartArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(BUBBLECHART$32);
    } 
  }
  
  public void setBubbleChartArray(CTBubbleChart[] paramArrayOfCTBubbleChart) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBubbleChart, BUBBLECHART$32);
  }
  
  public void setBubbleChartArray(int paramInt, CTBubbleChart paramCTBubbleChart) {
    generatedSetterHelperImpl((XmlObject)paramCTBubbleChart, BUBBLECHART$32, paramInt, (short)2);
  }
  
  public CTBubbleChart insertNewBubbleChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBubbleChart cTBubbleChart = null;
      cTBubbleChart = (CTBubbleChart)get_store().insert_element_user(BUBBLECHART$32, paramInt);
      return cTBubbleChart;
    } 
  }
  
  public CTBubbleChart addNewBubbleChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTBubbleChart cTBubbleChart = null;
      cTBubbleChart = (CTBubbleChart)get_store().add_element_user(BUBBLECHART$32);
      return cTBubbleChart;
    } 
  }
  
  public void removeBubbleChart(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BUBBLECHART$32, paramInt);
    } 
  }
  
  public List<CTValAx> getValAxList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ValAxList extends AbstractList<CTValAx> {
        public CTValAx get(int param1Int) {
          return CTPlotAreaImpl.this.getValAxArray(param1Int);
        }
        
        public CTValAx set(int param1Int, CTValAx param1CTValAx) {
          CTValAx cTValAx = CTPlotAreaImpl.this.getValAxArray(param1Int);
          CTPlotAreaImpl.this.setValAxArray(param1Int, param1CTValAx);
          return cTValAx;
        }
        
        public void add(int param1Int, CTValAx param1CTValAx) {
          CTPlotAreaImpl.this.insertNewValAx(param1Int).set((XmlObject)param1CTValAx);
        }
        
        public CTValAx remove(int param1Int) {
          CTValAx cTValAx = CTPlotAreaImpl.this.getValAxArray(param1Int);
          CTPlotAreaImpl.this.removeValAx(param1Int);
          return cTValAx;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfValAxArray();
        }
      };
      return new ValAxList();
    } 
  }
  
  @Deprecated
  public CTValAx[] getValAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(VALAX$34, arrayList);
      CTValAx[] arrayOfCTValAx = new CTValAx[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTValAx);
      return arrayOfCTValAx;
    } 
  }
  
  public CTValAx getValAxArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTValAx cTValAx = null;
      cTValAx = (CTValAx)get_store().find_element_user(VALAX$34, paramInt);
      if (cTValAx == null)
        throw new IndexOutOfBoundsException(); 
      return cTValAx;
    } 
  }
  
  public int sizeOfValAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(VALAX$34);
    } 
  }
  
  public void setValAxArray(CTValAx[] paramArrayOfCTValAx) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTValAx, VALAX$34);
  }
  
  public void setValAxArray(int paramInt, CTValAx paramCTValAx) {
    generatedSetterHelperImpl((XmlObject)paramCTValAx, VALAX$34, paramInt, (short)2);
  }
  
  public CTValAx insertNewValAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTValAx cTValAx = null;
      cTValAx = (CTValAx)get_store().insert_element_user(VALAX$34, paramInt);
      return cTValAx;
    } 
  }
  
  public CTValAx addNewValAx() {
    synchronized (monitor()) {
      check_orphaned();
      CTValAx cTValAx = null;
      cTValAx = (CTValAx)get_store().add_element_user(VALAX$34);
      return cTValAx;
    } 
  }
  
  public void removeValAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(VALAX$34, paramInt);
    } 
  }
  
  public List<CTCatAx> getCatAxList() {
    synchronized (monitor()) {
      check_orphaned();
      final class CatAxList extends AbstractList<CTCatAx> {
        public CTCatAx get(int param1Int) {
          return CTPlotAreaImpl.this.getCatAxArray(param1Int);
        }
        
        public CTCatAx set(int param1Int, CTCatAx param1CTCatAx) {
          CTCatAx cTCatAx = CTPlotAreaImpl.this.getCatAxArray(param1Int);
          CTPlotAreaImpl.this.setCatAxArray(param1Int, param1CTCatAx);
          return cTCatAx;
        }
        
        public void add(int param1Int, CTCatAx param1CTCatAx) {
          CTPlotAreaImpl.this.insertNewCatAx(param1Int).set((XmlObject)param1CTCatAx);
        }
        
        public CTCatAx remove(int param1Int) {
          CTCatAx cTCatAx = CTPlotAreaImpl.this.getCatAxArray(param1Int);
          CTPlotAreaImpl.this.removeCatAx(param1Int);
          return cTCatAx;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfCatAxArray();
        }
      };
      return new CatAxList();
    } 
  }
  
  @Deprecated
  public CTCatAx[] getCatAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CATAX$36, arrayList);
      CTCatAx[] arrayOfCTCatAx = new CTCatAx[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTCatAx);
      return arrayOfCTCatAx;
    } 
  }
  
  public CTCatAx getCatAxArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTCatAx cTCatAx = null;
      cTCatAx = (CTCatAx)get_store().find_element_user(CATAX$36, paramInt);
      if (cTCatAx == null)
        throw new IndexOutOfBoundsException(); 
      return cTCatAx;
    } 
  }
  
  public int sizeOfCatAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CATAX$36);
    } 
  }
  
  public void setCatAxArray(CTCatAx[] paramArrayOfCTCatAx) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTCatAx, CATAX$36);
  }
  
  public void setCatAxArray(int paramInt, CTCatAx paramCTCatAx) {
    generatedSetterHelperImpl((XmlObject)paramCTCatAx, CATAX$36, paramInt, (short)2);
  }
  
  public CTCatAx insertNewCatAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTCatAx cTCatAx = null;
      cTCatAx = (CTCatAx)get_store().insert_element_user(CATAX$36, paramInt);
      return cTCatAx;
    } 
  }
  
  public CTCatAx addNewCatAx() {
    synchronized (monitor()) {
      check_orphaned();
      CTCatAx cTCatAx = null;
      cTCatAx = (CTCatAx)get_store().add_element_user(CATAX$36);
      return cTCatAx;
    } 
  }
  
  public void removeCatAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CATAX$36, paramInt);
    } 
  }
  
  public List<CTDateAx> getDateAxList() {
    synchronized (monitor()) {
      check_orphaned();
      final class DateAxList extends AbstractList<CTDateAx> {
        public CTDateAx get(int param1Int) {
          return CTPlotAreaImpl.this.getDateAxArray(param1Int);
        }
        
        public CTDateAx set(int param1Int, CTDateAx param1CTDateAx) {
          CTDateAx cTDateAx = CTPlotAreaImpl.this.getDateAxArray(param1Int);
          CTPlotAreaImpl.this.setDateAxArray(param1Int, param1CTDateAx);
          return cTDateAx;
        }
        
        public void add(int param1Int, CTDateAx param1CTDateAx) {
          CTPlotAreaImpl.this.insertNewDateAx(param1Int).set((XmlObject)param1CTDateAx);
        }
        
        public CTDateAx remove(int param1Int) {
          CTDateAx cTDateAx = CTPlotAreaImpl.this.getDateAxArray(param1Int);
          CTPlotAreaImpl.this.removeDateAx(param1Int);
          return cTDateAx;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfDateAxArray();
        }
      };
      return new DateAxList();
    } 
  }
  
  @Deprecated
  public CTDateAx[] getDateAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(DATEAX$38, arrayList);
      CTDateAx[] arrayOfCTDateAx = new CTDateAx[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTDateAx);
      return arrayOfCTDateAx;
    } 
  }
  
  public CTDateAx getDateAxArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDateAx cTDateAx = null;
      cTDateAx = (CTDateAx)get_store().find_element_user(DATEAX$38, paramInt);
      if (cTDateAx == null)
        throw new IndexOutOfBoundsException(); 
      return cTDateAx;
    } 
  }
  
  public int sizeOfDateAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(DATEAX$38);
    } 
  }
  
  public void setDateAxArray(CTDateAx[] paramArrayOfCTDateAx) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTDateAx, DATEAX$38);
  }
  
  public void setDateAxArray(int paramInt, CTDateAx paramCTDateAx) {
    generatedSetterHelperImpl((XmlObject)paramCTDateAx, DATEAX$38, paramInt, (short)2);
  }
  
  public CTDateAx insertNewDateAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDateAx cTDateAx = null;
      cTDateAx = (CTDateAx)get_store().insert_element_user(DATEAX$38, paramInt);
      return cTDateAx;
    } 
  }
  
  public CTDateAx addNewDateAx() {
    synchronized (monitor()) {
      check_orphaned();
      CTDateAx cTDateAx = null;
      cTDateAx = (CTDateAx)get_store().add_element_user(DATEAX$38);
      return cTDateAx;
    } 
  }
  
  public void removeDateAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DATEAX$38, paramInt);
    } 
  }
  
  public List<CTSerAx> getSerAxList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SerAxList extends AbstractList<CTSerAx> {
        public CTSerAx get(int param1Int) {
          return CTPlotAreaImpl.this.getSerAxArray(param1Int);
        }
        
        public CTSerAx set(int param1Int, CTSerAx param1CTSerAx) {
          CTSerAx cTSerAx = CTPlotAreaImpl.this.getSerAxArray(param1Int);
          CTPlotAreaImpl.this.setSerAxArray(param1Int, param1CTSerAx);
          return cTSerAx;
        }
        
        public void add(int param1Int, CTSerAx param1CTSerAx) {
          CTPlotAreaImpl.this.insertNewSerAx(param1Int).set((XmlObject)param1CTSerAx);
        }
        
        public CTSerAx remove(int param1Int) {
          CTSerAx cTSerAx = CTPlotAreaImpl.this.getSerAxArray(param1Int);
          CTPlotAreaImpl.this.removeSerAx(param1Int);
          return cTSerAx;
        }
        
        public int size() {
          return CTPlotAreaImpl.this.sizeOfSerAxArray();
        }
      };
      return new SerAxList();
    } 
  }
  
  @Deprecated
  public CTSerAx[] getSerAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SERAX$40, arrayList);
      CTSerAx[] arrayOfCTSerAx = new CTSerAx[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSerAx);
      return arrayOfCTSerAx;
    } 
  }
  
  public CTSerAx getSerAxArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSerAx cTSerAx = null;
      cTSerAx = (CTSerAx)get_store().find_element_user(SERAX$40, paramInt);
      if (cTSerAx == null)
        throw new IndexOutOfBoundsException(); 
      return cTSerAx;
    } 
  }
  
  public int sizeOfSerAxArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SERAX$40);
    } 
  }
  
  public void setSerAxArray(CTSerAx[] paramArrayOfCTSerAx) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSerAx, SERAX$40);
  }
  
  public void setSerAxArray(int paramInt, CTSerAx paramCTSerAx) {
    generatedSetterHelperImpl((XmlObject)paramCTSerAx, SERAX$40, paramInt, (short)2);
  }
  
  public CTSerAx insertNewSerAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSerAx cTSerAx = null;
      cTSerAx = (CTSerAx)get_store().insert_element_user(SERAX$40, paramInt);
      return cTSerAx;
    } 
  }
  
  public CTSerAx addNewSerAx() {
    synchronized (monitor()) {
      check_orphaned();
      CTSerAx cTSerAx = null;
      cTSerAx = (CTSerAx)get_store().add_element_user(SERAX$40);
      return cTSerAx;
    } 
  }
  
  public void removeSerAx(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SERAX$40, paramInt);
    } 
  }
  
  public CTDTable getDTable() {
    synchronized (monitor()) {
      check_orphaned();
      CTDTable cTDTable = null;
      cTDTable = (CTDTable)get_store().find_element_user(DTABLE$42, 0);
      if (cTDTable == null)
        return null; 
      return cTDTable;
    } 
  }
  
  public boolean isSetDTable() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DTABLE$42) != 0);
    } 
  }
  
  public void setDTable(CTDTable paramCTDTable) {
    generatedSetterHelperImpl((XmlObject)paramCTDTable, DTABLE$42, 0, (short)1);
  }
  
  public CTDTable addNewDTable() {
    synchronized (monitor()) {
      check_orphaned();
      CTDTable cTDTable = null;
      cTDTable = (CTDTable)get_store().add_element_user(DTABLE$42);
      return cTDTable;
    } 
  }
  
  public void unsetDTable() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DTABLE$42, 0);
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$44, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$44) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$44, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$44);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$44, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$46, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$46) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$46, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$46);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$46, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTPlotAreaImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */