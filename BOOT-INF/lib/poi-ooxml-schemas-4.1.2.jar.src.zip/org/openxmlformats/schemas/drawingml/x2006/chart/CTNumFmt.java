package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlBoolean;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTNumFmt extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTNumFmt.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctnumfmtc0f5type");
  
  String getFormatCode();
  
  STXstring xgetFormatCode();
  
  void setFormatCode(String paramString);
  
  void xsetFormatCode(STXstring paramSTXstring);
  
  boolean getSourceLinked();
  
  XmlBoolean xgetSourceLinked();
  
  boolean isSetSourceLinked();
  
  void setSourceLinked(boolean paramBoolean);
  
  void xsetSourceLinked(XmlBoolean paramXmlBoolean);
  
  void unsetSourceLinked();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTNumFmt.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTNumFmt newInstance() {
      return (CTNumFmt)getTypeLoader().newInstance(CTNumFmt.type, null);
    }
    
    public static CTNumFmt newInstance(XmlOptions param1XmlOptions) {
      return (CTNumFmt)getTypeLoader().newInstance(CTNumFmt.type, param1XmlOptions);
    }
    
    public static CTNumFmt parse(String param1String) throws XmlException {
      return (CTNumFmt)getTypeLoader().parse(param1String, CTNumFmt.type, null);
    }
    
    public static CTNumFmt parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTNumFmt)getTypeLoader().parse(param1String, CTNumFmt.type, param1XmlOptions);
    }
    
    public static CTNumFmt parse(File param1File) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1File, CTNumFmt.type, null);
    }
    
    public static CTNumFmt parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1File, CTNumFmt.type, param1XmlOptions);
    }
    
    public static CTNumFmt parse(URL param1URL) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1URL, CTNumFmt.type, null);
    }
    
    public static CTNumFmt parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1URL, CTNumFmt.type, param1XmlOptions);
    }
    
    public static CTNumFmt parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1InputStream, CTNumFmt.type, null);
    }
    
    public static CTNumFmt parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1InputStream, CTNumFmt.type, param1XmlOptions);
    }
    
    public static CTNumFmt parse(Reader param1Reader) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1Reader, CTNumFmt.type, null);
    }
    
    public static CTNumFmt parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTNumFmt)getTypeLoader().parse(param1Reader, CTNumFmt.type, param1XmlOptions);
    }
    
    public static CTNumFmt parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTNumFmt)getTypeLoader().parse(param1XMLStreamReader, CTNumFmt.type, null);
    }
    
    public static CTNumFmt parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTNumFmt)getTypeLoader().parse(param1XMLStreamReader, CTNumFmt.type, param1XmlOptions);
    }
    
    public static CTNumFmt parse(Node param1Node) throws XmlException {
      return (CTNumFmt)getTypeLoader().parse(param1Node, CTNumFmt.type, null);
    }
    
    public static CTNumFmt parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTNumFmt)getTypeLoader().parse(param1Node, CTNumFmt.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTNumFmt parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTNumFmt)getTypeLoader().parse(param1XMLInputStream, CTNumFmt.type, null);
    }
    
    @Deprecated
    public static CTNumFmt parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTNumFmt)getTypeLoader().parse(param1XMLInputStream, CTNumFmt.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTNumFmt.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTNumFmt.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTNumFmt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */