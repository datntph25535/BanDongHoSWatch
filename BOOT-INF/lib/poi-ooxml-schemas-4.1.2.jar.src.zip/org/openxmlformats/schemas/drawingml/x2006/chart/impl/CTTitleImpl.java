package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLayout;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTTitle;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTTx;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextBody;

public class CTTitleImpl extends XmlComplexContentImpl implements CTTitle {
  private static final long serialVersionUID = 1L;
  
  private static final QName TX$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "tx");
  
  private static final QName LAYOUT$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "layout");
  
  private static final QName OVERLAY$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "overlay");
  
  private static final QName SPPR$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName TXPR$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "txPr");
  
  private static final QName EXTLST$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTTitleImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTTx getTx() {
    synchronized (monitor()) {
      check_orphaned();
      CTTx cTTx = null;
      cTTx = (CTTx)get_store().find_element_user(TX$0, 0);
      if (cTTx == null)
        return null; 
      return cTTx;
    } 
  }
  
  public boolean isSetTx() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(TX$0) != 0);
    } 
  }
  
  public void setTx(CTTx paramCTTx) {
    generatedSetterHelperImpl((XmlObject)paramCTTx, TX$0, 0, (short)1);
  }
  
  public CTTx addNewTx() {
    synchronized (monitor()) {
      check_orphaned();
      CTTx cTTx = null;
      cTTx = (CTTx)get_store().add_element_user(TX$0);
      return cTTx;
    } 
  }
  
  public void unsetTx() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TX$0, 0);
    } 
  }
  
  public CTLayout getLayout() {
    synchronized (monitor()) {
      check_orphaned();
      CTLayout cTLayout = null;
      cTLayout = (CTLayout)get_store().find_element_user(LAYOUT$2, 0);
      if (cTLayout == null)
        return null; 
      return cTLayout;
    } 
  }
  
  public boolean isSetLayout() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(LAYOUT$2) != 0);
    } 
  }
  
  public void setLayout(CTLayout paramCTLayout) {
    generatedSetterHelperImpl((XmlObject)paramCTLayout, LAYOUT$2, 0, (short)1);
  }
  
  public CTLayout addNewLayout() {
    synchronized (monitor()) {
      check_orphaned();
      CTLayout cTLayout = null;
      cTLayout = (CTLayout)get_store().add_element_user(LAYOUT$2);
      return cTLayout;
    } 
  }
  
  public void unsetLayout() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LAYOUT$2, 0);
    } 
  }
  
  public CTBoolean getOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(OVERLAY$4, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(OVERLAY$4) != 0);
    } 
  }
  
  public void setOverlay(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, OVERLAY$4, 0, (short)1);
  }
  
  public CTBoolean addNewOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(OVERLAY$4);
      return cTBoolean;
    } 
  }
  
  public void unsetOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OVERLAY$4, 0);
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$6, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$6) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$6, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$6);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$6, 0);
    } 
  }
  
  public CTTextBody getTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextBody cTTextBody = null;
      cTTextBody = (CTTextBody)get_store().find_element_user(TXPR$8, 0);
      if (cTTextBody == null)
        return null; 
      return cTTextBody;
    } 
  }
  
  public boolean isSetTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(TXPR$8) != 0);
    } 
  }
  
  public void setTxPr(CTTextBody paramCTTextBody) {
    generatedSetterHelperImpl((XmlObject)paramCTTextBody, TXPR$8, 0, (short)1);
  }
  
  public CTTextBody addNewTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextBody cTTextBody = null;
      cTTextBody = (CTTextBody)get_store().add_element_user(TXPR$8);
      return cTTextBody;
    } 
  }
  
  public void unsetTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TXPR$8, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$10, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$10) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$10, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$10);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$10, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTTitleImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */