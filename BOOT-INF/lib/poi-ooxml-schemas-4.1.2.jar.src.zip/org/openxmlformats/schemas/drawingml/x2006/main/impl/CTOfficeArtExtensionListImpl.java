package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTOfficeArtExtension;
import org.openxmlformats.schemas.drawingml.x2006.main.CTOfficeArtExtensionList;

public class CTOfficeArtExtensionListImpl extends XmlComplexContentImpl implements CTOfficeArtExtensionList {
  private static final long serialVersionUID = 1L;
  
  private static final QName EXT$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "ext");
  
  public CTOfficeArtExtensionListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTOfficeArtExtension> getExtList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ExtList extends AbstractList<CTOfficeArtExtension> {
        public CTOfficeArtExtension get(int param1Int) {
          return CTOfficeArtExtensionListImpl.this.getExtArray(param1Int);
        }
        
        public CTOfficeArtExtension set(int param1Int, CTOfficeArtExtension param1CTOfficeArtExtension) {
          CTOfficeArtExtension cTOfficeArtExtension = CTOfficeArtExtensionListImpl.this.getExtArray(param1Int);
          CTOfficeArtExtensionListImpl.this.setExtArray(param1Int, param1CTOfficeArtExtension);
          return cTOfficeArtExtension;
        }
        
        public void add(int param1Int, CTOfficeArtExtension param1CTOfficeArtExtension) {
          CTOfficeArtExtensionListImpl.this.insertNewExt(param1Int).set((XmlObject)param1CTOfficeArtExtension);
        }
        
        public CTOfficeArtExtension remove(int param1Int) {
          CTOfficeArtExtension cTOfficeArtExtension = CTOfficeArtExtensionListImpl.this.getExtArray(param1Int);
          CTOfficeArtExtensionListImpl.this.removeExt(param1Int);
          return cTOfficeArtExtension;
        }
        
        public int size() {
          return CTOfficeArtExtensionListImpl.this.sizeOfExtArray();
        }
      };
      return new ExtList();
    } 
  }
  
  @Deprecated
  public CTOfficeArtExtension[] getExtArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(EXT$0, arrayList);
      CTOfficeArtExtension[] arrayOfCTOfficeArtExtension = new CTOfficeArtExtension[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTOfficeArtExtension);
      return arrayOfCTOfficeArtExtension;
    } 
  }
  
  public CTOfficeArtExtension getExtArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTOfficeArtExtension cTOfficeArtExtension = null;
      cTOfficeArtExtension = (CTOfficeArtExtension)get_store().find_element_user(EXT$0, paramInt);
      if (cTOfficeArtExtension == null)
        throw new IndexOutOfBoundsException(); 
      return cTOfficeArtExtension;
    } 
  }
  
  public int sizeOfExtArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(EXT$0);
    } 
  }
  
  public void setExtArray(CTOfficeArtExtension[] paramArrayOfCTOfficeArtExtension) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTOfficeArtExtension, EXT$0);
  }
  
  public void setExtArray(int paramInt, CTOfficeArtExtension paramCTOfficeArtExtension) {
    generatedSetterHelperImpl((XmlObject)paramCTOfficeArtExtension, EXT$0, paramInt, (short)2);
  }
  
  public CTOfficeArtExtension insertNewExt(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTOfficeArtExtension cTOfficeArtExtension = null;
      cTOfficeArtExtension = (CTOfficeArtExtension)get_store().insert_element_user(EXT$0, paramInt);
      return cTOfficeArtExtension;
    } 
  }
  
  public CTOfficeArtExtension addNewExt() {
    synchronized (monitor()) {
      check_orphaned();
      CTOfficeArtExtension cTOfficeArtExtension = null;
      cTOfficeArtExtension = (CTOfficeArtExtension)get_store().add_element_user(EXT$0);
      return cTOfficeArtExtension;
    } 
  }
  
  public void removeExt(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXT$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTOfficeArtExtensionListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */