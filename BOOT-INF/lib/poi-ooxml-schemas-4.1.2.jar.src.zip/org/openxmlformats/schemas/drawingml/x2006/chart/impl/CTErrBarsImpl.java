package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDouble;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTErrBarType;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTErrBars;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTErrDir;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTErrValType;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTNumDataSource;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;

public class CTErrBarsImpl extends XmlComplexContentImpl implements CTErrBars {
  private static final long serialVersionUID = 1L;
  
  private static final QName ERRDIR$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "errDir");
  
  private static final QName ERRBARTYPE$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "errBarType");
  
  private static final QName ERRVALTYPE$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "errValType");
  
  private static final QName NOENDCAP$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "noEndCap");
  
  private static final QName PLUS$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "plus");
  
  private static final QName MINUS$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "minus");
  
  private static final QName VAL$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "val");
  
  private static final QName SPPR$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName EXTLST$16 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTErrBarsImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTErrDir getErrDir() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrDir cTErrDir = null;
      cTErrDir = (CTErrDir)get_store().find_element_user(ERRDIR$0, 0);
      if (cTErrDir == null)
        return null; 
      return cTErrDir;
    } 
  }
  
  public boolean isSetErrDir() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(ERRDIR$0) != 0);
    } 
  }
  
  public void setErrDir(CTErrDir paramCTErrDir) {
    generatedSetterHelperImpl((XmlObject)paramCTErrDir, ERRDIR$0, 0, (short)1);
  }
  
  public CTErrDir addNewErrDir() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrDir cTErrDir = null;
      cTErrDir = (CTErrDir)get_store().add_element_user(ERRDIR$0);
      return cTErrDir;
    } 
  }
  
  public void unsetErrDir() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ERRDIR$0, 0);
    } 
  }
  
  public CTErrBarType getErrBarType() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrBarType cTErrBarType = null;
      cTErrBarType = (CTErrBarType)get_store().find_element_user(ERRBARTYPE$2, 0);
      if (cTErrBarType == null)
        return null; 
      return cTErrBarType;
    } 
  }
  
  public void setErrBarType(CTErrBarType paramCTErrBarType) {
    generatedSetterHelperImpl((XmlObject)paramCTErrBarType, ERRBARTYPE$2, 0, (short)1);
  }
  
  public CTErrBarType addNewErrBarType() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrBarType cTErrBarType = null;
      cTErrBarType = (CTErrBarType)get_store().add_element_user(ERRBARTYPE$2);
      return cTErrBarType;
    } 
  }
  
  public CTErrValType getErrValType() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrValType cTErrValType = null;
      cTErrValType = (CTErrValType)get_store().find_element_user(ERRVALTYPE$4, 0);
      if (cTErrValType == null)
        return null; 
      return cTErrValType;
    } 
  }
  
  public void setErrValType(CTErrValType paramCTErrValType) {
    generatedSetterHelperImpl((XmlObject)paramCTErrValType, ERRVALTYPE$4, 0, (short)1);
  }
  
  public CTErrValType addNewErrValType() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrValType cTErrValType = null;
      cTErrValType = (CTErrValType)get_store().add_element_user(ERRVALTYPE$4);
      return cTErrValType;
    } 
  }
  
  public CTBoolean getNoEndCap() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(NOENDCAP$6, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetNoEndCap() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(NOENDCAP$6) != 0);
    } 
  }
  
  public void setNoEndCap(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, NOENDCAP$6, 0, (short)1);
  }
  
  public CTBoolean addNewNoEndCap() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(NOENDCAP$6);
      return cTBoolean;
    } 
  }
  
  public void unsetNoEndCap() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(NOENDCAP$6, 0);
    } 
  }
  
  public CTNumDataSource getPlus() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().find_element_user(PLUS$8, 0);
      if (cTNumDataSource == null)
        return null; 
      return cTNumDataSource;
    } 
  }
  
  public boolean isSetPlus() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PLUS$8) != 0);
    } 
  }
  
  public void setPlus(CTNumDataSource paramCTNumDataSource) {
    generatedSetterHelperImpl((XmlObject)paramCTNumDataSource, PLUS$8, 0, (short)1);
  }
  
  public CTNumDataSource addNewPlus() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().add_element_user(PLUS$8);
      return cTNumDataSource;
    } 
  }
  
  public void unsetPlus() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PLUS$8, 0);
    } 
  }
  
  public CTNumDataSource getMinus() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().find_element_user(MINUS$10, 0);
      if (cTNumDataSource == null)
        return null; 
      return cTNumDataSource;
    } 
  }
  
  public boolean isSetMinus() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(MINUS$10) != 0);
    } 
  }
  
  public void setMinus(CTNumDataSource paramCTNumDataSource) {
    generatedSetterHelperImpl((XmlObject)paramCTNumDataSource, MINUS$10, 0, (short)1);
  }
  
  public CTNumDataSource addNewMinus() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().add_element_user(MINUS$10);
      return cTNumDataSource;
    } 
  }
  
  public void unsetMinus() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(MINUS$10, 0);
    } 
  }
  
  public CTDouble getVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTDouble cTDouble = null;
      cTDouble = (CTDouble)get_store().find_element_user(VAL$12, 0);
      if (cTDouble == null)
        return null; 
      return cTDouble;
    } 
  }
  
  public boolean isSetVal() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(VAL$12) != 0);
    } 
  }
  
  public void setVal(CTDouble paramCTDouble) {
    generatedSetterHelperImpl((XmlObject)paramCTDouble, VAL$12, 0, (short)1);
  }
  
  public CTDouble addNewVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTDouble cTDouble = null;
      cTDouble = (CTDouble)get_store().add_element_user(VAL$12);
      return cTDouble;
    } 
  }
  
  public void unsetVal() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(VAL$12, 0);
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$14, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$14) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$14, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$14);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$14, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$16, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$16) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$16, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$16);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$16, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTErrBarsImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */