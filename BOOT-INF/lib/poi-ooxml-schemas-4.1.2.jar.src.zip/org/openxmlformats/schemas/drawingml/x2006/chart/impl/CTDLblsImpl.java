package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTChartLines;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLblPos;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbls;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTNumFmt;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextBody;

public class CTDLblsImpl extends XmlComplexContentImpl implements CTDLbls {
  private static final long serialVersionUID = 1L;
  
  private static final QName DLBL$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dLbl");
  
  private static final QName DELETE$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "delete");
  
  private static final QName NUMFMT$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "numFmt");
  
  private static final QName SPPR$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName TXPR$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "txPr");
  
  private static final QName DLBLPOS$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dLblPos");
  
  private static final QName SHOWLEGENDKEY$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "showLegendKey");
  
  private static final QName SHOWVAL$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "showVal");
  
  private static final QName SHOWCATNAME$16 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "showCatName");
  
  private static final QName SHOWSERNAME$18 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "showSerName");
  
  private static final QName SHOWPERCENT$20 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "showPercent");
  
  private static final QName SHOWBUBBLESIZE$22 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "showBubbleSize");
  
  private static final QName SEPARATOR$24 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "separator");
  
  private static final QName SHOWLEADERLINES$26 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "showLeaderLines");
  
  private static final QName LEADERLINES$28 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "leaderLines");
  
  private static final QName EXTLST$30 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTDLblsImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTDLbl> getDLblList() {
    synchronized (monitor()) {
      check_orphaned();
      final class DLblList extends AbstractList<CTDLbl> {
        public CTDLbl get(int param1Int) {
          return CTDLblsImpl.this.getDLblArray(param1Int);
        }
        
        public CTDLbl set(int param1Int, CTDLbl param1CTDLbl) {
          CTDLbl cTDLbl = CTDLblsImpl.this.getDLblArray(param1Int);
          CTDLblsImpl.this.setDLblArray(param1Int, param1CTDLbl);
          return cTDLbl;
        }
        
        public void add(int param1Int, CTDLbl param1CTDLbl) {
          CTDLblsImpl.this.insertNewDLbl(param1Int).set((XmlObject)param1CTDLbl);
        }
        
        public CTDLbl remove(int param1Int) {
          CTDLbl cTDLbl = CTDLblsImpl.this.getDLblArray(param1Int);
          CTDLblsImpl.this.removeDLbl(param1Int);
          return cTDLbl;
        }
        
        public int size() {
          return CTDLblsImpl.this.sizeOfDLblArray();
        }
      };
      return new DLblList();
    } 
  }
  
  @Deprecated
  public CTDLbl[] getDLblArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(DLBL$0, arrayList);
      CTDLbl[] arrayOfCTDLbl = new CTDLbl[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTDLbl);
      return arrayOfCTDLbl;
    } 
  }
  
  public CTDLbl getDLblArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbl cTDLbl = null;
      cTDLbl = (CTDLbl)get_store().find_element_user(DLBL$0, paramInt);
      if (cTDLbl == null)
        throw new IndexOutOfBoundsException(); 
      return cTDLbl;
    } 
  }
  
  public int sizeOfDLblArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(DLBL$0);
    } 
  }
  
  public void setDLblArray(CTDLbl[] paramArrayOfCTDLbl) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTDLbl, DLBL$0);
  }
  
  public void setDLblArray(int paramInt, CTDLbl paramCTDLbl) {
    generatedSetterHelperImpl((XmlObject)paramCTDLbl, DLBL$0, paramInt, (short)2);
  }
  
  public CTDLbl insertNewDLbl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbl cTDLbl = null;
      cTDLbl = (CTDLbl)get_store().insert_element_user(DLBL$0, paramInt);
      return cTDLbl;
    } 
  }
  
  public CTDLbl addNewDLbl() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbl cTDLbl = null;
      cTDLbl = (CTDLbl)get_store().add_element_user(DLBL$0);
      return cTDLbl;
    } 
  }
  
  public void removeDLbl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DLBL$0, paramInt);
    } 
  }
  
  public CTBoolean getDelete() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(DELETE$2, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetDelete() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DELETE$2) != 0);
    } 
  }
  
  public void setDelete(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, DELETE$2, 0, (short)1);
  }
  
  public CTBoolean addNewDelete() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(DELETE$2);
      return cTBoolean;
    } 
  }
  
  public void unsetDelete() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DELETE$2, 0);
    } 
  }
  
  public CTNumFmt getNumFmt() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumFmt cTNumFmt = null;
      cTNumFmt = (CTNumFmt)get_store().find_element_user(NUMFMT$4, 0);
      if (cTNumFmt == null)
        return null; 
      return cTNumFmt;
    } 
  }
  
  public boolean isSetNumFmt() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(NUMFMT$4) != 0);
    } 
  }
  
  public void setNumFmt(CTNumFmt paramCTNumFmt) {
    generatedSetterHelperImpl((XmlObject)paramCTNumFmt, NUMFMT$4, 0, (short)1);
  }
  
  public CTNumFmt addNewNumFmt() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumFmt cTNumFmt = null;
      cTNumFmt = (CTNumFmt)get_store().add_element_user(NUMFMT$4);
      return cTNumFmt;
    } 
  }
  
  public void unsetNumFmt() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(NUMFMT$4, 0);
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$6, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$6) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$6, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$6);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$6, 0);
    } 
  }
  
  public CTTextBody getTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextBody cTTextBody = null;
      cTTextBody = (CTTextBody)get_store().find_element_user(TXPR$8, 0);
      if (cTTextBody == null)
        return null; 
      return cTTextBody;
    } 
  }
  
  public boolean isSetTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(TXPR$8) != 0);
    } 
  }
  
  public void setTxPr(CTTextBody paramCTTextBody) {
    generatedSetterHelperImpl((XmlObject)paramCTTextBody, TXPR$8, 0, (short)1);
  }
  
  public CTTextBody addNewTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextBody cTTextBody = null;
      cTTextBody = (CTTextBody)get_store().add_element_user(TXPR$8);
      return cTTextBody;
    } 
  }
  
  public void unsetTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TXPR$8, 0);
    } 
  }
  
  public CTDLblPos getDLblPos() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLblPos cTDLblPos = null;
      cTDLblPos = (CTDLblPos)get_store().find_element_user(DLBLPOS$10, 0);
      if (cTDLblPos == null)
        return null; 
      return cTDLblPos;
    } 
  }
  
  public boolean isSetDLblPos() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DLBLPOS$10) != 0);
    } 
  }
  
  public void setDLblPos(CTDLblPos paramCTDLblPos) {
    generatedSetterHelperImpl((XmlObject)paramCTDLblPos, DLBLPOS$10, 0, (short)1);
  }
  
  public CTDLblPos addNewDLblPos() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLblPos cTDLblPos = null;
      cTDLblPos = (CTDLblPos)get_store().add_element_user(DLBLPOS$10);
      return cTDLblPos;
    } 
  }
  
  public void unsetDLblPos() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DLBLPOS$10, 0);
    } 
  }
  
  public CTBoolean getShowLegendKey() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(SHOWLEGENDKEY$12, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetShowLegendKey() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHOWLEGENDKEY$12) != 0);
    } 
  }
  
  public void setShowLegendKey(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, SHOWLEGENDKEY$12, 0, (short)1);
  }
  
  public CTBoolean addNewShowLegendKey() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(SHOWLEGENDKEY$12);
      return cTBoolean;
    } 
  }
  
  public void unsetShowLegendKey() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHOWLEGENDKEY$12, 0);
    } 
  }
  
  public CTBoolean getShowVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(SHOWVAL$14, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetShowVal() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHOWVAL$14) != 0);
    } 
  }
  
  public void setShowVal(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, SHOWVAL$14, 0, (short)1);
  }
  
  public CTBoolean addNewShowVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(SHOWVAL$14);
      return cTBoolean;
    } 
  }
  
  public void unsetShowVal() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHOWVAL$14, 0);
    } 
  }
  
  public CTBoolean getShowCatName() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(SHOWCATNAME$16, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetShowCatName() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHOWCATNAME$16) != 0);
    } 
  }
  
  public void setShowCatName(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, SHOWCATNAME$16, 0, (short)1);
  }
  
  public CTBoolean addNewShowCatName() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(SHOWCATNAME$16);
      return cTBoolean;
    } 
  }
  
  public void unsetShowCatName() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHOWCATNAME$16, 0);
    } 
  }
  
  public CTBoolean getShowSerName() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(SHOWSERNAME$18, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetShowSerName() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHOWSERNAME$18) != 0);
    } 
  }
  
  public void setShowSerName(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, SHOWSERNAME$18, 0, (short)1);
  }
  
  public CTBoolean addNewShowSerName() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(SHOWSERNAME$18);
      return cTBoolean;
    } 
  }
  
  public void unsetShowSerName() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHOWSERNAME$18, 0);
    } 
  }
  
  public CTBoolean getShowPercent() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(SHOWPERCENT$20, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetShowPercent() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHOWPERCENT$20) != 0);
    } 
  }
  
  public void setShowPercent(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, SHOWPERCENT$20, 0, (short)1);
  }
  
  public CTBoolean addNewShowPercent() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(SHOWPERCENT$20);
      return cTBoolean;
    } 
  }
  
  public void unsetShowPercent() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHOWPERCENT$20, 0);
    } 
  }
  
  public CTBoolean getShowBubbleSize() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(SHOWBUBBLESIZE$22, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetShowBubbleSize() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHOWBUBBLESIZE$22) != 0);
    } 
  }
  
  public void setShowBubbleSize(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, SHOWBUBBLESIZE$22, 0, (short)1);
  }
  
  public CTBoolean addNewShowBubbleSize() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(SHOWBUBBLESIZE$22);
      return cTBoolean;
    } 
  }
  
  public void unsetShowBubbleSize() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHOWBUBBLESIZE$22, 0);
    } 
  }
  
  public String getSeparator() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(SEPARATOR$24, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlString xgetSeparator() {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_element_user(SEPARATOR$24, 0);
      return xmlString;
    } 
  }
  
  public boolean isSetSeparator() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SEPARATOR$24) != 0);
    } 
  }
  
  public void setSeparator(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(SEPARATOR$24, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(SEPARATOR$24); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetSeparator(XmlString paramXmlString) {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_element_user(SEPARATOR$24, 0);
      if (xmlString == null)
        xmlString = (XmlString)get_store().add_element_user(SEPARATOR$24); 
      xmlString.set((XmlObject)paramXmlString);
    } 
  }
  
  public void unsetSeparator() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SEPARATOR$24, 0);
    } 
  }
  
  public CTBoolean getShowLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(SHOWLEADERLINES$26, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetShowLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHOWLEADERLINES$26) != 0);
    } 
  }
  
  public void setShowLeaderLines(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, SHOWLEADERLINES$26, 0, (short)1);
  }
  
  public CTBoolean addNewShowLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(SHOWLEADERLINES$26);
      return cTBoolean;
    } 
  }
  
  public void unsetShowLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHOWLEADERLINES$26, 0);
    } 
  }
  
  public CTChartLines getLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      CTChartLines cTChartLines = null;
      cTChartLines = (CTChartLines)get_store().find_element_user(LEADERLINES$28, 0);
      if (cTChartLines == null)
        return null; 
      return cTChartLines;
    } 
  }
  
  public boolean isSetLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(LEADERLINES$28) != 0);
    } 
  }
  
  public void setLeaderLines(CTChartLines paramCTChartLines) {
    generatedSetterHelperImpl((XmlObject)paramCTChartLines, LEADERLINES$28, 0, (short)1);
  }
  
  public CTChartLines addNewLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      CTChartLines cTChartLines = null;
      cTChartLines = (CTChartLines)get_store().add_element_user(LEADERLINES$28);
      return cTChartLines;
    } 
  }
  
  public void unsetLeaderLines() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LEADERLINES$28, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$30, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$30) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$30, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$30);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$30, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTDLblsImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */