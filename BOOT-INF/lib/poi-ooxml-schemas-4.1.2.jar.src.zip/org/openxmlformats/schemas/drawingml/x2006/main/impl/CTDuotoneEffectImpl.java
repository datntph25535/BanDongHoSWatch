package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTDuotoneEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTHslColor;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPresetColor;
import org.openxmlformats.schemas.drawingml.x2006.main.CTSRgbColor;
import org.openxmlformats.schemas.drawingml.x2006.main.CTScRgbColor;
import org.openxmlformats.schemas.drawingml.x2006.main.CTSchemeColor;
import org.openxmlformats.schemas.drawingml.x2006.main.CTSystemColor;

public class CTDuotoneEffectImpl extends XmlComplexContentImpl implements CTDuotoneEffect {
  private static final long serialVersionUID = 1L;
  
  private static final QName SCRGBCLR$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "scrgbClr");
  
  private static final QName SRGBCLR$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "srgbClr");
  
  private static final QName HSLCLR$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "hslClr");
  
  private static final QName SYSCLR$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "sysClr");
  
  private static final QName SCHEMECLR$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "schemeClr");
  
  private static final QName PRSTCLR$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "prstClr");
  
  public CTDuotoneEffectImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTScRgbColor> getScrgbClrList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ScrgbClrList extends AbstractList<CTScRgbColor> {
        public CTScRgbColor get(int param1Int) {
          return CTDuotoneEffectImpl.this.getScrgbClrArray(param1Int);
        }
        
        public CTScRgbColor set(int param1Int, CTScRgbColor param1CTScRgbColor) {
          CTScRgbColor cTScRgbColor = CTDuotoneEffectImpl.this.getScrgbClrArray(param1Int);
          CTDuotoneEffectImpl.this.setScrgbClrArray(param1Int, param1CTScRgbColor);
          return cTScRgbColor;
        }
        
        public void add(int param1Int, CTScRgbColor param1CTScRgbColor) {
          CTDuotoneEffectImpl.this.insertNewScrgbClr(param1Int).set((XmlObject)param1CTScRgbColor);
        }
        
        public CTScRgbColor remove(int param1Int) {
          CTScRgbColor cTScRgbColor = CTDuotoneEffectImpl.this.getScrgbClrArray(param1Int);
          CTDuotoneEffectImpl.this.removeScrgbClr(param1Int);
          return cTScRgbColor;
        }
        
        public int size() {
          return CTDuotoneEffectImpl.this.sizeOfScrgbClrArray();
        }
      };
      return new ScrgbClrList();
    } 
  }
  
  @Deprecated
  public CTScRgbColor[] getScrgbClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SCRGBCLR$0, arrayList);
      CTScRgbColor[] arrayOfCTScRgbColor = new CTScRgbColor[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTScRgbColor);
      return arrayOfCTScRgbColor;
    } 
  }
  
  public CTScRgbColor getScrgbClrArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTScRgbColor cTScRgbColor = null;
      cTScRgbColor = (CTScRgbColor)get_store().find_element_user(SCRGBCLR$0, paramInt);
      if (cTScRgbColor == null)
        throw new IndexOutOfBoundsException(); 
      return cTScRgbColor;
    } 
  }
  
  public int sizeOfScrgbClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SCRGBCLR$0);
    } 
  }
  
  public void setScrgbClrArray(CTScRgbColor[] paramArrayOfCTScRgbColor) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTScRgbColor, SCRGBCLR$0);
  }
  
  public void setScrgbClrArray(int paramInt, CTScRgbColor paramCTScRgbColor) {
    generatedSetterHelperImpl((XmlObject)paramCTScRgbColor, SCRGBCLR$0, paramInt, (short)2);
  }
  
  public CTScRgbColor insertNewScrgbClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTScRgbColor cTScRgbColor = null;
      cTScRgbColor = (CTScRgbColor)get_store().insert_element_user(SCRGBCLR$0, paramInt);
      return cTScRgbColor;
    } 
  }
  
  public CTScRgbColor addNewScrgbClr() {
    synchronized (monitor()) {
      check_orphaned();
      CTScRgbColor cTScRgbColor = null;
      cTScRgbColor = (CTScRgbColor)get_store().add_element_user(SCRGBCLR$0);
      return cTScRgbColor;
    } 
  }
  
  public void removeScrgbClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SCRGBCLR$0, paramInt);
    } 
  }
  
  public List<CTSRgbColor> getSrgbClrList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SrgbClrList extends AbstractList<CTSRgbColor> {
        public CTSRgbColor get(int param1Int) {
          return CTDuotoneEffectImpl.this.getSrgbClrArray(param1Int);
        }
        
        public CTSRgbColor set(int param1Int, CTSRgbColor param1CTSRgbColor) {
          CTSRgbColor cTSRgbColor = CTDuotoneEffectImpl.this.getSrgbClrArray(param1Int);
          CTDuotoneEffectImpl.this.setSrgbClrArray(param1Int, param1CTSRgbColor);
          return cTSRgbColor;
        }
        
        public void add(int param1Int, CTSRgbColor param1CTSRgbColor) {
          CTDuotoneEffectImpl.this.insertNewSrgbClr(param1Int).set((XmlObject)param1CTSRgbColor);
        }
        
        public CTSRgbColor remove(int param1Int) {
          CTSRgbColor cTSRgbColor = CTDuotoneEffectImpl.this.getSrgbClrArray(param1Int);
          CTDuotoneEffectImpl.this.removeSrgbClr(param1Int);
          return cTSRgbColor;
        }
        
        public int size() {
          return CTDuotoneEffectImpl.this.sizeOfSrgbClrArray();
        }
      };
      return new SrgbClrList();
    } 
  }
  
  @Deprecated
  public CTSRgbColor[] getSrgbClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SRGBCLR$2, arrayList);
      CTSRgbColor[] arrayOfCTSRgbColor = new CTSRgbColor[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSRgbColor);
      return arrayOfCTSRgbColor;
    } 
  }
  
  public CTSRgbColor getSrgbClrArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSRgbColor cTSRgbColor = null;
      cTSRgbColor = (CTSRgbColor)get_store().find_element_user(SRGBCLR$2, paramInt);
      if (cTSRgbColor == null)
        throw new IndexOutOfBoundsException(); 
      return cTSRgbColor;
    } 
  }
  
  public int sizeOfSrgbClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SRGBCLR$2);
    } 
  }
  
  public void setSrgbClrArray(CTSRgbColor[] paramArrayOfCTSRgbColor) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSRgbColor, SRGBCLR$2);
  }
  
  public void setSrgbClrArray(int paramInt, CTSRgbColor paramCTSRgbColor) {
    generatedSetterHelperImpl((XmlObject)paramCTSRgbColor, SRGBCLR$2, paramInt, (short)2);
  }
  
  public CTSRgbColor insertNewSrgbClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSRgbColor cTSRgbColor = null;
      cTSRgbColor = (CTSRgbColor)get_store().insert_element_user(SRGBCLR$2, paramInt);
      return cTSRgbColor;
    } 
  }
  
  public CTSRgbColor addNewSrgbClr() {
    synchronized (monitor()) {
      check_orphaned();
      CTSRgbColor cTSRgbColor = null;
      cTSRgbColor = (CTSRgbColor)get_store().add_element_user(SRGBCLR$2);
      return cTSRgbColor;
    } 
  }
  
  public void removeSrgbClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SRGBCLR$2, paramInt);
    } 
  }
  
  public List<CTHslColor> getHslClrList() {
    synchronized (monitor()) {
      check_orphaned();
      final class HslClrList extends AbstractList<CTHslColor> {
        public CTHslColor get(int param1Int) {
          return CTDuotoneEffectImpl.this.getHslClrArray(param1Int);
        }
        
        public CTHslColor set(int param1Int, CTHslColor param1CTHslColor) {
          CTHslColor cTHslColor = CTDuotoneEffectImpl.this.getHslClrArray(param1Int);
          CTDuotoneEffectImpl.this.setHslClrArray(param1Int, param1CTHslColor);
          return cTHslColor;
        }
        
        public void add(int param1Int, CTHslColor param1CTHslColor) {
          CTDuotoneEffectImpl.this.insertNewHslClr(param1Int).set((XmlObject)param1CTHslColor);
        }
        
        public CTHslColor remove(int param1Int) {
          CTHslColor cTHslColor = CTDuotoneEffectImpl.this.getHslClrArray(param1Int);
          CTDuotoneEffectImpl.this.removeHslClr(param1Int);
          return cTHslColor;
        }
        
        public int size() {
          return CTDuotoneEffectImpl.this.sizeOfHslClrArray();
        }
      };
      return new HslClrList();
    } 
  }
  
  @Deprecated
  public CTHslColor[] getHslClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(HSLCLR$4, arrayList);
      CTHslColor[] arrayOfCTHslColor = new CTHslColor[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTHslColor);
      return arrayOfCTHslColor;
    } 
  }
  
  public CTHslColor getHslClrArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTHslColor cTHslColor = null;
      cTHslColor = (CTHslColor)get_store().find_element_user(HSLCLR$4, paramInt);
      if (cTHslColor == null)
        throw new IndexOutOfBoundsException(); 
      return cTHslColor;
    } 
  }
  
  public int sizeOfHslClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(HSLCLR$4);
    } 
  }
  
  public void setHslClrArray(CTHslColor[] paramArrayOfCTHslColor) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTHslColor, HSLCLR$4);
  }
  
  public void setHslClrArray(int paramInt, CTHslColor paramCTHslColor) {
    generatedSetterHelperImpl((XmlObject)paramCTHslColor, HSLCLR$4, paramInt, (short)2);
  }
  
  public CTHslColor insertNewHslClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTHslColor cTHslColor = null;
      cTHslColor = (CTHslColor)get_store().insert_element_user(HSLCLR$4, paramInt);
      return cTHslColor;
    } 
  }
  
  public CTHslColor addNewHslClr() {
    synchronized (monitor()) {
      check_orphaned();
      CTHslColor cTHslColor = null;
      cTHslColor = (CTHslColor)get_store().add_element_user(HSLCLR$4);
      return cTHslColor;
    } 
  }
  
  public void removeHslClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(HSLCLR$4, paramInt);
    } 
  }
  
  public List<CTSystemColor> getSysClrList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SysClrList extends AbstractList<CTSystemColor> {
        public CTSystemColor get(int param1Int) {
          return CTDuotoneEffectImpl.this.getSysClrArray(param1Int);
        }
        
        public CTSystemColor set(int param1Int, CTSystemColor param1CTSystemColor) {
          CTSystemColor cTSystemColor = CTDuotoneEffectImpl.this.getSysClrArray(param1Int);
          CTDuotoneEffectImpl.this.setSysClrArray(param1Int, param1CTSystemColor);
          return cTSystemColor;
        }
        
        public void add(int param1Int, CTSystemColor param1CTSystemColor) {
          CTDuotoneEffectImpl.this.insertNewSysClr(param1Int).set((XmlObject)param1CTSystemColor);
        }
        
        public CTSystemColor remove(int param1Int) {
          CTSystemColor cTSystemColor = CTDuotoneEffectImpl.this.getSysClrArray(param1Int);
          CTDuotoneEffectImpl.this.removeSysClr(param1Int);
          return cTSystemColor;
        }
        
        public int size() {
          return CTDuotoneEffectImpl.this.sizeOfSysClrArray();
        }
      };
      return new SysClrList();
    } 
  }
  
  @Deprecated
  public CTSystemColor[] getSysClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SYSCLR$6, arrayList);
      CTSystemColor[] arrayOfCTSystemColor = new CTSystemColor[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSystemColor);
      return arrayOfCTSystemColor;
    } 
  }
  
  public CTSystemColor getSysClrArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSystemColor cTSystemColor = null;
      cTSystemColor = (CTSystemColor)get_store().find_element_user(SYSCLR$6, paramInt);
      if (cTSystemColor == null)
        throw new IndexOutOfBoundsException(); 
      return cTSystemColor;
    } 
  }
  
  public int sizeOfSysClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SYSCLR$6);
    } 
  }
  
  public void setSysClrArray(CTSystemColor[] paramArrayOfCTSystemColor) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSystemColor, SYSCLR$6);
  }
  
  public void setSysClrArray(int paramInt, CTSystemColor paramCTSystemColor) {
    generatedSetterHelperImpl((XmlObject)paramCTSystemColor, SYSCLR$6, paramInt, (short)2);
  }
  
  public CTSystemColor insertNewSysClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSystemColor cTSystemColor = null;
      cTSystemColor = (CTSystemColor)get_store().insert_element_user(SYSCLR$6, paramInt);
      return cTSystemColor;
    } 
  }
  
  public CTSystemColor addNewSysClr() {
    synchronized (monitor()) {
      check_orphaned();
      CTSystemColor cTSystemColor = null;
      cTSystemColor = (CTSystemColor)get_store().add_element_user(SYSCLR$6);
      return cTSystemColor;
    } 
  }
  
  public void removeSysClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SYSCLR$6, paramInt);
    } 
  }
  
  public List<CTSchemeColor> getSchemeClrList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SchemeClrList extends AbstractList<CTSchemeColor> {
        public CTSchemeColor get(int param1Int) {
          return CTDuotoneEffectImpl.this.getSchemeClrArray(param1Int);
        }
        
        public CTSchemeColor set(int param1Int, CTSchemeColor param1CTSchemeColor) {
          CTSchemeColor cTSchemeColor = CTDuotoneEffectImpl.this.getSchemeClrArray(param1Int);
          CTDuotoneEffectImpl.this.setSchemeClrArray(param1Int, param1CTSchemeColor);
          return cTSchemeColor;
        }
        
        public void add(int param1Int, CTSchemeColor param1CTSchemeColor) {
          CTDuotoneEffectImpl.this.insertNewSchemeClr(param1Int).set((XmlObject)param1CTSchemeColor);
        }
        
        public CTSchemeColor remove(int param1Int) {
          CTSchemeColor cTSchemeColor = CTDuotoneEffectImpl.this.getSchemeClrArray(param1Int);
          CTDuotoneEffectImpl.this.removeSchemeClr(param1Int);
          return cTSchemeColor;
        }
        
        public int size() {
          return CTDuotoneEffectImpl.this.sizeOfSchemeClrArray();
        }
      };
      return new SchemeClrList();
    } 
  }
  
  @Deprecated
  public CTSchemeColor[] getSchemeClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SCHEMECLR$8, arrayList);
      CTSchemeColor[] arrayOfCTSchemeColor = new CTSchemeColor[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSchemeColor);
      return arrayOfCTSchemeColor;
    } 
  }
  
  public CTSchemeColor getSchemeClrArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSchemeColor cTSchemeColor = null;
      cTSchemeColor = (CTSchemeColor)get_store().find_element_user(SCHEMECLR$8, paramInt);
      if (cTSchemeColor == null)
        throw new IndexOutOfBoundsException(); 
      return cTSchemeColor;
    } 
  }
  
  public int sizeOfSchemeClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SCHEMECLR$8);
    } 
  }
  
  public void setSchemeClrArray(CTSchemeColor[] paramArrayOfCTSchemeColor) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSchemeColor, SCHEMECLR$8);
  }
  
  public void setSchemeClrArray(int paramInt, CTSchemeColor paramCTSchemeColor) {
    generatedSetterHelperImpl((XmlObject)paramCTSchemeColor, SCHEMECLR$8, paramInt, (short)2);
  }
  
  public CTSchemeColor insertNewSchemeClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSchemeColor cTSchemeColor = null;
      cTSchemeColor = (CTSchemeColor)get_store().insert_element_user(SCHEMECLR$8, paramInt);
      return cTSchemeColor;
    } 
  }
  
  public CTSchemeColor addNewSchemeClr() {
    synchronized (monitor()) {
      check_orphaned();
      CTSchemeColor cTSchemeColor = null;
      cTSchemeColor = (CTSchemeColor)get_store().add_element_user(SCHEMECLR$8);
      return cTSchemeColor;
    } 
  }
  
  public void removeSchemeClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SCHEMECLR$8, paramInt);
    } 
  }
  
  public List<CTPresetColor> getPrstClrList() {
    synchronized (monitor()) {
      check_orphaned();
      final class PrstClrList extends AbstractList<CTPresetColor> {
        public CTPresetColor get(int param1Int) {
          return CTDuotoneEffectImpl.this.getPrstClrArray(param1Int);
        }
        
        public CTPresetColor set(int param1Int, CTPresetColor param1CTPresetColor) {
          CTPresetColor cTPresetColor = CTDuotoneEffectImpl.this.getPrstClrArray(param1Int);
          CTDuotoneEffectImpl.this.setPrstClrArray(param1Int, param1CTPresetColor);
          return cTPresetColor;
        }
        
        public void add(int param1Int, CTPresetColor param1CTPresetColor) {
          CTDuotoneEffectImpl.this.insertNewPrstClr(param1Int).set((XmlObject)param1CTPresetColor);
        }
        
        public CTPresetColor remove(int param1Int) {
          CTPresetColor cTPresetColor = CTDuotoneEffectImpl.this.getPrstClrArray(param1Int);
          CTDuotoneEffectImpl.this.removePrstClr(param1Int);
          return cTPresetColor;
        }
        
        public int size() {
          return CTDuotoneEffectImpl.this.sizeOfPrstClrArray();
        }
      };
      return new PrstClrList();
    } 
  }
  
  @Deprecated
  public CTPresetColor[] getPrstClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(PRSTCLR$10, arrayList);
      CTPresetColor[] arrayOfCTPresetColor = new CTPresetColor[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTPresetColor);
      return arrayOfCTPresetColor;
    } 
  }
  
  public CTPresetColor getPrstClrArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetColor cTPresetColor = null;
      cTPresetColor = (CTPresetColor)get_store().find_element_user(PRSTCLR$10, paramInt);
      if (cTPresetColor == null)
        throw new IndexOutOfBoundsException(); 
      return cTPresetColor;
    } 
  }
  
  public int sizeOfPrstClrArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(PRSTCLR$10);
    } 
  }
  
  public void setPrstClrArray(CTPresetColor[] paramArrayOfCTPresetColor) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTPresetColor, PRSTCLR$10);
  }
  
  public void setPrstClrArray(int paramInt, CTPresetColor paramCTPresetColor) {
    generatedSetterHelperImpl((XmlObject)paramCTPresetColor, PRSTCLR$10, paramInt, (short)2);
  }
  
  public CTPresetColor insertNewPrstClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetColor cTPresetColor = null;
      cTPresetColor = (CTPresetColor)get_store().insert_element_user(PRSTCLR$10, paramInt);
      return cTPresetColor;
    } 
  }
  
  public CTPresetColor addNewPrstClr() {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetColor cTPresetColor = null;
      cTPresetColor = (CTPresetColor)get_store().add_element_user(PRSTCLR$10);
      return cTPresetColor;
    } 
  }
  
  public void removePrstClr(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PRSTCLR$10, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTDuotoneEffectImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */