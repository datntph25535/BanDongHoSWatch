package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTRotY extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTRotY.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctroty8f1atype");
  
  int getVal();
  
  STRotY xgetVal();
  
  boolean isSetVal();
  
  void setVal(int paramInt);
  
  void xsetVal(STRotY paramSTRotY);
  
  void unsetVal();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTRotY.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTRotY newInstance() {
      return (CTRotY)getTypeLoader().newInstance(CTRotY.type, null);
    }
    
    public static CTRotY newInstance(XmlOptions param1XmlOptions) {
      return (CTRotY)getTypeLoader().newInstance(CTRotY.type, param1XmlOptions);
    }
    
    public static CTRotY parse(String param1String) throws XmlException {
      return (CTRotY)getTypeLoader().parse(param1String, CTRotY.type, null);
    }
    
    public static CTRotY parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRotY)getTypeLoader().parse(param1String, CTRotY.type, param1XmlOptions);
    }
    
    public static CTRotY parse(File param1File) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1File, CTRotY.type, null);
    }
    
    public static CTRotY parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1File, CTRotY.type, param1XmlOptions);
    }
    
    public static CTRotY parse(URL param1URL) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1URL, CTRotY.type, null);
    }
    
    public static CTRotY parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1URL, CTRotY.type, param1XmlOptions);
    }
    
    public static CTRotY parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1InputStream, CTRotY.type, null);
    }
    
    public static CTRotY parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1InputStream, CTRotY.type, param1XmlOptions);
    }
    
    public static CTRotY parse(Reader param1Reader) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1Reader, CTRotY.type, null);
    }
    
    public static CTRotY parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRotY)getTypeLoader().parse(param1Reader, CTRotY.type, param1XmlOptions);
    }
    
    public static CTRotY parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTRotY)getTypeLoader().parse(param1XMLStreamReader, CTRotY.type, null);
    }
    
    public static CTRotY parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRotY)getTypeLoader().parse(param1XMLStreamReader, CTRotY.type, param1XmlOptions);
    }
    
    public static CTRotY parse(Node param1Node) throws XmlException {
      return (CTRotY)getTypeLoader().parse(param1Node, CTRotY.type, null);
    }
    
    public static CTRotY parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRotY)getTypeLoader().parse(param1Node, CTRotY.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTRotY parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTRotY)getTypeLoader().parse(param1XMLInputStream, CTRotY.type, null);
    }
    
    @Deprecated
    public static CTRotY parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTRotY)getTypeLoader().parse(param1XMLInputStream, CTRotY.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTRotY.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTRotY.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTRotY.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */