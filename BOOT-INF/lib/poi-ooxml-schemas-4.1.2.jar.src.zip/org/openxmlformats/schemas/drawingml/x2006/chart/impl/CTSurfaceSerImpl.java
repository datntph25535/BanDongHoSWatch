package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTAxDataSource;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTNumDataSource;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSerTx;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSurfaceSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;

public class CTSurfaceSerImpl extends XmlComplexContentImpl implements CTSurfaceSer {
  private static final long serialVersionUID = 1L;
  
  private static final QName IDX$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "idx");
  
  private static final QName ORDER$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "order");
  
  private static final QName TX$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "tx");
  
  private static final QName SPPR$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName CAT$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "cat");
  
  private static final QName VAL$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "val");
  
  private static final QName EXTLST$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTSurfaceSerImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTUnsignedInt getIdx() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(IDX$0, 0);
      if (cTUnsignedInt == null)
        return null; 
      return cTUnsignedInt;
    } 
  }
  
  public void setIdx(CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, IDX$0, 0, (short)1);
  }
  
  public CTUnsignedInt addNewIdx() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(IDX$0);
      return cTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt getOrder() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(ORDER$2, 0);
      if (cTUnsignedInt == null)
        return null; 
      return cTUnsignedInt;
    } 
  }
  
  public void setOrder(CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, ORDER$2, 0, (short)1);
  }
  
  public CTUnsignedInt addNewOrder() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(ORDER$2);
      return cTUnsignedInt;
    } 
  }
  
  public CTSerTx getTx() {
    synchronized (monitor()) {
      check_orphaned();
      CTSerTx cTSerTx = null;
      cTSerTx = (CTSerTx)get_store().find_element_user(TX$4, 0);
      if (cTSerTx == null)
        return null; 
      return cTSerTx;
    } 
  }
  
  public boolean isSetTx() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(TX$4) != 0);
    } 
  }
  
  public void setTx(CTSerTx paramCTSerTx) {
    generatedSetterHelperImpl((XmlObject)paramCTSerTx, TX$4, 0, (short)1);
  }
  
  public CTSerTx addNewTx() {
    synchronized (monitor()) {
      check_orphaned();
      CTSerTx cTSerTx = null;
      cTSerTx = (CTSerTx)get_store().add_element_user(TX$4);
      return cTSerTx;
    } 
  }
  
  public void unsetTx() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TX$4, 0);
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$6, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$6) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$6, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$6);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$6, 0);
    } 
  }
  
  public CTAxDataSource getCat() {
    synchronized (monitor()) {
      check_orphaned();
      CTAxDataSource cTAxDataSource = null;
      cTAxDataSource = (CTAxDataSource)get_store().find_element_user(CAT$8, 0);
      if (cTAxDataSource == null)
        return null; 
      return cTAxDataSource;
    } 
  }
  
  public boolean isSetCat() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CAT$8) != 0);
    } 
  }
  
  public void setCat(CTAxDataSource paramCTAxDataSource) {
    generatedSetterHelperImpl((XmlObject)paramCTAxDataSource, CAT$8, 0, (short)1);
  }
  
  public CTAxDataSource addNewCat() {
    synchronized (monitor()) {
      check_orphaned();
      CTAxDataSource cTAxDataSource = null;
      cTAxDataSource = (CTAxDataSource)get_store().add_element_user(CAT$8);
      return cTAxDataSource;
    } 
  }
  
  public void unsetCat() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CAT$8, 0);
    } 
  }
  
  public CTNumDataSource getVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().find_element_user(VAL$10, 0);
      if (cTNumDataSource == null)
        return null; 
      return cTNumDataSource;
    } 
  }
  
  public boolean isSetVal() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(VAL$10) != 0);
    } 
  }
  
  public void setVal(CTNumDataSource paramCTNumDataSource) {
    generatedSetterHelperImpl((XmlObject)paramCTNumDataSource, VAL$10, 0, (short)1);
  }
  
  public CTNumDataSource addNewVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().add_element_user(VAL$10);
      return cTNumDataSource;
    } 
  }
  
  public void unsetVal() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(VAL$10, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$12, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$12) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$12, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$12);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$12, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTSurfaceSerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */