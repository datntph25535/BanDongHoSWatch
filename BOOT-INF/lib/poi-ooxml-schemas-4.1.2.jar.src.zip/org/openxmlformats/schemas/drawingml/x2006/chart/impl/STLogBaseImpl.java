package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaDoubleHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.chart.STLogBase;

public class STLogBaseImpl extends JavaDoubleHolderEx implements STLogBase {
  private static final long serialVersionUID = 1L;
  
  public STLogBaseImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STLogBaseImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\STLogBaseImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */