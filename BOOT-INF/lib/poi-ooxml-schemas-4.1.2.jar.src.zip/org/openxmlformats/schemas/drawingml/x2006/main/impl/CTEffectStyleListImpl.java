package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTEffectStyleItem;
import org.openxmlformats.schemas.drawingml.x2006.main.CTEffectStyleList;

public class CTEffectStyleListImpl extends XmlComplexContentImpl implements CTEffectStyleList {
  private static final long serialVersionUID = 1L;
  
  private static final QName EFFECTSTYLE$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "effectStyle");
  
  public CTEffectStyleListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTEffectStyleItem> getEffectStyleList() {
    synchronized (monitor()) {
      check_orphaned();
      final class EffectStyleList extends AbstractList<CTEffectStyleItem> {
        public CTEffectStyleItem get(int param1Int) {
          return CTEffectStyleListImpl.this.getEffectStyleArray(param1Int);
        }
        
        public CTEffectStyleItem set(int param1Int, CTEffectStyleItem param1CTEffectStyleItem) {
          CTEffectStyleItem cTEffectStyleItem = CTEffectStyleListImpl.this.getEffectStyleArray(param1Int);
          CTEffectStyleListImpl.this.setEffectStyleArray(param1Int, param1CTEffectStyleItem);
          return cTEffectStyleItem;
        }
        
        public void add(int param1Int, CTEffectStyleItem param1CTEffectStyleItem) {
          CTEffectStyleListImpl.this.insertNewEffectStyle(param1Int).set((XmlObject)param1CTEffectStyleItem);
        }
        
        public CTEffectStyleItem remove(int param1Int) {
          CTEffectStyleItem cTEffectStyleItem = CTEffectStyleListImpl.this.getEffectStyleArray(param1Int);
          CTEffectStyleListImpl.this.removeEffectStyle(param1Int);
          return cTEffectStyleItem;
        }
        
        public int size() {
          return CTEffectStyleListImpl.this.sizeOfEffectStyleArray();
        }
      };
      return new EffectStyleList();
    } 
  }
  
  @Deprecated
  public CTEffectStyleItem[] getEffectStyleArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(EFFECTSTYLE$0, arrayList);
      CTEffectStyleItem[] arrayOfCTEffectStyleItem = new CTEffectStyleItem[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTEffectStyleItem);
      return arrayOfCTEffectStyleItem;
    } 
  }
  
  public CTEffectStyleItem getEffectStyleArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectStyleItem cTEffectStyleItem = null;
      cTEffectStyleItem = (CTEffectStyleItem)get_store().find_element_user(EFFECTSTYLE$0, paramInt);
      if (cTEffectStyleItem == null)
        throw new IndexOutOfBoundsException(); 
      return cTEffectStyleItem;
    } 
  }
  
  public int sizeOfEffectStyleArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(EFFECTSTYLE$0);
    } 
  }
  
  public void setEffectStyleArray(CTEffectStyleItem[] paramArrayOfCTEffectStyleItem) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTEffectStyleItem, EFFECTSTYLE$0);
  }
  
  public void setEffectStyleArray(int paramInt, CTEffectStyleItem paramCTEffectStyleItem) {
    generatedSetterHelperImpl((XmlObject)paramCTEffectStyleItem, EFFECTSTYLE$0, paramInt, (short)2);
  }
  
  public CTEffectStyleItem insertNewEffectStyle(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectStyleItem cTEffectStyleItem = null;
      cTEffectStyleItem = (CTEffectStyleItem)get_store().insert_element_user(EFFECTSTYLE$0, paramInt);
      return cTEffectStyleItem;
    } 
  }
  
  public CTEffectStyleItem addNewEffectStyle() {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectStyleItem cTEffectStyleItem = null;
      cTEffectStyleItem = (CTEffectStyleItem)get_store().add_element_user(EFFECTSTYLE$0);
      return cTEffectStyleItem;
    } 
  }
  
  public void removeEffectStyle(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EFFECTSTYLE$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTEffectStyleListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */