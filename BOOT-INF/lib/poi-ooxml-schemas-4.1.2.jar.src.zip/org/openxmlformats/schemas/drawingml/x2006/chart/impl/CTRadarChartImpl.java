package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbls;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTRadarChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTRadarSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTRadarStyle;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;

public class CTRadarChartImpl extends XmlComplexContentImpl implements CTRadarChart {
  private static final long serialVersionUID = 1L;
  
  private static final QName RADARSTYLE$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "radarStyle");
  
  private static final QName VARYCOLORS$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "varyColors");
  
  private static final QName SER$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "ser");
  
  private static final QName DLBLS$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dLbls");
  
  private static final QName AXID$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "axId");
  
  private static final QName EXTLST$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTRadarChartImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTRadarStyle getRadarStyle() {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarStyle cTRadarStyle = null;
      cTRadarStyle = (CTRadarStyle)get_store().find_element_user(RADARSTYLE$0, 0);
      if (cTRadarStyle == null)
        return null; 
      return cTRadarStyle;
    } 
  }
  
  public void setRadarStyle(CTRadarStyle paramCTRadarStyle) {
    generatedSetterHelperImpl((XmlObject)paramCTRadarStyle, RADARSTYLE$0, 0, (short)1);
  }
  
  public CTRadarStyle addNewRadarStyle() {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarStyle cTRadarStyle = null;
      cTRadarStyle = (CTRadarStyle)get_store().add_element_user(RADARSTYLE$0);
      return cTRadarStyle;
    } 
  }
  
  public CTBoolean getVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(VARYCOLORS$2, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(VARYCOLORS$2) != 0);
    } 
  }
  
  public void setVaryColors(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, VARYCOLORS$2, 0, (short)1);
  }
  
  public CTBoolean addNewVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(VARYCOLORS$2);
      return cTBoolean;
    } 
  }
  
  public void unsetVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(VARYCOLORS$2, 0);
    } 
  }
  
  public List<CTRadarSer> getSerList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SerList extends AbstractList<CTRadarSer> {
        public CTRadarSer get(int param1Int) {
          return CTRadarChartImpl.this.getSerArray(param1Int);
        }
        
        public CTRadarSer set(int param1Int, CTRadarSer param1CTRadarSer) {
          CTRadarSer cTRadarSer = CTRadarChartImpl.this.getSerArray(param1Int);
          CTRadarChartImpl.this.setSerArray(param1Int, param1CTRadarSer);
          return cTRadarSer;
        }
        
        public void add(int param1Int, CTRadarSer param1CTRadarSer) {
          CTRadarChartImpl.this.insertNewSer(param1Int).set((XmlObject)param1CTRadarSer);
        }
        
        public CTRadarSer remove(int param1Int) {
          CTRadarSer cTRadarSer = CTRadarChartImpl.this.getSerArray(param1Int);
          CTRadarChartImpl.this.removeSer(param1Int);
          return cTRadarSer;
        }
        
        public int size() {
          return CTRadarChartImpl.this.sizeOfSerArray();
        }
      };
      return new SerList();
    } 
  }
  
  @Deprecated
  public CTRadarSer[] getSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SER$4, arrayList);
      CTRadarSer[] arrayOfCTRadarSer = new CTRadarSer[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTRadarSer);
      return arrayOfCTRadarSer;
    } 
  }
  
  public CTRadarSer getSerArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarSer cTRadarSer = null;
      cTRadarSer = (CTRadarSer)get_store().find_element_user(SER$4, paramInt);
      if (cTRadarSer == null)
        throw new IndexOutOfBoundsException(); 
      return cTRadarSer;
    } 
  }
  
  public int sizeOfSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SER$4);
    } 
  }
  
  public void setSerArray(CTRadarSer[] paramArrayOfCTRadarSer) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTRadarSer, SER$4);
  }
  
  public void setSerArray(int paramInt, CTRadarSer paramCTRadarSer) {
    generatedSetterHelperImpl((XmlObject)paramCTRadarSer, SER$4, paramInt, (short)2);
  }
  
  public CTRadarSer insertNewSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarSer cTRadarSer = null;
      cTRadarSer = (CTRadarSer)get_store().insert_element_user(SER$4, paramInt);
      return cTRadarSer;
    } 
  }
  
  public CTRadarSer addNewSer() {
    synchronized (monitor()) {
      check_orphaned();
      CTRadarSer cTRadarSer = null;
      cTRadarSer = (CTRadarSer)get_store().add_element_user(SER$4);
      return cTRadarSer;
    } 
  }
  
  public void removeSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SER$4, paramInt);
    } 
  }
  
  public CTDLbls getDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().find_element_user(DLBLS$6, 0);
      if (cTDLbls == null)
        return null; 
      return cTDLbls;
    } 
  }
  
  public boolean isSetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DLBLS$6) != 0);
    } 
  }
  
  public void setDLbls(CTDLbls paramCTDLbls) {
    generatedSetterHelperImpl((XmlObject)paramCTDLbls, DLBLS$6, 0, (short)1);
  }
  
  public CTDLbls addNewDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().add_element_user(DLBLS$6);
      return cTDLbls;
    } 
  }
  
  public void unsetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DLBLS$6, 0);
    } 
  }
  
  public List<CTUnsignedInt> getAxIdList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AxIdList extends AbstractList<CTUnsignedInt> {
        public CTUnsignedInt get(int param1Int) {
          return CTRadarChartImpl.this.getAxIdArray(param1Int);
        }
        
        public CTUnsignedInt set(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTUnsignedInt cTUnsignedInt = CTRadarChartImpl.this.getAxIdArray(param1Int);
          CTRadarChartImpl.this.setAxIdArray(param1Int, param1CTUnsignedInt);
          return cTUnsignedInt;
        }
        
        public void add(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTRadarChartImpl.this.insertNewAxId(param1Int).set((XmlObject)param1CTUnsignedInt);
        }
        
        public CTUnsignedInt remove(int param1Int) {
          CTUnsignedInt cTUnsignedInt = CTRadarChartImpl.this.getAxIdArray(param1Int);
          CTRadarChartImpl.this.removeAxId(param1Int);
          return cTUnsignedInt;
        }
        
        public int size() {
          return CTRadarChartImpl.this.sizeOfAxIdArray();
        }
      };
      return new AxIdList();
    } 
  }
  
  @Deprecated
  public CTUnsignedInt[] getAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(AXID$8, arrayList);
      CTUnsignedInt[] arrayOfCTUnsignedInt = new CTUnsignedInt[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTUnsignedInt);
      return arrayOfCTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt getAxIdArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(AXID$8, paramInt);
      if (cTUnsignedInt == null)
        throw new IndexOutOfBoundsException(); 
      return cTUnsignedInt;
    } 
  }
  
  public int sizeOfAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(AXID$8);
    } 
  }
  
  public void setAxIdArray(CTUnsignedInt[] paramArrayOfCTUnsignedInt) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTUnsignedInt, AXID$8);
  }
  
  public void setAxIdArray(int paramInt, CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, AXID$8, paramInt, (short)2);
  }
  
  public CTUnsignedInt insertNewAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().insert_element_user(AXID$8, paramInt);
      return cTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt addNewAxId() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(AXID$8);
      return cTUnsignedInt;
    } 
  }
  
  public void removeAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(AXID$8, paramInt);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$10, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$10) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$10, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$10);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$10, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTRadarChartImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */