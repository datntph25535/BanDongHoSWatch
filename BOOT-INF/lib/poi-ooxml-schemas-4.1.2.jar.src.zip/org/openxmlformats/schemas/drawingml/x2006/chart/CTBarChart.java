package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTBarChart extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTBarChart.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctbarchart4151type");
  
  CTBarDir getBarDir();
  
  void setBarDir(CTBarDir paramCTBarDir);
  
  CTBarDir addNewBarDir();
  
  CTBarGrouping getGrouping();
  
  boolean isSetGrouping();
  
  void setGrouping(CTBarGrouping paramCTBarGrouping);
  
  CTBarGrouping addNewGrouping();
  
  void unsetGrouping();
  
  CTBoolean getVaryColors();
  
  boolean isSetVaryColors();
  
  void setVaryColors(CTBoolean paramCTBoolean);
  
  CTBoolean addNewVaryColors();
  
  void unsetVaryColors();
  
  List<CTBarSer> getSerList();
  
  @Deprecated
  CTBarSer[] getSerArray();
  
  CTBarSer getSerArray(int paramInt);
  
  int sizeOfSerArray();
  
  void setSerArray(CTBarSer[] paramArrayOfCTBarSer);
  
  void setSerArray(int paramInt, CTBarSer paramCTBarSer);
  
  CTBarSer insertNewSer(int paramInt);
  
  CTBarSer addNewSer();
  
  void removeSer(int paramInt);
  
  CTDLbls getDLbls();
  
  boolean isSetDLbls();
  
  void setDLbls(CTDLbls paramCTDLbls);
  
  CTDLbls addNewDLbls();
  
  void unsetDLbls();
  
  CTGapAmount getGapWidth();
  
  boolean isSetGapWidth();
  
  void setGapWidth(CTGapAmount paramCTGapAmount);
  
  CTGapAmount addNewGapWidth();
  
  void unsetGapWidth();
  
  CTOverlap getOverlap();
  
  boolean isSetOverlap();
  
  void setOverlap(CTOverlap paramCTOverlap);
  
  CTOverlap addNewOverlap();
  
  void unsetOverlap();
  
  List<CTChartLines> getSerLinesList();
  
  @Deprecated
  CTChartLines[] getSerLinesArray();
  
  CTChartLines getSerLinesArray(int paramInt);
  
  int sizeOfSerLinesArray();
  
  void setSerLinesArray(CTChartLines[] paramArrayOfCTChartLines);
  
  void setSerLinesArray(int paramInt, CTChartLines paramCTChartLines);
  
  CTChartLines insertNewSerLines(int paramInt);
  
  CTChartLines addNewSerLines();
  
  void removeSerLines(int paramInt);
  
  List<CTUnsignedInt> getAxIdList();
  
  @Deprecated
  CTUnsignedInt[] getAxIdArray();
  
  CTUnsignedInt getAxIdArray(int paramInt);
  
  int sizeOfAxIdArray();
  
  void setAxIdArray(CTUnsignedInt[] paramArrayOfCTUnsignedInt);
  
  void setAxIdArray(int paramInt, CTUnsignedInt paramCTUnsignedInt);
  
  CTUnsignedInt insertNewAxId(int paramInt);
  
  CTUnsignedInt addNewAxId();
  
  void removeAxId(int paramInt);
  
  CTExtensionList getExtLst();
  
  boolean isSetExtLst();
  
  void setExtLst(CTExtensionList paramCTExtensionList);
  
  CTExtensionList addNewExtLst();
  
  void unsetExtLst();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTBarChart.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTBarChart newInstance() {
      return (CTBarChart)getTypeLoader().newInstance(CTBarChart.type, null);
    }
    
    public static CTBarChart newInstance(XmlOptions param1XmlOptions) {
      return (CTBarChart)getTypeLoader().newInstance(CTBarChart.type, param1XmlOptions);
    }
    
    public static CTBarChart parse(String param1String) throws XmlException {
      return (CTBarChart)getTypeLoader().parse(param1String, CTBarChart.type, null);
    }
    
    public static CTBarChart parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTBarChart)getTypeLoader().parse(param1String, CTBarChart.type, param1XmlOptions);
    }
    
    public static CTBarChart parse(File param1File) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1File, CTBarChart.type, null);
    }
    
    public static CTBarChart parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1File, CTBarChart.type, param1XmlOptions);
    }
    
    public static CTBarChart parse(URL param1URL) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1URL, CTBarChart.type, null);
    }
    
    public static CTBarChart parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1URL, CTBarChart.type, param1XmlOptions);
    }
    
    public static CTBarChart parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1InputStream, CTBarChart.type, null);
    }
    
    public static CTBarChart parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1InputStream, CTBarChart.type, param1XmlOptions);
    }
    
    public static CTBarChart parse(Reader param1Reader) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1Reader, CTBarChart.type, null);
    }
    
    public static CTBarChart parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTBarChart)getTypeLoader().parse(param1Reader, CTBarChart.type, param1XmlOptions);
    }
    
    public static CTBarChart parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTBarChart)getTypeLoader().parse(param1XMLStreamReader, CTBarChart.type, null);
    }
    
    public static CTBarChart parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTBarChart)getTypeLoader().parse(param1XMLStreamReader, CTBarChart.type, param1XmlOptions);
    }
    
    public static CTBarChart parse(Node param1Node) throws XmlException {
      return (CTBarChart)getTypeLoader().parse(param1Node, CTBarChart.type, null);
    }
    
    public static CTBarChart parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTBarChart)getTypeLoader().parse(param1Node, CTBarChart.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTBarChart parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTBarChart)getTypeLoader().parse(param1XMLInputStream, CTBarChart.type, null);
    }
    
    @Deprecated
    public static CTBarChart parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTBarChart)getTypeLoader().parse(param1XMLInputStream, CTBarChart.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTBarChart.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTBarChart.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTBarChart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */