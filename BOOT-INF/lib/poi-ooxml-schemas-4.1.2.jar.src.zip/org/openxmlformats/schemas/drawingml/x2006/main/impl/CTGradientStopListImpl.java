package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTGradientStop;
import org.openxmlformats.schemas.drawingml.x2006.main.CTGradientStopList;

public class CTGradientStopListImpl extends XmlComplexContentImpl implements CTGradientStopList {
  private static final long serialVersionUID = 1L;
  
  private static final QName GS$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "gs");
  
  public CTGradientStopListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTGradientStop> getGsList() {
    synchronized (monitor()) {
      check_orphaned();
      final class GsList extends AbstractList<CTGradientStop> {
        public CTGradientStop get(int param1Int) {
          return CTGradientStopListImpl.this.getGsArray(param1Int);
        }
        
        public CTGradientStop set(int param1Int, CTGradientStop param1CTGradientStop) {
          CTGradientStop cTGradientStop = CTGradientStopListImpl.this.getGsArray(param1Int);
          CTGradientStopListImpl.this.setGsArray(param1Int, param1CTGradientStop);
          return cTGradientStop;
        }
        
        public void add(int param1Int, CTGradientStop param1CTGradientStop) {
          CTGradientStopListImpl.this.insertNewGs(param1Int).set((XmlObject)param1CTGradientStop);
        }
        
        public CTGradientStop remove(int param1Int) {
          CTGradientStop cTGradientStop = CTGradientStopListImpl.this.getGsArray(param1Int);
          CTGradientStopListImpl.this.removeGs(param1Int);
          return cTGradientStop;
        }
        
        public int size() {
          return CTGradientStopListImpl.this.sizeOfGsArray();
        }
      };
      return new GsList();
    } 
  }
  
  @Deprecated
  public CTGradientStop[] getGsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(GS$0, arrayList);
      CTGradientStop[] arrayOfCTGradientStop = new CTGradientStop[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTGradientStop);
      return arrayOfCTGradientStop;
    } 
  }
  
  public CTGradientStop getGsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGradientStop cTGradientStop = null;
      cTGradientStop = (CTGradientStop)get_store().find_element_user(GS$0, paramInt);
      if (cTGradientStop == null)
        throw new IndexOutOfBoundsException(); 
      return cTGradientStop;
    } 
  }
  
  public int sizeOfGsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(GS$0);
    } 
  }
  
  public void setGsArray(CTGradientStop[] paramArrayOfCTGradientStop) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTGradientStop, GS$0);
  }
  
  public void setGsArray(int paramInt, CTGradientStop paramCTGradientStop) {
    generatedSetterHelperImpl((XmlObject)paramCTGradientStop, GS$0, paramInt, (short)2);
  }
  
  public CTGradientStop insertNewGs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGradientStop cTGradientStop = null;
      cTGradientStop = (CTGradientStop)get_store().insert_element_user(GS$0, paramInt);
      return cTGradientStop;
    } 
  }
  
  public CTGradientStop addNewGs() {
    synchronized (monitor()) {
      check_orphaned();
      CTGradientStop cTGradientStop = null;
      cTGradientStop = (CTGradientStop)get_store().add_element_user(GS$0);
      return cTGradientStop;
    } 
  }
  
  public void removeGs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GS$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTGradientStopListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */