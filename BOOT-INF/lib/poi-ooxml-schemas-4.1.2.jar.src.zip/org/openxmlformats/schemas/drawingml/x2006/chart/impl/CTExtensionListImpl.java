package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtension;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;

public class CTExtensionListImpl extends XmlComplexContentImpl implements CTExtensionList {
  private static final long serialVersionUID = 1L;
  
  private static final QName EXT$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "ext");
  
  public CTExtensionListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTExtension> getExtList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ExtList extends AbstractList<CTExtension> {
        public CTExtension get(int param1Int) {
          return CTExtensionListImpl.this.getExtArray(param1Int);
        }
        
        public CTExtension set(int param1Int, CTExtension param1CTExtension) {
          CTExtension cTExtension = CTExtensionListImpl.this.getExtArray(param1Int);
          CTExtensionListImpl.this.setExtArray(param1Int, param1CTExtension);
          return cTExtension;
        }
        
        public void add(int param1Int, CTExtension param1CTExtension) {
          CTExtensionListImpl.this.insertNewExt(param1Int).set((XmlObject)param1CTExtension);
        }
        
        public CTExtension remove(int param1Int) {
          CTExtension cTExtension = CTExtensionListImpl.this.getExtArray(param1Int);
          CTExtensionListImpl.this.removeExt(param1Int);
          return cTExtension;
        }
        
        public int size() {
          return CTExtensionListImpl.this.sizeOfExtArray();
        }
      };
      return new ExtList();
    } 
  }
  
  @Deprecated
  public CTExtension[] getExtArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(EXT$0, arrayList);
      CTExtension[] arrayOfCTExtension = new CTExtension[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTExtension);
      return arrayOfCTExtension;
    } 
  }
  
  public CTExtension getExtArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTExtension cTExtension = null;
      cTExtension = (CTExtension)get_store().find_element_user(EXT$0, paramInt);
      if (cTExtension == null)
        throw new IndexOutOfBoundsException(); 
      return cTExtension;
    } 
  }
  
  public int sizeOfExtArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(EXT$0);
    } 
  }
  
  public void setExtArray(CTExtension[] paramArrayOfCTExtension) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTExtension, EXT$0);
  }
  
  public void setExtArray(int paramInt, CTExtension paramCTExtension) {
    generatedSetterHelperImpl((XmlObject)paramCTExtension, EXT$0, paramInt, (short)2);
  }
  
  public CTExtension insertNewExt(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTExtension cTExtension = null;
      cTExtension = (CTExtension)get_store().insert_element_user(EXT$0, paramInt);
      return cTExtension;
    } 
  }
  
  public CTExtension addNewExt() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtension cTExtension = null;
      cTExtension = (CTExtension)get_store().add_element_user(EXT$0);
      return cTExtension;
    } 
  }
  
  public void removeExt(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXT$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTExtensionListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */