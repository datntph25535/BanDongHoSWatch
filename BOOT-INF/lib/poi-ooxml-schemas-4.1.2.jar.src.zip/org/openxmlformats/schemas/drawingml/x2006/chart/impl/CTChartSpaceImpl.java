package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTChartSpace;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExternalData;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPivotSource;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPrintSettings;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTProtection;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTRelId;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTStyle;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTTextLanguageID;
import org.openxmlformats.schemas.drawingml.x2006.main.CTColorMapping;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextBody;

public class CTChartSpaceImpl extends XmlComplexContentImpl implements CTChartSpace {
  private static final long serialVersionUID = 1L;
  
  private static final QName DATE1904$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "date1904");
  
  private static final QName LANG$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "lang");
  
  private static final QName ROUNDEDCORNERS$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "roundedCorners");
  
  private static final QName STYLE$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "style");
  
  private static final QName CLRMAPOVR$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "clrMapOvr");
  
  private static final QName PIVOTSOURCE$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "pivotSource");
  
  private static final QName PROTECTION$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "protection");
  
  private static final QName CHART$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "chart");
  
  private static final QName SPPR$16 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName TXPR$18 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "txPr");
  
  private static final QName EXTERNALDATA$20 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "externalData");
  
  private static final QName PRINTSETTINGS$22 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "printSettings");
  
  private static final QName USERSHAPES$24 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "userShapes");
  
  private static final QName EXTLST$26 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTChartSpaceImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTBoolean getDate1904() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(DATE1904$0, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetDate1904() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DATE1904$0) != 0);
    } 
  }
  
  public void setDate1904(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, DATE1904$0, 0, (short)1);
  }
  
  public CTBoolean addNewDate1904() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(DATE1904$0);
      return cTBoolean;
    } 
  }
  
  public void unsetDate1904() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DATE1904$0, 0);
    } 
  }
  
  public CTTextLanguageID getLang() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextLanguageID cTTextLanguageID = null;
      cTTextLanguageID = (CTTextLanguageID)get_store().find_element_user(LANG$2, 0);
      if (cTTextLanguageID == null)
        return null; 
      return cTTextLanguageID;
    } 
  }
  
  public boolean isSetLang() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(LANG$2) != 0);
    } 
  }
  
  public void setLang(CTTextLanguageID paramCTTextLanguageID) {
    generatedSetterHelperImpl((XmlObject)paramCTTextLanguageID, LANG$2, 0, (short)1);
  }
  
  public CTTextLanguageID addNewLang() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextLanguageID cTTextLanguageID = null;
      cTTextLanguageID = (CTTextLanguageID)get_store().add_element_user(LANG$2);
      return cTTextLanguageID;
    } 
  }
  
  public void unsetLang() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LANG$2, 0);
    } 
  }
  
  public CTBoolean getRoundedCorners() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(ROUNDEDCORNERS$4, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetRoundedCorners() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(ROUNDEDCORNERS$4) != 0);
    } 
  }
  
  public void setRoundedCorners(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, ROUNDEDCORNERS$4, 0, (short)1);
  }
  
  public CTBoolean addNewRoundedCorners() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(ROUNDEDCORNERS$4);
      return cTBoolean;
    } 
  }
  
  public void unsetRoundedCorners() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ROUNDEDCORNERS$4, 0);
    } 
  }
  
  public CTStyle getStyle() {
    synchronized (monitor()) {
      check_orphaned();
      CTStyle cTStyle = null;
      cTStyle = (CTStyle)get_store().find_element_user(STYLE$6, 0);
      if (cTStyle == null)
        return null; 
      return cTStyle;
    } 
  }
  
  public boolean isSetStyle() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(STYLE$6) != 0);
    } 
  }
  
  public void setStyle(CTStyle paramCTStyle) {
    generatedSetterHelperImpl((XmlObject)paramCTStyle, STYLE$6, 0, (short)1);
  }
  
  public CTStyle addNewStyle() {
    synchronized (monitor()) {
      check_orphaned();
      CTStyle cTStyle = null;
      cTStyle = (CTStyle)get_store().add_element_user(STYLE$6);
      return cTStyle;
    } 
  }
  
  public void unsetStyle() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(STYLE$6, 0);
    } 
  }
  
  public CTColorMapping getClrMapOvr() {
    synchronized (monitor()) {
      check_orphaned();
      CTColorMapping cTColorMapping = null;
      cTColorMapping = (CTColorMapping)get_store().find_element_user(CLRMAPOVR$8, 0);
      if (cTColorMapping == null)
        return null; 
      return cTColorMapping;
    } 
  }
  
  public boolean isSetClrMapOvr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CLRMAPOVR$8) != 0);
    } 
  }
  
  public void setClrMapOvr(CTColorMapping paramCTColorMapping) {
    generatedSetterHelperImpl((XmlObject)paramCTColorMapping, CLRMAPOVR$8, 0, (short)1);
  }
  
  public CTColorMapping addNewClrMapOvr() {
    synchronized (monitor()) {
      check_orphaned();
      CTColorMapping cTColorMapping = null;
      cTColorMapping = (CTColorMapping)get_store().add_element_user(CLRMAPOVR$8);
      return cTColorMapping;
    } 
  }
  
  public void unsetClrMapOvr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CLRMAPOVR$8, 0);
    } 
  }
  
  public CTPivotSource getPivotSource() {
    synchronized (monitor()) {
      check_orphaned();
      CTPivotSource cTPivotSource = null;
      cTPivotSource = (CTPivotSource)get_store().find_element_user(PIVOTSOURCE$10, 0);
      if (cTPivotSource == null)
        return null; 
      return cTPivotSource;
    } 
  }
  
  public boolean isSetPivotSource() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PIVOTSOURCE$10) != 0);
    } 
  }
  
  public void setPivotSource(CTPivotSource paramCTPivotSource) {
    generatedSetterHelperImpl((XmlObject)paramCTPivotSource, PIVOTSOURCE$10, 0, (short)1);
  }
  
  public CTPivotSource addNewPivotSource() {
    synchronized (monitor()) {
      check_orphaned();
      CTPivotSource cTPivotSource = null;
      cTPivotSource = (CTPivotSource)get_store().add_element_user(PIVOTSOURCE$10);
      return cTPivotSource;
    } 
  }
  
  public void unsetPivotSource() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PIVOTSOURCE$10, 0);
    } 
  }
  
  public CTProtection getProtection() {
    synchronized (monitor()) {
      check_orphaned();
      CTProtection cTProtection = null;
      cTProtection = (CTProtection)get_store().find_element_user(PROTECTION$12, 0);
      if (cTProtection == null)
        return null; 
      return cTProtection;
    } 
  }
  
  public boolean isSetProtection() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PROTECTION$12) != 0);
    } 
  }
  
  public void setProtection(CTProtection paramCTProtection) {
    generatedSetterHelperImpl((XmlObject)paramCTProtection, PROTECTION$12, 0, (short)1);
  }
  
  public CTProtection addNewProtection() {
    synchronized (monitor()) {
      check_orphaned();
      CTProtection cTProtection = null;
      cTProtection = (CTProtection)get_store().add_element_user(PROTECTION$12);
      return cTProtection;
    } 
  }
  
  public void unsetProtection() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PROTECTION$12, 0);
    } 
  }
  
  public CTChart getChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTChart cTChart = null;
      cTChart = (CTChart)get_store().find_element_user(CHART$14, 0);
      if (cTChart == null)
        return null; 
      return cTChart;
    } 
  }
  
  public void setChart(CTChart paramCTChart) {
    generatedSetterHelperImpl((XmlObject)paramCTChart, CHART$14, 0, (short)1);
  }
  
  public CTChart addNewChart() {
    synchronized (monitor()) {
      check_orphaned();
      CTChart cTChart = null;
      cTChart = (CTChart)get_store().add_element_user(CHART$14);
      return cTChart;
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$16, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$16) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$16, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$16);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$16, 0);
    } 
  }
  
  public CTTextBody getTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextBody cTTextBody = null;
      cTTextBody = (CTTextBody)get_store().find_element_user(TXPR$18, 0);
      if (cTTextBody == null)
        return null; 
      return cTTextBody;
    } 
  }
  
  public boolean isSetTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(TXPR$18) != 0);
    } 
  }
  
  public void setTxPr(CTTextBody paramCTTextBody) {
    generatedSetterHelperImpl((XmlObject)paramCTTextBody, TXPR$18, 0, (short)1);
  }
  
  public CTTextBody addNewTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTTextBody cTTextBody = null;
      cTTextBody = (CTTextBody)get_store().add_element_user(TXPR$18);
      return cTTextBody;
    } 
  }
  
  public void unsetTxPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TXPR$18, 0);
    } 
  }
  
  public CTExternalData getExternalData() {
    synchronized (monitor()) {
      check_orphaned();
      CTExternalData cTExternalData = null;
      cTExternalData = (CTExternalData)get_store().find_element_user(EXTERNALDATA$20, 0);
      if (cTExternalData == null)
        return null; 
      return cTExternalData;
    } 
  }
  
  public boolean isSetExternalData() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTERNALDATA$20) != 0);
    } 
  }
  
  public void setExternalData(CTExternalData paramCTExternalData) {
    generatedSetterHelperImpl((XmlObject)paramCTExternalData, EXTERNALDATA$20, 0, (short)1);
  }
  
  public CTExternalData addNewExternalData() {
    synchronized (monitor()) {
      check_orphaned();
      CTExternalData cTExternalData = null;
      cTExternalData = (CTExternalData)get_store().add_element_user(EXTERNALDATA$20);
      return cTExternalData;
    } 
  }
  
  public void unsetExternalData() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTERNALDATA$20, 0);
    } 
  }
  
  public CTPrintSettings getPrintSettings() {
    synchronized (monitor()) {
      check_orphaned();
      CTPrintSettings cTPrintSettings = null;
      cTPrintSettings = (CTPrintSettings)get_store().find_element_user(PRINTSETTINGS$22, 0);
      if (cTPrintSettings == null)
        return null; 
      return cTPrintSettings;
    } 
  }
  
  public boolean isSetPrintSettings() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PRINTSETTINGS$22) != 0);
    } 
  }
  
  public void setPrintSettings(CTPrintSettings paramCTPrintSettings) {
    generatedSetterHelperImpl((XmlObject)paramCTPrintSettings, PRINTSETTINGS$22, 0, (short)1);
  }
  
  public CTPrintSettings addNewPrintSettings() {
    synchronized (monitor()) {
      check_orphaned();
      CTPrintSettings cTPrintSettings = null;
      cTPrintSettings = (CTPrintSettings)get_store().add_element_user(PRINTSETTINGS$22);
      return cTPrintSettings;
    } 
  }
  
  public void unsetPrintSettings() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PRINTSETTINGS$22, 0);
    } 
  }
  
  public CTRelId getUserShapes() {
    synchronized (monitor()) {
      check_orphaned();
      CTRelId cTRelId = null;
      cTRelId = (CTRelId)get_store().find_element_user(USERSHAPES$24, 0);
      if (cTRelId == null)
        return null; 
      return cTRelId;
    } 
  }
  
  public boolean isSetUserShapes() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(USERSHAPES$24) != 0);
    } 
  }
  
  public void setUserShapes(CTRelId paramCTRelId) {
    generatedSetterHelperImpl((XmlObject)paramCTRelId, USERSHAPES$24, 0, (short)1);
  }
  
  public CTRelId addNewUserShapes() {
    synchronized (monitor()) {
      check_orphaned();
      CTRelId cTRelId = null;
      cTRelId = (CTRelId)get_store().add_element_user(USERSHAPES$24);
      return cTRelId;
    } 
  }
  
  public void unsetUserShapes() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(USERSHAPES$24, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$26, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$26) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$26, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$26);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$26, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTChartSpaceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */