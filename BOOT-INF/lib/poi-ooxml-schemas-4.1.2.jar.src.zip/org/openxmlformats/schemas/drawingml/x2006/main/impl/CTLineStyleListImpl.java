package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTLineProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTLineStyleList;

public class CTLineStyleListImpl extends XmlComplexContentImpl implements CTLineStyleList {
  private static final long serialVersionUID = 1L;
  
  private static final QName LN$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "ln");
  
  public CTLineStyleListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTLineProperties> getLnList() {
    synchronized (monitor()) {
      check_orphaned();
      final class LnList extends AbstractList<CTLineProperties> {
        public CTLineProperties get(int param1Int) {
          return CTLineStyleListImpl.this.getLnArray(param1Int);
        }
        
        public CTLineProperties set(int param1Int, CTLineProperties param1CTLineProperties) {
          CTLineProperties cTLineProperties = CTLineStyleListImpl.this.getLnArray(param1Int);
          CTLineStyleListImpl.this.setLnArray(param1Int, param1CTLineProperties);
          return cTLineProperties;
        }
        
        public void add(int param1Int, CTLineProperties param1CTLineProperties) {
          CTLineStyleListImpl.this.insertNewLn(param1Int).set((XmlObject)param1CTLineProperties);
        }
        
        public CTLineProperties remove(int param1Int) {
          CTLineProperties cTLineProperties = CTLineStyleListImpl.this.getLnArray(param1Int);
          CTLineStyleListImpl.this.removeLn(param1Int);
          return cTLineProperties;
        }
        
        public int size() {
          return CTLineStyleListImpl.this.sizeOfLnArray();
        }
      };
      return new LnList();
    } 
  }
  
  @Deprecated
  public CTLineProperties[] getLnArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(LN$0, arrayList);
      CTLineProperties[] arrayOfCTLineProperties = new CTLineProperties[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTLineProperties);
      return arrayOfCTLineProperties;
    } 
  }
  
  public CTLineProperties getLnArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLineProperties cTLineProperties = null;
      cTLineProperties = (CTLineProperties)get_store().find_element_user(LN$0, paramInt);
      if (cTLineProperties == null)
        throw new IndexOutOfBoundsException(); 
      return cTLineProperties;
    } 
  }
  
  public int sizeOfLnArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(LN$0);
    } 
  }
  
  public void setLnArray(CTLineProperties[] paramArrayOfCTLineProperties) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTLineProperties, LN$0);
  }
  
  public void setLnArray(int paramInt, CTLineProperties paramCTLineProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTLineProperties, LN$0, paramInt, (short)2);
  }
  
  public CTLineProperties insertNewLn(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLineProperties cTLineProperties = null;
      cTLineProperties = (CTLineProperties)get_store().insert_element_user(LN$0, paramInt);
      return cTLineProperties;
    } 
  }
  
  public CTLineProperties addNewLn() {
    synchronized (monitor()) {
      check_orphaned();
      CTLineProperties cTLineProperties = null;
      cTLineProperties = (CTLineProperties)get_store().add_element_user(LN$0);
      return cTLineProperties;
    } 
  }
  
  public void removeLn(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LN$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTLineStyleListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */