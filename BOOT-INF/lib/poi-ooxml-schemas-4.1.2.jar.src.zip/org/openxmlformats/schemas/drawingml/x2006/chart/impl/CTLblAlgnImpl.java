package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.StringEnumAbstractBase;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLblAlgn;
import org.openxmlformats.schemas.drawingml.x2006.chart.STLblAlgn;

public class CTLblAlgnImpl extends XmlComplexContentImpl implements CTLblAlgn {
  private static final long serialVersionUID = 1L;
  
  private static final QName VAL$0 = new QName("", "val");
  
  public CTLblAlgnImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public STLblAlgn.Enum getVal() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(VAL$0);
      if (simpleValue == null)
        return null; 
      return (STLblAlgn.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STLblAlgn xgetVal() {
    synchronized (monitor()) {
      check_orphaned();
      STLblAlgn sTLblAlgn = null;
      sTLblAlgn = (STLblAlgn)get_store().find_attribute_user(VAL$0);
      return sTLblAlgn;
    } 
  }
  
  public void setVal(STLblAlgn.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(VAL$0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(VAL$0); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetVal(STLblAlgn paramSTLblAlgn) {
    synchronized (monitor()) {
      check_orphaned();
      STLblAlgn sTLblAlgn = null;
      sTLblAlgn = (STLblAlgn)get_store().find_attribute_user(VAL$0);
      if (sTLblAlgn == null)
        sTLblAlgn = (STLblAlgn)get_store().add_attribute_user(VAL$0); 
      sTLblAlgn.set((XmlObject)paramSTLblAlgn);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTLblAlgnImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */