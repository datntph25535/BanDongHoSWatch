package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTAreaChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTAreaSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTChartLines;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbls;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTGrouping;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;

public class CTAreaChartImpl extends XmlComplexContentImpl implements CTAreaChart {
  private static final long serialVersionUID = 1L;
  
  private static final QName GROUPING$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "grouping");
  
  private static final QName VARYCOLORS$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "varyColors");
  
  private static final QName SER$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "ser");
  
  private static final QName DLBLS$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dLbls");
  
  private static final QName DROPLINES$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dropLines");
  
  private static final QName AXID$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "axId");
  
  private static final QName EXTLST$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTAreaChartImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTGrouping getGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      CTGrouping cTGrouping = null;
      cTGrouping = (CTGrouping)get_store().find_element_user(GROUPING$0, 0);
      if (cTGrouping == null)
        return null; 
      return cTGrouping;
    } 
  }
  
  public boolean isSetGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(GROUPING$0) != 0);
    } 
  }
  
  public void setGrouping(CTGrouping paramCTGrouping) {
    generatedSetterHelperImpl((XmlObject)paramCTGrouping, GROUPING$0, 0, (short)1);
  }
  
  public CTGrouping addNewGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      CTGrouping cTGrouping = null;
      cTGrouping = (CTGrouping)get_store().add_element_user(GROUPING$0);
      return cTGrouping;
    } 
  }
  
  public void unsetGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GROUPING$0, 0);
    } 
  }
  
  public CTBoolean getVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(VARYCOLORS$2, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(VARYCOLORS$2) != 0);
    } 
  }
  
  public void setVaryColors(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, VARYCOLORS$2, 0, (short)1);
  }
  
  public CTBoolean addNewVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(VARYCOLORS$2);
      return cTBoolean;
    } 
  }
  
  public void unsetVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(VARYCOLORS$2, 0);
    } 
  }
  
  public List<CTAreaSer> getSerList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SerList extends AbstractList<CTAreaSer> {
        public CTAreaSer get(int param1Int) {
          return CTAreaChartImpl.this.getSerArray(param1Int);
        }
        
        public CTAreaSer set(int param1Int, CTAreaSer param1CTAreaSer) {
          CTAreaSer cTAreaSer = CTAreaChartImpl.this.getSerArray(param1Int);
          CTAreaChartImpl.this.setSerArray(param1Int, param1CTAreaSer);
          return cTAreaSer;
        }
        
        public void add(int param1Int, CTAreaSer param1CTAreaSer) {
          CTAreaChartImpl.this.insertNewSer(param1Int).set((XmlObject)param1CTAreaSer);
        }
        
        public CTAreaSer remove(int param1Int) {
          CTAreaSer cTAreaSer = CTAreaChartImpl.this.getSerArray(param1Int);
          CTAreaChartImpl.this.removeSer(param1Int);
          return cTAreaSer;
        }
        
        public int size() {
          return CTAreaChartImpl.this.sizeOfSerArray();
        }
      };
      return new SerList();
    } 
  }
  
  @Deprecated
  public CTAreaSer[] getSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SER$4, arrayList);
      CTAreaSer[] arrayOfCTAreaSer = new CTAreaSer[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAreaSer);
      return arrayOfCTAreaSer;
    } 
  }
  
  public CTAreaSer getSerArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAreaSer cTAreaSer = null;
      cTAreaSer = (CTAreaSer)get_store().find_element_user(SER$4, paramInt);
      if (cTAreaSer == null)
        throw new IndexOutOfBoundsException(); 
      return cTAreaSer;
    } 
  }
  
  public int sizeOfSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SER$4);
    } 
  }
  
  public void setSerArray(CTAreaSer[] paramArrayOfCTAreaSer) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAreaSer, SER$4);
  }
  
  public void setSerArray(int paramInt, CTAreaSer paramCTAreaSer) {
    generatedSetterHelperImpl((XmlObject)paramCTAreaSer, SER$4, paramInt, (short)2);
  }
  
  public CTAreaSer insertNewSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAreaSer cTAreaSer = null;
      cTAreaSer = (CTAreaSer)get_store().insert_element_user(SER$4, paramInt);
      return cTAreaSer;
    } 
  }
  
  public CTAreaSer addNewSer() {
    synchronized (monitor()) {
      check_orphaned();
      CTAreaSer cTAreaSer = null;
      cTAreaSer = (CTAreaSer)get_store().add_element_user(SER$4);
      return cTAreaSer;
    } 
  }
  
  public void removeSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SER$4, paramInt);
    } 
  }
  
  public CTDLbls getDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().find_element_user(DLBLS$6, 0);
      if (cTDLbls == null)
        return null; 
      return cTDLbls;
    } 
  }
  
  public boolean isSetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DLBLS$6) != 0);
    } 
  }
  
  public void setDLbls(CTDLbls paramCTDLbls) {
    generatedSetterHelperImpl((XmlObject)paramCTDLbls, DLBLS$6, 0, (short)1);
  }
  
  public CTDLbls addNewDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().add_element_user(DLBLS$6);
      return cTDLbls;
    } 
  }
  
  public void unsetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DLBLS$6, 0);
    } 
  }
  
  public CTChartLines getDropLines() {
    synchronized (monitor()) {
      check_orphaned();
      CTChartLines cTChartLines = null;
      cTChartLines = (CTChartLines)get_store().find_element_user(DROPLINES$8, 0);
      if (cTChartLines == null)
        return null; 
      return cTChartLines;
    } 
  }
  
  public boolean isSetDropLines() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DROPLINES$8) != 0);
    } 
  }
  
  public void setDropLines(CTChartLines paramCTChartLines) {
    generatedSetterHelperImpl((XmlObject)paramCTChartLines, DROPLINES$8, 0, (short)1);
  }
  
  public CTChartLines addNewDropLines() {
    synchronized (monitor()) {
      check_orphaned();
      CTChartLines cTChartLines = null;
      cTChartLines = (CTChartLines)get_store().add_element_user(DROPLINES$8);
      return cTChartLines;
    } 
  }
  
  public void unsetDropLines() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DROPLINES$8, 0);
    } 
  }
  
  public List<CTUnsignedInt> getAxIdList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AxIdList extends AbstractList<CTUnsignedInt> {
        public CTUnsignedInt get(int param1Int) {
          return CTAreaChartImpl.this.getAxIdArray(param1Int);
        }
        
        public CTUnsignedInt set(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTUnsignedInt cTUnsignedInt = CTAreaChartImpl.this.getAxIdArray(param1Int);
          CTAreaChartImpl.this.setAxIdArray(param1Int, param1CTUnsignedInt);
          return cTUnsignedInt;
        }
        
        public void add(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTAreaChartImpl.this.insertNewAxId(param1Int).set((XmlObject)param1CTUnsignedInt);
        }
        
        public CTUnsignedInt remove(int param1Int) {
          CTUnsignedInt cTUnsignedInt = CTAreaChartImpl.this.getAxIdArray(param1Int);
          CTAreaChartImpl.this.removeAxId(param1Int);
          return cTUnsignedInt;
        }
        
        public int size() {
          return CTAreaChartImpl.this.sizeOfAxIdArray();
        }
      };
      return new AxIdList();
    } 
  }
  
  @Deprecated
  public CTUnsignedInt[] getAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(AXID$10, arrayList);
      CTUnsignedInt[] arrayOfCTUnsignedInt = new CTUnsignedInt[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTUnsignedInt);
      return arrayOfCTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt getAxIdArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(AXID$10, paramInt);
      if (cTUnsignedInt == null)
        throw new IndexOutOfBoundsException(); 
      return cTUnsignedInt;
    } 
  }
  
  public int sizeOfAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(AXID$10);
    } 
  }
  
  public void setAxIdArray(CTUnsignedInt[] paramArrayOfCTUnsignedInt) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTUnsignedInt, AXID$10);
  }
  
  public void setAxIdArray(int paramInt, CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, AXID$10, paramInt, (short)2);
  }
  
  public CTUnsignedInt insertNewAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().insert_element_user(AXID$10, paramInt);
      return cTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt addNewAxId() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(AXID$10);
      return cTUnsignedInt;
    } 
  }
  
  public void removeAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(AXID$10, paramInt);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$12, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$12) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$12, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$12);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$12, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTAreaChartImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */