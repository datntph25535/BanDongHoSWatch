package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTExtensionList extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTExtensionList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctextensionlist7389type");
  
  List<CTExtension> getExtList();
  
  @Deprecated
  CTExtension[] getExtArray();
  
  CTExtension getExtArray(int paramInt);
  
  int sizeOfExtArray();
  
  void setExtArray(CTExtension[] paramArrayOfCTExtension);
  
  void setExtArray(int paramInt, CTExtension paramCTExtension);
  
  CTExtension insertNewExt(int paramInt);
  
  CTExtension addNewExt();
  
  void removeExt(int paramInt);
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTExtensionList.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTExtensionList newInstance() {
      return (CTExtensionList)getTypeLoader().newInstance(CTExtensionList.type, null);
    }
    
    public static CTExtensionList newInstance(XmlOptions param1XmlOptions) {
      return (CTExtensionList)getTypeLoader().newInstance(CTExtensionList.type, param1XmlOptions);
    }
    
    public static CTExtensionList parse(String param1String) throws XmlException {
      return (CTExtensionList)getTypeLoader().parse(param1String, CTExtensionList.type, null);
    }
    
    public static CTExtensionList parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTExtensionList)getTypeLoader().parse(param1String, CTExtensionList.type, param1XmlOptions);
    }
    
    public static CTExtensionList parse(File param1File) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1File, CTExtensionList.type, null);
    }
    
    public static CTExtensionList parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1File, CTExtensionList.type, param1XmlOptions);
    }
    
    public static CTExtensionList parse(URL param1URL) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1URL, CTExtensionList.type, null);
    }
    
    public static CTExtensionList parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1URL, CTExtensionList.type, param1XmlOptions);
    }
    
    public static CTExtensionList parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1InputStream, CTExtensionList.type, null);
    }
    
    public static CTExtensionList parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1InputStream, CTExtensionList.type, param1XmlOptions);
    }
    
    public static CTExtensionList parse(Reader param1Reader) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1Reader, CTExtensionList.type, null);
    }
    
    public static CTExtensionList parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTExtensionList)getTypeLoader().parse(param1Reader, CTExtensionList.type, param1XmlOptions);
    }
    
    public static CTExtensionList parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTExtensionList)getTypeLoader().parse(param1XMLStreamReader, CTExtensionList.type, null);
    }
    
    public static CTExtensionList parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTExtensionList)getTypeLoader().parse(param1XMLStreamReader, CTExtensionList.type, param1XmlOptions);
    }
    
    public static CTExtensionList parse(Node param1Node) throws XmlException {
      return (CTExtensionList)getTypeLoader().parse(param1Node, CTExtensionList.type, null);
    }
    
    public static CTExtensionList parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTExtensionList)getTypeLoader().parse(param1Node, CTExtensionList.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTExtensionList parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTExtensionList)getTypeLoader().parse(param1XMLInputStream, CTExtensionList.type, null);
    }
    
    @Deprecated
    public static CTExtensionList parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTExtensionList)getTypeLoader().parse(param1XMLInputStream, CTExtensionList.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTExtensionList.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTExtensionList.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTExtensionList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */