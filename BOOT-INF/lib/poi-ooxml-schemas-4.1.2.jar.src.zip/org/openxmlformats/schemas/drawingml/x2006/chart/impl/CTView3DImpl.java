package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDepthPercent;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTHPercent;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPerspective;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTRotX;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTRotY;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTView3D;

public class CTView3DImpl extends XmlComplexContentImpl implements CTView3D {
  private static final long serialVersionUID = 1L;
  
  private static final QName ROTX$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "rotX");
  
  private static final QName HPERCENT$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "hPercent");
  
  private static final QName ROTY$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "rotY");
  
  private static final QName DEPTHPERCENT$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "depthPercent");
  
  private static final QName RANGAX$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "rAngAx");
  
  private static final QName PERSPECTIVE$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "perspective");
  
  private static final QName EXTLST$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTView3DImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTRotX getRotX() {
    synchronized (monitor()) {
      check_orphaned();
      CTRotX cTRotX = null;
      cTRotX = (CTRotX)get_store().find_element_user(ROTX$0, 0);
      if (cTRotX == null)
        return null; 
      return cTRotX;
    } 
  }
  
  public boolean isSetRotX() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(ROTX$0) != 0);
    } 
  }
  
  public void setRotX(CTRotX paramCTRotX) {
    generatedSetterHelperImpl((XmlObject)paramCTRotX, ROTX$0, 0, (short)1);
  }
  
  public CTRotX addNewRotX() {
    synchronized (monitor()) {
      check_orphaned();
      CTRotX cTRotX = null;
      cTRotX = (CTRotX)get_store().add_element_user(ROTX$0);
      return cTRotX;
    } 
  }
  
  public void unsetRotX() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ROTX$0, 0);
    } 
  }
  
  public CTHPercent getHPercent() {
    synchronized (monitor()) {
      check_orphaned();
      CTHPercent cTHPercent = null;
      cTHPercent = (CTHPercent)get_store().find_element_user(HPERCENT$2, 0);
      if (cTHPercent == null)
        return null; 
      return cTHPercent;
    } 
  }
  
  public boolean isSetHPercent() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(HPERCENT$2) != 0);
    } 
  }
  
  public void setHPercent(CTHPercent paramCTHPercent) {
    generatedSetterHelperImpl((XmlObject)paramCTHPercent, HPERCENT$2, 0, (short)1);
  }
  
  public CTHPercent addNewHPercent() {
    synchronized (monitor()) {
      check_orphaned();
      CTHPercent cTHPercent = null;
      cTHPercent = (CTHPercent)get_store().add_element_user(HPERCENT$2);
      return cTHPercent;
    } 
  }
  
  public void unsetHPercent() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(HPERCENT$2, 0);
    } 
  }
  
  public CTRotY getRotY() {
    synchronized (monitor()) {
      check_orphaned();
      CTRotY cTRotY = null;
      cTRotY = (CTRotY)get_store().find_element_user(ROTY$4, 0);
      if (cTRotY == null)
        return null; 
      return cTRotY;
    } 
  }
  
  public boolean isSetRotY() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(ROTY$4) != 0);
    } 
  }
  
  public void setRotY(CTRotY paramCTRotY) {
    generatedSetterHelperImpl((XmlObject)paramCTRotY, ROTY$4, 0, (short)1);
  }
  
  public CTRotY addNewRotY() {
    synchronized (monitor()) {
      check_orphaned();
      CTRotY cTRotY = null;
      cTRotY = (CTRotY)get_store().add_element_user(ROTY$4);
      return cTRotY;
    } 
  }
  
  public void unsetRotY() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ROTY$4, 0);
    } 
  }
  
  public CTDepthPercent getDepthPercent() {
    synchronized (monitor()) {
      check_orphaned();
      CTDepthPercent cTDepthPercent = null;
      cTDepthPercent = (CTDepthPercent)get_store().find_element_user(DEPTHPERCENT$6, 0);
      if (cTDepthPercent == null)
        return null; 
      return cTDepthPercent;
    } 
  }
  
  public boolean isSetDepthPercent() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DEPTHPERCENT$6) != 0);
    } 
  }
  
  public void setDepthPercent(CTDepthPercent paramCTDepthPercent) {
    generatedSetterHelperImpl((XmlObject)paramCTDepthPercent, DEPTHPERCENT$6, 0, (short)1);
  }
  
  public CTDepthPercent addNewDepthPercent() {
    synchronized (monitor()) {
      check_orphaned();
      CTDepthPercent cTDepthPercent = null;
      cTDepthPercent = (CTDepthPercent)get_store().add_element_user(DEPTHPERCENT$6);
      return cTDepthPercent;
    } 
  }
  
  public void unsetDepthPercent() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DEPTHPERCENT$6, 0);
    } 
  }
  
  public CTBoolean getRAngAx() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(RANGAX$8, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetRAngAx() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(RANGAX$8) != 0);
    } 
  }
  
  public void setRAngAx(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, RANGAX$8, 0, (short)1);
  }
  
  public CTBoolean addNewRAngAx() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(RANGAX$8);
      return cTBoolean;
    } 
  }
  
  public void unsetRAngAx() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(RANGAX$8, 0);
    } 
  }
  
  public CTPerspective getPerspective() {
    synchronized (monitor()) {
      check_orphaned();
      CTPerspective cTPerspective = null;
      cTPerspective = (CTPerspective)get_store().find_element_user(PERSPECTIVE$10, 0);
      if (cTPerspective == null)
        return null; 
      return cTPerspective;
    } 
  }
  
  public boolean isSetPerspective() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PERSPECTIVE$10) != 0);
    } 
  }
  
  public void setPerspective(CTPerspective paramCTPerspective) {
    generatedSetterHelperImpl((XmlObject)paramCTPerspective, PERSPECTIVE$10, 0, (short)1);
  }
  
  public CTPerspective addNewPerspective() {
    synchronized (monitor()) {
      check_orphaned();
      CTPerspective cTPerspective = null;
      cTPerspective = (CTPerspective)get_store().add_element_user(PERSPECTIVE$10);
      return cTPerspective;
    } 
  }
  
  public void unsetPerspective() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PERSPECTIVE$10, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$12, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$12) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$12, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$12);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$12, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTView3DImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */