package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTAxDataSource;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbls;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDPt;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTErrBars;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTNumDataSource;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPictureOptions;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSerTx;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTShape;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTTrendline;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;

public class CTBarSerImpl extends XmlComplexContentImpl implements CTBarSer {
  private static final long serialVersionUID = 1L;
  
  private static final QName IDX$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "idx");
  
  private static final QName ORDER$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "order");
  
  private static final QName TX$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "tx");
  
  private static final QName SPPR$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName INVERTIFNEGATIVE$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "invertIfNegative");
  
  private static final QName PICTUREOPTIONS$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "pictureOptions");
  
  private static final QName DPT$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dPt");
  
  private static final QName DLBLS$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dLbls");
  
  private static final QName TRENDLINE$16 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "trendline");
  
  private static final QName ERRBARS$18 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "errBars");
  
  private static final QName CAT$20 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "cat");
  
  private static final QName VAL$22 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "val");
  
  private static final QName SHAPE$24 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "shape");
  
  private static final QName EXTLST$26 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTBarSerImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTUnsignedInt getIdx() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(IDX$0, 0);
      if (cTUnsignedInt == null)
        return null; 
      return cTUnsignedInt;
    } 
  }
  
  public void setIdx(CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, IDX$0, 0, (short)1);
  }
  
  public CTUnsignedInt addNewIdx() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(IDX$0);
      return cTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt getOrder() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(ORDER$2, 0);
      if (cTUnsignedInt == null)
        return null; 
      return cTUnsignedInt;
    } 
  }
  
  public void setOrder(CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, ORDER$2, 0, (short)1);
  }
  
  public CTUnsignedInt addNewOrder() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(ORDER$2);
      return cTUnsignedInt;
    } 
  }
  
  public CTSerTx getTx() {
    synchronized (monitor()) {
      check_orphaned();
      CTSerTx cTSerTx = null;
      cTSerTx = (CTSerTx)get_store().find_element_user(TX$4, 0);
      if (cTSerTx == null)
        return null; 
      return cTSerTx;
    } 
  }
  
  public boolean isSetTx() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(TX$4) != 0);
    } 
  }
  
  public void setTx(CTSerTx paramCTSerTx) {
    generatedSetterHelperImpl((XmlObject)paramCTSerTx, TX$4, 0, (short)1);
  }
  
  public CTSerTx addNewTx() {
    synchronized (monitor()) {
      check_orphaned();
      CTSerTx cTSerTx = null;
      cTSerTx = (CTSerTx)get_store().add_element_user(TX$4);
      return cTSerTx;
    } 
  }
  
  public void unsetTx() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TX$4, 0);
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$6, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$6) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$6, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$6);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$6, 0);
    } 
  }
  
  public CTBoolean getInvertIfNegative() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(INVERTIFNEGATIVE$8, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetInvertIfNegative() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(INVERTIFNEGATIVE$8) != 0);
    } 
  }
  
  public void setInvertIfNegative(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, INVERTIFNEGATIVE$8, 0, (short)1);
  }
  
  public CTBoolean addNewInvertIfNegative() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(INVERTIFNEGATIVE$8);
      return cTBoolean;
    } 
  }
  
  public void unsetInvertIfNegative() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(INVERTIFNEGATIVE$8, 0);
    } 
  }
  
  public CTPictureOptions getPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      CTPictureOptions cTPictureOptions = null;
      cTPictureOptions = (CTPictureOptions)get_store().find_element_user(PICTUREOPTIONS$10, 0);
      if (cTPictureOptions == null)
        return null; 
      return cTPictureOptions;
    } 
  }
  
  public boolean isSetPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PICTUREOPTIONS$10) != 0);
    } 
  }
  
  public void setPictureOptions(CTPictureOptions paramCTPictureOptions) {
    generatedSetterHelperImpl((XmlObject)paramCTPictureOptions, PICTUREOPTIONS$10, 0, (short)1);
  }
  
  public CTPictureOptions addNewPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      CTPictureOptions cTPictureOptions = null;
      cTPictureOptions = (CTPictureOptions)get_store().add_element_user(PICTUREOPTIONS$10);
      return cTPictureOptions;
    } 
  }
  
  public void unsetPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PICTUREOPTIONS$10, 0);
    } 
  }
  
  public List<CTDPt> getDPtList() {
    synchronized (monitor()) {
      check_orphaned();
      final class DPtList extends AbstractList<CTDPt> {
        public CTDPt get(int param1Int) {
          return CTBarSerImpl.this.getDPtArray(param1Int);
        }
        
        public CTDPt set(int param1Int, CTDPt param1CTDPt) {
          CTDPt cTDPt = CTBarSerImpl.this.getDPtArray(param1Int);
          CTBarSerImpl.this.setDPtArray(param1Int, param1CTDPt);
          return cTDPt;
        }
        
        public void add(int param1Int, CTDPt param1CTDPt) {
          CTBarSerImpl.this.insertNewDPt(param1Int).set((XmlObject)param1CTDPt);
        }
        
        public CTDPt remove(int param1Int) {
          CTDPt cTDPt = CTBarSerImpl.this.getDPtArray(param1Int);
          CTBarSerImpl.this.removeDPt(param1Int);
          return cTDPt;
        }
        
        public int size() {
          return CTBarSerImpl.this.sizeOfDPtArray();
        }
      };
      return new DPtList();
    } 
  }
  
  @Deprecated
  public CTDPt[] getDPtArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(DPT$12, arrayList);
      CTDPt[] arrayOfCTDPt = new CTDPt[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTDPt);
      return arrayOfCTDPt;
    } 
  }
  
  public CTDPt getDPtArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDPt cTDPt = null;
      cTDPt = (CTDPt)get_store().find_element_user(DPT$12, paramInt);
      if (cTDPt == null)
        throw new IndexOutOfBoundsException(); 
      return cTDPt;
    } 
  }
  
  public int sizeOfDPtArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(DPT$12);
    } 
  }
  
  public void setDPtArray(CTDPt[] paramArrayOfCTDPt) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTDPt, DPT$12);
  }
  
  public void setDPtArray(int paramInt, CTDPt paramCTDPt) {
    generatedSetterHelperImpl((XmlObject)paramCTDPt, DPT$12, paramInt, (short)2);
  }
  
  public CTDPt insertNewDPt(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDPt cTDPt = null;
      cTDPt = (CTDPt)get_store().insert_element_user(DPT$12, paramInt);
      return cTDPt;
    } 
  }
  
  public CTDPt addNewDPt() {
    synchronized (monitor()) {
      check_orphaned();
      CTDPt cTDPt = null;
      cTDPt = (CTDPt)get_store().add_element_user(DPT$12);
      return cTDPt;
    } 
  }
  
  public void removeDPt(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DPT$12, paramInt);
    } 
  }
  
  public CTDLbls getDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().find_element_user(DLBLS$14, 0);
      if (cTDLbls == null)
        return null; 
      return cTDLbls;
    } 
  }
  
  public boolean isSetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DLBLS$14) != 0);
    } 
  }
  
  public void setDLbls(CTDLbls paramCTDLbls) {
    generatedSetterHelperImpl((XmlObject)paramCTDLbls, DLBLS$14, 0, (short)1);
  }
  
  public CTDLbls addNewDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().add_element_user(DLBLS$14);
      return cTDLbls;
    } 
  }
  
  public void unsetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DLBLS$14, 0);
    } 
  }
  
  public List<CTTrendline> getTrendlineList() {
    synchronized (monitor()) {
      check_orphaned();
      final class TrendlineList extends AbstractList<CTTrendline> {
        public CTTrendline get(int param1Int) {
          return CTBarSerImpl.this.getTrendlineArray(param1Int);
        }
        
        public CTTrendline set(int param1Int, CTTrendline param1CTTrendline) {
          CTTrendline cTTrendline = CTBarSerImpl.this.getTrendlineArray(param1Int);
          CTBarSerImpl.this.setTrendlineArray(param1Int, param1CTTrendline);
          return cTTrendline;
        }
        
        public void add(int param1Int, CTTrendline param1CTTrendline) {
          CTBarSerImpl.this.insertNewTrendline(param1Int).set((XmlObject)param1CTTrendline);
        }
        
        public CTTrendline remove(int param1Int) {
          CTTrendline cTTrendline = CTBarSerImpl.this.getTrendlineArray(param1Int);
          CTBarSerImpl.this.removeTrendline(param1Int);
          return cTTrendline;
        }
        
        public int size() {
          return CTBarSerImpl.this.sizeOfTrendlineArray();
        }
      };
      return new TrendlineList();
    } 
  }
  
  @Deprecated
  public CTTrendline[] getTrendlineArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(TRENDLINE$16, arrayList);
      CTTrendline[] arrayOfCTTrendline = new CTTrendline[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTTrendline);
      return arrayOfCTTrendline;
    } 
  }
  
  public CTTrendline getTrendlineArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTTrendline cTTrendline = null;
      cTTrendline = (CTTrendline)get_store().find_element_user(TRENDLINE$16, paramInt);
      if (cTTrendline == null)
        throw new IndexOutOfBoundsException(); 
      return cTTrendline;
    } 
  }
  
  public int sizeOfTrendlineArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(TRENDLINE$16);
    } 
  }
  
  public void setTrendlineArray(CTTrendline[] paramArrayOfCTTrendline) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTTrendline, TRENDLINE$16);
  }
  
  public void setTrendlineArray(int paramInt, CTTrendline paramCTTrendline) {
    generatedSetterHelperImpl((XmlObject)paramCTTrendline, TRENDLINE$16, paramInt, (short)2);
  }
  
  public CTTrendline insertNewTrendline(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTTrendline cTTrendline = null;
      cTTrendline = (CTTrendline)get_store().insert_element_user(TRENDLINE$16, paramInt);
      return cTTrendline;
    } 
  }
  
  public CTTrendline addNewTrendline() {
    synchronized (monitor()) {
      check_orphaned();
      CTTrendline cTTrendline = null;
      cTTrendline = (CTTrendline)get_store().add_element_user(TRENDLINE$16);
      return cTTrendline;
    } 
  }
  
  public void removeTrendline(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TRENDLINE$16, paramInt);
    } 
  }
  
  public CTErrBars getErrBars() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrBars cTErrBars = null;
      cTErrBars = (CTErrBars)get_store().find_element_user(ERRBARS$18, 0);
      if (cTErrBars == null)
        return null; 
      return cTErrBars;
    } 
  }
  
  public boolean isSetErrBars() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(ERRBARS$18) != 0);
    } 
  }
  
  public void setErrBars(CTErrBars paramCTErrBars) {
    generatedSetterHelperImpl((XmlObject)paramCTErrBars, ERRBARS$18, 0, (short)1);
  }
  
  public CTErrBars addNewErrBars() {
    synchronized (monitor()) {
      check_orphaned();
      CTErrBars cTErrBars = null;
      cTErrBars = (CTErrBars)get_store().add_element_user(ERRBARS$18);
      return cTErrBars;
    } 
  }
  
  public void unsetErrBars() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ERRBARS$18, 0);
    } 
  }
  
  public CTAxDataSource getCat() {
    synchronized (monitor()) {
      check_orphaned();
      CTAxDataSource cTAxDataSource = null;
      cTAxDataSource = (CTAxDataSource)get_store().find_element_user(CAT$20, 0);
      if (cTAxDataSource == null)
        return null; 
      return cTAxDataSource;
    } 
  }
  
  public boolean isSetCat() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CAT$20) != 0);
    } 
  }
  
  public void setCat(CTAxDataSource paramCTAxDataSource) {
    generatedSetterHelperImpl((XmlObject)paramCTAxDataSource, CAT$20, 0, (short)1);
  }
  
  public CTAxDataSource addNewCat() {
    synchronized (monitor()) {
      check_orphaned();
      CTAxDataSource cTAxDataSource = null;
      cTAxDataSource = (CTAxDataSource)get_store().add_element_user(CAT$20);
      return cTAxDataSource;
    } 
  }
  
  public void unsetCat() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CAT$20, 0);
    } 
  }
  
  public CTNumDataSource getVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().find_element_user(VAL$22, 0);
      if (cTNumDataSource == null)
        return null; 
      return cTNumDataSource;
    } 
  }
  
  public boolean isSetVal() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(VAL$22) != 0);
    } 
  }
  
  public void setVal(CTNumDataSource paramCTNumDataSource) {
    generatedSetterHelperImpl((XmlObject)paramCTNumDataSource, VAL$22, 0, (short)1);
  }
  
  public CTNumDataSource addNewVal() {
    synchronized (monitor()) {
      check_orphaned();
      CTNumDataSource cTNumDataSource = null;
      cTNumDataSource = (CTNumDataSource)get_store().add_element_user(VAL$22);
      return cTNumDataSource;
    } 
  }
  
  public void unsetVal() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(VAL$22, 0);
    } 
  }
  
  public CTShape getShape() {
    synchronized (monitor()) {
      check_orphaned();
      CTShape cTShape = null;
      cTShape = (CTShape)get_store().find_element_user(SHAPE$24, 0);
      if (cTShape == null)
        return null; 
      return cTShape;
    } 
  }
  
  public boolean isSetShape() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SHAPE$24) != 0);
    } 
  }
  
  public void setShape(CTShape paramCTShape) {
    generatedSetterHelperImpl((XmlObject)paramCTShape, SHAPE$24, 0, (short)1);
  }
  
  public CTShape addNewShape() {
    synchronized (monitor()) {
      check_orphaned();
      CTShape cTShape = null;
      cTShape = (CTShape)get_store().add_element_user(SHAPE$24);
      return cTShape;
    } 
  }
  
  public void unsetShape() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SHAPE$24, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$26, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$26) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$26, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$26);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$26, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTBarSerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */