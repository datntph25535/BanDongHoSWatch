package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.StringEnumAbstractBase;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlToken;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaBiLevelEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaCeilingEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaFloorEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaInverseEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaModulateEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaModulateFixedEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaOutsetEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAlphaReplaceEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTBiLevelEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTBlendEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTBlurEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTColorChangeEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTColorReplaceEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTDuotoneEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTEffectContainer;
import org.openxmlformats.schemas.drawingml.x2006.main.CTEffectReference;
import org.openxmlformats.schemas.drawingml.x2006.main.CTFillEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTFillOverlayEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTGlowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTGrayscaleEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTHSLEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTInnerShadowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTLuminanceEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTOuterShadowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPresetShadowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTReflectionEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTRelativeOffsetEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTSoftEdgesEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTintEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTransformEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.STEffectContainerType;

public class CTEffectContainerImpl extends XmlComplexContentImpl implements CTEffectContainer {
  private static final long serialVersionUID = 1L;
  
  private static final QName CONT$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "cont");
  
  private static final QName EFFECT$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "effect");
  
  private static final QName ALPHABILEVEL$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaBiLevel");
  
  private static final QName ALPHACEILING$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaCeiling");
  
  private static final QName ALPHAFLOOR$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaFloor");
  
  private static final QName ALPHAINV$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaInv");
  
  private static final QName ALPHAMOD$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaMod");
  
  private static final QName ALPHAMODFIX$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaModFix");
  
  private static final QName ALPHAOUTSET$16 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaOutset");
  
  private static final QName ALPHAREPL$18 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "alphaRepl");
  
  private static final QName BILEVEL$20 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "biLevel");
  
  private static final QName BLEND$22 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "blend");
  
  private static final QName BLUR$24 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "blur");
  
  private static final QName CLRCHANGE$26 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "clrChange");
  
  private static final QName CLRREPL$28 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "clrRepl");
  
  private static final QName DUOTONE$30 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "duotone");
  
  private static final QName FILL$32 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "fill");
  
  private static final QName FILLOVERLAY$34 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "fillOverlay");
  
  private static final QName GLOW$36 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "glow");
  
  private static final QName GRAYSCL$38 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "grayscl");
  
  private static final QName HSL$40 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "hsl");
  
  private static final QName INNERSHDW$42 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "innerShdw");
  
  private static final QName LUM$44 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "lum");
  
  private static final QName OUTERSHDW$46 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "outerShdw");
  
  private static final QName PRSTSHDW$48 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "prstShdw");
  
  private static final QName REFLECTION$50 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "reflection");
  
  private static final QName RELOFF$52 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "relOff");
  
  private static final QName SOFTEDGE$54 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "softEdge");
  
  private static final QName TINT$56 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "tint");
  
  private static final QName XFRM$58 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "xfrm");
  
  private static final QName TYPE$60 = new QName("", "type");
  
  private static final QName NAME$62 = new QName("", "name");
  
  public CTEffectContainerImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTEffectContainer> getContList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ContList extends AbstractList<CTEffectContainer> {
        public CTEffectContainer get(int param1Int) {
          return CTEffectContainerImpl.this.getContArray(param1Int);
        }
        
        public CTEffectContainer set(int param1Int, CTEffectContainer param1CTEffectContainer) {
          CTEffectContainer cTEffectContainer = CTEffectContainerImpl.this.getContArray(param1Int);
          CTEffectContainerImpl.this.setContArray(param1Int, param1CTEffectContainer);
          return cTEffectContainer;
        }
        
        public void add(int param1Int, CTEffectContainer param1CTEffectContainer) {
          CTEffectContainerImpl.this.insertNewCont(param1Int).set((XmlObject)param1CTEffectContainer);
        }
        
        public CTEffectContainer remove(int param1Int) {
          CTEffectContainer cTEffectContainer = CTEffectContainerImpl.this.getContArray(param1Int);
          CTEffectContainerImpl.this.removeCont(param1Int);
          return cTEffectContainer;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfContArray();
        }
      };
      return new ContList();
    } 
  }
  
  @Deprecated
  public CTEffectContainer[] getContArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CONT$0, arrayList);
      CTEffectContainer[] arrayOfCTEffectContainer = new CTEffectContainer[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTEffectContainer);
      return arrayOfCTEffectContainer;
    } 
  }
  
  public CTEffectContainer getContArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectContainer cTEffectContainer = null;
      cTEffectContainer = (CTEffectContainer)get_store().find_element_user(CONT$0, paramInt);
      if (cTEffectContainer == null)
        throw new IndexOutOfBoundsException(); 
      return cTEffectContainer;
    } 
  }
  
  public int sizeOfContArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CONT$0);
    } 
  }
  
  public void setContArray(CTEffectContainer[] paramArrayOfCTEffectContainer) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTEffectContainer, CONT$0);
  }
  
  public void setContArray(int paramInt, CTEffectContainer paramCTEffectContainer) {
    generatedSetterHelperImpl((XmlObject)paramCTEffectContainer, CONT$0, paramInt, (short)2);
  }
  
  public CTEffectContainer insertNewCont(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectContainer cTEffectContainer = null;
      cTEffectContainer = (CTEffectContainer)get_store().insert_element_user(CONT$0, paramInt);
      return cTEffectContainer;
    } 
  }
  
  public CTEffectContainer addNewCont() {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectContainer cTEffectContainer = null;
      cTEffectContainer = (CTEffectContainer)get_store().add_element_user(CONT$0);
      return cTEffectContainer;
    } 
  }
  
  public void removeCont(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CONT$0, paramInt);
    } 
  }
  
  public List<CTEffectReference> getEffectList() {
    synchronized (monitor()) {
      check_orphaned();
      final class EffectList extends AbstractList<CTEffectReference> {
        public CTEffectReference get(int param1Int) {
          return CTEffectContainerImpl.this.getEffectArray(param1Int);
        }
        
        public CTEffectReference set(int param1Int, CTEffectReference param1CTEffectReference) {
          CTEffectReference cTEffectReference = CTEffectContainerImpl.this.getEffectArray(param1Int);
          CTEffectContainerImpl.this.setEffectArray(param1Int, param1CTEffectReference);
          return cTEffectReference;
        }
        
        public void add(int param1Int, CTEffectReference param1CTEffectReference) {
          CTEffectContainerImpl.this.insertNewEffect(param1Int).set((XmlObject)param1CTEffectReference);
        }
        
        public CTEffectReference remove(int param1Int) {
          CTEffectReference cTEffectReference = CTEffectContainerImpl.this.getEffectArray(param1Int);
          CTEffectContainerImpl.this.removeEffect(param1Int);
          return cTEffectReference;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfEffectArray();
        }
      };
      return new EffectList();
    } 
  }
  
  @Deprecated
  public CTEffectReference[] getEffectArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(EFFECT$2, arrayList);
      CTEffectReference[] arrayOfCTEffectReference = new CTEffectReference[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTEffectReference);
      return arrayOfCTEffectReference;
    } 
  }
  
  public CTEffectReference getEffectArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectReference cTEffectReference = null;
      cTEffectReference = (CTEffectReference)get_store().find_element_user(EFFECT$2, paramInt);
      if (cTEffectReference == null)
        throw new IndexOutOfBoundsException(); 
      return cTEffectReference;
    } 
  }
  
  public int sizeOfEffectArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(EFFECT$2);
    } 
  }
  
  public void setEffectArray(CTEffectReference[] paramArrayOfCTEffectReference) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTEffectReference, EFFECT$2);
  }
  
  public void setEffectArray(int paramInt, CTEffectReference paramCTEffectReference) {
    generatedSetterHelperImpl((XmlObject)paramCTEffectReference, EFFECT$2, paramInt, (short)2);
  }
  
  public CTEffectReference insertNewEffect(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectReference cTEffectReference = null;
      cTEffectReference = (CTEffectReference)get_store().insert_element_user(EFFECT$2, paramInt);
      return cTEffectReference;
    } 
  }
  
  public CTEffectReference addNewEffect() {
    synchronized (monitor()) {
      check_orphaned();
      CTEffectReference cTEffectReference = null;
      cTEffectReference = (CTEffectReference)get_store().add_element_user(EFFECT$2);
      return cTEffectReference;
    } 
  }
  
  public void removeEffect(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EFFECT$2, paramInt);
    } 
  }
  
  public List<CTAlphaBiLevelEffect> getAlphaBiLevelList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaBiLevelList extends AbstractList<CTAlphaBiLevelEffect> {
        public CTAlphaBiLevelEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaBiLevelArray(param1Int);
        }
        
        public CTAlphaBiLevelEffect set(int param1Int, CTAlphaBiLevelEffect param1CTAlphaBiLevelEffect) {
          CTAlphaBiLevelEffect cTAlphaBiLevelEffect = CTEffectContainerImpl.this.getAlphaBiLevelArray(param1Int);
          CTEffectContainerImpl.this.setAlphaBiLevelArray(param1Int, param1CTAlphaBiLevelEffect);
          return cTAlphaBiLevelEffect;
        }
        
        public void add(int param1Int, CTAlphaBiLevelEffect param1CTAlphaBiLevelEffect) {
          CTEffectContainerImpl.this.insertNewAlphaBiLevel(param1Int).set((XmlObject)param1CTAlphaBiLevelEffect);
        }
        
        public CTAlphaBiLevelEffect remove(int param1Int) {
          CTAlphaBiLevelEffect cTAlphaBiLevelEffect = CTEffectContainerImpl.this.getAlphaBiLevelArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaBiLevel(param1Int);
          return cTAlphaBiLevelEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaBiLevelArray();
        }
      };
      return new AlphaBiLevelList();
    } 
  }
  
  @Deprecated
  public CTAlphaBiLevelEffect[] getAlphaBiLevelArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHABILEVEL$4, arrayList);
      CTAlphaBiLevelEffect[] arrayOfCTAlphaBiLevelEffect = new CTAlphaBiLevelEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaBiLevelEffect);
      return arrayOfCTAlphaBiLevelEffect;
    } 
  }
  
  public CTAlphaBiLevelEffect getAlphaBiLevelArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaBiLevelEffect cTAlphaBiLevelEffect = null;
      cTAlphaBiLevelEffect = (CTAlphaBiLevelEffect)get_store().find_element_user(ALPHABILEVEL$4, paramInt);
      if (cTAlphaBiLevelEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaBiLevelEffect;
    } 
  }
  
  public int sizeOfAlphaBiLevelArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHABILEVEL$4);
    } 
  }
  
  public void setAlphaBiLevelArray(CTAlphaBiLevelEffect[] paramArrayOfCTAlphaBiLevelEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaBiLevelEffect, ALPHABILEVEL$4);
  }
  
  public void setAlphaBiLevelArray(int paramInt, CTAlphaBiLevelEffect paramCTAlphaBiLevelEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaBiLevelEffect, ALPHABILEVEL$4, paramInt, (short)2);
  }
  
  public CTAlphaBiLevelEffect insertNewAlphaBiLevel(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaBiLevelEffect cTAlphaBiLevelEffect = null;
      cTAlphaBiLevelEffect = (CTAlphaBiLevelEffect)get_store().insert_element_user(ALPHABILEVEL$4, paramInt);
      return cTAlphaBiLevelEffect;
    } 
  }
  
  public CTAlphaBiLevelEffect addNewAlphaBiLevel() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaBiLevelEffect cTAlphaBiLevelEffect = null;
      cTAlphaBiLevelEffect = (CTAlphaBiLevelEffect)get_store().add_element_user(ALPHABILEVEL$4);
      return cTAlphaBiLevelEffect;
    } 
  }
  
  public void removeAlphaBiLevel(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHABILEVEL$4, paramInt);
    } 
  }
  
  public List<CTAlphaCeilingEffect> getAlphaCeilingList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaCeilingList extends AbstractList<CTAlphaCeilingEffect> {
        public CTAlphaCeilingEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaCeilingArray(param1Int);
        }
        
        public CTAlphaCeilingEffect set(int param1Int, CTAlphaCeilingEffect param1CTAlphaCeilingEffect) {
          CTAlphaCeilingEffect cTAlphaCeilingEffect = CTEffectContainerImpl.this.getAlphaCeilingArray(param1Int);
          CTEffectContainerImpl.this.setAlphaCeilingArray(param1Int, param1CTAlphaCeilingEffect);
          return cTAlphaCeilingEffect;
        }
        
        public void add(int param1Int, CTAlphaCeilingEffect param1CTAlphaCeilingEffect) {
          CTEffectContainerImpl.this.insertNewAlphaCeiling(param1Int).set((XmlObject)param1CTAlphaCeilingEffect);
        }
        
        public CTAlphaCeilingEffect remove(int param1Int) {
          CTAlphaCeilingEffect cTAlphaCeilingEffect = CTEffectContainerImpl.this.getAlphaCeilingArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaCeiling(param1Int);
          return cTAlphaCeilingEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaCeilingArray();
        }
      };
      return new AlphaCeilingList();
    } 
  }
  
  @Deprecated
  public CTAlphaCeilingEffect[] getAlphaCeilingArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHACEILING$6, arrayList);
      CTAlphaCeilingEffect[] arrayOfCTAlphaCeilingEffect = new CTAlphaCeilingEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaCeilingEffect);
      return arrayOfCTAlphaCeilingEffect;
    } 
  }
  
  public CTAlphaCeilingEffect getAlphaCeilingArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaCeilingEffect cTAlphaCeilingEffect = null;
      cTAlphaCeilingEffect = (CTAlphaCeilingEffect)get_store().find_element_user(ALPHACEILING$6, paramInt);
      if (cTAlphaCeilingEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaCeilingEffect;
    } 
  }
  
  public int sizeOfAlphaCeilingArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHACEILING$6);
    } 
  }
  
  public void setAlphaCeilingArray(CTAlphaCeilingEffect[] paramArrayOfCTAlphaCeilingEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaCeilingEffect, ALPHACEILING$6);
  }
  
  public void setAlphaCeilingArray(int paramInt, CTAlphaCeilingEffect paramCTAlphaCeilingEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaCeilingEffect, ALPHACEILING$6, paramInt, (short)2);
  }
  
  public CTAlphaCeilingEffect insertNewAlphaCeiling(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaCeilingEffect cTAlphaCeilingEffect = null;
      cTAlphaCeilingEffect = (CTAlphaCeilingEffect)get_store().insert_element_user(ALPHACEILING$6, paramInt);
      return cTAlphaCeilingEffect;
    } 
  }
  
  public CTAlphaCeilingEffect addNewAlphaCeiling() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaCeilingEffect cTAlphaCeilingEffect = null;
      cTAlphaCeilingEffect = (CTAlphaCeilingEffect)get_store().add_element_user(ALPHACEILING$6);
      return cTAlphaCeilingEffect;
    } 
  }
  
  public void removeAlphaCeiling(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHACEILING$6, paramInt);
    } 
  }
  
  public List<CTAlphaFloorEffect> getAlphaFloorList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaFloorList extends AbstractList<CTAlphaFloorEffect> {
        public CTAlphaFloorEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaFloorArray(param1Int);
        }
        
        public CTAlphaFloorEffect set(int param1Int, CTAlphaFloorEffect param1CTAlphaFloorEffect) {
          CTAlphaFloorEffect cTAlphaFloorEffect = CTEffectContainerImpl.this.getAlphaFloorArray(param1Int);
          CTEffectContainerImpl.this.setAlphaFloorArray(param1Int, param1CTAlphaFloorEffect);
          return cTAlphaFloorEffect;
        }
        
        public void add(int param1Int, CTAlphaFloorEffect param1CTAlphaFloorEffect) {
          CTEffectContainerImpl.this.insertNewAlphaFloor(param1Int).set((XmlObject)param1CTAlphaFloorEffect);
        }
        
        public CTAlphaFloorEffect remove(int param1Int) {
          CTAlphaFloorEffect cTAlphaFloorEffect = CTEffectContainerImpl.this.getAlphaFloorArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaFloor(param1Int);
          return cTAlphaFloorEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaFloorArray();
        }
      };
      return new AlphaFloorList();
    } 
  }
  
  @Deprecated
  public CTAlphaFloorEffect[] getAlphaFloorArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHAFLOOR$8, arrayList);
      CTAlphaFloorEffect[] arrayOfCTAlphaFloorEffect = new CTAlphaFloorEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaFloorEffect);
      return arrayOfCTAlphaFloorEffect;
    } 
  }
  
  public CTAlphaFloorEffect getAlphaFloorArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaFloorEffect cTAlphaFloorEffect = null;
      cTAlphaFloorEffect = (CTAlphaFloorEffect)get_store().find_element_user(ALPHAFLOOR$8, paramInt);
      if (cTAlphaFloorEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaFloorEffect;
    } 
  }
  
  public int sizeOfAlphaFloorArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHAFLOOR$8);
    } 
  }
  
  public void setAlphaFloorArray(CTAlphaFloorEffect[] paramArrayOfCTAlphaFloorEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaFloorEffect, ALPHAFLOOR$8);
  }
  
  public void setAlphaFloorArray(int paramInt, CTAlphaFloorEffect paramCTAlphaFloorEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaFloorEffect, ALPHAFLOOR$8, paramInt, (short)2);
  }
  
  public CTAlphaFloorEffect insertNewAlphaFloor(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaFloorEffect cTAlphaFloorEffect = null;
      cTAlphaFloorEffect = (CTAlphaFloorEffect)get_store().insert_element_user(ALPHAFLOOR$8, paramInt);
      return cTAlphaFloorEffect;
    } 
  }
  
  public CTAlphaFloorEffect addNewAlphaFloor() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaFloorEffect cTAlphaFloorEffect = null;
      cTAlphaFloorEffect = (CTAlphaFloorEffect)get_store().add_element_user(ALPHAFLOOR$8);
      return cTAlphaFloorEffect;
    } 
  }
  
  public void removeAlphaFloor(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHAFLOOR$8, paramInt);
    } 
  }
  
  public List<CTAlphaInverseEffect> getAlphaInvList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaInvList extends AbstractList<CTAlphaInverseEffect> {
        public CTAlphaInverseEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaInvArray(param1Int);
        }
        
        public CTAlphaInverseEffect set(int param1Int, CTAlphaInverseEffect param1CTAlphaInverseEffect) {
          CTAlphaInverseEffect cTAlphaInverseEffect = CTEffectContainerImpl.this.getAlphaInvArray(param1Int);
          CTEffectContainerImpl.this.setAlphaInvArray(param1Int, param1CTAlphaInverseEffect);
          return cTAlphaInverseEffect;
        }
        
        public void add(int param1Int, CTAlphaInverseEffect param1CTAlphaInverseEffect) {
          CTEffectContainerImpl.this.insertNewAlphaInv(param1Int).set((XmlObject)param1CTAlphaInverseEffect);
        }
        
        public CTAlphaInverseEffect remove(int param1Int) {
          CTAlphaInverseEffect cTAlphaInverseEffect = CTEffectContainerImpl.this.getAlphaInvArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaInv(param1Int);
          return cTAlphaInverseEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaInvArray();
        }
      };
      return new AlphaInvList();
    } 
  }
  
  @Deprecated
  public CTAlphaInverseEffect[] getAlphaInvArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHAINV$10, arrayList);
      CTAlphaInverseEffect[] arrayOfCTAlphaInverseEffect = new CTAlphaInverseEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaInverseEffect);
      return arrayOfCTAlphaInverseEffect;
    } 
  }
  
  public CTAlphaInverseEffect getAlphaInvArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaInverseEffect cTAlphaInverseEffect = null;
      cTAlphaInverseEffect = (CTAlphaInverseEffect)get_store().find_element_user(ALPHAINV$10, paramInt);
      if (cTAlphaInverseEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaInverseEffect;
    } 
  }
  
  public int sizeOfAlphaInvArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHAINV$10);
    } 
  }
  
  public void setAlphaInvArray(CTAlphaInverseEffect[] paramArrayOfCTAlphaInverseEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaInverseEffect, ALPHAINV$10);
  }
  
  public void setAlphaInvArray(int paramInt, CTAlphaInverseEffect paramCTAlphaInverseEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaInverseEffect, ALPHAINV$10, paramInt, (short)2);
  }
  
  public CTAlphaInverseEffect insertNewAlphaInv(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaInverseEffect cTAlphaInverseEffect = null;
      cTAlphaInverseEffect = (CTAlphaInverseEffect)get_store().insert_element_user(ALPHAINV$10, paramInt);
      return cTAlphaInverseEffect;
    } 
  }
  
  public CTAlphaInverseEffect addNewAlphaInv() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaInverseEffect cTAlphaInverseEffect = null;
      cTAlphaInverseEffect = (CTAlphaInverseEffect)get_store().add_element_user(ALPHAINV$10);
      return cTAlphaInverseEffect;
    } 
  }
  
  public void removeAlphaInv(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHAINV$10, paramInt);
    } 
  }
  
  public List<CTAlphaModulateEffect> getAlphaModList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaModList extends AbstractList<CTAlphaModulateEffect> {
        public CTAlphaModulateEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaModArray(param1Int);
        }
        
        public CTAlphaModulateEffect set(int param1Int, CTAlphaModulateEffect param1CTAlphaModulateEffect) {
          CTAlphaModulateEffect cTAlphaModulateEffect = CTEffectContainerImpl.this.getAlphaModArray(param1Int);
          CTEffectContainerImpl.this.setAlphaModArray(param1Int, param1CTAlphaModulateEffect);
          return cTAlphaModulateEffect;
        }
        
        public void add(int param1Int, CTAlphaModulateEffect param1CTAlphaModulateEffect) {
          CTEffectContainerImpl.this.insertNewAlphaMod(param1Int).set((XmlObject)param1CTAlphaModulateEffect);
        }
        
        public CTAlphaModulateEffect remove(int param1Int) {
          CTAlphaModulateEffect cTAlphaModulateEffect = CTEffectContainerImpl.this.getAlphaModArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaMod(param1Int);
          return cTAlphaModulateEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaModArray();
        }
      };
      return new AlphaModList();
    } 
  }
  
  @Deprecated
  public CTAlphaModulateEffect[] getAlphaModArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHAMOD$12, arrayList);
      CTAlphaModulateEffect[] arrayOfCTAlphaModulateEffect = new CTAlphaModulateEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaModulateEffect);
      return arrayOfCTAlphaModulateEffect;
    } 
  }
  
  public CTAlphaModulateEffect getAlphaModArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaModulateEffect cTAlphaModulateEffect = null;
      cTAlphaModulateEffect = (CTAlphaModulateEffect)get_store().find_element_user(ALPHAMOD$12, paramInt);
      if (cTAlphaModulateEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaModulateEffect;
    } 
  }
  
  public int sizeOfAlphaModArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHAMOD$12);
    } 
  }
  
  public void setAlphaModArray(CTAlphaModulateEffect[] paramArrayOfCTAlphaModulateEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaModulateEffect, ALPHAMOD$12);
  }
  
  public void setAlphaModArray(int paramInt, CTAlphaModulateEffect paramCTAlphaModulateEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaModulateEffect, ALPHAMOD$12, paramInt, (short)2);
  }
  
  public CTAlphaModulateEffect insertNewAlphaMod(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaModulateEffect cTAlphaModulateEffect = null;
      cTAlphaModulateEffect = (CTAlphaModulateEffect)get_store().insert_element_user(ALPHAMOD$12, paramInt);
      return cTAlphaModulateEffect;
    } 
  }
  
  public CTAlphaModulateEffect addNewAlphaMod() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaModulateEffect cTAlphaModulateEffect = null;
      cTAlphaModulateEffect = (CTAlphaModulateEffect)get_store().add_element_user(ALPHAMOD$12);
      return cTAlphaModulateEffect;
    } 
  }
  
  public void removeAlphaMod(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHAMOD$12, paramInt);
    } 
  }
  
  public List<CTAlphaModulateFixedEffect> getAlphaModFixList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaModFixList extends AbstractList<CTAlphaModulateFixedEffect> {
        public CTAlphaModulateFixedEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaModFixArray(param1Int);
        }
        
        public CTAlphaModulateFixedEffect set(int param1Int, CTAlphaModulateFixedEffect param1CTAlphaModulateFixedEffect) {
          CTAlphaModulateFixedEffect cTAlphaModulateFixedEffect = CTEffectContainerImpl.this.getAlphaModFixArray(param1Int);
          CTEffectContainerImpl.this.setAlphaModFixArray(param1Int, param1CTAlphaModulateFixedEffect);
          return cTAlphaModulateFixedEffect;
        }
        
        public void add(int param1Int, CTAlphaModulateFixedEffect param1CTAlphaModulateFixedEffect) {
          CTEffectContainerImpl.this.insertNewAlphaModFix(param1Int).set((XmlObject)param1CTAlphaModulateFixedEffect);
        }
        
        public CTAlphaModulateFixedEffect remove(int param1Int) {
          CTAlphaModulateFixedEffect cTAlphaModulateFixedEffect = CTEffectContainerImpl.this.getAlphaModFixArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaModFix(param1Int);
          return cTAlphaModulateFixedEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaModFixArray();
        }
      };
      return new AlphaModFixList();
    } 
  }
  
  @Deprecated
  public CTAlphaModulateFixedEffect[] getAlphaModFixArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHAMODFIX$14, arrayList);
      CTAlphaModulateFixedEffect[] arrayOfCTAlphaModulateFixedEffect = new CTAlphaModulateFixedEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaModulateFixedEffect);
      return arrayOfCTAlphaModulateFixedEffect;
    } 
  }
  
  public CTAlphaModulateFixedEffect getAlphaModFixArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaModulateFixedEffect cTAlphaModulateFixedEffect = null;
      cTAlphaModulateFixedEffect = (CTAlphaModulateFixedEffect)get_store().find_element_user(ALPHAMODFIX$14, paramInt);
      if (cTAlphaModulateFixedEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaModulateFixedEffect;
    } 
  }
  
  public int sizeOfAlphaModFixArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHAMODFIX$14);
    } 
  }
  
  public void setAlphaModFixArray(CTAlphaModulateFixedEffect[] paramArrayOfCTAlphaModulateFixedEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaModulateFixedEffect, ALPHAMODFIX$14);
  }
  
  public void setAlphaModFixArray(int paramInt, CTAlphaModulateFixedEffect paramCTAlphaModulateFixedEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaModulateFixedEffect, ALPHAMODFIX$14, paramInt, (short)2);
  }
  
  public CTAlphaModulateFixedEffect insertNewAlphaModFix(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaModulateFixedEffect cTAlphaModulateFixedEffect = null;
      cTAlphaModulateFixedEffect = (CTAlphaModulateFixedEffect)get_store().insert_element_user(ALPHAMODFIX$14, paramInt);
      return cTAlphaModulateFixedEffect;
    } 
  }
  
  public CTAlphaModulateFixedEffect addNewAlphaModFix() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaModulateFixedEffect cTAlphaModulateFixedEffect = null;
      cTAlphaModulateFixedEffect = (CTAlphaModulateFixedEffect)get_store().add_element_user(ALPHAMODFIX$14);
      return cTAlphaModulateFixedEffect;
    } 
  }
  
  public void removeAlphaModFix(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHAMODFIX$14, paramInt);
    } 
  }
  
  public List<CTAlphaOutsetEffect> getAlphaOutsetList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaOutsetList extends AbstractList<CTAlphaOutsetEffect> {
        public CTAlphaOutsetEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaOutsetArray(param1Int);
        }
        
        public CTAlphaOutsetEffect set(int param1Int, CTAlphaOutsetEffect param1CTAlphaOutsetEffect) {
          CTAlphaOutsetEffect cTAlphaOutsetEffect = CTEffectContainerImpl.this.getAlphaOutsetArray(param1Int);
          CTEffectContainerImpl.this.setAlphaOutsetArray(param1Int, param1CTAlphaOutsetEffect);
          return cTAlphaOutsetEffect;
        }
        
        public void add(int param1Int, CTAlphaOutsetEffect param1CTAlphaOutsetEffect) {
          CTEffectContainerImpl.this.insertNewAlphaOutset(param1Int).set((XmlObject)param1CTAlphaOutsetEffect);
        }
        
        public CTAlphaOutsetEffect remove(int param1Int) {
          CTAlphaOutsetEffect cTAlphaOutsetEffect = CTEffectContainerImpl.this.getAlphaOutsetArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaOutset(param1Int);
          return cTAlphaOutsetEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaOutsetArray();
        }
      };
      return new AlphaOutsetList();
    } 
  }
  
  @Deprecated
  public CTAlphaOutsetEffect[] getAlphaOutsetArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHAOUTSET$16, arrayList);
      CTAlphaOutsetEffect[] arrayOfCTAlphaOutsetEffect = new CTAlphaOutsetEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaOutsetEffect);
      return arrayOfCTAlphaOutsetEffect;
    } 
  }
  
  public CTAlphaOutsetEffect getAlphaOutsetArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaOutsetEffect cTAlphaOutsetEffect = null;
      cTAlphaOutsetEffect = (CTAlphaOutsetEffect)get_store().find_element_user(ALPHAOUTSET$16, paramInt);
      if (cTAlphaOutsetEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaOutsetEffect;
    } 
  }
  
  public int sizeOfAlphaOutsetArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHAOUTSET$16);
    } 
  }
  
  public void setAlphaOutsetArray(CTAlphaOutsetEffect[] paramArrayOfCTAlphaOutsetEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaOutsetEffect, ALPHAOUTSET$16);
  }
  
  public void setAlphaOutsetArray(int paramInt, CTAlphaOutsetEffect paramCTAlphaOutsetEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaOutsetEffect, ALPHAOUTSET$16, paramInt, (short)2);
  }
  
  public CTAlphaOutsetEffect insertNewAlphaOutset(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaOutsetEffect cTAlphaOutsetEffect = null;
      cTAlphaOutsetEffect = (CTAlphaOutsetEffect)get_store().insert_element_user(ALPHAOUTSET$16, paramInt);
      return cTAlphaOutsetEffect;
    } 
  }
  
  public CTAlphaOutsetEffect addNewAlphaOutset() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaOutsetEffect cTAlphaOutsetEffect = null;
      cTAlphaOutsetEffect = (CTAlphaOutsetEffect)get_store().add_element_user(ALPHAOUTSET$16);
      return cTAlphaOutsetEffect;
    } 
  }
  
  public void removeAlphaOutset(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHAOUTSET$16, paramInt);
    } 
  }
  
  public List<CTAlphaReplaceEffect> getAlphaReplList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AlphaReplList extends AbstractList<CTAlphaReplaceEffect> {
        public CTAlphaReplaceEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getAlphaReplArray(param1Int);
        }
        
        public CTAlphaReplaceEffect set(int param1Int, CTAlphaReplaceEffect param1CTAlphaReplaceEffect) {
          CTAlphaReplaceEffect cTAlphaReplaceEffect = CTEffectContainerImpl.this.getAlphaReplArray(param1Int);
          CTEffectContainerImpl.this.setAlphaReplArray(param1Int, param1CTAlphaReplaceEffect);
          return cTAlphaReplaceEffect;
        }
        
        public void add(int param1Int, CTAlphaReplaceEffect param1CTAlphaReplaceEffect) {
          CTEffectContainerImpl.this.insertNewAlphaRepl(param1Int).set((XmlObject)param1CTAlphaReplaceEffect);
        }
        
        public CTAlphaReplaceEffect remove(int param1Int) {
          CTAlphaReplaceEffect cTAlphaReplaceEffect = CTEffectContainerImpl.this.getAlphaReplArray(param1Int);
          CTEffectContainerImpl.this.removeAlphaRepl(param1Int);
          return cTAlphaReplaceEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfAlphaReplArray();
        }
      };
      return new AlphaReplList();
    } 
  }
  
  @Deprecated
  public CTAlphaReplaceEffect[] getAlphaReplArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ALPHAREPL$18, arrayList);
      CTAlphaReplaceEffect[] arrayOfCTAlphaReplaceEffect = new CTAlphaReplaceEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTAlphaReplaceEffect);
      return arrayOfCTAlphaReplaceEffect;
    } 
  }
  
  public CTAlphaReplaceEffect getAlphaReplArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaReplaceEffect cTAlphaReplaceEffect = null;
      cTAlphaReplaceEffect = (CTAlphaReplaceEffect)get_store().find_element_user(ALPHAREPL$18, paramInt);
      if (cTAlphaReplaceEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTAlphaReplaceEffect;
    } 
  }
  
  public int sizeOfAlphaReplArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ALPHAREPL$18);
    } 
  }
  
  public void setAlphaReplArray(CTAlphaReplaceEffect[] paramArrayOfCTAlphaReplaceEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTAlphaReplaceEffect, ALPHAREPL$18);
  }
  
  public void setAlphaReplArray(int paramInt, CTAlphaReplaceEffect paramCTAlphaReplaceEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTAlphaReplaceEffect, ALPHAREPL$18, paramInt, (short)2);
  }
  
  public CTAlphaReplaceEffect insertNewAlphaRepl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaReplaceEffect cTAlphaReplaceEffect = null;
      cTAlphaReplaceEffect = (CTAlphaReplaceEffect)get_store().insert_element_user(ALPHAREPL$18, paramInt);
      return cTAlphaReplaceEffect;
    } 
  }
  
  public CTAlphaReplaceEffect addNewAlphaRepl() {
    synchronized (monitor()) {
      check_orphaned();
      CTAlphaReplaceEffect cTAlphaReplaceEffect = null;
      cTAlphaReplaceEffect = (CTAlphaReplaceEffect)get_store().add_element_user(ALPHAREPL$18);
      return cTAlphaReplaceEffect;
    } 
  }
  
  public void removeAlphaRepl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ALPHAREPL$18, paramInt);
    } 
  }
  
  public List<CTBiLevelEffect> getBiLevelList() {
    synchronized (monitor()) {
      check_orphaned();
      final class BiLevelList extends AbstractList<CTBiLevelEffect> {
        public CTBiLevelEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getBiLevelArray(param1Int);
        }
        
        public CTBiLevelEffect set(int param1Int, CTBiLevelEffect param1CTBiLevelEffect) {
          CTBiLevelEffect cTBiLevelEffect = CTEffectContainerImpl.this.getBiLevelArray(param1Int);
          CTEffectContainerImpl.this.setBiLevelArray(param1Int, param1CTBiLevelEffect);
          return cTBiLevelEffect;
        }
        
        public void add(int param1Int, CTBiLevelEffect param1CTBiLevelEffect) {
          CTEffectContainerImpl.this.insertNewBiLevel(param1Int).set((XmlObject)param1CTBiLevelEffect);
        }
        
        public CTBiLevelEffect remove(int param1Int) {
          CTBiLevelEffect cTBiLevelEffect = CTEffectContainerImpl.this.getBiLevelArray(param1Int);
          CTEffectContainerImpl.this.removeBiLevel(param1Int);
          return cTBiLevelEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfBiLevelArray();
        }
      };
      return new BiLevelList();
    } 
  }
  
  @Deprecated
  public CTBiLevelEffect[] getBiLevelArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(BILEVEL$20, arrayList);
      CTBiLevelEffect[] arrayOfCTBiLevelEffect = new CTBiLevelEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBiLevelEffect);
      return arrayOfCTBiLevelEffect;
    } 
  }
  
  public CTBiLevelEffect getBiLevelArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBiLevelEffect cTBiLevelEffect = null;
      cTBiLevelEffect = (CTBiLevelEffect)get_store().find_element_user(BILEVEL$20, paramInt);
      if (cTBiLevelEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTBiLevelEffect;
    } 
  }
  
  public int sizeOfBiLevelArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(BILEVEL$20);
    } 
  }
  
  public void setBiLevelArray(CTBiLevelEffect[] paramArrayOfCTBiLevelEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBiLevelEffect, BILEVEL$20);
  }
  
  public void setBiLevelArray(int paramInt, CTBiLevelEffect paramCTBiLevelEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTBiLevelEffect, BILEVEL$20, paramInt, (short)2);
  }
  
  public CTBiLevelEffect insertNewBiLevel(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBiLevelEffect cTBiLevelEffect = null;
      cTBiLevelEffect = (CTBiLevelEffect)get_store().insert_element_user(BILEVEL$20, paramInt);
      return cTBiLevelEffect;
    } 
  }
  
  public CTBiLevelEffect addNewBiLevel() {
    synchronized (monitor()) {
      check_orphaned();
      CTBiLevelEffect cTBiLevelEffect = null;
      cTBiLevelEffect = (CTBiLevelEffect)get_store().add_element_user(BILEVEL$20);
      return cTBiLevelEffect;
    } 
  }
  
  public void removeBiLevel(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BILEVEL$20, paramInt);
    } 
  }
  
  public List<CTBlendEffect> getBlendList() {
    synchronized (monitor()) {
      check_orphaned();
      final class BlendList extends AbstractList<CTBlendEffect> {
        public CTBlendEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getBlendArray(param1Int);
        }
        
        public CTBlendEffect set(int param1Int, CTBlendEffect param1CTBlendEffect) {
          CTBlendEffect cTBlendEffect = CTEffectContainerImpl.this.getBlendArray(param1Int);
          CTEffectContainerImpl.this.setBlendArray(param1Int, param1CTBlendEffect);
          return cTBlendEffect;
        }
        
        public void add(int param1Int, CTBlendEffect param1CTBlendEffect) {
          CTEffectContainerImpl.this.insertNewBlend(param1Int).set((XmlObject)param1CTBlendEffect);
        }
        
        public CTBlendEffect remove(int param1Int) {
          CTBlendEffect cTBlendEffect = CTEffectContainerImpl.this.getBlendArray(param1Int);
          CTEffectContainerImpl.this.removeBlend(param1Int);
          return cTBlendEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfBlendArray();
        }
      };
      return new BlendList();
    } 
  }
  
  @Deprecated
  public CTBlendEffect[] getBlendArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(BLEND$22, arrayList);
      CTBlendEffect[] arrayOfCTBlendEffect = new CTBlendEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBlendEffect);
      return arrayOfCTBlendEffect;
    } 
  }
  
  public CTBlendEffect getBlendArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBlendEffect cTBlendEffect = null;
      cTBlendEffect = (CTBlendEffect)get_store().find_element_user(BLEND$22, paramInt);
      if (cTBlendEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTBlendEffect;
    } 
  }
  
  public int sizeOfBlendArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(BLEND$22);
    } 
  }
  
  public void setBlendArray(CTBlendEffect[] paramArrayOfCTBlendEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBlendEffect, BLEND$22);
  }
  
  public void setBlendArray(int paramInt, CTBlendEffect paramCTBlendEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTBlendEffect, BLEND$22, paramInt, (short)2);
  }
  
  public CTBlendEffect insertNewBlend(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBlendEffect cTBlendEffect = null;
      cTBlendEffect = (CTBlendEffect)get_store().insert_element_user(BLEND$22, paramInt);
      return cTBlendEffect;
    } 
  }
  
  public CTBlendEffect addNewBlend() {
    synchronized (monitor()) {
      check_orphaned();
      CTBlendEffect cTBlendEffect = null;
      cTBlendEffect = (CTBlendEffect)get_store().add_element_user(BLEND$22);
      return cTBlendEffect;
    } 
  }
  
  public void removeBlend(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BLEND$22, paramInt);
    } 
  }
  
  public List<CTBlurEffect> getBlurList() {
    synchronized (monitor()) {
      check_orphaned();
      final class BlurList extends AbstractList<CTBlurEffect> {
        public CTBlurEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getBlurArray(param1Int);
        }
        
        public CTBlurEffect set(int param1Int, CTBlurEffect param1CTBlurEffect) {
          CTBlurEffect cTBlurEffect = CTEffectContainerImpl.this.getBlurArray(param1Int);
          CTEffectContainerImpl.this.setBlurArray(param1Int, param1CTBlurEffect);
          return cTBlurEffect;
        }
        
        public void add(int param1Int, CTBlurEffect param1CTBlurEffect) {
          CTEffectContainerImpl.this.insertNewBlur(param1Int).set((XmlObject)param1CTBlurEffect);
        }
        
        public CTBlurEffect remove(int param1Int) {
          CTBlurEffect cTBlurEffect = CTEffectContainerImpl.this.getBlurArray(param1Int);
          CTEffectContainerImpl.this.removeBlur(param1Int);
          return cTBlurEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfBlurArray();
        }
      };
      return new BlurList();
    } 
  }
  
  @Deprecated
  public CTBlurEffect[] getBlurArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(BLUR$24, arrayList);
      CTBlurEffect[] arrayOfCTBlurEffect = new CTBlurEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBlurEffect);
      return arrayOfCTBlurEffect;
    } 
  }
  
  public CTBlurEffect getBlurArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBlurEffect cTBlurEffect = null;
      cTBlurEffect = (CTBlurEffect)get_store().find_element_user(BLUR$24, paramInt);
      if (cTBlurEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTBlurEffect;
    } 
  }
  
  public int sizeOfBlurArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(BLUR$24);
    } 
  }
  
  public void setBlurArray(CTBlurEffect[] paramArrayOfCTBlurEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBlurEffect, BLUR$24);
  }
  
  public void setBlurArray(int paramInt, CTBlurEffect paramCTBlurEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTBlurEffect, BLUR$24, paramInt, (short)2);
  }
  
  public CTBlurEffect insertNewBlur(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBlurEffect cTBlurEffect = null;
      cTBlurEffect = (CTBlurEffect)get_store().insert_element_user(BLUR$24, paramInt);
      return cTBlurEffect;
    } 
  }
  
  public CTBlurEffect addNewBlur() {
    synchronized (monitor()) {
      check_orphaned();
      CTBlurEffect cTBlurEffect = null;
      cTBlurEffect = (CTBlurEffect)get_store().add_element_user(BLUR$24);
      return cTBlurEffect;
    } 
  }
  
  public void removeBlur(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BLUR$24, paramInt);
    } 
  }
  
  public List<CTColorChangeEffect> getClrChangeList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ClrChangeList extends AbstractList<CTColorChangeEffect> {
        public CTColorChangeEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getClrChangeArray(param1Int);
        }
        
        public CTColorChangeEffect set(int param1Int, CTColorChangeEffect param1CTColorChangeEffect) {
          CTColorChangeEffect cTColorChangeEffect = CTEffectContainerImpl.this.getClrChangeArray(param1Int);
          CTEffectContainerImpl.this.setClrChangeArray(param1Int, param1CTColorChangeEffect);
          return cTColorChangeEffect;
        }
        
        public void add(int param1Int, CTColorChangeEffect param1CTColorChangeEffect) {
          CTEffectContainerImpl.this.insertNewClrChange(param1Int).set((XmlObject)param1CTColorChangeEffect);
        }
        
        public CTColorChangeEffect remove(int param1Int) {
          CTColorChangeEffect cTColorChangeEffect = CTEffectContainerImpl.this.getClrChangeArray(param1Int);
          CTEffectContainerImpl.this.removeClrChange(param1Int);
          return cTColorChangeEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfClrChangeArray();
        }
      };
      return new ClrChangeList();
    } 
  }
  
  @Deprecated
  public CTColorChangeEffect[] getClrChangeArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CLRCHANGE$26, arrayList);
      CTColorChangeEffect[] arrayOfCTColorChangeEffect = new CTColorChangeEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTColorChangeEffect);
      return arrayOfCTColorChangeEffect;
    } 
  }
  
  public CTColorChangeEffect getClrChangeArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTColorChangeEffect cTColorChangeEffect = null;
      cTColorChangeEffect = (CTColorChangeEffect)get_store().find_element_user(CLRCHANGE$26, paramInt);
      if (cTColorChangeEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTColorChangeEffect;
    } 
  }
  
  public int sizeOfClrChangeArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CLRCHANGE$26);
    } 
  }
  
  public void setClrChangeArray(CTColorChangeEffect[] paramArrayOfCTColorChangeEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTColorChangeEffect, CLRCHANGE$26);
  }
  
  public void setClrChangeArray(int paramInt, CTColorChangeEffect paramCTColorChangeEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTColorChangeEffect, CLRCHANGE$26, paramInt, (short)2);
  }
  
  public CTColorChangeEffect insertNewClrChange(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTColorChangeEffect cTColorChangeEffect = null;
      cTColorChangeEffect = (CTColorChangeEffect)get_store().insert_element_user(CLRCHANGE$26, paramInt);
      return cTColorChangeEffect;
    } 
  }
  
  public CTColorChangeEffect addNewClrChange() {
    synchronized (monitor()) {
      check_orphaned();
      CTColorChangeEffect cTColorChangeEffect = null;
      cTColorChangeEffect = (CTColorChangeEffect)get_store().add_element_user(CLRCHANGE$26);
      return cTColorChangeEffect;
    } 
  }
  
  public void removeClrChange(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CLRCHANGE$26, paramInt);
    } 
  }
  
  public List<CTColorReplaceEffect> getClrReplList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ClrReplList extends AbstractList<CTColorReplaceEffect> {
        public CTColorReplaceEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getClrReplArray(param1Int);
        }
        
        public CTColorReplaceEffect set(int param1Int, CTColorReplaceEffect param1CTColorReplaceEffect) {
          CTColorReplaceEffect cTColorReplaceEffect = CTEffectContainerImpl.this.getClrReplArray(param1Int);
          CTEffectContainerImpl.this.setClrReplArray(param1Int, param1CTColorReplaceEffect);
          return cTColorReplaceEffect;
        }
        
        public void add(int param1Int, CTColorReplaceEffect param1CTColorReplaceEffect) {
          CTEffectContainerImpl.this.insertNewClrRepl(param1Int).set((XmlObject)param1CTColorReplaceEffect);
        }
        
        public CTColorReplaceEffect remove(int param1Int) {
          CTColorReplaceEffect cTColorReplaceEffect = CTEffectContainerImpl.this.getClrReplArray(param1Int);
          CTEffectContainerImpl.this.removeClrRepl(param1Int);
          return cTColorReplaceEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfClrReplArray();
        }
      };
      return new ClrReplList();
    } 
  }
  
  @Deprecated
  public CTColorReplaceEffect[] getClrReplArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CLRREPL$28, arrayList);
      CTColorReplaceEffect[] arrayOfCTColorReplaceEffect = new CTColorReplaceEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTColorReplaceEffect);
      return arrayOfCTColorReplaceEffect;
    } 
  }
  
  public CTColorReplaceEffect getClrReplArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTColorReplaceEffect cTColorReplaceEffect = null;
      cTColorReplaceEffect = (CTColorReplaceEffect)get_store().find_element_user(CLRREPL$28, paramInt);
      if (cTColorReplaceEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTColorReplaceEffect;
    } 
  }
  
  public int sizeOfClrReplArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CLRREPL$28);
    } 
  }
  
  public void setClrReplArray(CTColorReplaceEffect[] paramArrayOfCTColorReplaceEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTColorReplaceEffect, CLRREPL$28);
  }
  
  public void setClrReplArray(int paramInt, CTColorReplaceEffect paramCTColorReplaceEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTColorReplaceEffect, CLRREPL$28, paramInt, (short)2);
  }
  
  public CTColorReplaceEffect insertNewClrRepl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTColorReplaceEffect cTColorReplaceEffect = null;
      cTColorReplaceEffect = (CTColorReplaceEffect)get_store().insert_element_user(CLRREPL$28, paramInt);
      return cTColorReplaceEffect;
    } 
  }
  
  public CTColorReplaceEffect addNewClrRepl() {
    synchronized (monitor()) {
      check_orphaned();
      CTColorReplaceEffect cTColorReplaceEffect = null;
      cTColorReplaceEffect = (CTColorReplaceEffect)get_store().add_element_user(CLRREPL$28);
      return cTColorReplaceEffect;
    } 
  }
  
  public void removeClrRepl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CLRREPL$28, paramInt);
    } 
  }
  
  public List<CTDuotoneEffect> getDuotoneList() {
    synchronized (monitor()) {
      check_orphaned();
      final class DuotoneList extends AbstractList<CTDuotoneEffect> {
        public CTDuotoneEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getDuotoneArray(param1Int);
        }
        
        public CTDuotoneEffect set(int param1Int, CTDuotoneEffect param1CTDuotoneEffect) {
          CTDuotoneEffect cTDuotoneEffect = CTEffectContainerImpl.this.getDuotoneArray(param1Int);
          CTEffectContainerImpl.this.setDuotoneArray(param1Int, param1CTDuotoneEffect);
          return cTDuotoneEffect;
        }
        
        public void add(int param1Int, CTDuotoneEffect param1CTDuotoneEffect) {
          CTEffectContainerImpl.this.insertNewDuotone(param1Int).set((XmlObject)param1CTDuotoneEffect);
        }
        
        public CTDuotoneEffect remove(int param1Int) {
          CTDuotoneEffect cTDuotoneEffect = CTEffectContainerImpl.this.getDuotoneArray(param1Int);
          CTEffectContainerImpl.this.removeDuotone(param1Int);
          return cTDuotoneEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfDuotoneArray();
        }
      };
      return new DuotoneList();
    } 
  }
  
  @Deprecated
  public CTDuotoneEffect[] getDuotoneArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(DUOTONE$30, arrayList);
      CTDuotoneEffect[] arrayOfCTDuotoneEffect = new CTDuotoneEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTDuotoneEffect);
      return arrayOfCTDuotoneEffect;
    } 
  }
  
  public CTDuotoneEffect getDuotoneArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDuotoneEffect cTDuotoneEffect = null;
      cTDuotoneEffect = (CTDuotoneEffect)get_store().find_element_user(DUOTONE$30, paramInt);
      if (cTDuotoneEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTDuotoneEffect;
    } 
  }
  
  public int sizeOfDuotoneArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(DUOTONE$30);
    } 
  }
  
  public void setDuotoneArray(CTDuotoneEffect[] paramArrayOfCTDuotoneEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTDuotoneEffect, DUOTONE$30);
  }
  
  public void setDuotoneArray(int paramInt, CTDuotoneEffect paramCTDuotoneEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTDuotoneEffect, DUOTONE$30, paramInt, (short)2);
  }
  
  public CTDuotoneEffect insertNewDuotone(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTDuotoneEffect cTDuotoneEffect = null;
      cTDuotoneEffect = (CTDuotoneEffect)get_store().insert_element_user(DUOTONE$30, paramInt);
      return cTDuotoneEffect;
    } 
  }
  
  public CTDuotoneEffect addNewDuotone() {
    synchronized (monitor()) {
      check_orphaned();
      CTDuotoneEffect cTDuotoneEffect = null;
      cTDuotoneEffect = (CTDuotoneEffect)get_store().add_element_user(DUOTONE$30);
      return cTDuotoneEffect;
    } 
  }
  
  public void removeDuotone(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DUOTONE$30, paramInt);
    } 
  }
  
  public List<CTFillEffect> getFillList() {
    synchronized (monitor()) {
      check_orphaned();
      final class FillList extends AbstractList<CTFillEffect> {
        public CTFillEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getFillArray(param1Int);
        }
        
        public CTFillEffect set(int param1Int, CTFillEffect param1CTFillEffect) {
          CTFillEffect cTFillEffect = CTEffectContainerImpl.this.getFillArray(param1Int);
          CTEffectContainerImpl.this.setFillArray(param1Int, param1CTFillEffect);
          return cTFillEffect;
        }
        
        public void add(int param1Int, CTFillEffect param1CTFillEffect) {
          CTEffectContainerImpl.this.insertNewFill(param1Int).set((XmlObject)param1CTFillEffect);
        }
        
        public CTFillEffect remove(int param1Int) {
          CTFillEffect cTFillEffect = CTEffectContainerImpl.this.getFillArray(param1Int);
          CTEffectContainerImpl.this.removeFill(param1Int);
          return cTFillEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfFillArray();
        }
      };
      return new FillList();
    } 
  }
  
  @Deprecated
  public CTFillEffect[] getFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(FILL$32, arrayList);
      CTFillEffect[] arrayOfCTFillEffect = new CTFillEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTFillEffect);
      return arrayOfCTFillEffect;
    } 
  }
  
  public CTFillEffect getFillArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTFillEffect cTFillEffect = null;
      cTFillEffect = (CTFillEffect)get_store().find_element_user(FILL$32, paramInt);
      if (cTFillEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTFillEffect;
    } 
  }
  
  public int sizeOfFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(FILL$32);
    } 
  }
  
  public void setFillArray(CTFillEffect[] paramArrayOfCTFillEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTFillEffect, FILL$32);
  }
  
  public void setFillArray(int paramInt, CTFillEffect paramCTFillEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTFillEffect, FILL$32, paramInt, (short)2);
  }
  
  public CTFillEffect insertNewFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTFillEffect cTFillEffect = null;
      cTFillEffect = (CTFillEffect)get_store().insert_element_user(FILL$32, paramInt);
      return cTFillEffect;
    } 
  }
  
  public CTFillEffect addNewFill() {
    synchronized (monitor()) {
      check_orphaned();
      CTFillEffect cTFillEffect = null;
      cTFillEffect = (CTFillEffect)get_store().add_element_user(FILL$32);
      return cTFillEffect;
    } 
  }
  
  public void removeFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(FILL$32, paramInt);
    } 
  }
  
  public List<CTFillOverlayEffect> getFillOverlayList() {
    synchronized (monitor()) {
      check_orphaned();
      final class FillOverlayList extends AbstractList<CTFillOverlayEffect> {
        public CTFillOverlayEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getFillOverlayArray(param1Int);
        }
        
        public CTFillOverlayEffect set(int param1Int, CTFillOverlayEffect param1CTFillOverlayEffect) {
          CTFillOverlayEffect cTFillOverlayEffect = CTEffectContainerImpl.this.getFillOverlayArray(param1Int);
          CTEffectContainerImpl.this.setFillOverlayArray(param1Int, param1CTFillOverlayEffect);
          return cTFillOverlayEffect;
        }
        
        public void add(int param1Int, CTFillOverlayEffect param1CTFillOverlayEffect) {
          CTEffectContainerImpl.this.insertNewFillOverlay(param1Int).set((XmlObject)param1CTFillOverlayEffect);
        }
        
        public CTFillOverlayEffect remove(int param1Int) {
          CTFillOverlayEffect cTFillOverlayEffect = CTEffectContainerImpl.this.getFillOverlayArray(param1Int);
          CTEffectContainerImpl.this.removeFillOverlay(param1Int);
          return cTFillOverlayEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfFillOverlayArray();
        }
      };
      return new FillOverlayList();
    } 
  }
  
  @Deprecated
  public CTFillOverlayEffect[] getFillOverlayArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(FILLOVERLAY$34, arrayList);
      CTFillOverlayEffect[] arrayOfCTFillOverlayEffect = new CTFillOverlayEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTFillOverlayEffect);
      return arrayOfCTFillOverlayEffect;
    } 
  }
  
  public CTFillOverlayEffect getFillOverlayArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTFillOverlayEffect cTFillOverlayEffect = null;
      cTFillOverlayEffect = (CTFillOverlayEffect)get_store().find_element_user(FILLOVERLAY$34, paramInt);
      if (cTFillOverlayEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTFillOverlayEffect;
    } 
  }
  
  public int sizeOfFillOverlayArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(FILLOVERLAY$34);
    } 
  }
  
  public void setFillOverlayArray(CTFillOverlayEffect[] paramArrayOfCTFillOverlayEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTFillOverlayEffect, FILLOVERLAY$34);
  }
  
  public void setFillOverlayArray(int paramInt, CTFillOverlayEffect paramCTFillOverlayEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTFillOverlayEffect, FILLOVERLAY$34, paramInt, (short)2);
  }
  
  public CTFillOverlayEffect insertNewFillOverlay(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTFillOverlayEffect cTFillOverlayEffect = null;
      cTFillOverlayEffect = (CTFillOverlayEffect)get_store().insert_element_user(FILLOVERLAY$34, paramInt);
      return cTFillOverlayEffect;
    } 
  }
  
  public CTFillOverlayEffect addNewFillOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      CTFillOverlayEffect cTFillOverlayEffect = null;
      cTFillOverlayEffect = (CTFillOverlayEffect)get_store().add_element_user(FILLOVERLAY$34);
      return cTFillOverlayEffect;
    } 
  }
  
  public void removeFillOverlay(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(FILLOVERLAY$34, paramInt);
    } 
  }
  
  public List<CTGlowEffect> getGlowList() {
    synchronized (monitor()) {
      check_orphaned();
      final class GlowList extends AbstractList<CTGlowEffect> {
        public CTGlowEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getGlowArray(param1Int);
        }
        
        public CTGlowEffect set(int param1Int, CTGlowEffect param1CTGlowEffect) {
          CTGlowEffect cTGlowEffect = CTEffectContainerImpl.this.getGlowArray(param1Int);
          CTEffectContainerImpl.this.setGlowArray(param1Int, param1CTGlowEffect);
          return cTGlowEffect;
        }
        
        public void add(int param1Int, CTGlowEffect param1CTGlowEffect) {
          CTEffectContainerImpl.this.insertNewGlow(param1Int).set((XmlObject)param1CTGlowEffect);
        }
        
        public CTGlowEffect remove(int param1Int) {
          CTGlowEffect cTGlowEffect = CTEffectContainerImpl.this.getGlowArray(param1Int);
          CTEffectContainerImpl.this.removeGlow(param1Int);
          return cTGlowEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfGlowArray();
        }
      };
      return new GlowList();
    } 
  }
  
  @Deprecated
  public CTGlowEffect[] getGlowArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(GLOW$36, arrayList);
      CTGlowEffect[] arrayOfCTGlowEffect = new CTGlowEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTGlowEffect);
      return arrayOfCTGlowEffect;
    } 
  }
  
  public CTGlowEffect getGlowArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGlowEffect cTGlowEffect = null;
      cTGlowEffect = (CTGlowEffect)get_store().find_element_user(GLOW$36, paramInt);
      if (cTGlowEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTGlowEffect;
    } 
  }
  
  public int sizeOfGlowArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(GLOW$36);
    } 
  }
  
  public void setGlowArray(CTGlowEffect[] paramArrayOfCTGlowEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTGlowEffect, GLOW$36);
  }
  
  public void setGlowArray(int paramInt, CTGlowEffect paramCTGlowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTGlowEffect, GLOW$36, paramInt, (short)2);
  }
  
  public CTGlowEffect insertNewGlow(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGlowEffect cTGlowEffect = null;
      cTGlowEffect = (CTGlowEffect)get_store().insert_element_user(GLOW$36, paramInt);
      return cTGlowEffect;
    } 
  }
  
  public CTGlowEffect addNewGlow() {
    synchronized (monitor()) {
      check_orphaned();
      CTGlowEffect cTGlowEffect = null;
      cTGlowEffect = (CTGlowEffect)get_store().add_element_user(GLOW$36);
      return cTGlowEffect;
    } 
  }
  
  public void removeGlow(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GLOW$36, paramInt);
    } 
  }
  
  public List<CTGrayscaleEffect> getGraysclList() {
    synchronized (monitor()) {
      check_orphaned();
      final class GraysclList extends AbstractList<CTGrayscaleEffect> {
        public CTGrayscaleEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getGraysclArray(param1Int);
        }
        
        public CTGrayscaleEffect set(int param1Int, CTGrayscaleEffect param1CTGrayscaleEffect) {
          CTGrayscaleEffect cTGrayscaleEffect = CTEffectContainerImpl.this.getGraysclArray(param1Int);
          CTEffectContainerImpl.this.setGraysclArray(param1Int, param1CTGrayscaleEffect);
          return cTGrayscaleEffect;
        }
        
        public void add(int param1Int, CTGrayscaleEffect param1CTGrayscaleEffect) {
          CTEffectContainerImpl.this.insertNewGrayscl(param1Int).set((XmlObject)param1CTGrayscaleEffect);
        }
        
        public CTGrayscaleEffect remove(int param1Int) {
          CTGrayscaleEffect cTGrayscaleEffect = CTEffectContainerImpl.this.getGraysclArray(param1Int);
          CTEffectContainerImpl.this.removeGrayscl(param1Int);
          return cTGrayscaleEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfGraysclArray();
        }
      };
      return new GraysclList();
    } 
  }
  
  @Deprecated
  public CTGrayscaleEffect[] getGraysclArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(GRAYSCL$38, arrayList);
      CTGrayscaleEffect[] arrayOfCTGrayscaleEffect = new CTGrayscaleEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTGrayscaleEffect);
      return arrayOfCTGrayscaleEffect;
    } 
  }
  
  public CTGrayscaleEffect getGraysclArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGrayscaleEffect cTGrayscaleEffect = null;
      cTGrayscaleEffect = (CTGrayscaleEffect)get_store().find_element_user(GRAYSCL$38, paramInt);
      if (cTGrayscaleEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTGrayscaleEffect;
    } 
  }
  
  public int sizeOfGraysclArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(GRAYSCL$38);
    } 
  }
  
  public void setGraysclArray(CTGrayscaleEffect[] paramArrayOfCTGrayscaleEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTGrayscaleEffect, GRAYSCL$38);
  }
  
  public void setGraysclArray(int paramInt, CTGrayscaleEffect paramCTGrayscaleEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTGrayscaleEffect, GRAYSCL$38, paramInt, (short)2);
  }
  
  public CTGrayscaleEffect insertNewGrayscl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGrayscaleEffect cTGrayscaleEffect = null;
      cTGrayscaleEffect = (CTGrayscaleEffect)get_store().insert_element_user(GRAYSCL$38, paramInt);
      return cTGrayscaleEffect;
    } 
  }
  
  public CTGrayscaleEffect addNewGrayscl() {
    synchronized (monitor()) {
      check_orphaned();
      CTGrayscaleEffect cTGrayscaleEffect = null;
      cTGrayscaleEffect = (CTGrayscaleEffect)get_store().add_element_user(GRAYSCL$38);
      return cTGrayscaleEffect;
    } 
  }
  
  public void removeGrayscl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GRAYSCL$38, paramInt);
    } 
  }
  
  public List<CTHSLEffect> getHslList() {
    synchronized (monitor()) {
      check_orphaned();
      final class HslList extends AbstractList<CTHSLEffect> {
        public CTHSLEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getHslArray(param1Int);
        }
        
        public CTHSLEffect set(int param1Int, CTHSLEffect param1CTHSLEffect) {
          CTHSLEffect cTHSLEffect = CTEffectContainerImpl.this.getHslArray(param1Int);
          CTEffectContainerImpl.this.setHslArray(param1Int, param1CTHSLEffect);
          return cTHSLEffect;
        }
        
        public void add(int param1Int, CTHSLEffect param1CTHSLEffect) {
          CTEffectContainerImpl.this.insertNewHsl(param1Int).set((XmlObject)param1CTHSLEffect);
        }
        
        public CTHSLEffect remove(int param1Int) {
          CTHSLEffect cTHSLEffect = CTEffectContainerImpl.this.getHslArray(param1Int);
          CTEffectContainerImpl.this.removeHsl(param1Int);
          return cTHSLEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfHslArray();
        }
      };
      return new HslList();
    } 
  }
  
  @Deprecated
  public CTHSLEffect[] getHslArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(HSL$40, arrayList);
      CTHSLEffect[] arrayOfCTHSLEffect = new CTHSLEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTHSLEffect);
      return arrayOfCTHSLEffect;
    } 
  }
  
  public CTHSLEffect getHslArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTHSLEffect cTHSLEffect = null;
      cTHSLEffect = (CTHSLEffect)get_store().find_element_user(HSL$40, paramInt);
      if (cTHSLEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTHSLEffect;
    } 
  }
  
  public int sizeOfHslArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(HSL$40);
    } 
  }
  
  public void setHslArray(CTHSLEffect[] paramArrayOfCTHSLEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTHSLEffect, HSL$40);
  }
  
  public void setHslArray(int paramInt, CTHSLEffect paramCTHSLEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTHSLEffect, HSL$40, paramInt, (short)2);
  }
  
  public CTHSLEffect insertNewHsl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTHSLEffect cTHSLEffect = null;
      cTHSLEffect = (CTHSLEffect)get_store().insert_element_user(HSL$40, paramInt);
      return cTHSLEffect;
    } 
  }
  
  public CTHSLEffect addNewHsl() {
    synchronized (monitor()) {
      check_orphaned();
      CTHSLEffect cTHSLEffect = null;
      cTHSLEffect = (CTHSLEffect)get_store().add_element_user(HSL$40);
      return cTHSLEffect;
    } 
  }
  
  public void removeHsl(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(HSL$40, paramInt);
    } 
  }
  
  public List<CTInnerShadowEffect> getInnerShdwList() {
    synchronized (monitor()) {
      check_orphaned();
      final class InnerShdwList extends AbstractList<CTInnerShadowEffect> {
        public CTInnerShadowEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getInnerShdwArray(param1Int);
        }
        
        public CTInnerShadowEffect set(int param1Int, CTInnerShadowEffect param1CTInnerShadowEffect) {
          CTInnerShadowEffect cTInnerShadowEffect = CTEffectContainerImpl.this.getInnerShdwArray(param1Int);
          CTEffectContainerImpl.this.setInnerShdwArray(param1Int, param1CTInnerShadowEffect);
          return cTInnerShadowEffect;
        }
        
        public void add(int param1Int, CTInnerShadowEffect param1CTInnerShadowEffect) {
          CTEffectContainerImpl.this.insertNewInnerShdw(param1Int).set((XmlObject)param1CTInnerShadowEffect);
        }
        
        public CTInnerShadowEffect remove(int param1Int) {
          CTInnerShadowEffect cTInnerShadowEffect = CTEffectContainerImpl.this.getInnerShdwArray(param1Int);
          CTEffectContainerImpl.this.removeInnerShdw(param1Int);
          return cTInnerShadowEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfInnerShdwArray();
        }
      };
      return new InnerShdwList();
    } 
  }
  
  @Deprecated
  public CTInnerShadowEffect[] getInnerShdwArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(INNERSHDW$42, arrayList);
      CTInnerShadowEffect[] arrayOfCTInnerShadowEffect = new CTInnerShadowEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTInnerShadowEffect);
      return arrayOfCTInnerShadowEffect;
    } 
  }
  
  public CTInnerShadowEffect getInnerShdwArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTInnerShadowEffect cTInnerShadowEffect = null;
      cTInnerShadowEffect = (CTInnerShadowEffect)get_store().find_element_user(INNERSHDW$42, paramInt);
      if (cTInnerShadowEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTInnerShadowEffect;
    } 
  }
  
  public int sizeOfInnerShdwArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(INNERSHDW$42);
    } 
  }
  
  public void setInnerShdwArray(CTInnerShadowEffect[] paramArrayOfCTInnerShadowEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTInnerShadowEffect, INNERSHDW$42);
  }
  
  public void setInnerShdwArray(int paramInt, CTInnerShadowEffect paramCTInnerShadowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTInnerShadowEffect, INNERSHDW$42, paramInt, (short)2);
  }
  
  public CTInnerShadowEffect insertNewInnerShdw(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTInnerShadowEffect cTInnerShadowEffect = null;
      cTInnerShadowEffect = (CTInnerShadowEffect)get_store().insert_element_user(INNERSHDW$42, paramInt);
      return cTInnerShadowEffect;
    } 
  }
  
  public CTInnerShadowEffect addNewInnerShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTInnerShadowEffect cTInnerShadowEffect = null;
      cTInnerShadowEffect = (CTInnerShadowEffect)get_store().add_element_user(INNERSHDW$42);
      return cTInnerShadowEffect;
    } 
  }
  
  public void removeInnerShdw(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(INNERSHDW$42, paramInt);
    } 
  }
  
  public List<CTLuminanceEffect> getLumList() {
    synchronized (monitor()) {
      check_orphaned();
      final class LumList extends AbstractList<CTLuminanceEffect> {
        public CTLuminanceEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getLumArray(param1Int);
        }
        
        public CTLuminanceEffect set(int param1Int, CTLuminanceEffect param1CTLuminanceEffect) {
          CTLuminanceEffect cTLuminanceEffect = CTEffectContainerImpl.this.getLumArray(param1Int);
          CTEffectContainerImpl.this.setLumArray(param1Int, param1CTLuminanceEffect);
          return cTLuminanceEffect;
        }
        
        public void add(int param1Int, CTLuminanceEffect param1CTLuminanceEffect) {
          CTEffectContainerImpl.this.insertNewLum(param1Int).set((XmlObject)param1CTLuminanceEffect);
        }
        
        public CTLuminanceEffect remove(int param1Int) {
          CTLuminanceEffect cTLuminanceEffect = CTEffectContainerImpl.this.getLumArray(param1Int);
          CTEffectContainerImpl.this.removeLum(param1Int);
          return cTLuminanceEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfLumArray();
        }
      };
      return new LumList();
    } 
  }
  
  @Deprecated
  public CTLuminanceEffect[] getLumArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(LUM$44, arrayList);
      CTLuminanceEffect[] arrayOfCTLuminanceEffect = new CTLuminanceEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTLuminanceEffect);
      return arrayOfCTLuminanceEffect;
    } 
  }
  
  public CTLuminanceEffect getLumArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLuminanceEffect cTLuminanceEffect = null;
      cTLuminanceEffect = (CTLuminanceEffect)get_store().find_element_user(LUM$44, paramInt);
      if (cTLuminanceEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTLuminanceEffect;
    } 
  }
  
  public int sizeOfLumArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(LUM$44);
    } 
  }
  
  public void setLumArray(CTLuminanceEffect[] paramArrayOfCTLuminanceEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTLuminanceEffect, LUM$44);
  }
  
  public void setLumArray(int paramInt, CTLuminanceEffect paramCTLuminanceEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTLuminanceEffect, LUM$44, paramInt, (short)2);
  }
  
  public CTLuminanceEffect insertNewLum(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTLuminanceEffect cTLuminanceEffect = null;
      cTLuminanceEffect = (CTLuminanceEffect)get_store().insert_element_user(LUM$44, paramInt);
      return cTLuminanceEffect;
    } 
  }
  
  public CTLuminanceEffect addNewLum() {
    synchronized (monitor()) {
      check_orphaned();
      CTLuminanceEffect cTLuminanceEffect = null;
      cTLuminanceEffect = (CTLuminanceEffect)get_store().add_element_user(LUM$44);
      return cTLuminanceEffect;
    } 
  }
  
  public void removeLum(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(LUM$44, paramInt);
    } 
  }
  
  public List<CTOuterShadowEffect> getOuterShdwList() {
    synchronized (monitor()) {
      check_orphaned();
      final class OuterShdwList extends AbstractList<CTOuterShadowEffect> {
        public CTOuterShadowEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getOuterShdwArray(param1Int);
        }
        
        public CTOuterShadowEffect set(int param1Int, CTOuterShadowEffect param1CTOuterShadowEffect) {
          CTOuterShadowEffect cTOuterShadowEffect = CTEffectContainerImpl.this.getOuterShdwArray(param1Int);
          CTEffectContainerImpl.this.setOuterShdwArray(param1Int, param1CTOuterShadowEffect);
          return cTOuterShadowEffect;
        }
        
        public void add(int param1Int, CTOuterShadowEffect param1CTOuterShadowEffect) {
          CTEffectContainerImpl.this.insertNewOuterShdw(param1Int).set((XmlObject)param1CTOuterShadowEffect);
        }
        
        public CTOuterShadowEffect remove(int param1Int) {
          CTOuterShadowEffect cTOuterShadowEffect = CTEffectContainerImpl.this.getOuterShdwArray(param1Int);
          CTEffectContainerImpl.this.removeOuterShdw(param1Int);
          return cTOuterShadowEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfOuterShdwArray();
        }
      };
      return new OuterShdwList();
    } 
  }
  
  @Deprecated
  public CTOuterShadowEffect[] getOuterShdwArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(OUTERSHDW$46, arrayList);
      CTOuterShadowEffect[] arrayOfCTOuterShadowEffect = new CTOuterShadowEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTOuterShadowEffect);
      return arrayOfCTOuterShadowEffect;
    } 
  }
  
  public CTOuterShadowEffect getOuterShdwArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTOuterShadowEffect cTOuterShadowEffect = null;
      cTOuterShadowEffect = (CTOuterShadowEffect)get_store().find_element_user(OUTERSHDW$46, paramInt);
      if (cTOuterShadowEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTOuterShadowEffect;
    } 
  }
  
  public int sizeOfOuterShdwArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(OUTERSHDW$46);
    } 
  }
  
  public void setOuterShdwArray(CTOuterShadowEffect[] paramArrayOfCTOuterShadowEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTOuterShadowEffect, OUTERSHDW$46);
  }
  
  public void setOuterShdwArray(int paramInt, CTOuterShadowEffect paramCTOuterShadowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTOuterShadowEffect, OUTERSHDW$46, paramInt, (short)2);
  }
  
  public CTOuterShadowEffect insertNewOuterShdw(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTOuterShadowEffect cTOuterShadowEffect = null;
      cTOuterShadowEffect = (CTOuterShadowEffect)get_store().insert_element_user(OUTERSHDW$46, paramInt);
      return cTOuterShadowEffect;
    } 
  }
  
  public CTOuterShadowEffect addNewOuterShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTOuterShadowEffect cTOuterShadowEffect = null;
      cTOuterShadowEffect = (CTOuterShadowEffect)get_store().add_element_user(OUTERSHDW$46);
      return cTOuterShadowEffect;
    } 
  }
  
  public void removeOuterShdw(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OUTERSHDW$46, paramInt);
    } 
  }
  
  public List<CTPresetShadowEffect> getPrstShdwList() {
    synchronized (monitor()) {
      check_orphaned();
      final class PrstShdwList extends AbstractList<CTPresetShadowEffect> {
        public CTPresetShadowEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getPrstShdwArray(param1Int);
        }
        
        public CTPresetShadowEffect set(int param1Int, CTPresetShadowEffect param1CTPresetShadowEffect) {
          CTPresetShadowEffect cTPresetShadowEffect = CTEffectContainerImpl.this.getPrstShdwArray(param1Int);
          CTEffectContainerImpl.this.setPrstShdwArray(param1Int, param1CTPresetShadowEffect);
          return cTPresetShadowEffect;
        }
        
        public void add(int param1Int, CTPresetShadowEffect param1CTPresetShadowEffect) {
          CTEffectContainerImpl.this.insertNewPrstShdw(param1Int).set((XmlObject)param1CTPresetShadowEffect);
        }
        
        public CTPresetShadowEffect remove(int param1Int) {
          CTPresetShadowEffect cTPresetShadowEffect = CTEffectContainerImpl.this.getPrstShdwArray(param1Int);
          CTEffectContainerImpl.this.removePrstShdw(param1Int);
          return cTPresetShadowEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfPrstShdwArray();
        }
      };
      return new PrstShdwList();
    } 
  }
  
  @Deprecated
  public CTPresetShadowEffect[] getPrstShdwArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(PRSTSHDW$48, arrayList);
      CTPresetShadowEffect[] arrayOfCTPresetShadowEffect = new CTPresetShadowEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTPresetShadowEffect);
      return arrayOfCTPresetShadowEffect;
    } 
  }
  
  public CTPresetShadowEffect getPrstShdwArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetShadowEffect cTPresetShadowEffect = null;
      cTPresetShadowEffect = (CTPresetShadowEffect)get_store().find_element_user(PRSTSHDW$48, paramInt);
      if (cTPresetShadowEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTPresetShadowEffect;
    } 
  }
  
  public int sizeOfPrstShdwArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(PRSTSHDW$48);
    } 
  }
  
  public void setPrstShdwArray(CTPresetShadowEffect[] paramArrayOfCTPresetShadowEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTPresetShadowEffect, PRSTSHDW$48);
  }
  
  public void setPrstShdwArray(int paramInt, CTPresetShadowEffect paramCTPresetShadowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTPresetShadowEffect, PRSTSHDW$48, paramInt, (short)2);
  }
  
  public CTPresetShadowEffect insertNewPrstShdw(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetShadowEffect cTPresetShadowEffect = null;
      cTPresetShadowEffect = (CTPresetShadowEffect)get_store().insert_element_user(PRSTSHDW$48, paramInt);
      return cTPresetShadowEffect;
    } 
  }
  
  public CTPresetShadowEffect addNewPrstShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetShadowEffect cTPresetShadowEffect = null;
      cTPresetShadowEffect = (CTPresetShadowEffect)get_store().add_element_user(PRSTSHDW$48);
      return cTPresetShadowEffect;
    } 
  }
  
  public void removePrstShdw(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PRSTSHDW$48, paramInt);
    } 
  }
  
  public List<CTReflectionEffect> getReflectionList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ReflectionList extends AbstractList<CTReflectionEffect> {
        public CTReflectionEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getReflectionArray(param1Int);
        }
        
        public CTReflectionEffect set(int param1Int, CTReflectionEffect param1CTReflectionEffect) {
          CTReflectionEffect cTReflectionEffect = CTEffectContainerImpl.this.getReflectionArray(param1Int);
          CTEffectContainerImpl.this.setReflectionArray(param1Int, param1CTReflectionEffect);
          return cTReflectionEffect;
        }
        
        public void add(int param1Int, CTReflectionEffect param1CTReflectionEffect) {
          CTEffectContainerImpl.this.insertNewReflection(param1Int).set((XmlObject)param1CTReflectionEffect);
        }
        
        public CTReflectionEffect remove(int param1Int) {
          CTReflectionEffect cTReflectionEffect = CTEffectContainerImpl.this.getReflectionArray(param1Int);
          CTEffectContainerImpl.this.removeReflection(param1Int);
          return cTReflectionEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfReflectionArray();
        }
      };
      return new ReflectionList();
    } 
  }
  
  @Deprecated
  public CTReflectionEffect[] getReflectionArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(REFLECTION$50, arrayList);
      CTReflectionEffect[] arrayOfCTReflectionEffect = new CTReflectionEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTReflectionEffect);
      return arrayOfCTReflectionEffect;
    } 
  }
  
  public CTReflectionEffect getReflectionArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTReflectionEffect cTReflectionEffect = null;
      cTReflectionEffect = (CTReflectionEffect)get_store().find_element_user(REFLECTION$50, paramInt);
      if (cTReflectionEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTReflectionEffect;
    } 
  }
  
  public int sizeOfReflectionArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(REFLECTION$50);
    } 
  }
  
  public void setReflectionArray(CTReflectionEffect[] paramArrayOfCTReflectionEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTReflectionEffect, REFLECTION$50);
  }
  
  public void setReflectionArray(int paramInt, CTReflectionEffect paramCTReflectionEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTReflectionEffect, REFLECTION$50, paramInt, (short)2);
  }
  
  public CTReflectionEffect insertNewReflection(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTReflectionEffect cTReflectionEffect = null;
      cTReflectionEffect = (CTReflectionEffect)get_store().insert_element_user(REFLECTION$50, paramInt);
      return cTReflectionEffect;
    } 
  }
  
  public CTReflectionEffect addNewReflection() {
    synchronized (monitor()) {
      check_orphaned();
      CTReflectionEffect cTReflectionEffect = null;
      cTReflectionEffect = (CTReflectionEffect)get_store().add_element_user(REFLECTION$50);
      return cTReflectionEffect;
    } 
  }
  
  public void removeReflection(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REFLECTION$50, paramInt);
    } 
  }
  
  public List<CTRelativeOffsetEffect> getRelOffList() {
    synchronized (monitor()) {
      check_orphaned();
      final class RelOffList extends AbstractList<CTRelativeOffsetEffect> {
        public CTRelativeOffsetEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getRelOffArray(param1Int);
        }
        
        public CTRelativeOffsetEffect set(int param1Int, CTRelativeOffsetEffect param1CTRelativeOffsetEffect) {
          CTRelativeOffsetEffect cTRelativeOffsetEffect = CTEffectContainerImpl.this.getRelOffArray(param1Int);
          CTEffectContainerImpl.this.setRelOffArray(param1Int, param1CTRelativeOffsetEffect);
          return cTRelativeOffsetEffect;
        }
        
        public void add(int param1Int, CTRelativeOffsetEffect param1CTRelativeOffsetEffect) {
          CTEffectContainerImpl.this.insertNewRelOff(param1Int).set((XmlObject)param1CTRelativeOffsetEffect);
        }
        
        public CTRelativeOffsetEffect remove(int param1Int) {
          CTRelativeOffsetEffect cTRelativeOffsetEffect = CTEffectContainerImpl.this.getRelOffArray(param1Int);
          CTEffectContainerImpl.this.removeRelOff(param1Int);
          return cTRelativeOffsetEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfRelOffArray();
        }
      };
      return new RelOffList();
    } 
  }
  
  @Deprecated
  public CTRelativeOffsetEffect[] getRelOffArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(RELOFF$52, arrayList);
      CTRelativeOffsetEffect[] arrayOfCTRelativeOffsetEffect = new CTRelativeOffsetEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTRelativeOffsetEffect);
      return arrayOfCTRelativeOffsetEffect;
    } 
  }
  
  public CTRelativeOffsetEffect getRelOffArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTRelativeOffsetEffect cTRelativeOffsetEffect = null;
      cTRelativeOffsetEffect = (CTRelativeOffsetEffect)get_store().find_element_user(RELOFF$52, paramInt);
      if (cTRelativeOffsetEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTRelativeOffsetEffect;
    } 
  }
  
  public int sizeOfRelOffArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(RELOFF$52);
    } 
  }
  
  public void setRelOffArray(CTRelativeOffsetEffect[] paramArrayOfCTRelativeOffsetEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTRelativeOffsetEffect, RELOFF$52);
  }
  
  public void setRelOffArray(int paramInt, CTRelativeOffsetEffect paramCTRelativeOffsetEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTRelativeOffsetEffect, RELOFF$52, paramInt, (short)2);
  }
  
  public CTRelativeOffsetEffect insertNewRelOff(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTRelativeOffsetEffect cTRelativeOffsetEffect = null;
      cTRelativeOffsetEffect = (CTRelativeOffsetEffect)get_store().insert_element_user(RELOFF$52, paramInt);
      return cTRelativeOffsetEffect;
    } 
  }
  
  public CTRelativeOffsetEffect addNewRelOff() {
    synchronized (monitor()) {
      check_orphaned();
      CTRelativeOffsetEffect cTRelativeOffsetEffect = null;
      cTRelativeOffsetEffect = (CTRelativeOffsetEffect)get_store().add_element_user(RELOFF$52);
      return cTRelativeOffsetEffect;
    } 
  }
  
  public void removeRelOff(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(RELOFF$52, paramInt);
    } 
  }
  
  public List<CTSoftEdgesEffect> getSoftEdgeList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SoftEdgeList extends AbstractList<CTSoftEdgesEffect> {
        public CTSoftEdgesEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getSoftEdgeArray(param1Int);
        }
        
        public CTSoftEdgesEffect set(int param1Int, CTSoftEdgesEffect param1CTSoftEdgesEffect) {
          CTSoftEdgesEffect cTSoftEdgesEffect = CTEffectContainerImpl.this.getSoftEdgeArray(param1Int);
          CTEffectContainerImpl.this.setSoftEdgeArray(param1Int, param1CTSoftEdgesEffect);
          return cTSoftEdgesEffect;
        }
        
        public void add(int param1Int, CTSoftEdgesEffect param1CTSoftEdgesEffect) {
          CTEffectContainerImpl.this.insertNewSoftEdge(param1Int).set((XmlObject)param1CTSoftEdgesEffect);
        }
        
        public CTSoftEdgesEffect remove(int param1Int) {
          CTSoftEdgesEffect cTSoftEdgesEffect = CTEffectContainerImpl.this.getSoftEdgeArray(param1Int);
          CTEffectContainerImpl.this.removeSoftEdge(param1Int);
          return cTSoftEdgesEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfSoftEdgeArray();
        }
      };
      return new SoftEdgeList();
    } 
  }
  
  @Deprecated
  public CTSoftEdgesEffect[] getSoftEdgeArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SOFTEDGE$54, arrayList);
      CTSoftEdgesEffect[] arrayOfCTSoftEdgesEffect = new CTSoftEdgesEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSoftEdgesEffect);
      return arrayOfCTSoftEdgesEffect;
    } 
  }
  
  public CTSoftEdgesEffect getSoftEdgeArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSoftEdgesEffect cTSoftEdgesEffect = null;
      cTSoftEdgesEffect = (CTSoftEdgesEffect)get_store().find_element_user(SOFTEDGE$54, paramInt);
      if (cTSoftEdgesEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTSoftEdgesEffect;
    } 
  }
  
  public int sizeOfSoftEdgeArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SOFTEDGE$54);
    } 
  }
  
  public void setSoftEdgeArray(CTSoftEdgesEffect[] paramArrayOfCTSoftEdgesEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSoftEdgesEffect, SOFTEDGE$54);
  }
  
  public void setSoftEdgeArray(int paramInt, CTSoftEdgesEffect paramCTSoftEdgesEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTSoftEdgesEffect, SOFTEDGE$54, paramInt, (short)2);
  }
  
  public CTSoftEdgesEffect insertNewSoftEdge(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSoftEdgesEffect cTSoftEdgesEffect = null;
      cTSoftEdgesEffect = (CTSoftEdgesEffect)get_store().insert_element_user(SOFTEDGE$54, paramInt);
      return cTSoftEdgesEffect;
    } 
  }
  
  public CTSoftEdgesEffect addNewSoftEdge() {
    synchronized (monitor()) {
      check_orphaned();
      CTSoftEdgesEffect cTSoftEdgesEffect = null;
      cTSoftEdgesEffect = (CTSoftEdgesEffect)get_store().add_element_user(SOFTEDGE$54);
      return cTSoftEdgesEffect;
    } 
  }
  
  public void removeSoftEdge(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SOFTEDGE$54, paramInt);
    } 
  }
  
  public List<CTTintEffect> getTintList() {
    synchronized (monitor()) {
      check_orphaned();
      final class TintList extends AbstractList<CTTintEffect> {
        public CTTintEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getTintArray(param1Int);
        }
        
        public CTTintEffect set(int param1Int, CTTintEffect param1CTTintEffect) {
          CTTintEffect cTTintEffect = CTEffectContainerImpl.this.getTintArray(param1Int);
          CTEffectContainerImpl.this.setTintArray(param1Int, param1CTTintEffect);
          return cTTintEffect;
        }
        
        public void add(int param1Int, CTTintEffect param1CTTintEffect) {
          CTEffectContainerImpl.this.insertNewTint(param1Int).set((XmlObject)param1CTTintEffect);
        }
        
        public CTTintEffect remove(int param1Int) {
          CTTintEffect cTTintEffect = CTEffectContainerImpl.this.getTintArray(param1Int);
          CTEffectContainerImpl.this.removeTint(param1Int);
          return cTTintEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfTintArray();
        }
      };
      return new TintList();
    } 
  }
  
  @Deprecated
  public CTTintEffect[] getTintArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(TINT$56, arrayList);
      CTTintEffect[] arrayOfCTTintEffect = new CTTintEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTTintEffect);
      return arrayOfCTTintEffect;
    } 
  }
  
  public CTTintEffect getTintArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTTintEffect cTTintEffect = null;
      cTTintEffect = (CTTintEffect)get_store().find_element_user(TINT$56, paramInt);
      if (cTTintEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTTintEffect;
    } 
  }
  
  public int sizeOfTintArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(TINT$56);
    } 
  }
  
  public void setTintArray(CTTintEffect[] paramArrayOfCTTintEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTTintEffect, TINT$56);
  }
  
  public void setTintArray(int paramInt, CTTintEffect paramCTTintEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTTintEffect, TINT$56, paramInt, (short)2);
  }
  
  public CTTintEffect insertNewTint(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTTintEffect cTTintEffect = null;
      cTTintEffect = (CTTintEffect)get_store().insert_element_user(TINT$56, paramInt);
      return cTTintEffect;
    } 
  }
  
  public CTTintEffect addNewTint() {
    synchronized (monitor()) {
      check_orphaned();
      CTTintEffect cTTintEffect = null;
      cTTintEffect = (CTTintEffect)get_store().add_element_user(TINT$56);
      return cTTintEffect;
    } 
  }
  
  public void removeTint(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(TINT$56, paramInt);
    } 
  }
  
  public List<CTTransformEffect> getXfrmList() {
    synchronized (monitor()) {
      check_orphaned();
      final class XfrmList extends AbstractList<CTTransformEffect> {
        public CTTransformEffect get(int param1Int) {
          return CTEffectContainerImpl.this.getXfrmArray(param1Int);
        }
        
        public CTTransformEffect set(int param1Int, CTTransformEffect param1CTTransformEffect) {
          CTTransformEffect cTTransformEffect = CTEffectContainerImpl.this.getXfrmArray(param1Int);
          CTEffectContainerImpl.this.setXfrmArray(param1Int, param1CTTransformEffect);
          return cTTransformEffect;
        }
        
        public void add(int param1Int, CTTransformEffect param1CTTransformEffect) {
          CTEffectContainerImpl.this.insertNewXfrm(param1Int).set((XmlObject)param1CTTransformEffect);
        }
        
        public CTTransformEffect remove(int param1Int) {
          CTTransformEffect cTTransformEffect = CTEffectContainerImpl.this.getXfrmArray(param1Int);
          CTEffectContainerImpl.this.removeXfrm(param1Int);
          return cTTransformEffect;
        }
        
        public int size() {
          return CTEffectContainerImpl.this.sizeOfXfrmArray();
        }
      };
      return new XfrmList();
    } 
  }
  
  @Deprecated
  public CTTransformEffect[] getXfrmArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(XFRM$58, arrayList);
      CTTransformEffect[] arrayOfCTTransformEffect = new CTTransformEffect[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTTransformEffect);
      return arrayOfCTTransformEffect;
    } 
  }
  
  public CTTransformEffect getXfrmArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTTransformEffect cTTransformEffect = null;
      cTTransformEffect = (CTTransformEffect)get_store().find_element_user(XFRM$58, paramInt);
      if (cTTransformEffect == null)
        throw new IndexOutOfBoundsException(); 
      return cTTransformEffect;
    } 
  }
  
  public int sizeOfXfrmArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(XFRM$58);
    } 
  }
  
  public void setXfrmArray(CTTransformEffect[] paramArrayOfCTTransformEffect) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTTransformEffect, XFRM$58);
  }
  
  public void setXfrmArray(int paramInt, CTTransformEffect paramCTTransformEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTTransformEffect, XFRM$58, paramInt, (short)2);
  }
  
  public CTTransformEffect insertNewXfrm(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTTransformEffect cTTransformEffect = null;
      cTTransformEffect = (CTTransformEffect)get_store().insert_element_user(XFRM$58, paramInt);
      return cTTransformEffect;
    } 
  }
  
  public CTTransformEffect addNewXfrm() {
    synchronized (monitor()) {
      check_orphaned();
      CTTransformEffect cTTransformEffect = null;
      cTTransformEffect = (CTTransformEffect)get_store().add_element_user(XFRM$58);
      return cTTransformEffect;
    } 
  }
  
  public void removeXfrm(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(XFRM$58, paramInt);
    } 
  }
  
  public STEffectContainerType.Enum getType() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TYPE$60);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_default_attribute_value(TYPE$60); 
      if (simpleValue == null)
        return null; 
      return (STEffectContainerType.Enum)simpleValue.getEnumValue();
    } 
  }
  
  public STEffectContainerType xgetType() {
    synchronized (monitor()) {
      check_orphaned();
      STEffectContainerType sTEffectContainerType = null;
      sTEffectContainerType = (STEffectContainerType)get_store().find_attribute_user(TYPE$60);
      if (sTEffectContainerType == null)
        sTEffectContainerType = (STEffectContainerType)get_default_attribute_value(TYPE$60); 
      return sTEffectContainerType;
    } 
  }
  
  public boolean isSetType() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(TYPE$60) != null);
    } 
  }
  
  public void setType(STEffectContainerType.Enum paramEnum) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(TYPE$60);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(TYPE$60); 
      simpleValue.setEnumValue((StringEnumAbstractBase)paramEnum);
    } 
  }
  
  public void xsetType(STEffectContainerType paramSTEffectContainerType) {
    synchronized (monitor()) {
      check_orphaned();
      STEffectContainerType sTEffectContainerType = null;
      sTEffectContainerType = (STEffectContainerType)get_store().find_attribute_user(TYPE$60);
      if (sTEffectContainerType == null)
        sTEffectContainerType = (STEffectContainerType)get_store().add_attribute_user(TYPE$60); 
      sTEffectContainerType.set((XmlObject)paramSTEffectContainerType);
    } 
  }
  
  public void unsetType() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(TYPE$60);
    } 
  }
  
  public String getName() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(NAME$62);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlToken xgetName() {
    synchronized (monitor()) {
      check_orphaned();
      XmlToken xmlToken = null;
      xmlToken = (XmlToken)get_store().find_attribute_user(NAME$62);
      return xmlToken;
    } 
  }
  
  public boolean isSetName() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(NAME$62) != null);
    } 
  }
  
  public void setName(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(NAME$62);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(NAME$62); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetName(XmlToken paramXmlToken) {
    synchronized (monitor()) {
      check_orphaned();
      XmlToken xmlToken = null;
      xmlToken = (XmlToken)get_store().find_attribute_user(NAME$62);
      if (xmlToken == null)
        xmlToken = (XmlToken)get_store().add_attribute_user(NAME$62); 
      xmlToken.set((XmlObject)paramXmlToken);
    } 
  }
  
  public void unsetName() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(NAME$62);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTEffectContainerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */