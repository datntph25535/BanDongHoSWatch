package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;
import org.w3c.dom.Node;

public interface CTAreaSer extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTAreaSer.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctareaser4f73type");
  
  CTUnsignedInt getIdx();
  
  void setIdx(CTUnsignedInt paramCTUnsignedInt);
  
  CTUnsignedInt addNewIdx();
  
  CTUnsignedInt getOrder();
  
  void setOrder(CTUnsignedInt paramCTUnsignedInt);
  
  CTUnsignedInt addNewOrder();
  
  CTSerTx getTx();
  
  boolean isSetTx();
  
  void setTx(CTSerTx paramCTSerTx);
  
  CTSerTx addNewTx();
  
  void unsetTx();
  
  CTShapeProperties getSpPr();
  
  boolean isSetSpPr();
  
  void setSpPr(CTShapeProperties paramCTShapeProperties);
  
  CTShapeProperties addNewSpPr();
  
  void unsetSpPr();
  
  CTPictureOptions getPictureOptions();
  
  boolean isSetPictureOptions();
  
  void setPictureOptions(CTPictureOptions paramCTPictureOptions);
  
  CTPictureOptions addNewPictureOptions();
  
  void unsetPictureOptions();
  
  List<CTDPt> getDPtList();
  
  @Deprecated
  CTDPt[] getDPtArray();
  
  CTDPt getDPtArray(int paramInt);
  
  int sizeOfDPtArray();
  
  void setDPtArray(CTDPt[] paramArrayOfCTDPt);
  
  void setDPtArray(int paramInt, CTDPt paramCTDPt);
  
  CTDPt insertNewDPt(int paramInt);
  
  CTDPt addNewDPt();
  
  void removeDPt(int paramInt);
  
  CTDLbls getDLbls();
  
  boolean isSetDLbls();
  
  void setDLbls(CTDLbls paramCTDLbls);
  
  CTDLbls addNewDLbls();
  
  void unsetDLbls();
  
  List<CTTrendline> getTrendlineList();
  
  @Deprecated
  CTTrendline[] getTrendlineArray();
  
  CTTrendline getTrendlineArray(int paramInt);
  
  int sizeOfTrendlineArray();
  
  void setTrendlineArray(CTTrendline[] paramArrayOfCTTrendline);
  
  void setTrendlineArray(int paramInt, CTTrendline paramCTTrendline);
  
  CTTrendline insertNewTrendline(int paramInt);
  
  CTTrendline addNewTrendline();
  
  void removeTrendline(int paramInt);
  
  List<CTErrBars> getErrBarsList();
  
  @Deprecated
  CTErrBars[] getErrBarsArray();
  
  CTErrBars getErrBarsArray(int paramInt);
  
  int sizeOfErrBarsArray();
  
  void setErrBarsArray(CTErrBars[] paramArrayOfCTErrBars);
  
  void setErrBarsArray(int paramInt, CTErrBars paramCTErrBars);
  
  CTErrBars insertNewErrBars(int paramInt);
  
  CTErrBars addNewErrBars();
  
  void removeErrBars(int paramInt);
  
  CTAxDataSource getCat();
  
  boolean isSetCat();
  
  void setCat(CTAxDataSource paramCTAxDataSource);
  
  CTAxDataSource addNewCat();
  
  void unsetCat();
  
  CTNumDataSource getVal();
  
  boolean isSetVal();
  
  void setVal(CTNumDataSource paramCTNumDataSource);
  
  CTNumDataSource addNewVal();
  
  void unsetVal();
  
  CTExtensionList getExtLst();
  
  boolean isSetExtLst();
  
  void setExtLst(CTExtensionList paramCTExtensionList);
  
  CTExtensionList addNewExtLst();
  
  void unsetExtLst();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTAreaSer.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTAreaSer newInstance() {
      return (CTAreaSer)getTypeLoader().newInstance(CTAreaSer.type, null);
    }
    
    public static CTAreaSer newInstance(XmlOptions param1XmlOptions) {
      return (CTAreaSer)getTypeLoader().newInstance(CTAreaSer.type, param1XmlOptions);
    }
    
    public static CTAreaSer parse(String param1String) throws XmlException {
      return (CTAreaSer)getTypeLoader().parse(param1String, CTAreaSer.type, null);
    }
    
    public static CTAreaSer parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTAreaSer)getTypeLoader().parse(param1String, CTAreaSer.type, param1XmlOptions);
    }
    
    public static CTAreaSer parse(File param1File) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1File, CTAreaSer.type, null);
    }
    
    public static CTAreaSer parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1File, CTAreaSer.type, param1XmlOptions);
    }
    
    public static CTAreaSer parse(URL param1URL) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1URL, CTAreaSer.type, null);
    }
    
    public static CTAreaSer parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1URL, CTAreaSer.type, param1XmlOptions);
    }
    
    public static CTAreaSer parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1InputStream, CTAreaSer.type, null);
    }
    
    public static CTAreaSer parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1InputStream, CTAreaSer.type, param1XmlOptions);
    }
    
    public static CTAreaSer parse(Reader param1Reader) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1Reader, CTAreaSer.type, null);
    }
    
    public static CTAreaSer parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTAreaSer)getTypeLoader().parse(param1Reader, CTAreaSer.type, param1XmlOptions);
    }
    
    public static CTAreaSer parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTAreaSer)getTypeLoader().parse(param1XMLStreamReader, CTAreaSer.type, null);
    }
    
    public static CTAreaSer parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTAreaSer)getTypeLoader().parse(param1XMLStreamReader, CTAreaSer.type, param1XmlOptions);
    }
    
    public static CTAreaSer parse(Node param1Node) throws XmlException {
      return (CTAreaSer)getTypeLoader().parse(param1Node, CTAreaSer.type, null);
    }
    
    public static CTAreaSer parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTAreaSer)getTypeLoader().parse(param1Node, CTAreaSer.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTAreaSer parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTAreaSer)getTypeLoader().parse(param1XMLInputStream, CTAreaSer.type, null);
    }
    
    @Deprecated
    public static CTAreaSer parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTAreaSer)getTypeLoader().parse(param1XMLInputStream, CTAreaSer.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTAreaSer.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTAreaSer.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTAreaSer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */