package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.StringEnumAbstractBase;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface STRadarStyle extends XmlString {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STRadarStyle.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("stradarstyle3dc1type");
  
  public static final Enum STANDARD = Enum.forString("standard");
  
  public static final Enum MARKER = Enum.forString("marker");
  
  public static final Enum FILLED = Enum.forString("filled");
  
  public static final int INT_STANDARD = 1;
  
  public static final int INT_MARKER = 2;
  
  public static final int INT_FILLED = 3;
  
  StringEnumAbstractBase enumValue();
  
  void set(StringEnumAbstractBase paramStringEnumAbstractBase);
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    public static STRadarStyle newValue(Object param1Object) {
      return (STRadarStyle)STRadarStyle.type.newValue(param1Object);
    }
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(STRadarStyle.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static STRadarStyle newInstance() {
      return (STRadarStyle)getTypeLoader().newInstance(STRadarStyle.type, null);
    }
    
    public static STRadarStyle newInstance(XmlOptions param1XmlOptions) {
      return (STRadarStyle)getTypeLoader().newInstance(STRadarStyle.type, param1XmlOptions);
    }
    
    public static STRadarStyle parse(String param1String) throws XmlException {
      return (STRadarStyle)getTypeLoader().parse(param1String, STRadarStyle.type, null);
    }
    
    public static STRadarStyle parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (STRadarStyle)getTypeLoader().parse(param1String, STRadarStyle.type, param1XmlOptions);
    }
    
    public static STRadarStyle parse(File param1File) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1File, STRadarStyle.type, null);
    }
    
    public static STRadarStyle parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1File, STRadarStyle.type, param1XmlOptions);
    }
    
    public static STRadarStyle parse(URL param1URL) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1URL, STRadarStyle.type, null);
    }
    
    public static STRadarStyle parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1URL, STRadarStyle.type, param1XmlOptions);
    }
    
    public static STRadarStyle parse(InputStream param1InputStream) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1InputStream, STRadarStyle.type, null);
    }
    
    public static STRadarStyle parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1InputStream, STRadarStyle.type, param1XmlOptions);
    }
    
    public static STRadarStyle parse(Reader param1Reader) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1Reader, STRadarStyle.type, null);
    }
    
    public static STRadarStyle parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STRadarStyle)getTypeLoader().parse(param1Reader, STRadarStyle.type, param1XmlOptions);
    }
    
    public static STRadarStyle parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (STRadarStyle)getTypeLoader().parse(param1XMLStreamReader, STRadarStyle.type, null);
    }
    
    public static STRadarStyle parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (STRadarStyle)getTypeLoader().parse(param1XMLStreamReader, STRadarStyle.type, param1XmlOptions);
    }
    
    public static STRadarStyle parse(Node param1Node) throws XmlException {
      return (STRadarStyle)getTypeLoader().parse(param1Node, STRadarStyle.type, null);
    }
    
    public static STRadarStyle parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (STRadarStyle)getTypeLoader().parse(param1Node, STRadarStyle.type, param1XmlOptions);
    }
    
    @Deprecated
    public static STRadarStyle parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (STRadarStyle)getTypeLoader().parse(param1XMLInputStream, STRadarStyle.type, null);
    }
    
    @Deprecated
    public static STRadarStyle parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (STRadarStyle)getTypeLoader().parse(param1XMLInputStream, STRadarStyle.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, STRadarStyle.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, STRadarStyle.type, param1XmlOptions);
    }
  }
  
  public static final class Enum extends StringEnumAbstractBase {
    static final int INT_STANDARD = 1;
    
    static final int INT_MARKER = 2;
    
    static final int INT_FILLED = 3;
    
    public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table((StringEnumAbstractBase[])new Enum[] { new Enum("standard", 1), new Enum("marker", 2), new Enum("filled", 3) });
    
    private static final long serialVersionUID = 1L;
    
    public static Enum forString(String param1String) {
      return (Enum)table.forString(param1String);
    }
    
    public static Enum forInt(int param1Int) {
      return (Enum)table.forInt(param1Int);
    }
    
    private Enum(String param1String, int param1Int) {
      super(param1String, param1Int);
    }
    
    private Object readResolve() {
      return forInt(intValue());
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\STRadarStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */