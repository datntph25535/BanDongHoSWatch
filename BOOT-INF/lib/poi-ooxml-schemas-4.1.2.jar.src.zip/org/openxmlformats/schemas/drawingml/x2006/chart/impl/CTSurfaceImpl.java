package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPictureOptions;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSurface;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;

public class CTSurfaceImpl extends XmlComplexContentImpl implements CTSurface {
  private static final long serialVersionUID = 1L;
  
  private static final QName THICKNESS$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "thickness");
  
  private static final QName SPPR$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "spPr");
  
  private static final QName PICTUREOPTIONS$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "pictureOptions");
  
  private static final QName EXTLST$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTSurfaceImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTUnsignedInt getThickness() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(THICKNESS$0, 0);
      if (cTUnsignedInt == null)
        return null; 
      return cTUnsignedInt;
    } 
  }
  
  public boolean isSetThickness() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(THICKNESS$0) != 0);
    } 
  }
  
  public void setThickness(CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, THICKNESS$0, 0, (short)1);
  }
  
  public CTUnsignedInt addNewThickness() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(THICKNESS$0);
      return cTUnsignedInt;
    } 
  }
  
  public void unsetThickness() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(THICKNESS$0, 0);
    } 
  }
  
  public CTShapeProperties getSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().find_element_user(SPPR$2, 0);
      if (cTShapeProperties == null)
        return null; 
      return cTShapeProperties;
    } 
  }
  
  public boolean isSetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SPPR$2) != 0);
    } 
  }
  
  public void setSpPr(CTShapeProperties paramCTShapeProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTShapeProperties, SPPR$2, 0, (short)1);
  }
  
  public CTShapeProperties addNewSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      CTShapeProperties cTShapeProperties = null;
      cTShapeProperties = (CTShapeProperties)get_store().add_element_user(SPPR$2);
      return cTShapeProperties;
    } 
  }
  
  public void unsetSpPr() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SPPR$2, 0);
    } 
  }
  
  public CTPictureOptions getPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      CTPictureOptions cTPictureOptions = null;
      cTPictureOptions = (CTPictureOptions)get_store().find_element_user(PICTUREOPTIONS$4, 0);
      if (cTPictureOptions == null)
        return null; 
      return cTPictureOptions;
    } 
  }
  
  public boolean isSetPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PICTUREOPTIONS$4) != 0);
    } 
  }
  
  public void setPictureOptions(CTPictureOptions paramCTPictureOptions) {
    generatedSetterHelperImpl((XmlObject)paramCTPictureOptions, PICTUREOPTIONS$4, 0, (short)1);
  }
  
  public CTPictureOptions addNewPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      CTPictureOptions cTPictureOptions = null;
      cTPictureOptions = (CTPictureOptions)get_store().add_element_user(PICTUREOPTIONS$4);
      return cTPictureOptions;
    } 
  }
  
  public void unsetPictureOptions() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PICTUREOPTIONS$4, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$6, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$6) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$6, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$6);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$6, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTSurfaceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */