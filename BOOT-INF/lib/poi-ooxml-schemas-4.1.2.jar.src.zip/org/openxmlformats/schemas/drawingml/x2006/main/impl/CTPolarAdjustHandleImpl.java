package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAdjPoint2D;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPolarAdjustHandle;
import org.openxmlformats.schemas.drawingml.x2006.main.STAdjAngle;
import org.openxmlformats.schemas.drawingml.x2006.main.STAdjCoordinate;
import org.openxmlformats.schemas.drawingml.x2006.main.STGeomGuideName;

public class CTPolarAdjustHandleImpl extends XmlComplexContentImpl implements CTPolarAdjustHandle {
  private static final long serialVersionUID = 1L;
  
  private static final QName POS$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "pos");
  
  private static final QName GDREFR$2 = new QName("", "gdRefR");
  
  private static final QName MINR$4 = new QName("", "minR");
  
  private static final QName MAXR$6 = new QName("", "maxR");
  
  private static final QName GDREFANG$8 = new QName("", "gdRefAng");
  
  private static final QName MINANG$10 = new QName("", "minAng");
  
  private static final QName MAXANG$12 = new QName("", "maxAng");
  
  public CTPolarAdjustHandleImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTAdjPoint2D getPos() {
    synchronized (monitor()) {
      check_orphaned();
      CTAdjPoint2D cTAdjPoint2D = null;
      cTAdjPoint2D = (CTAdjPoint2D)get_store().find_element_user(POS$0, 0);
      if (cTAdjPoint2D == null)
        return null; 
      return cTAdjPoint2D;
    } 
  }
  
  public void setPos(CTAdjPoint2D paramCTAdjPoint2D) {
    generatedSetterHelperImpl((XmlObject)paramCTAdjPoint2D, POS$0, 0, (short)1);
  }
  
  public CTAdjPoint2D addNewPos() {
    synchronized (monitor()) {
      check_orphaned();
      CTAdjPoint2D cTAdjPoint2D = null;
      cTAdjPoint2D = (CTAdjPoint2D)get_store().add_element_user(POS$0);
      return cTAdjPoint2D;
    } 
  }
  
  public String getGdRefR() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(GDREFR$2);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public STGeomGuideName xgetGdRefR() {
    synchronized (monitor()) {
      check_orphaned();
      STGeomGuideName sTGeomGuideName = null;
      sTGeomGuideName = (STGeomGuideName)get_store().find_attribute_user(GDREFR$2);
      return sTGeomGuideName;
    } 
  }
  
  public boolean isSetGdRefR() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(GDREFR$2) != null);
    } 
  }
  
  public void setGdRefR(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(GDREFR$2);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(GDREFR$2); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetGdRefR(STGeomGuideName paramSTGeomGuideName) {
    synchronized (monitor()) {
      check_orphaned();
      STGeomGuideName sTGeomGuideName = null;
      sTGeomGuideName = (STGeomGuideName)get_store().find_attribute_user(GDREFR$2);
      if (sTGeomGuideName == null)
        sTGeomGuideName = (STGeomGuideName)get_store().add_attribute_user(GDREFR$2); 
      sTGeomGuideName.set((XmlObject)paramSTGeomGuideName);
    } 
  }
  
  public void unsetGdRefR() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(GDREFR$2);
    } 
  }
  
  public Object getMinR() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MINR$4);
      if (simpleValue == null)
        return null; 
      return simpleValue.getObjectValue();
    } 
  }
  
  public STAdjCoordinate xgetMinR() {
    synchronized (monitor()) {
      check_orphaned();
      STAdjCoordinate sTAdjCoordinate = null;
      sTAdjCoordinate = (STAdjCoordinate)get_store().find_attribute_user(MINR$4);
      return sTAdjCoordinate;
    } 
  }
  
  public boolean isSetMinR() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(MINR$4) != null);
    } 
  }
  
  public void setMinR(Object paramObject) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MINR$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(MINR$4); 
      simpleValue.setObjectValue(paramObject);
    } 
  }
  
  public void xsetMinR(STAdjCoordinate paramSTAdjCoordinate) {
    synchronized (monitor()) {
      check_orphaned();
      STAdjCoordinate sTAdjCoordinate = null;
      sTAdjCoordinate = (STAdjCoordinate)get_store().find_attribute_user(MINR$4);
      if (sTAdjCoordinate == null)
        sTAdjCoordinate = (STAdjCoordinate)get_store().add_attribute_user(MINR$4); 
      sTAdjCoordinate.set((XmlObject)paramSTAdjCoordinate);
    } 
  }
  
  public void unsetMinR() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(MINR$4);
    } 
  }
  
  public Object getMaxR() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MAXR$6);
      if (simpleValue == null)
        return null; 
      return simpleValue.getObjectValue();
    } 
  }
  
  public STAdjCoordinate xgetMaxR() {
    synchronized (monitor()) {
      check_orphaned();
      STAdjCoordinate sTAdjCoordinate = null;
      sTAdjCoordinate = (STAdjCoordinate)get_store().find_attribute_user(MAXR$6);
      return sTAdjCoordinate;
    } 
  }
  
  public boolean isSetMaxR() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(MAXR$6) != null);
    } 
  }
  
  public void setMaxR(Object paramObject) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MAXR$6);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(MAXR$6); 
      simpleValue.setObjectValue(paramObject);
    } 
  }
  
  public void xsetMaxR(STAdjCoordinate paramSTAdjCoordinate) {
    synchronized (monitor()) {
      check_orphaned();
      STAdjCoordinate sTAdjCoordinate = null;
      sTAdjCoordinate = (STAdjCoordinate)get_store().find_attribute_user(MAXR$6);
      if (sTAdjCoordinate == null)
        sTAdjCoordinate = (STAdjCoordinate)get_store().add_attribute_user(MAXR$6); 
      sTAdjCoordinate.set((XmlObject)paramSTAdjCoordinate);
    } 
  }
  
  public void unsetMaxR() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(MAXR$6);
    } 
  }
  
  public String getGdRefAng() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(GDREFANG$8);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public STGeomGuideName xgetGdRefAng() {
    synchronized (monitor()) {
      check_orphaned();
      STGeomGuideName sTGeomGuideName = null;
      sTGeomGuideName = (STGeomGuideName)get_store().find_attribute_user(GDREFANG$8);
      return sTGeomGuideName;
    } 
  }
  
  public boolean isSetGdRefAng() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(GDREFANG$8) != null);
    } 
  }
  
  public void setGdRefAng(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(GDREFANG$8);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(GDREFANG$8); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetGdRefAng(STGeomGuideName paramSTGeomGuideName) {
    synchronized (monitor()) {
      check_orphaned();
      STGeomGuideName sTGeomGuideName = null;
      sTGeomGuideName = (STGeomGuideName)get_store().find_attribute_user(GDREFANG$8);
      if (sTGeomGuideName == null)
        sTGeomGuideName = (STGeomGuideName)get_store().add_attribute_user(GDREFANG$8); 
      sTGeomGuideName.set((XmlObject)paramSTGeomGuideName);
    } 
  }
  
  public void unsetGdRefAng() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(GDREFANG$8);
    } 
  }
  
  public Object getMinAng() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MINANG$10);
      if (simpleValue == null)
        return null; 
      return simpleValue.getObjectValue();
    } 
  }
  
  public STAdjAngle xgetMinAng() {
    synchronized (monitor()) {
      check_orphaned();
      STAdjAngle sTAdjAngle = null;
      sTAdjAngle = (STAdjAngle)get_store().find_attribute_user(MINANG$10);
      return sTAdjAngle;
    } 
  }
  
  public boolean isSetMinAng() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(MINANG$10) != null);
    } 
  }
  
  public void setMinAng(Object paramObject) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MINANG$10);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(MINANG$10); 
      simpleValue.setObjectValue(paramObject);
    } 
  }
  
  public void xsetMinAng(STAdjAngle paramSTAdjAngle) {
    synchronized (monitor()) {
      check_orphaned();
      STAdjAngle sTAdjAngle = null;
      sTAdjAngle = (STAdjAngle)get_store().find_attribute_user(MINANG$10);
      if (sTAdjAngle == null)
        sTAdjAngle = (STAdjAngle)get_store().add_attribute_user(MINANG$10); 
      sTAdjAngle.set((XmlObject)paramSTAdjAngle);
    } 
  }
  
  public void unsetMinAng() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(MINANG$10);
    } 
  }
  
  public Object getMaxAng() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MAXANG$12);
      if (simpleValue == null)
        return null; 
      return simpleValue.getObjectValue();
    } 
  }
  
  public STAdjAngle xgetMaxAng() {
    synchronized (monitor()) {
      check_orphaned();
      STAdjAngle sTAdjAngle = null;
      sTAdjAngle = (STAdjAngle)get_store().find_attribute_user(MAXANG$12);
      return sTAdjAngle;
    } 
  }
  
  public boolean isSetMaxAng() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(MAXANG$12) != null);
    } 
  }
  
  public void setMaxAng(Object paramObject) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(MAXANG$12);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(MAXANG$12); 
      simpleValue.setObjectValue(paramObject);
    } 
  }
  
  public void xsetMaxAng(STAdjAngle paramSTAdjAngle) {
    synchronized (monitor()) {
      check_orphaned();
      STAdjAngle sTAdjAngle = null;
      sTAdjAngle = (STAdjAngle)get_store().find_attribute_user(MAXANG$12);
      if (sTAdjAngle == null)
        sTAdjAngle = (STAdjAngle)get_store().add_attribute_user(MAXANG$12); 
      sTAdjAngle.set((XmlObject)paramSTAdjAngle);
    } 
  }
  
  public void unsetMaxAng() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(MAXANG$12);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTPolarAdjustHandleImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */