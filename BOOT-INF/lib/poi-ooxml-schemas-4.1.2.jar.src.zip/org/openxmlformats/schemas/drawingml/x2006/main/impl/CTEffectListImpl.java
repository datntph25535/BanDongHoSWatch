package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTBlurEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTEffectList;
import org.openxmlformats.schemas.drawingml.x2006.main.CTFillOverlayEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTGlowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTInnerShadowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTOuterShadowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPresetShadowEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTReflectionEffect;
import org.openxmlformats.schemas.drawingml.x2006.main.CTSoftEdgesEffect;

public class CTEffectListImpl extends XmlComplexContentImpl implements CTEffectList {
  private static final long serialVersionUID = 1L;
  
  private static final QName BLUR$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "blur");
  
  private static final QName FILLOVERLAY$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "fillOverlay");
  
  private static final QName GLOW$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "glow");
  
  private static final QName INNERSHDW$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "innerShdw");
  
  private static final QName OUTERSHDW$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "outerShdw");
  
  private static final QName PRSTSHDW$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "prstShdw");
  
  private static final QName REFLECTION$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "reflection");
  
  private static final QName SOFTEDGE$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "softEdge");
  
  public CTEffectListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTBlurEffect getBlur() {
    synchronized (monitor()) {
      check_orphaned();
      CTBlurEffect cTBlurEffect = null;
      cTBlurEffect = (CTBlurEffect)get_store().find_element_user(BLUR$0, 0);
      if (cTBlurEffect == null)
        return null; 
      return cTBlurEffect;
    } 
  }
  
  public boolean isSetBlur() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(BLUR$0) != 0);
    } 
  }
  
  public void setBlur(CTBlurEffect paramCTBlurEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTBlurEffect, BLUR$0, 0, (short)1);
  }
  
  public CTBlurEffect addNewBlur() {
    synchronized (monitor()) {
      check_orphaned();
      CTBlurEffect cTBlurEffect = null;
      cTBlurEffect = (CTBlurEffect)get_store().add_element_user(BLUR$0);
      return cTBlurEffect;
    } 
  }
  
  public void unsetBlur() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BLUR$0, 0);
    } 
  }
  
  public CTFillOverlayEffect getFillOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      CTFillOverlayEffect cTFillOverlayEffect = null;
      cTFillOverlayEffect = (CTFillOverlayEffect)get_store().find_element_user(FILLOVERLAY$2, 0);
      if (cTFillOverlayEffect == null)
        return null; 
      return cTFillOverlayEffect;
    } 
  }
  
  public boolean isSetFillOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(FILLOVERLAY$2) != 0);
    } 
  }
  
  public void setFillOverlay(CTFillOverlayEffect paramCTFillOverlayEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTFillOverlayEffect, FILLOVERLAY$2, 0, (short)1);
  }
  
  public CTFillOverlayEffect addNewFillOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      CTFillOverlayEffect cTFillOverlayEffect = null;
      cTFillOverlayEffect = (CTFillOverlayEffect)get_store().add_element_user(FILLOVERLAY$2);
      return cTFillOverlayEffect;
    } 
  }
  
  public void unsetFillOverlay() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(FILLOVERLAY$2, 0);
    } 
  }
  
  public CTGlowEffect getGlow() {
    synchronized (monitor()) {
      check_orphaned();
      CTGlowEffect cTGlowEffect = null;
      cTGlowEffect = (CTGlowEffect)get_store().find_element_user(GLOW$4, 0);
      if (cTGlowEffect == null)
        return null; 
      return cTGlowEffect;
    } 
  }
  
  public boolean isSetGlow() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(GLOW$4) != 0);
    } 
  }
  
  public void setGlow(CTGlowEffect paramCTGlowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTGlowEffect, GLOW$4, 0, (short)1);
  }
  
  public CTGlowEffect addNewGlow() {
    synchronized (monitor()) {
      check_orphaned();
      CTGlowEffect cTGlowEffect = null;
      cTGlowEffect = (CTGlowEffect)get_store().add_element_user(GLOW$4);
      return cTGlowEffect;
    } 
  }
  
  public void unsetGlow() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GLOW$4, 0);
    } 
  }
  
  public CTInnerShadowEffect getInnerShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTInnerShadowEffect cTInnerShadowEffect = null;
      cTInnerShadowEffect = (CTInnerShadowEffect)get_store().find_element_user(INNERSHDW$6, 0);
      if (cTInnerShadowEffect == null)
        return null; 
      return cTInnerShadowEffect;
    } 
  }
  
  public boolean isSetInnerShdw() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(INNERSHDW$6) != 0);
    } 
  }
  
  public void setInnerShdw(CTInnerShadowEffect paramCTInnerShadowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTInnerShadowEffect, INNERSHDW$6, 0, (short)1);
  }
  
  public CTInnerShadowEffect addNewInnerShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTInnerShadowEffect cTInnerShadowEffect = null;
      cTInnerShadowEffect = (CTInnerShadowEffect)get_store().add_element_user(INNERSHDW$6);
      return cTInnerShadowEffect;
    } 
  }
  
  public void unsetInnerShdw() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(INNERSHDW$6, 0);
    } 
  }
  
  public CTOuterShadowEffect getOuterShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTOuterShadowEffect cTOuterShadowEffect = null;
      cTOuterShadowEffect = (CTOuterShadowEffect)get_store().find_element_user(OUTERSHDW$8, 0);
      if (cTOuterShadowEffect == null)
        return null; 
      return cTOuterShadowEffect;
    } 
  }
  
  public boolean isSetOuterShdw() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(OUTERSHDW$8) != 0);
    } 
  }
  
  public void setOuterShdw(CTOuterShadowEffect paramCTOuterShadowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTOuterShadowEffect, OUTERSHDW$8, 0, (short)1);
  }
  
  public CTOuterShadowEffect addNewOuterShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTOuterShadowEffect cTOuterShadowEffect = null;
      cTOuterShadowEffect = (CTOuterShadowEffect)get_store().add_element_user(OUTERSHDW$8);
      return cTOuterShadowEffect;
    } 
  }
  
  public void unsetOuterShdw() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OUTERSHDW$8, 0);
    } 
  }
  
  public CTPresetShadowEffect getPrstShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetShadowEffect cTPresetShadowEffect = null;
      cTPresetShadowEffect = (CTPresetShadowEffect)get_store().find_element_user(PRSTSHDW$10, 0);
      if (cTPresetShadowEffect == null)
        return null; 
      return cTPresetShadowEffect;
    } 
  }
  
  public boolean isSetPrstShdw() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(PRSTSHDW$10) != 0);
    } 
  }
  
  public void setPrstShdw(CTPresetShadowEffect paramCTPresetShadowEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTPresetShadowEffect, PRSTSHDW$10, 0, (short)1);
  }
  
  public CTPresetShadowEffect addNewPrstShdw() {
    synchronized (monitor()) {
      check_orphaned();
      CTPresetShadowEffect cTPresetShadowEffect = null;
      cTPresetShadowEffect = (CTPresetShadowEffect)get_store().add_element_user(PRSTSHDW$10);
      return cTPresetShadowEffect;
    } 
  }
  
  public void unsetPrstShdw() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PRSTSHDW$10, 0);
    } 
  }
  
  public CTReflectionEffect getReflection() {
    synchronized (monitor()) {
      check_orphaned();
      CTReflectionEffect cTReflectionEffect = null;
      cTReflectionEffect = (CTReflectionEffect)get_store().find_element_user(REFLECTION$12, 0);
      if (cTReflectionEffect == null)
        return null; 
      return cTReflectionEffect;
    } 
  }
  
  public boolean isSetReflection() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(REFLECTION$12) != 0);
    } 
  }
  
  public void setReflection(CTReflectionEffect paramCTReflectionEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTReflectionEffect, REFLECTION$12, 0, (short)1);
  }
  
  public CTReflectionEffect addNewReflection() {
    synchronized (monitor()) {
      check_orphaned();
      CTReflectionEffect cTReflectionEffect = null;
      cTReflectionEffect = (CTReflectionEffect)get_store().add_element_user(REFLECTION$12);
      return cTReflectionEffect;
    } 
  }
  
  public void unsetReflection() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REFLECTION$12, 0);
    } 
  }
  
  public CTSoftEdgesEffect getSoftEdge() {
    synchronized (monitor()) {
      check_orphaned();
      CTSoftEdgesEffect cTSoftEdgesEffect = null;
      cTSoftEdgesEffect = (CTSoftEdgesEffect)get_store().find_element_user(SOFTEDGE$14, 0);
      if (cTSoftEdgesEffect == null)
        return null; 
      return cTSoftEdgesEffect;
    } 
  }
  
  public boolean isSetSoftEdge() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(SOFTEDGE$14) != 0);
    } 
  }
  
  public void setSoftEdge(CTSoftEdgesEffect paramCTSoftEdgesEffect) {
    generatedSetterHelperImpl((XmlObject)paramCTSoftEdgesEffect, SOFTEDGE$14, 0, (short)1);
  }
  
  public CTSoftEdgesEffect addNewSoftEdge() {
    synchronized (monitor()) {
      check_orphaned();
      CTSoftEdgesEffect cTSoftEdgesEffect = null;
      cTSoftEdgesEffect = (CTSoftEdgesEffect)get_store().add_element_user(SOFTEDGE$14);
      return cTSoftEdgesEffect;
    } 
  }
  
  public void unsetSoftEdge() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SOFTEDGE$14, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTEffectListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */