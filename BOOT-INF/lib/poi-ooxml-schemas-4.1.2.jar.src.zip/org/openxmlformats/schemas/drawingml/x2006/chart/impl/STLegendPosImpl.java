package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;
import org.openxmlformats.schemas.drawingml.x2006.chart.STLegendPos;

public class STLegendPosImpl extends JavaStringEnumerationHolderEx implements STLegendPos {
  private static final long serialVersionUID = 1L;
  
  public STLegendPosImpl(SchemaType paramSchemaType) {
    super(paramSchemaType, false);
  }
  
  protected STLegendPosImpl(SchemaType paramSchemaType, boolean paramBoolean) {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\STLegendPosImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */