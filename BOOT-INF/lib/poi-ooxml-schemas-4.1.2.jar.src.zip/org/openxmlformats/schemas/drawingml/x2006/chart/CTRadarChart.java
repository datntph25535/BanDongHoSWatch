package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CTRadarChart extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTRadarChart.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctradarchart0f04type");
  
  CTRadarStyle getRadarStyle();
  
  void setRadarStyle(CTRadarStyle paramCTRadarStyle);
  
  CTRadarStyle addNewRadarStyle();
  
  CTBoolean getVaryColors();
  
  boolean isSetVaryColors();
  
  void setVaryColors(CTBoolean paramCTBoolean);
  
  CTBoolean addNewVaryColors();
  
  void unsetVaryColors();
  
  List<CTRadarSer> getSerList();
  
  @Deprecated
  CTRadarSer[] getSerArray();
  
  CTRadarSer getSerArray(int paramInt);
  
  int sizeOfSerArray();
  
  void setSerArray(CTRadarSer[] paramArrayOfCTRadarSer);
  
  void setSerArray(int paramInt, CTRadarSer paramCTRadarSer);
  
  CTRadarSer insertNewSer(int paramInt);
  
  CTRadarSer addNewSer();
  
  void removeSer(int paramInt);
  
  CTDLbls getDLbls();
  
  boolean isSetDLbls();
  
  void setDLbls(CTDLbls paramCTDLbls);
  
  CTDLbls addNewDLbls();
  
  void unsetDLbls();
  
  List<CTUnsignedInt> getAxIdList();
  
  @Deprecated
  CTUnsignedInt[] getAxIdArray();
  
  CTUnsignedInt getAxIdArray(int paramInt);
  
  int sizeOfAxIdArray();
  
  void setAxIdArray(CTUnsignedInt[] paramArrayOfCTUnsignedInt);
  
  void setAxIdArray(int paramInt, CTUnsignedInt paramCTUnsignedInt);
  
  CTUnsignedInt insertNewAxId(int paramInt);
  
  CTUnsignedInt addNewAxId();
  
  void removeAxId(int paramInt);
  
  CTExtensionList getExtLst();
  
  boolean isSetExtLst();
  
  void setExtLst(CTExtensionList paramCTExtensionList);
  
  CTExtensionList addNewExtLst();
  
  void unsetExtLst();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTRadarChart.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTRadarChart newInstance() {
      return (CTRadarChart)getTypeLoader().newInstance(CTRadarChart.type, null);
    }
    
    public static CTRadarChart newInstance(XmlOptions param1XmlOptions) {
      return (CTRadarChart)getTypeLoader().newInstance(CTRadarChart.type, param1XmlOptions);
    }
    
    public static CTRadarChart parse(String param1String) throws XmlException {
      return (CTRadarChart)getTypeLoader().parse(param1String, CTRadarChart.type, null);
    }
    
    public static CTRadarChart parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRadarChart)getTypeLoader().parse(param1String, CTRadarChart.type, param1XmlOptions);
    }
    
    public static CTRadarChart parse(File param1File) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1File, CTRadarChart.type, null);
    }
    
    public static CTRadarChart parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1File, CTRadarChart.type, param1XmlOptions);
    }
    
    public static CTRadarChart parse(URL param1URL) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1URL, CTRadarChart.type, null);
    }
    
    public static CTRadarChart parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1URL, CTRadarChart.type, param1XmlOptions);
    }
    
    public static CTRadarChart parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1InputStream, CTRadarChart.type, null);
    }
    
    public static CTRadarChart parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1InputStream, CTRadarChart.type, param1XmlOptions);
    }
    
    public static CTRadarChart parse(Reader param1Reader) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1Reader, CTRadarChart.type, null);
    }
    
    public static CTRadarChart parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTRadarChart)getTypeLoader().parse(param1Reader, CTRadarChart.type, param1XmlOptions);
    }
    
    public static CTRadarChart parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTRadarChart)getTypeLoader().parse(param1XMLStreamReader, CTRadarChart.type, null);
    }
    
    public static CTRadarChart parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRadarChart)getTypeLoader().parse(param1XMLStreamReader, CTRadarChart.type, param1XmlOptions);
    }
    
    public static CTRadarChart parse(Node param1Node) throws XmlException {
      return (CTRadarChart)getTypeLoader().parse(param1Node, CTRadarChart.type, null);
    }
    
    public static CTRadarChart parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTRadarChart)getTypeLoader().parse(param1Node, CTRadarChart.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTRadarChart parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTRadarChart)getTypeLoader().parse(param1XMLInputStream, CTRadarChart.type, null);
    }
    
    @Deprecated
    public static CTRadarChart parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTRadarChart)getTypeLoader().parse(param1XMLInputStream, CTRadarChart.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTRadarChart.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTRadarChart.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTRadarChart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */