package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTAdjPoint2D;
import org.openxmlformats.schemas.drawingml.x2006.main.CTConnectionSite;
import org.openxmlformats.schemas.drawingml.x2006.main.STAdjAngle;

public class CTConnectionSiteImpl extends XmlComplexContentImpl implements CTConnectionSite {
  private static final long serialVersionUID = 1L;
  
  private static final QName POS$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "pos");
  
  private static final QName ANG$2 = new QName("", "ang");
  
  public CTConnectionSiteImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTAdjPoint2D getPos() {
    synchronized (monitor()) {
      check_orphaned();
      CTAdjPoint2D cTAdjPoint2D = null;
      cTAdjPoint2D = (CTAdjPoint2D)get_store().find_element_user(POS$0, 0);
      if (cTAdjPoint2D == null)
        return null; 
      return cTAdjPoint2D;
    } 
  }
  
  public void setPos(CTAdjPoint2D paramCTAdjPoint2D) {
    generatedSetterHelperImpl((XmlObject)paramCTAdjPoint2D, POS$0, 0, (short)1);
  }
  
  public CTAdjPoint2D addNewPos() {
    synchronized (monitor()) {
      check_orphaned();
      CTAdjPoint2D cTAdjPoint2D = null;
      cTAdjPoint2D = (CTAdjPoint2D)get_store().add_element_user(POS$0);
      return cTAdjPoint2D;
    } 
  }
  
  public Object getAng() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ANG$2);
      if (simpleValue == null)
        return null; 
      return simpleValue.getObjectValue();
    } 
  }
  
  public STAdjAngle xgetAng() {
    synchronized (monitor()) {
      check_orphaned();
      STAdjAngle sTAdjAngle = null;
      sTAdjAngle = (STAdjAngle)get_store().find_attribute_user(ANG$2);
      return sTAdjAngle;
    } 
  }
  
  public void setAng(Object paramObject) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ANG$2);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ANG$2); 
      simpleValue.setObjectValue(paramObject);
    } 
  }
  
  public void xsetAng(STAdjAngle paramSTAdjAngle) {
    synchronized (monitor()) {
      check_orphaned();
      STAdjAngle sTAdjAngle = null;
      sTAdjAngle = (STAdjAngle)get_store().find_attribute_user(ANG$2);
      if (sTAdjAngle == null)
        sTAdjAngle = (STAdjAngle)get_store().add_attribute_user(ANG$2); 
      sTAdjAngle.set((XmlObject)paramSTAdjAngle);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTConnectionSiteImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */