package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPath2D;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPath2DList;

public class CTPath2DListImpl extends XmlComplexContentImpl implements CTPath2DList {
  private static final long serialVersionUID = 1L;
  
  private static final QName PATH$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "path");
  
  public CTPath2DListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTPath2D> getPathList() {
    synchronized (monitor()) {
      check_orphaned();
      final class PathList extends AbstractList<CTPath2D> {
        public CTPath2D get(int param1Int) {
          return CTPath2DListImpl.this.getPathArray(param1Int);
        }
        
        public CTPath2D set(int param1Int, CTPath2D param1CTPath2D) {
          CTPath2D cTPath2D = CTPath2DListImpl.this.getPathArray(param1Int);
          CTPath2DListImpl.this.setPathArray(param1Int, param1CTPath2D);
          return cTPath2D;
        }
        
        public void add(int param1Int, CTPath2D param1CTPath2D) {
          CTPath2DListImpl.this.insertNewPath(param1Int).set((XmlObject)param1CTPath2D);
        }
        
        public CTPath2D remove(int param1Int) {
          CTPath2D cTPath2D = CTPath2DListImpl.this.getPathArray(param1Int);
          CTPath2DListImpl.this.removePath(param1Int);
          return cTPath2D;
        }
        
        public int size() {
          return CTPath2DListImpl.this.sizeOfPathArray();
        }
      };
      return new PathList();
    } 
  }
  
  @Deprecated
  public CTPath2D[] getPathArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(PATH$0, arrayList);
      CTPath2D[] arrayOfCTPath2D = new CTPath2D[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTPath2D);
      return arrayOfCTPath2D;
    } 
  }
  
  public CTPath2D getPathArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPath2D cTPath2D = null;
      cTPath2D = (CTPath2D)get_store().find_element_user(PATH$0, paramInt);
      if (cTPath2D == null)
        throw new IndexOutOfBoundsException(); 
      return cTPath2D;
    } 
  }
  
  public int sizeOfPathArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(PATH$0);
    } 
  }
  
  public void setPathArray(CTPath2D[] paramArrayOfCTPath2D) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTPath2D, PATH$0);
  }
  
  public void setPathArray(int paramInt, CTPath2D paramCTPath2D) {
    generatedSetterHelperImpl((XmlObject)paramCTPath2D, PATH$0, paramInt, (short)2);
  }
  
  public CTPath2D insertNewPath(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPath2D cTPath2D = null;
      cTPath2D = (CTPath2D)get_store().insert_element_user(PATH$0, paramInt);
      return cTPath2D;
    } 
  }
  
  public CTPath2D addNewPath() {
    synchronized (monitor()) {
      check_orphaned();
      CTPath2D cTPath2D = null;
      cTPath2D = (CTPath2D)get_store().add_element_user(PATH$0);
      return cTPath2D;
    } 
  }
  
  public void removePath(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PATH$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTPath2DListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */