package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.openxmlformats.schemas.drawingml.x2006.main.CTShapeProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTTextBody;
import org.w3c.dom.Node;

public interface CTDLbls extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTDLbls.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("ctdlblsb585type");
  
  List<CTDLbl> getDLblList();
  
  @Deprecated
  CTDLbl[] getDLblArray();
  
  CTDLbl getDLblArray(int paramInt);
  
  int sizeOfDLblArray();
  
  void setDLblArray(CTDLbl[] paramArrayOfCTDLbl);
  
  void setDLblArray(int paramInt, CTDLbl paramCTDLbl);
  
  CTDLbl insertNewDLbl(int paramInt);
  
  CTDLbl addNewDLbl();
  
  void removeDLbl(int paramInt);
  
  CTBoolean getDelete();
  
  boolean isSetDelete();
  
  void setDelete(CTBoolean paramCTBoolean);
  
  CTBoolean addNewDelete();
  
  void unsetDelete();
  
  CTNumFmt getNumFmt();
  
  boolean isSetNumFmt();
  
  void setNumFmt(CTNumFmt paramCTNumFmt);
  
  CTNumFmt addNewNumFmt();
  
  void unsetNumFmt();
  
  CTShapeProperties getSpPr();
  
  boolean isSetSpPr();
  
  void setSpPr(CTShapeProperties paramCTShapeProperties);
  
  CTShapeProperties addNewSpPr();
  
  void unsetSpPr();
  
  CTTextBody getTxPr();
  
  boolean isSetTxPr();
  
  void setTxPr(CTTextBody paramCTTextBody);
  
  CTTextBody addNewTxPr();
  
  void unsetTxPr();
  
  CTDLblPos getDLblPos();
  
  boolean isSetDLblPos();
  
  void setDLblPos(CTDLblPos paramCTDLblPos);
  
  CTDLblPos addNewDLblPos();
  
  void unsetDLblPos();
  
  CTBoolean getShowLegendKey();
  
  boolean isSetShowLegendKey();
  
  void setShowLegendKey(CTBoolean paramCTBoolean);
  
  CTBoolean addNewShowLegendKey();
  
  void unsetShowLegendKey();
  
  CTBoolean getShowVal();
  
  boolean isSetShowVal();
  
  void setShowVal(CTBoolean paramCTBoolean);
  
  CTBoolean addNewShowVal();
  
  void unsetShowVal();
  
  CTBoolean getShowCatName();
  
  boolean isSetShowCatName();
  
  void setShowCatName(CTBoolean paramCTBoolean);
  
  CTBoolean addNewShowCatName();
  
  void unsetShowCatName();
  
  CTBoolean getShowSerName();
  
  boolean isSetShowSerName();
  
  void setShowSerName(CTBoolean paramCTBoolean);
  
  CTBoolean addNewShowSerName();
  
  void unsetShowSerName();
  
  CTBoolean getShowPercent();
  
  boolean isSetShowPercent();
  
  void setShowPercent(CTBoolean paramCTBoolean);
  
  CTBoolean addNewShowPercent();
  
  void unsetShowPercent();
  
  CTBoolean getShowBubbleSize();
  
  boolean isSetShowBubbleSize();
  
  void setShowBubbleSize(CTBoolean paramCTBoolean);
  
  CTBoolean addNewShowBubbleSize();
  
  void unsetShowBubbleSize();
  
  String getSeparator();
  
  XmlString xgetSeparator();
  
  boolean isSetSeparator();
  
  void setSeparator(String paramString);
  
  void xsetSeparator(XmlString paramXmlString);
  
  void unsetSeparator();
  
  CTBoolean getShowLeaderLines();
  
  boolean isSetShowLeaderLines();
  
  void setShowLeaderLines(CTBoolean paramCTBoolean);
  
  CTBoolean addNewShowLeaderLines();
  
  void unsetShowLeaderLines();
  
  CTChartLines getLeaderLines();
  
  boolean isSetLeaderLines();
  
  void setLeaderLines(CTChartLines paramCTChartLines);
  
  CTChartLines addNewLeaderLines();
  
  void unsetLeaderLines();
  
  CTExtensionList getExtLst();
  
  boolean isSetExtLst();
  
  void setExtLst(CTExtensionList paramCTExtensionList);
  
  CTExtensionList addNewExtLst();
  
  void unsetExtLst();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CTDLbls.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CTDLbls newInstance() {
      return (CTDLbls)getTypeLoader().newInstance(CTDLbls.type, null);
    }
    
    public static CTDLbls newInstance(XmlOptions param1XmlOptions) {
      return (CTDLbls)getTypeLoader().newInstance(CTDLbls.type, param1XmlOptions);
    }
    
    public static CTDLbls parse(String param1String) throws XmlException {
      return (CTDLbls)getTypeLoader().parse(param1String, CTDLbls.type, null);
    }
    
    public static CTDLbls parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CTDLbls)getTypeLoader().parse(param1String, CTDLbls.type, param1XmlOptions);
    }
    
    public static CTDLbls parse(File param1File) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1File, CTDLbls.type, null);
    }
    
    public static CTDLbls parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1File, CTDLbls.type, param1XmlOptions);
    }
    
    public static CTDLbls parse(URL param1URL) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1URL, CTDLbls.type, null);
    }
    
    public static CTDLbls parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1URL, CTDLbls.type, param1XmlOptions);
    }
    
    public static CTDLbls parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1InputStream, CTDLbls.type, null);
    }
    
    public static CTDLbls parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1InputStream, CTDLbls.type, param1XmlOptions);
    }
    
    public static CTDLbls parse(Reader param1Reader) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1Reader, CTDLbls.type, null);
    }
    
    public static CTDLbls parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CTDLbls)getTypeLoader().parse(param1Reader, CTDLbls.type, param1XmlOptions);
    }
    
    public static CTDLbls parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CTDLbls)getTypeLoader().parse(param1XMLStreamReader, CTDLbls.type, null);
    }
    
    public static CTDLbls parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CTDLbls)getTypeLoader().parse(param1XMLStreamReader, CTDLbls.type, param1XmlOptions);
    }
    
    public static CTDLbls parse(Node param1Node) throws XmlException {
      return (CTDLbls)getTypeLoader().parse(param1Node, CTDLbls.type, null);
    }
    
    public static CTDLbls parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CTDLbls)getTypeLoader().parse(param1Node, CTDLbls.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CTDLbls parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CTDLbls)getTypeLoader().parse(param1XMLInputStream, CTDLbls.type, null);
    }
    
    @Deprecated
    public static CTDLbls parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CTDLbls)getTypeLoader().parse(param1XMLInputStream, CTDLbls.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTDLbls.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CTDLbls.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\CTDLbls.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */