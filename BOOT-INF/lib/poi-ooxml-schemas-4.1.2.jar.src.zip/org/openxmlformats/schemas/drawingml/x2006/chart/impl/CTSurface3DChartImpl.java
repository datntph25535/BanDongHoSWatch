package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBandFmts;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSurface3DChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTSurfaceSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;

public class CTSurface3DChartImpl extends XmlComplexContentImpl implements CTSurface3DChart {
  private static final long serialVersionUID = 1L;
  
  private static final QName WIREFRAME$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "wireframe");
  
  private static final QName SER$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "ser");
  
  private static final QName BANDFMTS$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "bandFmts");
  
  private static final QName AXID$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "axId");
  
  private static final QName EXTLST$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTSurface3DChartImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTBoolean getWireframe() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(WIREFRAME$0, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetWireframe() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(WIREFRAME$0) != 0);
    } 
  }
  
  public void setWireframe(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, WIREFRAME$0, 0, (short)1);
  }
  
  public CTBoolean addNewWireframe() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(WIREFRAME$0);
      return cTBoolean;
    } 
  }
  
  public void unsetWireframe() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(WIREFRAME$0, 0);
    } 
  }
  
  public List<CTSurfaceSer> getSerList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SerList extends AbstractList<CTSurfaceSer> {
        public CTSurfaceSer get(int param1Int) {
          return CTSurface3DChartImpl.this.getSerArray(param1Int);
        }
        
        public CTSurfaceSer set(int param1Int, CTSurfaceSer param1CTSurfaceSer) {
          CTSurfaceSer cTSurfaceSer = CTSurface3DChartImpl.this.getSerArray(param1Int);
          CTSurface3DChartImpl.this.setSerArray(param1Int, param1CTSurfaceSer);
          return cTSurfaceSer;
        }
        
        public void add(int param1Int, CTSurfaceSer param1CTSurfaceSer) {
          CTSurface3DChartImpl.this.insertNewSer(param1Int).set((XmlObject)param1CTSurfaceSer);
        }
        
        public CTSurfaceSer remove(int param1Int) {
          CTSurfaceSer cTSurfaceSer = CTSurface3DChartImpl.this.getSerArray(param1Int);
          CTSurface3DChartImpl.this.removeSer(param1Int);
          return cTSurfaceSer;
        }
        
        public int size() {
          return CTSurface3DChartImpl.this.sizeOfSerArray();
        }
      };
      return new SerList();
    } 
  }
  
  @Deprecated
  public CTSurfaceSer[] getSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SER$2, arrayList);
      CTSurfaceSer[] arrayOfCTSurfaceSer = new CTSurfaceSer[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSurfaceSer);
      return arrayOfCTSurfaceSer;
    } 
  }
  
  public CTSurfaceSer getSerArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSurfaceSer cTSurfaceSer = null;
      cTSurfaceSer = (CTSurfaceSer)get_store().find_element_user(SER$2, paramInt);
      if (cTSurfaceSer == null)
        throw new IndexOutOfBoundsException(); 
      return cTSurfaceSer;
    } 
  }
  
  public int sizeOfSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SER$2);
    } 
  }
  
  public void setSerArray(CTSurfaceSer[] paramArrayOfCTSurfaceSer) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSurfaceSer, SER$2);
  }
  
  public void setSerArray(int paramInt, CTSurfaceSer paramCTSurfaceSer) {
    generatedSetterHelperImpl((XmlObject)paramCTSurfaceSer, SER$2, paramInt, (short)2);
  }
  
  public CTSurfaceSer insertNewSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSurfaceSer cTSurfaceSer = null;
      cTSurfaceSer = (CTSurfaceSer)get_store().insert_element_user(SER$2, paramInt);
      return cTSurfaceSer;
    } 
  }
  
  public CTSurfaceSer addNewSer() {
    synchronized (monitor()) {
      check_orphaned();
      CTSurfaceSer cTSurfaceSer = null;
      cTSurfaceSer = (CTSurfaceSer)get_store().add_element_user(SER$2);
      return cTSurfaceSer;
    } 
  }
  
  public void removeSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SER$2, paramInt);
    } 
  }
  
  public CTBandFmts getBandFmts() {
    synchronized (monitor()) {
      check_orphaned();
      CTBandFmts cTBandFmts = null;
      cTBandFmts = (CTBandFmts)get_store().find_element_user(BANDFMTS$4, 0);
      if (cTBandFmts == null)
        return null; 
      return cTBandFmts;
    } 
  }
  
  public boolean isSetBandFmts() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(BANDFMTS$4) != 0);
    } 
  }
  
  public void setBandFmts(CTBandFmts paramCTBandFmts) {
    generatedSetterHelperImpl((XmlObject)paramCTBandFmts, BANDFMTS$4, 0, (short)1);
  }
  
  public CTBandFmts addNewBandFmts() {
    synchronized (monitor()) {
      check_orphaned();
      CTBandFmts cTBandFmts = null;
      cTBandFmts = (CTBandFmts)get_store().add_element_user(BANDFMTS$4);
      return cTBandFmts;
    } 
  }
  
  public void unsetBandFmts() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BANDFMTS$4, 0);
    } 
  }
  
  public List<CTUnsignedInt> getAxIdList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AxIdList extends AbstractList<CTUnsignedInt> {
        public CTUnsignedInt get(int param1Int) {
          return CTSurface3DChartImpl.this.getAxIdArray(param1Int);
        }
        
        public CTUnsignedInt set(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTUnsignedInt cTUnsignedInt = CTSurface3DChartImpl.this.getAxIdArray(param1Int);
          CTSurface3DChartImpl.this.setAxIdArray(param1Int, param1CTUnsignedInt);
          return cTUnsignedInt;
        }
        
        public void add(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTSurface3DChartImpl.this.insertNewAxId(param1Int).set((XmlObject)param1CTUnsignedInt);
        }
        
        public CTUnsignedInt remove(int param1Int) {
          CTUnsignedInt cTUnsignedInt = CTSurface3DChartImpl.this.getAxIdArray(param1Int);
          CTSurface3DChartImpl.this.removeAxId(param1Int);
          return cTUnsignedInt;
        }
        
        public int size() {
          return CTSurface3DChartImpl.this.sizeOfAxIdArray();
        }
      };
      return new AxIdList();
    } 
  }
  
  @Deprecated
  public CTUnsignedInt[] getAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(AXID$6, arrayList);
      CTUnsignedInt[] arrayOfCTUnsignedInt = new CTUnsignedInt[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTUnsignedInt);
      return arrayOfCTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt getAxIdArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(AXID$6, paramInt);
      if (cTUnsignedInt == null)
        throw new IndexOutOfBoundsException(); 
      return cTUnsignedInt;
    } 
  }
  
  public int sizeOfAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(AXID$6);
    } 
  }
  
  public void setAxIdArray(CTUnsignedInt[] paramArrayOfCTUnsignedInt) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTUnsignedInt, AXID$6);
  }
  
  public void setAxIdArray(int paramInt, CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, AXID$6, paramInt, (short)2);
  }
  
  public CTUnsignedInt insertNewAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().insert_element_user(AXID$6, paramInt);
      return cTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt addNewAxId() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(AXID$6);
      return cTUnsignedInt;
    } 
  }
  
  public void removeAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(AXID$6, paramInt);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$8, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$8) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$8, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$8);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$8, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTSurface3DChartImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */