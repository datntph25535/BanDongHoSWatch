package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTChartSpace;
import org.openxmlformats.schemas.drawingml.x2006.chart.ChartSpaceDocument;

public class ChartSpaceDocumentImpl extends XmlComplexContentImpl implements ChartSpaceDocument {
  private static final long serialVersionUID = 1L;
  
  private static final QName CHARTSPACE$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "chartSpace");
  
  public ChartSpaceDocumentImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTChartSpace getChartSpace() {
    synchronized (monitor()) {
      check_orphaned();
      CTChartSpace cTChartSpace = null;
      cTChartSpace = (CTChartSpace)get_store().find_element_user(CHARTSPACE$0, 0);
      if (cTChartSpace == null)
        return null; 
      return cTChartSpace;
    } 
  }
  
  public void setChartSpace(CTChartSpace paramCTChartSpace) {
    generatedSetterHelperImpl((XmlObject)paramCTChartSpace, CHARTSPACE$0, 0, (short)1);
  }
  
  public CTChartSpace addNewChartSpace() {
    synchronized (monitor()) {
      check_orphaned();
      CTChartSpace cTChartSpace = null;
      cTChartSpace = (CTChartSpace)get_store().add_element_user(CHARTSPACE$0);
      return cTChartSpace;
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\ChartSpaceDocumentImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */