package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTBlipFillProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTFillStyleList;
import org.openxmlformats.schemas.drawingml.x2006.main.CTGradientFillProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTGroupFillProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTNoFillProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTPatternFillProperties;
import org.openxmlformats.schemas.drawingml.x2006.main.CTSolidColorFillProperties;

public class CTFillStyleListImpl extends XmlComplexContentImpl implements CTFillStyleList {
  private static final long serialVersionUID = 1L;
  
  private static final QName NOFILL$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "noFill");
  
  private static final QName SOLIDFILL$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "solidFill");
  
  private static final QName GRADFILL$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "gradFill");
  
  private static final QName BLIPFILL$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "blipFill");
  
  private static final QName PATTFILL$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "pattFill");
  
  private static final QName GRPFILL$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/main", "grpFill");
  
  public CTFillStyleListImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CTNoFillProperties> getNoFillList() {
    synchronized (monitor()) {
      check_orphaned();
      final class NoFillList extends AbstractList<CTNoFillProperties> {
        public CTNoFillProperties get(int param1Int) {
          return CTFillStyleListImpl.this.getNoFillArray(param1Int);
        }
        
        public CTNoFillProperties set(int param1Int, CTNoFillProperties param1CTNoFillProperties) {
          CTNoFillProperties cTNoFillProperties = CTFillStyleListImpl.this.getNoFillArray(param1Int);
          CTFillStyleListImpl.this.setNoFillArray(param1Int, param1CTNoFillProperties);
          return cTNoFillProperties;
        }
        
        public void add(int param1Int, CTNoFillProperties param1CTNoFillProperties) {
          CTFillStyleListImpl.this.insertNewNoFill(param1Int).set((XmlObject)param1CTNoFillProperties);
        }
        
        public CTNoFillProperties remove(int param1Int) {
          CTNoFillProperties cTNoFillProperties = CTFillStyleListImpl.this.getNoFillArray(param1Int);
          CTFillStyleListImpl.this.removeNoFill(param1Int);
          return cTNoFillProperties;
        }
        
        public int size() {
          return CTFillStyleListImpl.this.sizeOfNoFillArray();
        }
      };
      return new NoFillList();
    } 
  }
  
  @Deprecated
  public CTNoFillProperties[] getNoFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(NOFILL$0, arrayList);
      CTNoFillProperties[] arrayOfCTNoFillProperties = new CTNoFillProperties[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTNoFillProperties);
      return arrayOfCTNoFillProperties;
    } 
  }
  
  public CTNoFillProperties getNoFillArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTNoFillProperties cTNoFillProperties = null;
      cTNoFillProperties = (CTNoFillProperties)get_store().find_element_user(NOFILL$0, paramInt);
      if (cTNoFillProperties == null)
        throw new IndexOutOfBoundsException(); 
      return cTNoFillProperties;
    } 
  }
  
  public int sizeOfNoFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(NOFILL$0);
    } 
  }
  
  public void setNoFillArray(CTNoFillProperties[] paramArrayOfCTNoFillProperties) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTNoFillProperties, NOFILL$0);
  }
  
  public void setNoFillArray(int paramInt, CTNoFillProperties paramCTNoFillProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTNoFillProperties, NOFILL$0, paramInt, (short)2);
  }
  
  public CTNoFillProperties insertNewNoFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTNoFillProperties cTNoFillProperties = null;
      cTNoFillProperties = (CTNoFillProperties)get_store().insert_element_user(NOFILL$0, paramInt);
      return cTNoFillProperties;
    } 
  }
  
  public CTNoFillProperties addNewNoFill() {
    synchronized (monitor()) {
      check_orphaned();
      CTNoFillProperties cTNoFillProperties = null;
      cTNoFillProperties = (CTNoFillProperties)get_store().add_element_user(NOFILL$0);
      return cTNoFillProperties;
    } 
  }
  
  public void removeNoFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(NOFILL$0, paramInt);
    } 
  }
  
  public List<CTSolidColorFillProperties> getSolidFillList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SolidFillList extends AbstractList<CTSolidColorFillProperties> {
        public CTSolidColorFillProperties get(int param1Int) {
          return CTFillStyleListImpl.this.getSolidFillArray(param1Int);
        }
        
        public CTSolidColorFillProperties set(int param1Int, CTSolidColorFillProperties param1CTSolidColorFillProperties) {
          CTSolidColorFillProperties cTSolidColorFillProperties = CTFillStyleListImpl.this.getSolidFillArray(param1Int);
          CTFillStyleListImpl.this.setSolidFillArray(param1Int, param1CTSolidColorFillProperties);
          return cTSolidColorFillProperties;
        }
        
        public void add(int param1Int, CTSolidColorFillProperties param1CTSolidColorFillProperties) {
          CTFillStyleListImpl.this.insertNewSolidFill(param1Int).set((XmlObject)param1CTSolidColorFillProperties);
        }
        
        public CTSolidColorFillProperties remove(int param1Int) {
          CTSolidColorFillProperties cTSolidColorFillProperties = CTFillStyleListImpl.this.getSolidFillArray(param1Int);
          CTFillStyleListImpl.this.removeSolidFill(param1Int);
          return cTSolidColorFillProperties;
        }
        
        public int size() {
          return CTFillStyleListImpl.this.sizeOfSolidFillArray();
        }
      };
      return new SolidFillList();
    } 
  }
  
  @Deprecated
  public CTSolidColorFillProperties[] getSolidFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SOLIDFILL$2, arrayList);
      CTSolidColorFillProperties[] arrayOfCTSolidColorFillProperties = new CTSolidColorFillProperties[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTSolidColorFillProperties);
      return arrayOfCTSolidColorFillProperties;
    } 
  }
  
  public CTSolidColorFillProperties getSolidFillArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSolidColorFillProperties cTSolidColorFillProperties = null;
      cTSolidColorFillProperties = (CTSolidColorFillProperties)get_store().find_element_user(SOLIDFILL$2, paramInt);
      if (cTSolidColorFillProperties == null)
        throw new IndexOutOfBoundsException(); 
      return cTSolidColorFillProperties;
    } 
  }
  
  public int sizeOfSolidFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SOLIDFILL$2);
    } 
  }
  
  public void setSolidFillArray(CTSolidColorFillProperties[] paramArrayOfCTSolidColorFillProperties) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTSolidColorFillProperties, SOLIDFILL$2);
  }
  
  public void setSolidFillArray(int paramInt, CTSolidColorFillProperties paramCTSolidColorFillProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTSolidColorFillProperties, SOLIDFILL$2, paramInt, (short)2);
  }
  
  public CTSolidColorFillProperties insertNewSolidFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTSolidColorFillProperties cTSolidColorFillProperties = null;
      cTSolidColorFillProperties = (CTSolidColorFillProperties)get_store().insert_element_user(SOLIDFILL$2, paramInt);
      return cTSolidColorFillProperties;
    } 
  }
  
  public CTSolidColorFillProperties addNewSolidFill() {
    synchronized (monitor()) {
      check_orphaned();
      CTSolidColorFillProperties cTSolidColorFillProperties = null;
      cTSolidColorFillProperties = (CTSolidColorFillProperties)get_store().add_element_user(SOLIDFILL$2);
      return cTSolidColorFillProperties;
    } 
  }
  
  public void removeSolidFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SOLIDFILL$2, paramInt);
    } 
  }
  
  public List<CTGradientFillProperties> getGradFillList() {
    synchronized (monitor()) {
      check_orphaned();
      final class GradFillList extends AbstractList<CTGradientFillProperties> {
        public CTGradientFillProperties get(int param1Int) {
          return CTFillStyleListImpl.this.getGradFillArray(param1Int);
        }
        
        public CTGradientFillProperties set(int param1Int, CTGradientFillProperties param1CTGradientFillProperties) {
          CTGradientFillProperties cTGradientFillProperties = CTFillStyleListImpl.this.getGradFillArray(param1Int);
          CTFillStyleListImpl.this.setGradFillArray(param1Int, param1CTGradientFillProperties);
          return cTGradientFillProperties;
        }
        
        public void add(int param1Int, CTGradientFillProperties param1CTGradientFillProperties) {
          CTFillStyleListImpl.this.insertNewGradFill(param1Int).set((XmlObject)param1CTGradientFillProperties);
        }
        
        public CTGradientFillProperties remove(int param1Int) {
          CTGradientFillProperties cTGradientFillProperties = CTFillStyleListImpl.this.getGradFillArray(param1Int);
          CTFillStyleListImpl.this.removeGradFill(param1Int);
          return cTGradientFillProperties;
        }
        
        public int size() {
          return CTFillStyleListImpl.this.sizeOfGradFillArray();
        }
      };
      return new GradFillList();
    } 
  }
  
  @Deprecated
  public CTGradientFillProperties[] getGradFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(GRADFILL$4, arrayList);
      CTGradientFillProperties[] arrayOfCTGradientFillProperties = new CTGradientFillProperties[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTGradientFillProperties);
      return arrayOfCTGradientFillProperties;
    } 
  }
  
  public CTGradientFillProperties getGradFillArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGradientFillProperties cTGradientFillProperties = null;
      cTGradientFillProperties = (CTGradientFillProperties)get_store().find_element_user(GRADFILL$4, paramInt);
      if (cTGradientFillProperties == null)
        throw new IndexOutOfBoundsException(); 
      return cTGradientFillProperties;
    } 
  }
  
  public int sizeOfGradFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(GRADFILL$4);
    } 
  }
  
  public void setGradFillArray(CTGradientFillProperties[] paramArrayOfCTGradientFillProperties) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTGradientFillProperties, GRADFILL$4);
  }
  
  public void setGradFillArray(int paramInt, CTGradientFillProperties paramCTGradientFillProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTGradientFillProperties, GRADFILL$4, paramInt, (short)2);
  }
  
  public CTGradientFillProperties insertNewGradFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGradientFillProperties cTGradientFillProperties = null;
      cTGradientFillProperties = (CTGradientFillProperties)get_store().insert_element_user(GRADFILL$4, paramInt);
      return cTGradientFillProperties;
    } 
  }
  
  public CTGradientFillProperties addNewGradFill() {
    synchronized (monitor()) {
      check_orphaned();
      CTGradientFillProperties cTGradientFillProperties = null;
      cTGradientFillProperties = (CTGradientFillProperties)get_store().add_element_user(GRADFILL$4);
      return cTGradientFillProperties;
    } 
  }
  
  public void removeGradFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GRADFILL$4, paramInt);
    } 
  }
  
  public List<CTBlipFillProperties> getBlipFillList() {
    synchronized (monitor()) {
      check_orphaned();
      final class BlipFillList extends AbstractList<CTBlipFillProperties> {
        public CTBlipFillProperties get(int param1Int) {
          return CTFillStyleListImpl.this.getBlipFillArray(param1Int);
        }
        
        public CTBlipFillProperties set(int param1Int, CTBlipFillProperties param1CTBlipFillProperties) {
          CTBlipFillProperties cTBlipFillProperties = CTFillStyleListImpl.this.getBlipFillArray(param1Int);
          CTFillStyleListImpl.this.setBlipFillArray(param1Int, param1CTBlipFillProperties);
          return cTBlipFillProperties;
        }
        
        public void add(int param1Int, CTBlipFillProperties param1CTBlipFillProperties) {
          CTFillStyleListImpl.this.insertNewBlipFill(param1Int).set((XmlObject)param1CTBlipFillProperties);
        }
        
        public CTBlipFillProperties remove(int param1Int) {
          CTBlipFillProperties cTBlipFillProperties = CTFillStyleListImpl.this.getBlipFillArray(param1Int);
          CTFillStyleListImpl.this.removeBlipFill(param1Int);
          return cTBlipFillProperties;
        }
        
        public int size() {
          return CTFillStyleListImpl.this.sizeOfBlipFillArray();
        }
      };
      return new BlipFillList();
    } 
  }
  
  @Deprecated
  public CTBlipFillProperties[] getBlipFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(BLIPFILL$6, arrayList);
      CTBlipFillProperties[] arrayOfCTBlipFillProperties = new CTBlipFillProperties[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBlipFillProperties);
      return arrayOfCTBlipFillProperties;
    } 
  }
  
  public CTBlipFillProperties getBlipFillArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBlipFillProperties cTBlipFillProperties = null;
      cTBlipFillProperties = (CTBlipFillProperties)get_store().find_element_user(BLIPFILL$6, paramInt);
      if (cTBlipFillProperties == null)
        throw new IndexOutOfBoundsException(); 
      return cTBlipFillProperties;
    } 
  }
  
  public int sizeOfBlipFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(BLIPFILL$6);
    } 
  }
  
  public void setBlipFillArray(CTBlipFillProperties[] paramArrayOfCTBlipFillProperties) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBlipFillProperties, BLIPFILL$6);
  }
  
  public void setBlipFillArray(int paramInt, CTBlipFillProperties paramCTBlipFillProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTBlipFillProperties, BLIPFILL$6, paramInt, (short)2);
  }
  
  public CTBlipFillProperties insertNewBlipFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBlipFillProperties cTBlipFillProperties = null;
      cTBlipFillProperties = (CTBlipFillProperties)get_store().insert_element_user(BLIPFILL$6, paramInt);
      return cTBlipFillProperties;
    } 
  }
  
  public CTBlipFillProperties addNewBlipFill() {
    synchronized (monitor()) {
      check_orphaned();
      CTBlipFillProperties cTBlipFillProperties = null;
      cTBlipFillProperties = (CTBlipFillProperties)get_store().add_element_user(BLIPFILL$6);
      return cTBlipFillProperties;
    } 
  }
  
  public void removeBlipFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BLIPFILL$6, paramInt);
    } 
  }
  
  public List<CTPatternFillProperties> getPattFillList() {
    synchronized (monitor()) {
      check_orphaned();
      final class PattFillList extends AbstractList<CTPatternFillProperties> {
        public CTPatternFillProperties get(int param1Int) {
          return CTFillStyleListImpl.this.getPattFillArray(param1Int);
        }
        
        public CTPatternFillProperties set(int param1Int, CTPatternFillProperties param1CTPatternFillProperties) {
          CTPatternFillProperties cTPatternFillProperties = CTFillStyleListImpl.this.getPattFillArray(param1Int);
          CTFillStyleListImpl.this.setPattFillArray(param1Int, param1CTPatternFillProperties);
          return cTPatternFillProperties;
        }
        
        public void add(int param1Int, CTPatternFillProperties param1CTPatternFillProperties) {
          CTFillStyleListImpl.this.insertNewPattFill(param1Int).set((XmlObject)param1CTPatternFillProperties);
        }
        
        public CTPatternFillProperties remove(int param1Int) {
          CTPatternFillProperties cTPatternFillProperties = CTFillStyleListImpl.this.getPattFillArray(param1Int);
          CTFillStyleListImpl.this.removePattFill(param1Int);
          return cTPatternFillProperties;
        }
        
        public int size() {
          return CTFillStyleListImpl.this.sizeOfPattFillArray();
        }
      };
      return new PattFillList();
    } 
  }
  
  @Deprecated
  public CTPatternFillProperties[] getPattFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(PATTFILL$8, arrayList);
      CTPatternFillProperties[] arrayOfCTPatternFillProperties = new CTPatternFillProperties[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTPatternFillProperties);
      return arrayOfCTPatternFillProperties;
    } 
  }
  
  public CTPatternFillProperties getPattFillArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPatternFillProperties cTPatternFillProperties = null;
      cTPatternFillProperties = (CTPatternFillProperties)get_store().find_element_user(PATTFILL$8, paramInt);
      if (cTPatternFillProperties == null)
        throw new IndexOutOfBoundsException(); 
      return cTPatternFillProperties;
    } 
  }
  
  public int sizeOfPattFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(PATTFILL$8);
    } 
  }
  
  public void setPattFillArray(CTPatternFillProperties[] paramArrayOfCTPatternFillProperties) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTPatternFillProperties, PATTFILL$8);
  }
  
  public void setPattFillArray(int paramInt, CTPatternFillProperties paramCTPatternFillProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTPatternFillProperties, PATTFILL$8, paramInt, (short)2);
  }
  
  public CTPatternFillProperties insertNewPattFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTPatternFillProperties cTPatternFillProperties = null;
      cTPatternFillProperties = (CTPatternFillProperties)get_store().insert_element_user(PATTFILL$8, paramInt);
      return cTPatternFillProperties;
    } 
  }
  
  public CTPatternFillProperties addNewPattFill() {
    synchronized (monitor()) {
      check_orphaned();
      CTPatternFillProperties cTPatternFillProperties = null;
      cTPatternFillProperties = (CTPatternFillProperties)get_store().add_element_user(PATTFILL$8);
      return cTPatternFillProperties;
    } 
  }
  
  public void removePattFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(PATTFILL$8, paramInt);
    } 
  }
  
  public List<CTGroupFillProperties> getGrpFillList() {
    synchronized (monitor()) {
      check_orphaned();
      final class GrpFillList extends AbstractList<CTGroupFillProperties> {
        public CTGroupFillProperties get(int param1Int) {
          return CTFillStyleListImpl.this.getGrpFillArray(param1Int);
        }
        
        public CTGroupFillProperties set(int param1Int, CTGroupFillProperties param1CTGroupFillProperties) {
          CTGroupFillProperties cTGroupFillProperties = CTFillStyleListImpl.this.getGrpFillArray(param1Int);
          CTFillStyleListImpl.this.setGrpFillArray(param1Int, param1CTGroupFillProperties);
          return cTGroupFillProperties;
        }
        
        public void add(int param1Int, CTGroupFillProperties param1CTGroupFillProperties) {
          CTFillStyleListImpl.this.insertNewGrpFill(param1Int).set((XmlObject)param1CTGroupFillProperties);
        }
        
        public CTGroupFillProperties remove(int param1Int) {
          CTGroupFillProperties cTGroupFillProperties = CTFillStyleListImpl.this.getGrpFillArray(param1Int);
          CTFillStyleListImpl.this.removeGrpFill(param1Int);
          return cTGroupFillProperties;
        }
        
        public int size() {
          return CTFillStyleListImpl.this.sizeOfGrpFillArray();
        }
      };
      return new GrpFillList();
    } 
  }
  
  @Deprecated
  public CTGroupFillProperties[] getGrpFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(GRPFILL$10, arrayList);
      CTGroupFillProperties[] arrayOfCTGroupFillProperties = new CTGroupFillProperties[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTGroupFillProperties);
      return arrayOfCTGroupFillProperties;
    } 
  }
  
  public CTGroupFillProperties getGrpFillArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGroupFillProperties cTGroupFillProperties = null;
      cTGroupFillProperties = (CTGroupFillProperties)get_store().find_element_user(GRPFILL$10, paramInt);
      if (cTGroupFillProperties == null)
        throw new IndexOutOfBoundsException(); 
      return cTGroupFillProperties;
    } 
  }
  
  public int sizeOfGrpFillArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(GRPFILL$10);
    } 
  }
  
  public void setGrpFillArray(CTGroupFillProperties[] paramArrayOfCTGroupFillProperties) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTGroupFillProperties, GRPFILL$10);
  }
  
  public void setGrpFillArray(int paramInt, CTGroupFillProperties paramCTGroupFillProperties) {
    generatedSetterHelperImpl((XmlObject)paramCTGroupFillProperties, GRPFILL$10, paramInt, (short)2);
  }
  
  public CTGroupFillProperties insertNewGrpFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTGroupFillProperties cTGroupFillProperties = null;
      cTGroupFillProperties = (CTGroupFillProperties)get_store().insert_element_user(GRPFILL$10, paramInt);
      return cTGroupFillProperties;
    } 
  }
  
  public CTGroupFillProperties addNewGrpFill() {
    synchronized (monitor()) {
      check_orphaned();
      CTGroupFillProperties cTGroupFillProperties = null;
      cTGroupFillProperties = (CTGroupFillProperties)get_store().add_element_user(GRPFILL$10);
      return cTGroupFillProperties;
    } 
  }
  
  public void removeGrpFill(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GRPFILL$10, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTFillStyleListImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */