package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLayout;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTManualLayout;

public class CTLayoutImpl extends XmlComplexContentImpl implements CTLayout {
  private static final long serialVersionUID = 1L;
  
  private static final QName MANUALLAYOUT$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "manualLayout");
  
  private static final QName EXTLST$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTLayoutImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTManualLayout getManualLayout() {
    synchronized (monitor()) {
      check_orphaned();
      CTManualLayout cTManualLayout = null;
      cTManualLayout = (CTManualLayout)get_store().find_element_user(MANUALLAYOUT$0, 0);
      if (cTManualLayout == null)
        return null; 
      return cTManualLayout;
    } 
  }
  
  public boolean isSetManualLayout() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(MANUALLAYOUT$0) != 0);
    } 
  }
  
  public void setManualLayout(CTManualLayout paramCTManualLayout) {
    generatedSetterHelperImpl((XmlObject)paramCTManualLayout, MANUALLAYOUT$0, 0, (short)1);
  }
  
  public CTManualLayout addNewManualLayout() {
    synchronized (monitor()) {
      check_orphaned();
      CTManualLayout cTManualLayout = null;
      cTManualLayout = (CTManualLayout)get_store().add_element_user(MANUALLAYOUT$0);
      return cTManualLayout;
    } 
  }
  
  public void unsetManualLayout() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(MANUALLAYOUT$0, 0);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$2, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$2) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$2, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$2);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$2, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTLayoutImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */