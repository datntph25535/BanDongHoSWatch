package org.openxmlformats.schemas.drawingml.x2006.main.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.main.CTDashStop;
import org.openxmlformats.schemas.drawingml.x2006.main.STPositivePercentage;

public class CTDashStopImpl extends XmlComplexContentImpl implements CTDashStop {
  private static final long serialVersionUID = 1L;
  
  private static final QName D$0 = new QName("", "d");
  
  private static final QName SP$2 = new QName("", "sp");
  
  public CTDashStopImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public int getD() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(D$0);
      if (simpleValue == null)
        return 0; 
      return simpleValue.getIntValue();
    } 
  }
  
  public STPositivePercentage xgetD() {
    synchronized (monitor()) {
      check_orphaned();
      STPositivePercentage sTPositivePercentage = null;
      sTPositivePercentage = (STPositivePercentage)get_store().find_attribute_user(D$0);
      return sTPositivePercentage;
    } 
  }
  
  public void setD(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(D$0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(D$0); 
      simpleValue.setIntValue(paramInt);
    } 
  }
  
  public void xsetD(STPositivePercentage paramSTPositivePercentage) {
    synchronized (monitor()) {
      check_orphaned();
      STPositivePercentage sTPositivePercentage = null;
      sTPositivePercentage = (STPositivePercentage)get_store().find_attribute_user(D$0);
      if (sTPositivePercentage == null)
        sTPositivePercentage = (STPositivePercentage)get_store().add_attribute_user(D$0); 
      sTPositivePercentage.set((XmlObject)paramSTPositivePercentage);
    } 
  }
  
  public int getSp() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(SP$2);
      if (simpleValue == null)
        return 0; 
      return simpleValue.getIntValue();
    } 
  }
  
  public STPositivePercentage xgetSp() {
    synchronized (monitor()) {
      check_orphaned();
      STPositivePercentage sTPositivePercentage = null;
      sTPositivePercentage = (STPositivePercentage)get_store().find_attribute_user(SP$2);
      return sTPositivePercentage;
    } 
  }
  
  public void setSp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(SP$2);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(SP$2); 
      simpleValue.setIntValue(paramInt);
    } 
  }
  
  public void xsetSp(STPositivePercentage paramSTPositivePercentage) {
    synchronized (monitor()) {
      check_orphaned();
      STPositivePercentage sTPositivePercentage = null;
      sTPositivePercentage = (STPositivePercentage)get_store().find_attribute_user(SP$2);
      if (sTPositivePercentage == null)
        sTPositivePercentage = (STPositivePercentage)get_store().add_attribute_user(SP$2); 
      sTPositivePercentage.set((XmlObject)paramSTPositivePercentage);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\main\impl\CTDashStopImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */