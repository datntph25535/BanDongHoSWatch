package org.openxmlformats.schemas.drawingml.x2006.chart;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlUnsignedShort;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface STGapAmount extends XmlUnsignedShort {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STGapAmount.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD023D6490046BA0250A839A9AD24C443").resolveHandle("stgapamount99a8type");
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    public static STGapAmount newValue(Object param1Object) {
      return (STGapAmount)STGapAmount.type.newValue(param1Object);
    }
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(STGapAmount.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static STGapAmount newInstance() {
      return (STGapAmount)getTypeLoader().newInstance(STGapAmount.type, null);
    }
    
    public static STGapAmount newInstance(XmlOptions param1XmlOptions) {
      return (STGapAmount)getTypeLoader().newInstance(STGapAmount.type, param1XmlOptions);
    }
    
    public static STGapAmount parse(String param1String) throws XmlException {
      return (STGapAmount)getTypeLoader().parse(param1String, STGapAmount.type, null);
    }
    
    public static STGapAmount parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (STGapAmount)getTypeLoader().parse(param1String, STGapAmount.type, param1XmlOptions);
    }
    
    public static STGapAmount parse(File param1File) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1File, STGapAmount.type, null);
    }
    
    public static STGapAmount parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1File, STGapAmount.type, param1XmlOptions);
    }
    
    public static STGapAmount parse(URL param1URL) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1URL, STGapAmount.type, null);
    }
    
    public static STGapAmount parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1URL, STGapAmount.type, param1XmlOptions);
    }
    
    public static STGapAmount parse(InputStream param1InputStream) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1InputStream, STGapAmount.type, null);
    }
    
    public static STGapAmount parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1InputStream, STGapAmount.type, param1XmlOptions);
    }
    
    public static STGapAmount parse(Reader param1Reader) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1Reader, STGapAmount.type, null);
    }
    
    public static STGapAmount parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (STGapAmount)getTypeLoader().parse(param1Reader, STGapAmount.type, param1XmlOptions);
    }
    
    public static STGapAmount parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (STGapAmount)getTypeLoader().parse(param1XMLStreamReader, STGapAmount.type, null);
    }
    
    public static STGapAmount parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (STGapAmount)getTypeLoader().parse(param1XMLStreamReader, STGapAmount.type, param1XmlOptions);
    }
    
    public static STGapAmount parse(Node param1Node) throws XmlException {
      return (STGapAmount)getTypeLoader().parse(param1Node, STGapAmount.type, null);
    }
    
    public static STGapAmount parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (STGapAmount)getTypeLoader().parse(param1Node, STGapAmount.type, param1XmlOptions);
    }
    
    @Deprecated
    public static STGapAmount parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (STGapAmount)getTypeLoader().parse(param1XMLInputStream, STGapAmount.type, null);
    }
    
    @Deprecated
    public static STGapAmount parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (STGapAmount)getTypeLoader().parse(param1XMLInputStream, STGapAmount.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, STGapAmount.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, STGapAmount.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\STGapAmount.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */