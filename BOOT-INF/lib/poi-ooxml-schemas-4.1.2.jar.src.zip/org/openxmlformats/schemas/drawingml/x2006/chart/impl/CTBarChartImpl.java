package org.openxmlformats.schemas.drawingml.x2006.chart.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarChart;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarDir;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarGrouping;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBarSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTBoolean;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTChartLines;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbls;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTExtensionList;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTGapAmount;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTOverlap;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;

public class CTBarChartImpl extends XmlComplexContentImpl implements CTBarChart {
  private static final long serialVersionUID = 1L;
  
  private static final QName BARDIR$0 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "barDir");
  
  private static final QName GROUPING$2 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "grouping");
  
  private static final QName VARYCOLORS$4 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "varyColors");
  
  private static final QName SER$6 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "ser");
  
  private static final QName DLBLS$8 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "dLbls");
  
  private static final QName GAPWIDTH$10 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "gapWidth");
  
  private static final QName OVERLAP$12 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "overlap");
  
  private static final QName SERLINES$14 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "serLines");
  
  private static final QName AXID$16 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "axId");
  
  private static final QName EXTLST$18 = new QName("http://schemas.openxmlformats.org/drawingml/2006/chart", "extLst");
  
  public CTBarChartImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CTBarDir getBarDir() {
    synchronized (monitor()) {
      check_orphaned();
      CTBarDir cTBarDir = null;
      cTBarDir = (CTBarDir)get_store().find_element_user(BARDIR$0, 0);
      if (cTBarDir == null)
        return null; 
      return cTBarDir;
    } 
  }
  
  public void setBarDir(CTBarDir paramCTBarDir) {
    generatedSetterHelperImpl((XmlObject)paramCTBarDir, BARDIR$0, 0, (short)1);
  }
  
  public CTBarDir addNewBarDir() {
    synchronized (monitor()) {
      check_orphaned();
      CTBarDir cTBarDir = null;
      cTBarDir = (CTBarDir)get_store().add_element_user(BARDIR$0);
      return cTBarDir;
    } 
  }
  
  public CTBarGrouping getGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      CTBarGrouping cTBarGrouping = null;
      cTBarGrouping = (CTBarGrouping)get_store().find_element_user(GROUPING$2, 0);
      if (cTBarGrouping == null)
        return null; 
      return cTBarGrouping;
    } 
  }
  
  public boolean isSetGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(GROUPING$2) != 0);
    } 
  }
  
  public void setGrouping(CTBarGrouping paramCTBarGrouping) {
    generatedSetterHelperImpl((XmlObject)paramCTBarGrouping, GROUPING$2, 0, (short)1);
  }
  
  public CTBarGrouping addNewGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      CTBarGrouping cTBarGrouping = null;
      cTBarGrouping = (CTBarGrouping)get_store().add_element_user(GROUPING$2);
      return cTBarGrouping;
    } 
  }
  
  public void unsetGrouping() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GROUPING$2, 0);
    } 
  }
  
  public CTBoolean getVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().find_element_user(VARYCOLORS$4, 0);
      if (cTBoolean == null)
        return null; 
      return cTBoolean;
    } 
  }
  
  public boolean isSetVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(VARYCOLORS$4) != 0);
    } 
  }
  
  public void setVaryColors(CTBoolean paramCTBoolean) {
    generatedSetterHelperImpl((XmlObject)paramCTBoolean, VARYCOLORS$4, 0, (short)1);
  }
  
  public CTBoolean addNewVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      CTBoolean cTBoolean = null;
      cTBoolean = (CTBoolean)get_store().add_element_user(VARYCOLORS$4);
      return cTBoolean;
    } 
  }
  
  public void unsetVaryColors() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(VARYCOLORS$4, 0);
    } 
  }
  
  public List<CTBarSer> getSerList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SerList extends AbstractList<CTBarSer> {
        public CTBarSer get(int param1Int) {
          return CTBarChartImpl.this.getSerArray(param1Int);
        }
        
        public CTBarSer set(int param1Int, CTBarSer param1CTBarSer) {
          CTBarSer cTBarSer = CTBarChartImpl.this.getSerArray(param1Int);
          CTBarChartImpl.this.setSerArray(param1Int, param1CTBarSer);
          return cTBarSer;
        }
        
        public void add(int param1Int, CTBarSer param1CTBarSer) {
          CTBarChartImpl.this.insertNewSer(param1Int).set((XmlObject)param1CTBarSer);
        }
        
        public CTBarSer remove(int param1Int) {
          CTBarSer cTBarSer = CTBarChartImpl.this.getSerArray(param1Int);
          CTBarChartImpl.this.removeSer(param1Int);
          return cTBarSer;
        }
        
        public int size() {
          return CTBarChartImpl.this.sizeOfSerArray();
        }
      };
      return new SerList();
    } 
  }
  
  @Deprecated
  public CTBarSer[] getSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SER$6, arrayList);
      CTBarSer[] arrayOfCTBarSer = new CTBarSer[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTBarSer);
      return arrayOfCTBarSer;
    } 
  }
  
  public CTBarSer getSerArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBarSer cTBarSer = null;
      cTBarSer = (CTBarSer)get_store().find_element_user(SER$6, paramInt);
      if (cTBarSer == null)
        throw new IndexOutOfBoundsException(); 
      return cTBarSer;
    } 
  }
  
  public int sizeOfSerArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SER$6);
    } 
  }
  
  public void setSerArray(CTBarSer[] paramArrayOfCTBarSer) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTBarSer, SER$6);
  }
  
  public void setSerArray(int paramInt, CTBarSer paramCTBarSer) {
    generatedSetterHelperImpl((XmlObject)paramCTBarSer, SER$6, paramInt, (short)2);
  }
  
  public CTBarSer insertNewSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTBarSer cTBarSer = null;
      cTBarSer = (CTBarSer)get_store().insert_element_user(SER$6, paramInt);
      return cTBarSer;
    } 
  }
  
  public CTBarSer addNewSer() {
    synchronized (monitor()) {
      check_orphaned();
      CTBarSer cTBarSer = null;
      cTBarSer = (CTBarSer)get_store().add_element_user(SER$6);
      return cTBarSer;
    } 
  }
  
  public void removeSer(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SER$6, paramInt);
    } 
  }
  
  public CTDLbls getDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().find_element_user(DLBLS$8, 0);
      if (cTDLbls == null)
        return null; 
      return cTDLbls;
    } 
  }
  
  public boolean isSetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(DLBLS$8) != 0);
    } 
  }
  
  public void setDLbls(CTDLbls paramCTDLbls) {
    generatedSetterHelperImpl((XmlObject)paramCTDLbls, DLBLS$8, 0, (short)1);
  }
  
  public CTDLbls addNewDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      CTDLbls cTDLbls = null;
      cTDLbls = (CTDLbls)get_store().add_element_user(DLBLS$8);
      return cTDLbls;
    } 
  }
  
  public void unsetDLbls() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(DLBLS$8, 0);
    } 
  }
  
  public CTGapAmount getGapWidth() {
    synchronized (monitor()) {
      check_orphaned();
      CTGapAmount cTGapAmount = null;
      cTGapAmount = (CTGapAmount)get_store().find_element_user(GAPWIDTH$10, 0);
      if (cTGapAmount == null)
        return null; 
      return cTGapAmount;
    } 
  }
  
  public boolean isSetGapWidth() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(GAPWIDTH$10) != 0);
    } 
  }
  
  public void setGapWidth(CTGapAmount paramCTGapAmount) {
    generatedSetterHelperImpl((XmlObject)paramCTGapAmount, GAPWIDTH$10, 0, (short)1);
  }
  
  public CTGapAmount addNewGapWidth() {
    synchronized (monitor()) {
      check_orphaned();
      CTGapAmount cTGapAmount = null;
      cTGapAmount = (CTGapAmount)get_store().add_element_user(GAPWIDTH$10);
      return cTGapAmount;
    } 
  }
  
  public void unsetGapWidth() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(GAPWIDTH$10, 0);
    } 
  }
  
  public CTOverlap getOverlap() {
    synchronized (monitor()) {
      check_orphaned();
      CTOverlap cTOverlap = null;
      cTOverlap = (CTOverlap)get_store().find_element_user(OVERLAP$12, 0);
      if (cTOverlap == null)
        return null; 
      return cTOverlap;
    } 
  }
  
  public boolean isSetOverlap() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(OVERLAP$12) != 0);
    } 
  }
  
  public void setOverlap(CTOverlap paramCTOverlap) {
    generatedSetterHelperImpl((XmlObject)paramCTOverlap, OVERLAP$12, 0, (short)1);
  }
  
  public CTOverlap addNewOverlap() {
    synchronized (monitor()) {
      check_orphaned();
      CTOverlap cTOverlap = null;
      cTOverlap = (CTOverlap)get_store().add_element_user(OVERLAP$12);
      return cTOverlap;
    } 
  }
  
  public void unsetOverlap() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OVERLAP$12, 0);
    } 
  }
  
  public List<CTChartLines> getSerLinesList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SerLinesList extends AbstractList<CTChartLines> {
        public CTChartLines get(int param1Int) {
          return CTBarChartImpl.this.getSerLinesArray(param1Int);
        }
        
        public CTChartLines set(int param1Int, CTChartLines param1CTChartLines) {
          CTChartLines cTChartLines = CTBarChartImpl.this.getSerLinesArray(param1Int);
          CTBarChartImpl.this.setSerLinesArray(param1Int, param1CTChartLines);
          return cTChartLines;
        }
        
        public void add(int param1Int, CTChartLines param1CTChartLines) {
          CTBarChartImpl.this.insertNewSerLines(param1Int).set((XmlObject)param1CTChartLines);
        }
        
        public CTChartLines remove(int param1Int) {
          CTChartLines cTChartLines = CTBarChartImpl.this.getSerLinesArray(param1Int);
          CTBarChartImpl.this.removeSerLines(param1Int);
          return cTChartLines;
        }
        
        public int size() {
          return CTBarChartImpl.this.sizeOfSerLinesArray();
        }
      };
      return new SerLinesList();
    } 
  }
  
  @Deprecated
  public CTChartLines[] getSerLinesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SERLINES$14, arrayList);
      CTChartLines[] arrayOfCTChartLines = new CTChartLines[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTChartLines);
      return arrayOfCTChartLines;
    } 
  }
  
  public CTChartLines getSerLinesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTChartLines cTChartLines = null;
      cTChartLines = (CTChartLines)get_store().find_element_user(SERLINES$14, paramInt);
      if (cTChartLines == null)
        throw new IndexOutOfBoundsException(); 
      return cTChartLines;
    } 
  }
  
  public int sizeOfSerLinesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SERLINES$14);
    } 
  }
  
  public void setSerLinesArray(CTChartLines[] paramArrayOfCTChartLines) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTChartLines, SERLINES$14);
  }
  
  public void setSerLinesArray(int paramInt, CTChartLines paramCTChartLines) {
    generatedSetterHelperImpl((XmlObject)paramCTChartLines, SERLINES$14, paramInt, (short)2);
  }
  
  public CTChartLines insertNewSerLines(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTChartLines cTChartLines = null;
      cTChartLines = (CTChartLines)get_store().insert_element_user(SERLINES$14, paramInt);
      return cTChartLines;
    } 
  }
  
  public CTChartLines addNewSerLines() {
    synchronized (monitor()) {
      check_orphaned();
      CTChartLines cTChartLines = null;
      cTChartLines = (CTChartLines)get_store().add_element_user(SERLINES$14);
      return cTChartLines;
    } 
  }
  
  public void removeSerLines(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SERLINES$14, paramInt);
    } 
  }
  
  public List<CTUnsignedInt> getAxIdList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AxIdList extends AbstractList<CTUnsignedInt> {
        public CTUnsignedInt get(int param1Int) {
          return CTBarChartImpl.this.getAxIdArray(param1Int);
        }
        
        public CTUnsignedInt set(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTUnsignedInt cTUnsignedInt = CTBarChartImpl.this.getAxIdArray(param1Int);
          CTBarChartImpl.this.setAxIdArray(param1Int, param1CTUnsignedInt);
          return cTUnsignedInt;
        }
        
        public void add(int param1Int, CTUnsignedInt param1CTUnsignedInt) {
          CTBarChartImpl.this.insertNewAxId(param1Int).set((XmlObject)param1CTUnsignedInt);
        }
        
        public CTUnsignedInt remove(int param1Int) {
          CTUnsignedInt cTUnsignedInt = CTBarChartImpl.this.getAxIdArray(param1Int);
          CTBarChartImpl.this.removeAxId(param1Int);
          return cTUnsignedInt;
        }
        
        public int size() {
          return CTBarChartImpl.this.sizeOfAxIdArray();
        }
      };
      return new AxIdList();
    } 
  }
  
  @Deprecated
  public CTUnsignedInt[] getAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(AXID$16, arrayList);
      CTUnsignedInt[] arrayOfCTUnsignedInt = new CTUnsignedInt[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCTUnsignedInt);
      return arrayOfCTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt getAxIdArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().find_element_user(AXID$16, paramInt);
      if (cTUnsignedInt == null)
        throw new IndexOutOfBoundsException(); 
      return cTUnsignedInt;
    } 
  }
  
  public int sizeOfAxIdArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(AXID$16);
    } 
  }
  
  public void setAxIdArray(CTUnsignedInt[] paramArrayOfCTUnsignedInt) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCTUnsignedInt, AXID$16);
  }
  
  public void setAxIdArray(int paramInt, CTUnsignedInt paramCTUnsignedInt) {
    generatedSetterHelperImpl((XmlObject)paramCTUnsignedInt, AXID$16, paramInt, (short)2);
  }
  
  public CTUnsignedInt insertNewAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().insert_element_user(AXID$16, paramInt);
      return cTUnsignedInt;
    } 
  }
  
  public CTUnsignedInt addNewAxId() {
    synchronized (monitor()) {
      check_orphaned();
      CTUnsignedInt cTUnsignedInt = null;
      cTUnsignedInt = (CTUnsignedInt)get_store().add_element_user(AXID$16);
      return cTUnsignedInt;
    } 
  }
  
  public void removeAxId(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(AXID$16, paramInt);
    } 
  }
  
  public CTExtensionList getExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().find_element_user(EXTLST$18, 0);
      if (cTExtensionList == null)
        return null; 
      return cTExtensionList;
    } 
  }
  
  public boolean isSetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(EXTLST$18) != 0);
    } 
  }
  
  public void setExtLst(CTExtensionList paramCTExtensionList) {
    generatedSetterHelperImpl((XmlObject)paramCTExtensionList, EXTLST$18, 0, (short)1);
  }
  
  public CTExtensionList addNewExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      CTExtensionList cTExtensionList = null;
      cTExtensionList = (CTExtensionList)get_store().add_element_user(EXTLST$18);
      return cTExtensionList;
    } 
  }
  
  public void unsetExtLst() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(EXTLST$18, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\openxmlformats\schemas\drawingml\x2006\chart\impl\CTBarChartImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */