package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.QualifyingPropertiesDocument;
import org.etsi.uri.x01903.v13.QualifyingPropertiesType;

public class QualifyingPropertiesDocumentImpl extends XmlComplexContentImpl implements QualifyingPropertiesDocument {
  private static final long serialVersionUID = 1L;
  
  private static final QName QUALIFYINGPROPERTIES$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "QualifyingProperties");
  
  public QualifyingPropertiesDocumentImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public QualifyingPropertiesType getQualifyingProperties() {
    synchronized (monitor()) {
      check_orphaned();
      QualifyingPropertiesType qualifyingPropertiesType = null;
      qualifyingPropertiesType = (QualifyingPropertiesType)get_store().find_element_user(QUALIFYINGPROPERTIES$0, 0);
      if (qualifyingPropertiesType == null)
        return null; 
      return qualifyingPropertiesType;
    } 
  }
  
  public void setQualifyingProperties(QualifyingPropertiesType paramQualifyingPropertiesType) {
    generatedSetterHelperImpl((XmlObject)paramQualifyingPropertiesType, QUALIFYINGPROPERTIES$0, 0, (short)1);
  }
  
  public QualifyingPropertiesType addNewQualifyingProperties() {
    synchronized (monitor()) {
      check_orphaned();
      QualifyingPropertiesType qualifyingPropertiesType = null;
      qualifyingPropertiesType = (QualifyingPropertiesType)get_store().add_element_user(QUALIFYINGPROPERTIES$0);
      return qualifyingPropertiesType;
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\QualifyingPropertiesDocumentImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */