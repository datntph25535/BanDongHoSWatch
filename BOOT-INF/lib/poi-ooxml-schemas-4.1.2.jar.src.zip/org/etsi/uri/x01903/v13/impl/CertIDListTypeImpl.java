package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CertIDListType;
import org.etsi.uri.x01903.v13.CertIDType;

public class CertIDListTypeImpl extends XmlComplexContentImpl implements CertIDListType {
  private static final long serialVersionUID = 1L;
  
  private static final QName CERT$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "Cert");
  
  public CertIDListTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CertIDType> getCertList() {
    synchronized (monitor()) {
      check_orphaned();
      final class CertList extends AbstractList<CertIDType> {
        public CertIDType get(int param1Int) {
          return CertIDListTypeImpl.this.getCertArray(param1Int);
        }
        
        public CertIDType set(int param1Int, CertIDType param1CertIDType) {
          CertIDType certIDType = CertIDListTypeImpl.this.getCertArray(param1Int);
          CertIDListTypeImpl.this.setCertArray(param1Int, param1CertIDType);
          return certIDType;
        }
        
        public void add(int param1Int, CertIDType param1CertIDType) {
          CertIDListTypeImpl.this.insertNewCert(param1Int).set((XmlObject)param1CertIDType);
        }
        
        public CertIDType remove(int param1Int) {
          CertIDType certIDType = CertIDListTypeImpl.this.getCertArray(param1Int);
          CertIDListTypeImpl.this.removeCert(param1Int);
          return certIDType;
        }
        
        public int size() {
          return CertIDListTypeImpl.this.sizeOfCertArray();
        }
      };
      return new CertList();
    } 
  }
  
  @Deprecated
  public CertIDType[] getCertArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CERT$0, arrayList);
      CertIDType[] arrayOfCertIDType = new CertIDType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCertIDType);
      return arrayOfCertIDType;
    } 
  }
  
  public CertIDType getCertArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertIDType certIDType = null;
      certIDType = (CertIDType)get_store().find_element_user(CERT$0, paramInt);
      if (certIDType == null)
        throw new IndexOutOfBoundsException(); 
      return certIDType;
    } 
  }
  
  public int sizeOfCertArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CERT$0);
    } 
  }
  
  public void setCertArray(CertIDType[] paramArrayOfCertIDType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCertIDType, CERT$0);
  }
  
  public void setCertArray(int paramInt, CertIDType paramCertIDType) {
    generatedSetterHelperImpl((XmlObject)paramCertIDType, CERT$0, paramInt, (short)2);
  }
  
  public CertIDType insertNewCert(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertIDType certIDType = null;
      certIDType = (CertIDType)get_store().insert_element_user(CERT$0, paramInt);
      return certIDType;
    } 
  }
  
  public CertIDType addNewCert() {
    synchronized (monitor()) {
      check_orphaned();
      CertIDType certIDType = null;
      certIDType = (CertIDType)get_store().add_element_user(CERT$0);
      return certIDType;
    } 
  }
  
  public void removeCert(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CERT$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\CertIDListTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */