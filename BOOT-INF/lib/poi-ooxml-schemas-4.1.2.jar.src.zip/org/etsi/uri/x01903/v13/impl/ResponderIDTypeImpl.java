package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.ResponderIDType;

public class ResponderIDTypeImpl extends XmlComplexContentImpl implements ResponderIDType {
  private static final long serialVersionUID = 1L;
  
  private static final QName BYNAME$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ByName");
  
  private static final QName BYKEY$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ByKey");
  
  public ResponderIDTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public String getByName() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(BYNAME$0, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlString xgetByName() {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_element_user(BYNAME$0, 0);
      return xmlString;
    } 
  }
  
  public boolean isSetByName() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(BYNAME$0) != 0);
    } 
  }
  
  public void setByName(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(BYNAME$0, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(BYNAME$0); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetByName(XmlString paramXmlString) {
    synchronized (monitor()) {
      check_orphaned();
      XmlString xmlString = null;
      xmlString = (XmlString)get_store().find_element_user(BYNAME$0, 0);
      if (xmlString == null)
        xmlString = (XmlString)get_store().add_element_user(BYNAME$0); 
      xmlString.set((XmlObject)paramXmlString);
    } 
  }
  
  public void unsetByName() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BYNAME$0, 0);
    } 
  }
  
  public byte[] getByKey() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(BYKEY$2, 0);
      if (simpleValue == null)
        return null; 
      return simpleValue.getByteArrayValue();
    } 
  }
  
  public XmlBase64Binary xgetByKey() {
    synchronized (monitor()) {
      check_orphaned();
      XmlBase64Binary xmlBase64Binary = null;
      xmlBase64Binary = (XmlBase64Binary)get_store().find_element_user(BYKEY$2, 0);
      return xmlBase64Binary;
    } 
  }
  
  public boolean isSetByKey() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(BYKEY$2) != 0);
    } 
  }
  
  public void setByKey(byte[] paramArrayOfbyte) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_element_user(BYKEY$2, 0);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_element_user(BYKEY$2); 
      simpleValue.setByteArrayValue(paramArrayOfbyte);
    } 
  }
  
  public void xsetByKey(XmlBase64Binary paramXmlBase64Binary) {
    synchronized (monitor()) {
      check_orphaned();
      XmlBase64Binary xmlBase64Binary = null;
      xmlBase64Binary = (XmlBase64Binary)get_store().find_element_user(BYKEY$2, 0);
      if (xmlBase64Binary == null)
        xmlBase64Binary = (XmlBase64Binary)get_store().add_element_user(BYKEY$2); 
      xmlBase64Binary.set((XmlObject)paramXmlBase64Binary);
    } 
  }
  
  public void unsetByKey() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(BYKEY$2, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\ResponderIDTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */