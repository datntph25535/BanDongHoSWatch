package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CertifiedRolesListType;
import org.etsi.uri.x01903.v13.ClaimedRolesListType;
import org.etsi.uri.x01903.v13.SignerRoleType;

public class SignerRoleTypeImpl extends XmlComplexContentImpl implements SignerRoleType {
  private static final long serialVersionUID = 1L;
  
  private static final QName CLAIMEDROLES$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ClaimedRoles");
  
  private static final QName CERTIFIEDROLES$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CertifiedRoles");
  
  public SignerRoleTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public ClaimedRolesListType getClaimedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      ClaimedRolesListType claimedRolesListType = null;
      claimedRolesListType = (ClaimedRolesListType)get_store().find_element_user(CLAIMEDROLES$0, 0);
      if (claimedRolesListType == null)
        return null; 
      return claimedRolesListType;
    } 
  }
  
  public boolean isSetClaimedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CLAIMEDROLES$0) != 0);
    } 
  }
  
  public void setClaimedRoles(ClaimedRolesListType paramClaimedRolesListType) {
    generatedSetterHelperImpl((XmlObject)paramClaimedRolesListType, CLAIMEDROLES$0, 0, (short)1);
  }
  
  public ClaimedRolesListType addNewClaimedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      ClaimedRolesListType claimedRolesListType = null;
      claimedRolesListType = (ClaimedRolesListType)get_store().add_element_user(CLAIMEDROLES$0);
      return claimedRolesListType;
    } 
  }
  
  public void unsetClaimedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CLAIMEDROLES$0, 0);
    } 
  }
  
  public CertifiedRolesListType getCertifiedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      CertifiedRolesListType certifiedRolesListType = null;
      certifiedRolesListType = (CertifiedRolesListType)get_store().find_element_user(CERTIFIEDROLES$2, 0);
      if (certifiedRolesListType == null)
        return null; 
      return certifiedRolesListType;
    } 
  }
  
  public boolean isSetCertifiedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CERTIFIEDROLES$2) != 0);
    } 
  }
  
  public void setCertifiedRoles(CertifiedRolesListType paramCertifiedRolesListType) {
    generatedSetterHelperImpl((XmlObject)paramCertifiedRolesListType, CERTIFIEDROLES$2, 0, (short)1);
  }
  
  public CertifiedRolesListType addNewCertifiedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      CertifiedRolesListType certifiedRolesListType = null;
      certifiedRolesListType = (CertifiedRolesListType)get_store().add_element_user(CERTIFIEDROLES$2);
      return certifiedRolesListType;
    } 
  }
  
  public void unsetCertifiedRoles() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CERTIFIEDROLES$2, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\SignerRoleTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */