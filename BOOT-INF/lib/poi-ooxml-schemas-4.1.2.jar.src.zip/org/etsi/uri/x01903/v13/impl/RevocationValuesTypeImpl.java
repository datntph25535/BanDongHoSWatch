package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLValuesType;
import org.etsi.uri.x01903.v13.OCSPValuesType;
import org.etsi.uri.x01903.v13.OtherCertStatusValuesType;
import org.etsi.uri.x01903.v13.RevocationValuesType;

public class RevocationValuesTypeImpl extends XmlComplexContentImpl implements RevocationValuesType {
  private static final long serialVersionUID = 1L;
  
  private static final QName CRLVALUES$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CRLValues");
  
  private static final QName OCSPVALUES$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "OCSPValues");
  
  private static final QName OTHERVALUES$4 = new QName("http://uri.etsi.org/01903/v1.3.2#", "OtherValues");
  
  private static final QName ID$6 = new QName("", "Id");
  
  public RevocationValuesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public CRLValuesType getCRLValues() {
    synchronized (monitor()) {
      check_orphaned();
      CRLValuesType cRLValuesType = null;
      cRLValuesType = (CRLValuesType)get_store().find_element_user(CRLVALUES$0, 0);
      if (cRLValuesType == null)
        return null; 
      return cRLValuesType;
    } 
  }
  
  public boolean isSetCRLValues() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CRLVALUES$0) != 0);
    } 
  }
  
  public void setCRLValues(CRLValuesType paramCRLValuesType) {
    generatedSetterHelperImpl((XmlObject)paramCRLValuesType, CRLVALUES$0, 0, (short)1);
  }
  
  public CRLValuesType addNewCRLValues() {
    synchronized (monitor()) {
      check_orphaned();
      CRLValuesType cRLValuesType = null;
      cRLValuesType = (CRLValuesType)get_store().add_element_user(CRLVALUES$0);
      return cRLValuesType;
    } 
  }
  
  public void unsetCRLValues() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CRLVALUES$0, 0);
    } 
  }
  
  public OCSPValuesType getOCSPValues() {
    synchronized (monitor()) {
      check_orphaned();
      OCSPValuesType oCSPValuesType = null;
      oCSPValuesType = (OCSPValuesType)get_store().find_element_user(OCSPVALUES$2, 0);
      if (oCSPValuesType == null)
        return null; 
      return oCSPValuesType;
    } 
  }
  
  public boolean isSetOCSPValues() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(OCSPVALUES$2) != 0);
    } 
  }
  
  public void setOCSPValues(OCSPValuesType paramOCSPValuesType) {
    generatedSetterHelperImpl((XmlObject)paramOCSPValuesType, OCSPVALUES$2, 0, (short)1);
  }
  
  public OCSPValuesType addNewOCSPValues() {
    synchronized (monitor()) {
      check_orphaned();
      OCSPValuesType oCSPValuesType = null;
      oCSPValuesType = (OCSPValuesType)get_store().add_element_user(OCSPVALUES$2);
      return oCSPValuesType;
    } 
  }
  
  public void unsetOCSPValues() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OCSPVALUES$2, 0);
    } 
  }
  
  public OtherCertStatusValuesType getOtherValues() {
    synchronized (monitor()) {
      check_orphaned();
      OtherCertStatusValuesType otherCertStatusValuesType = null;
      otherCertStatusValuesType = (OtherCertStatusValuesType)get_store().find_element_user(OTHERVALUES$4, 0);
      if (otherCertStatusValuesType == null)
        return null; 
      return otherCertStatusValuesType;
    } 
  }
  
  public boolean isSetOtherValues() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(OTHERVALUES$4) != 0);
    } 
  }
  
  public void setOtherValues(OtherCertStatusValuesType paramOtherCertStatusValuesType) {
    generatedSetterHelperImpl((XmlObject)paramOtherCertStatusValuesType, OTHERVALUES$4, 0, (short)1);
  }
  
  public OtherCertStatusValuesType addNewOtherValues() {
    synchronized (monitor()) {
      check_orphaned();
      OtherCertStatusValuesType otherCertStatusValuesType = null;
      otherCertStatusValuesType = (OtherCertStatusValuesType)get_store().add_element_user(OTHERVALUES$4);
      return otherCertStatusValuesType;
    } 
  }
  
  public void unsetOtherValues() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OTHERVALUES$4, 0);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$6);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$6);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$6) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$6);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$6); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$6);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$6); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$6);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\RevocationValuesTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */