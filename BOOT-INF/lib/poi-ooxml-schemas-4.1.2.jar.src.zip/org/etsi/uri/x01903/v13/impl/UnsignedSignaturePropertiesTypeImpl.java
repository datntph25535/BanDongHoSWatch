package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CertificateValuesType;
import org.etsi.uri.x01903.v13.CompleteCertificateRefsType;
import org.etsi.uri.x01903.v13.CompleteRevocationRefsType;
import org.etsi.uri.x01903.v13.CounterSignatureType;
import org.etsi.uri.x01903.v13.RevocationValuesType;
import org.etsi.uri.x01903.v13.UnsignedSignaturePropertiesType;
import org.etsi.uri.x01903.v13.XAdESTimeStampType;

public class UnsignedSignaturePropertiesTypeImpl extends XmlComplexContentImpl implements UnsignedSignaturePropertiesType {
  private static final long serialVersionUID = 1L;
  
  private static final QName COUNTERSIGNATURE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CounterSignature");
  
  private static final QName SIGNATURETIMESTAMP$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SignatureTimeStamp");
  
  private static final QName COMPLETECERTIFICATEREFS$4 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CompleteCertificateRefs");
  
  private static final QName COMPLETEREVOCATIONREFS$6 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CompleteRevocationRefs");
  
  private static final QName ATTRIBUTECERTIFICATEREFS$8 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttributeCertificateRefs");
  
  private static final QName ATTRIBUTEREVOCATIONREFS$10 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttributeRevocationRefs");
  
  private static final QName SIGANDREFSTIMESTAMP$12 = new QName("http://uri.etsi.org/01903/v1.3.2#", "SigAndRefsTimeStamp");
  
  private static final QName REFSONLYTIMESTAMP$14 = new QName("http://uri.etsi.org/01903/v1.3.2#", "RefsOnlyTimeStamp");
  
  private static final QName CERTIFICATEVALUES$16 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CertificateValues");
  
  private static final QName REVOCATIONVALUES$18 = new QName("http://uri.etsi.org/01903/v1.3.2#", "RevocationValues");
  
  private static final QName ATTRAUTHORITIESCERTVALUES$20 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttrAuthoritiesCertValues");
  
  private static final QName ATTRIBUTEREVOCATIONVALUES$22 = new QName("http://uri.etsi.org/01903/v1.3.2#", "AttributeRevocationValues");
  
  private static final QName ARCHIVETIMESTAMP$24 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ArchiveTimeStamp");
  
  private static final QName ID$26 = new QName("", "Id");
  
  public UnsignedSignaturePropertiesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CounterSignatureType> getCounterSignatureList() {
    synchronized (monitor()) {
      check_orphaned();
      final class CounterSignatureList extends AbstractList<CounterSignatureType> {
        public CounterSignatureType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getCounterSignatureArray(param1Int);
        }
        
        public CounterSignatureType set(int param1Int, CounterSignatureType param1CounterSignatureType) {
          CounterSignatureType counterSignatureType = UnsignedSignaturePropertiesTypeImpl.this.getCounterSignatureArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setCounterSignatureArray(param1Int, param1CounterSignatureType);
          return counterSignatureType;
        }
        
        public void add(int param1Int, CounterSignatureType param1CounterSignatureType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewCounterSignature(param1Int).set((XmlObject)param1CounterSignatureType);
        }
        
        public CounterSignatureType remove(int param1Int) {
          CounterSignatureType counterSignatureType = UnsignedSignaturePropertiesTypeImpl.this.getCounterSignatureArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeCounterSignature(param1Int);
          return counterSignatureType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfCounterSignatureArray();
        }
      };
      return new CounterSignatureList();
    } 
  }
  
  @Deprecated
  public CounterSignatureType[] getCounterSignatureArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(COUNTERSIGNATURE$0, arrayList);
      CounterSignatureType[] arrayOfCounterSignatureType = new CounterSignatureType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCounterSignatureType);
      return arrayOfCounterSignatureType;
    } 
  }
  
  public CounterSignatureType getCounterSignatureArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CounterSignatureType counterSignatureType = null;
      counterSignatureType = (CounterSignatureType)get_store().find_element_user(COUNTERSIGNATURE$0, paramInt);
      if (counterSignatureType == null)
        throw new IndexOutOfBoundsException(); 
      return counterSignatureType;
    } 
  }
  
  public int sizeOfCounterSignatureArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(COUNTERSIGNATURE$0);
    } 
  }
  
  public void setCounterSignatureArray(CounterSignatureType[] paramArrayOfCounterSignatureType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCounterSignatureType, COUNTERSIGNATURE$0);
  }
  
  public void setCounterSignatureArray(int paramInt, CounterSignatureType paramCounterSignatureType) {
    generatedSetterHelperImpl((XmlObject)paramCounterSignatureType, COUNTERSIGNATURE$0, paramInt, (short)2);
  }
  
  public CounterSignatureType insertNewCounterSignature(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CounterSignatureType counterSignatureType = null;
      counterSignatureType = (CounterSignatureType)get_store().insert_element_user(COUNTERSIGNATURE$0, paramInt);
      return counterSignatureType;
    } 
  }
  
  public CounterSignatureType addNewCounterSignature() {
    synchronized (monitor()) {
      check_orphaned();
      CounterSignatureType counterSignatureType = null;
      counterSignatureType = (CounterSignatureType)get_store().add_element_user(COUNTERSIGNATURE$0);
      return counterSignatureType;
    } 
  }
  
  public void removeCounterSignature(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(COUNTERSIGNATURE$0, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getSignatureTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SignatureTimeStampList extends AbstractList<XAdESTimeStampType> {
        public XAdESTimeStampType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getSignatureTimeStampArray(param1Int);
        }
        
        public XAdESTimeStampType set(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getSignatureTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setSignatureTimeStampArray(param1Int, param1XAdESTimeStampType);
          return xAdESTimeStampType;
        }
        
        public void add(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewSignatureTimeStamp(param1Int).set((XmlObject)param1XAdESTimeStampType);
        }
        
        public XAdESTimeStampType remove(int param1Int) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getSignatureTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeSignatureTimeStamp(param1Int);
          return xAdESTimeStampType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfSignatureTimeStampArray();
        }
      };
      return new SignatureTimeStampList();
    } 
  }
  
  @Deprecated
  public XAdESTimeStampType[] getSignatureTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SIGNATURETIMESTAMP$2, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getSignatureTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(SIGNATURETIMESTAMP$2, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfSignatureTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SIGNATURETIMESTAMP$2);
    } 
  }
  
  public void setSignatureTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, SIGNATURETIMESTAMP$2);
  }
  
  public void setSignatureTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    generatedSetterHelperImpl((XmlObject)paramXAdESTimeStampType, SIGNATURETIMESTAMP$2, paramInt, (short)2);
  }
  
  public XAdESTimeStampType insertNewSignatureTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(SIGNATURETIMESTAMP$2, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewSignatureTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(SIGNATURETIMESTAMP$2);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeSignatureTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGNATURETIMESTAMP$2, paramInt);
    } 
  }
  
  public List<CompleteCertificateRefsType> getCompleteCertificateRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      final class CompleteCertificateRefsList extends AbstractList<CompleteCertificateRefsType> {
        public CompleteCertificateRefsType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getCompleteCertificateRefsArray(param1Int);
        }
        
        public CompleteCertificateRefsType set(int param1Int, CompleteCertificateRefsType param1CompleteCertificateRefsType) {
          CompleteCertificateRefsType completeCertificateRefsType = UnsignedSignaturePropertiesTypeImpl.this.getCompleteCertificateRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setCompleteCertificateRefsArray(param1Int, param1CompleteCertificateRefsType);
          return completeCertificateRefsType;
        }
        
        public void add(int param1Int, CompleteCertificateRefsType param1CompleteCertificateRefsType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewCompleteCertificateRefs(param1Int).set((XmlObject)param1CompleteCertificateRefsType);
        }
        
        public CompleteCertificateRefsType remove(int param1Int) {
          CompleteCertificateRefsType completeCertificateRefsType = UnsignedSignaturePropertiesTypeImpl.this.getCompleteCertificateRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeCompleteCertificateRefs(param1Int);
          return completeCertificateRefsType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfCompleteCertificateRefsArray();
        }
      };
      return new CompleteCertificateRefsList();
    } 
  }
  
  @Deprecated
  public CompleteCertificateRefsType[] getCompleteCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(COMPLETECERTIFICATEREFS$4, arrayList);
      CompleteCertificateRefsType[] arrayOfCompleteCertificateRefsType = new CompleteCertificateRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteCertificateRefsType);
      return arrayOfCompleteCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType getCompleteCertificateRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().find_element_user(COMPLETECERTIFICATEREFS$4, paramInt);
      if (completeCertificateRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeCertificateRefsType;
    } 
  }
  
  public int sizeOfCompleteCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(COMPLETECERTIFICATEREFS$4);
    } 
  }
  
  public void setCompleteCertificateRefsArray(CompleteCertificateRefsType[] paramArrayOfCompleteCertificateRefsType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCompleteCertificateRefsType, COMPLETECERTIFICATEREFS$4);
  }
  
  public void setCompleteCertificateRefsArray(int paramInt, CompleteCertificateRefsType paramCompleteCertificateRefsType) {
    generatedSetterHelperImpl((XmlObject)paramCompleteCertificateRefsType, COMPLETECERTIFICATEREFS$4, paramInt, (short)2);
  }
  
  public CompleteCertificateRefsType insertNewCompleteCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().insert_element_user(COMPLETECERTIFICATEREFS$4, paramInt);
      return completeCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType addNewCompleteCertificateRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().add_element_user(COMPLETECERTIFICATEREFS$4);
      return completeCertificateRefsType;
    } 
  }
  
  public void removeCompleteCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(COMPLETECERTIFICATEREFS$4, paramInt);
    } 
  }
  
  public List<CompleteRevocationRefsType> getCompleteRevocationRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      final class CompleteRevocationRefsList extends AbstractList<CompleteRevocationRefsType> {
        public CompleteRevocationRefsType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getCompleteRevocationRefsArray(param1Int);
        }
        
        public CompleteRevocationRefsType set(int param1Int, CompleteRevocationRefsType param1CompleteRevocationRefsType) {
          CompleteRevocationRefsType completeRevocationRefsType = UnsignedSignaturePropertiesTypeImpl.this.getCompleteRevocationRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setCompleteRevocationRefsArray(param1Int, param1CompleteRevocationRefsType);
          return completeRevocationRefsType;
        }
        
        public void add(int param1Int, CompleteRevocationRefsType param1CompleteRevocationRefsType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewCompleteRevocationRefs(param1Int).set((XmlObject)param1CompleteRevocationRefsType);
        }
        
        public CompleteRevocationRefsType remove(int param1Int) {
          CompleteRevocationRefsType completeRevocationRefsType = UnsignedSignaturePropertiesTypeImpl.this.getCompleteRevocationRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeCompleteRevocationRefs(param1Int);
          return completeRevocationRefsType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfCompleteRevocationRefsArray();
        }
      };
      return new CompleteRevocationRefsList();
    } 
  }
  
  @Deprecated
  public CompleteRevocationRefsType[] getCompleteRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(COMPLETEREVOCATIONREFS$6, arrayList);
      CompleteRevocationRefsType[] arrayOfCompleteRevocationRefsType = new CompleteRevocationRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteRevocationRefsType);
      return arrayOfCompleteRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType getCompleteRevocationRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().find_element_user(COMPLETEREVOCATIONREFS$6, paramInt);
      if (completeRevocationRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeRevocationRefsType;
    } 
  }
  
  public int sizeOfCompleteRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(COMPLETEREVOCATIONREFS$6);
    } 
  }
  
  public void setCompleteRevocationRefsArray(CompleteRevocationRefsType[] paramArrayOfCompleteRevocationRefsType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCompleteRevocationRefsType, COMPLETEREVOCATIONREFS$6);
  }
  
  public void setCompleteRevocationRefsArray(int paramInt, CompleteRevocationRefsType paramCompleteRevocationRefsType) {
    generatedSetterHelperImpl((XmlObject)paramCompleteRevocationRefsType, COMPLETEREVOCATIONREFS$6, paramInt, (short)2);
  }
  
  public CompleteRevocationRefsType insertNewCompleteRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().insert_element_user(COMPLETEREVOCATIONREFS$6, paramInt);
      return completeRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType addNewCompleteRevocationRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().add_element_user(COMPLETEREVOCATIONREFS$6);
      return completeRevocationRefsType;
    } 
  }
  
  public void removeCompleteRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(COMPLETEREVOCATIONREFS$6, paramInt);
    } 
  }
  
  public List<CompleteCertificateRefsType> getAttributeCertificateRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AttributeCertificateRefsList extends AbstractList<CompleteCertificateRefsType> {
        public CompleteCertificateRefsType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getAttributeCertificateRefsArray(param1Int);
        }
        
        public CompleteCertificateRefsType set(int param1Int, CompleteCertificateRefsType param1CompleteCertificateRefsType) {
          CompleteCertificateRefsType completeCertificateRefsType = UnsignedSignaturePropertiesTypeImpl.this.getAttributeCertificateRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setAttributeCertificateRefsArray(param1Int, param1CompleteCertificateRefsType);
          return completeCertificateRefsType;
        }
        
        public void add(int param1Int, CompleteCertificateRefsType param1CompleteCertificateRefsType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewAttributeCertificateRefs(param1Int).set((XmlObject)param1CompleteCertificateRefsType);
        }
        
        public CompleteCertificateRefsType remove(int param1Int) {
          CompleteCertificateRefsType completeCertificateRefsType = UnsignedSignaturePropertiesTypeImpl.this.getAttributeCertificateRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeAttributeCertificateRefs(param1Int);
          return completeCertificateRefsType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfAttributeCertificateRefsArray();
        }
      };
      return new AttributeCertificateRefsList();
    } 
  }
  
  @Deprecated
  public CompleteCertificateRefsType[] getAttributeCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRIBUTECERTIFICATEREFS$8, arrayList);
      CompleteCertificateRefsType[] arrayOfCompleteCertificateRefsType = new CompleteCertificateRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteCertificateRefsType);
      return arrayOfCompleteCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType getAttributeCertificateRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().find_element_user(ATTRIBUTECERTIFICATEREFS$8, paramInt);
      if (completeCertificateRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeCertificateRefsType;
    } 
  }
  
  public int sizeOfAttributeCertificateRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRIBUTECERTIFICATEREFS$8);
    } 
  }
  
  public void setAttributeCertificateRefsArray(CompleteCertificateRefsType[] paramArrayOfCompleteCertificateRefsType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCompleteCertificateRefsType, ATTRIBUTECERTIFICATEREFS$8);
  }
  
  public void setAttributeCertificateRefsArray(int paramInt, CompleteCertificateRefsType paramCompleteCertificateRefsType) {
    generatedSetterHelperImpl((XmlObject)paramCompleteCertificateRefsType, ATTRIBUTECERTIFICATEREFS$8, paramInt, (short)2);
  }
  
  public CompleteCertificateRefsType insertNewAttributeCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().insert_element_user(ATTRIBUTECERTIFICATEREFS$8, paramInt);
      return completeCertificateRefsType;
    } 
  }
  
  public CompleteCertificateRefsType addNewAttributeCertificateRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteCertificateRefsType completeCertificateRefsType = null;
      completeCertificateRefsType = (CompleteCertificateRefsType)get_store().add_element_user(ATTRIBUTECERTIFICATEREFS$8);
      return completeCertificateRefsType;
    } 
  }
  
  public void removeAttributeCertificateRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRIBUTECERTIFICATEREFS$8, paramInt);
    } 
  }
  
  public List<CompleteRevocationRefsType> getAttributeRevocationRefsList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AttributeRevocationRefsList extends AbstractList<CompleteRevocationRefsType> {
        public CompleteRevocationRefsType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getAttributeRevocationRefsArray(param1Int);
        }
        
        public CompleteRevocationRefsType set(int param1Int, CompleteRevocationRefsType param1CompleteRevocationRefsType) {
          CompleteRevocationRefsType completeRevocationRefsType = UnsignedSignaturePropertiesTypeImpl.this.getAttributeRevocationRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setAttributeRevocationRefsArray(param1Int, param1CompleteRevocationRefsType);
          return completeRevocationRefsType;
        }
        
        public void add(int param1Int, CompleteRevocationRefsType param1CompleteRevocationRefsType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewAttributeRevocationRefs(param1Int).set((XmlObject)param1CompleteRevocationRefsType);
        }
        
        public CompleteRevocationRefsType remove(int param1Int) {
          CompleteRevocationRefsType completeRevocationRefsType = UnsignedSignaturePropertiesTypeImpl.this.getAttributeRevocationRefsArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeAttributeRevocationRefs(param1Int);
          return completeRevocationRefsType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfAttributeRevocationRefsArray();
        }
      };
      return new AttributeRevocationRefsList();
    } 
  }
  
  @Deprecated
  public CompleteRevocationRefsType[] getAttributeRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRIBUTEREVOCATIONREFS$10, arrayList);
      CompleteRevocationRefsType[] arrayOfCompleteRevocationRefsType = new CompleteRevocationRefsType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCompleteRevocationRefsType);
      return arrayOfCompleteRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType getAttributeRevocationRefsArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().find_element_user(ATTRIBUTEREVOCATIONREFS$10, paramInt);
      if (completeRevocationRefsType == null)
        throw new IndexOutOfBoundsException(); 
      return completeRevocationRefsType;
    } 
  }
  
  public int sizeOfAttributeRevocationRefsArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRIBUTEREVOCATIONREFS$10);
    } 
  }
  
  public void setAttributeRevocationRefsArray(CompleteRevocationRefsType[] paramArrayOfCompleteRevocationRefsType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCompleteRevocationRefsType, ATTRIBUTEREVOCATIONREFS$10);
  }
  
  public void setAttributeRevocationRefsArray(int paramInt, CompleteRevocationRefsType paramCompleteRevocationRefsType) {
    generatedSetterHelperImpl((XmlObject)paramCompleteRevocationRefsType, ATTRIBUTEREVOCATIONREFS$10, paramInt, (short)2);
  }
  
  public CompleteRevocationRefsType insertNewAttributeRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().insert_element_user(ATTRIBUTEREVOCATIONREFS$10, paramInt);
      return completeRevocationRefsType;
    } 
  }
  
  public CompleteRevocationRefsType addNewAttributeRevocationRefs() {
    synchronized (monitor()) {
      check_orphaned();
      CompleteRevocationRefsType completeRevocationRefsType = null;
      completeRevocationRefsType = (CompleteRevocationRefsType)get_store().add_element_user(ATTRIBUTEREVOCATIONREFS$10);
      return completeRevocationRefsType;
    } 
  }
  
  public void removeAttributeRevocationRefs(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRIBUTEREVOCATIONREFS$10, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getSigAndRefsTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      final class SigAndRefsTimeStampList extends AbstractList<XAdESTimeStampType> {
        public XAdESTimeStampType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getSigAndRefsTimeStampArray(param1Int);
        }
        
        public XAdESTimeStampType set(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getSigAndRefsTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setSigAndRefsTimeStampArray(param1Int, param1XAdESTimeStampType);
          return xAdESTimeStampType;
        }
        
        public void add(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewSigAndRefsTimeStamp(param1Int).set((XmlObject)param1XAdESTimeStampType);
        }
        
        public XAdESTimeStampType remove(int param1Int) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getSigAndRefsTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeSigAndRefsTimeStamp(param1Int);
          return xAdESTimeStampType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfSigAndRefsTimeStampArray();
        }
      };
      return new SigAndRefsTimeStampList();
    } 
  }
  
  @Deprecated
  public XAdESTimeStampType[] getSigAndRefsTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(SIGANDREFSTIMESTAMP$12, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getSigAndRefsTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(SIGANDREFSTIMESTAMP$12, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfSigAndRefsTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(SIGANDREFSTIMESTAMP$12);
    } 
  }
  
  public void setSigAndRefsTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, SIGANDREFSTIMESTAMP$12);
  }
  
  public void setSigAndRefsTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    generatedSetterHelperImpl((XmlObject)paramXAdESTimeStampType, SIGANDREFSTIMESTAMP$12, paramInt, (short)2);
  }
  
  public XAdESTimeStampType insertNewSigAndRefsTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(SIGANDREFSTIMESTAMP$12, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewSigAndRefsTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(SIGANDREFSTIMESTAMP$12);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeSigAndRefsTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(SIGANDREFSTIMESTAMP$12, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getRefsOnlyTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      final class RefsOnlyTimeStampList extends AbstractList<XAdESTimeStampType> {
        public XAdESTimeStampType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getRefsOnlyTimeStampArray(param1Int);
        }
        
        public XAdESTimeStampType set(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getRefsOnlyTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setRefsOnlyTimeStampArray(param1Int, param1XAdESTimeStampType);
          return xAdESTimeStampType;
        }
        
        public void add(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewRefsOnlyTimeStamp(param1Int).set((XmlObject)param1XAdESTimeStampType);
        }
        
        public XAdESTimeStampType remove(int param1Int) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getRefsOnlyTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeRefsOnlyTimeStamp(param1Int);
          return xAdESTimeStampType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfRefsOnlyTimeStampArray();
        }
      };
      return new RefsOnlyTimeStampList();
    } 
  }
  
  @Deprecated
  public XAdESTimeStampType[] getRefsOnlyTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(REFSONLYTIMESTAMP$14, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getRefsOnlyTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(REFSONLYTIMESTAMP$14, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfRefsOnlyTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(REFSONLYTIMESTAMP$14);
    } 
  }
  
  public void setRefsOnlyTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, REFSONLYTIMESTAMP$14);
  }
  
  public void setRefsOnlyTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    generatedSetterHelperImpl((XmlObject)paramXAdESTimeStampType, REFSONLYTIMESTAMP$14, paramInt, (short)2);
  }
  
  public XAdESTimeStampType insertNewRefsOnlyTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(REFSONLYTIMESTAMP$14, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewRefsOnlyTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(REFSONLYTIMESTAMP$14);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeRefsOnlyTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REFSONLYTIMESTAMP$14, paramInt);
    } 
  }
  
  public List<CertificateValuesType> getCertificateValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      final class CertificateValuesList extends AbstractList<CertificateValuesType> {
        public CertificateValuesType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getCertificateValuesArray(param1Int);
        }
        
        public CertificateValuesType set(int param1Int, CertificateValuesType param1CertificateValuesType) {
          CertificateValuesType certificateValuesType = UnsignedSignaturePropertiesTypeImpl.this.getCertificateValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setCertificateValuesArray(param1Int, param1CertificateValuesType);
          return certificateValuesType;
        }
        
        public void add(int param1Int, CertificateValuesType param1CertificateValuesType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewCertificateValues(param1Int).set((XmlObject)param1CertificateValuesType);
        }
        
        public CertificateValuesType remove(int param1Int) {
          CertificateValuesType certificateValuesType = UnsignedSignaturePropertiesTypeImpl.this.getCertificateValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeCertificateValues(param1Int);
          return certificateValuesType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfCertificateValuesArray();
        }
      };
      return new CertificateValuesList();
    } 
  }
  
  @Deprecated
  public CertificateValuesType[] getCertificateValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CERTIFICATEVALUES$16, arrayList);
      CertificateValuesType[] arrayOfCertificateValuesType = new CertificateValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCertificateValuesType);
      return arrayOfCertificateValuesType;
    } 
  }
  
  public CertificateValuesType getCertificateValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().find_element_user(CERTIFICATEVALUES$16, paramInt);
      if (certificateValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return certificateValuesType;
    } 
  }
  
  public int sizeOfCertificateValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CERTIFICATEVALUES$16);
    } 
  }
  
  public void setCertificateValuesArray(CertificateValuesType[] paramArrayOfCertificateValuesType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCertificateValuesType, CERTIFICATEVALUES$16);
  }
  
  public void setCertificateValuesArray(int paramInt, CertificateValuesType paramCertificateValuesType) {
    generatedSetterHelperImpl((XmlObject)paramCertificateValuesType, CERTIFICATEVALUES$16, paramInt, (short)2);
  }
  
  public CertificateValuesType insertNewCertificateValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().insert_element_user(CERTIFICATEVALUES$16, paramInt);
      return certificateValuesType;
    } 
  }
  
  public CertificateValuesType addNewCertificateValues() {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().add_element_user(CERTIFICATEVALUES$16);
      return certificateValuesType;
    } 
  }
  
  public void removeCertificateValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CERTIFICATEVALUES$16, paramInt);
    } 
  }
  
  public List<RevocationValuesType> getRevocationValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      final class RevocationValuesList extends AbstractList<RevocationValuesType> {
        public RevocationValuesType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getRevocationValuesArray(param1Int);
        }
        
        public RevocationValuesType set(int param1Int, RevocationValuesType param1RevocationValuesType) {
          RevocationValuesType revocationValuesType = UnsignedSignaturePropertiesTypeImpl.this.getRevocationValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setRevocationValuesArray(param1Int, param1RevocationValuesType);
          return revocationValuesType;
        }
        
        public void add(int param1Int, RevocationValuesType param1RevocationValuesType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewRevocationValues(param1Int).set((XmlObject)param1RevocationValuesType);
        }
        
        public RevocationValuesType remove(int param1Int) {
          RevocationValuesType revocationValuesType = UnsignedSignaturePropertiesTypeImpl.this.getRevocationValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeRevocationValues(param1Int);
          return revocationValuesType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfRevocationValuesArray();
        }
      };
      return new RevocationValuesList();
    } 
  }
  
  @Deprecated
  public RevocationValuesType[] getRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(REVOCATIONVALUES$18, arrayList);
      RevocationValuesType[] arrayOfRevocationValuesType = new RevocationValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfRevocationValuesType);
      return arrayOfRevocationValuesType;
    } 
  }
  
  public RevocationValuesType getRevocationValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().find_element_user(REVOCATIONVALUES$18, paramInt);
      if (revocationValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return revocationValuesType;
    } 
  }
  
  public int sizeOfRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(REVOCATIONVALUES$18);
    } 
  }
  
  public void setRevocationValuesArray(RevocationValuesType[] paramArrayOfRevocationValuesType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfRevocationValuesType, REVOCATIONVALUES$18);
  }
  
  public void setRevocationValuesArray(int paramInt, RevocationValuesType paramRevocationValuesType) {
    generatedSetterHelperImpl((XmlObject)paramRevocationValuesType, REVOCATIONVALUES$18, paramInt, (short)2);
  }
  
  public RevocationValuesType insertNewRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().insert_element_user(REVOCATIONVALUES$18, paramInt);
      return revocationValuesType;
    } 
  }
  
  public RevocationValuesType addNewRevocationValues() {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().add_element_user(REVOCATIONVALUES$18);
      return revocationValuesType;
    } 
  }
  
  public void removeRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REVOCATIONVALUES$18, paramInt);
    } 
  }
  
  public List<CertificateValuesType> getAttrAuthoritiesCertValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AttrAuthoritiesCertValuesList extends AbstractList<CertificateValuesType> {
        public CertificateValuesType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getAttrAuthoritiesCertValuesArray(param1Int);
        }
        
        public CertificateValuesType set(int param1Int, CertificateValuesType param1CertificateValuesType) {
          CertificateValuesType certificateValuesType = UnsignedSignaturePropertiesTypeImpl.this.getAttrAuthoritiesCertValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setAttrAuthoritiesCertValuesArray(param1Int, param1CertificateValuesType);
          return certificateValuesType;
        }
        
        public void add(int param1Int, CertificateValuesType param1CertificateValuesType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewAttrAuthoritiesCertValues(param1Int).set((XmlObject)param1CertificateValuesType);
        }
        
        public CertificateValuesType remove(int param1Int) {
          CertificateValuesType certificateValuesType = UnsignedSignaturePropertiesTypeImpl.this.getAttrAuthoritiesCertValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeAttrAuthoritiesCertValues(param1Int);
          return certificateValuesType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfAttrAuthoritiesCertValuesArray();
        }
      };
      return new AttrAuthoritiesCertValuesList();
    } 
  }
  
  @Deprecated
  public CertificateValuesType[] getAttrAuthoritiesCertValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRAUTHORITIESCERTVALUES$20, arrayList);
      CertificateValuesType[] arrayOfCertificateValuesType = new CertificateValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCertificateValuesType);
      return arrayOfCertificateValuesType;
    } 
  }
  
  public CertificateValuesType getAttrAuthoritiesCertValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().find_element_user(ATTRAUTHORITIESCERTVALUES$20, paramInt);
      if (certificateValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return certificateValuesType;
    } 
  }
  
  public int sizeOfAttrAuthoritiesCertValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRAUTHORITIESCERTVALUES$20);
    } 
  }
  
  public void setAttrAuthoritiesCertValuesArray(CertificateValuesType[] paramArrayOfCertificateValuesType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCertificateValuesType, ATTRAUTHORITIESCERTVALUES$20);
  }
  
  public void setAttrAuthoritiesCertValuesArray(int paramInt, CertificateValuesType paramCertificateValuesType) {
    generatedSetterHelperImpl((XmlObject)paramCertificateValuesType, ATTRAUTHORITIESCERTVALUES$20, paramInt, (short)2);
  }
  
  public CertificateValuesType insertNewAttrAuthoritiesCertValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().insert_element_user(ATTRAUTHORITIESCERTVALUES$20, paramInt);
      return certificateValuesType;
    } 
  }
  
  public CertificateValuesType addNewAttrAuthoritiesCertValues() {
    synchronized (monitor()) {
      check_orphaned();
      CertificateValuesType certificateValuesType = null;
      certificateValuesType = (CertificateValuesType)get_store().add_element_user(ATTRAUTHORITIESCERTVALUES$20);
      return certificateValuesType;
    } 
  }
  
  public void removeAttrAuthoritiesCertValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRAUTHORITIESCERTVALUES$20, paramInt);
    } 
  }
  
  public List<RevocationValuesType> getAttributeRevocationValuesList() {
    synchronized (monitor()) {
      check_orphaned();
      final class AttributeRevocationValuesList extends AbstractList<RevocationValuesType> {
        public RevocationValuesType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getAttributeRevocationValuesArray(param1Int);
        }
        
        public RevocationValuesType set(int param1Int, RevocationValuesType param1RevocationValuesType) {
          RevocationValuesType revocationValuesType = UnsignedSignaturePropertiesTypeImpl.this.getAttributeRevocationValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setAttributeRevocationValuesArray(param1Int, param1RevocationValuesType);
          return revocationValuesType;
        }
        
        public void add(int param1Int, RevocationValuesType param1RevocationValuesType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewAttributeRevocationValues(param1Int).set((XmlObject)param1RevocationValuesType);
        }
        
        public RevocationValuesType remove(int param1Int) {
          RevocationValuesType revocationValuesType = UnsignedSignaturePropertiesTypeImpl.this.getAttributeRevocationValuesArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeAttributeRevocationValues(param1Int);
          return revocationValuesType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfAttributeRevocationValuesArray();
        }
      };
      return new AttributeRevocationValuesList();
    } 
  }
  
  @Deprecated
  public RevocationValuesType[] getAttributeRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ATTRIBUTEREVOCATIONVALUES$22, arrayList);
      RevocationValuesType[] arrayOfRevocationValuesType = new RevocationValuesType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfRevocationValuesType);
      return arrayOfRevocationValuesType;
    } 
  }
  
  public RevocationValuesType getAttributeRevocationValuesArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().find_element_user(ATTRIBUTEREVOCATIONVALUES$22, paramInt);
      if (revocationValuesType == null)
        throw new IndexOutOfBoundsException(); 
      return revocationValuesType;
    } 
  }
  
  public int sizeOfAttributeRevocationValuesArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ATTRIBUTEREVOCATIONVALUES$22);
    } 
  }
  
  public void setAttributeRevocationValuesArray(RevocationValuesType[] paramArrayOfRevocationValuesType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfRevocationValuesType, ATTRIBUTEREVOCATIONVALUES$22);
  }
  
  public void setAttributeRevocationValuesArray(int paramInt, RevocationValuesType paramRevocationValuesType) {
    generatedSetterHelperImpl((XmlObject)paramRevocationValuesType, ATTRIBUTEREVOCATIONVALUES$22, paramInt, (short)2);
  }
  
  public RevocationValuesType insertNewAttributeRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().insert_element_user(ATTRIBUTEREVOCATIONVALUES$22, paramInt);
      return revocationValuesType;
    } 
  }
  
  public RevocationValuesType addNewAttributeRevocationValues() {
    synchronized (monitor()) {
      check_orphaned();
      RevocationValuesType revocationValuesType = null;
      revocationValuesType = (RevocationValuesType)get_store().add_element_user(ATTRIBUTEREVOCATIONVALUES$22);
      return revocationValuesType;
    } 
  }
  
  public void removeAttributeRevocationValues(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ATTRIBUTEREVOCATIONVALUES$22, paramInt);
    } 
  }
  
  public List<XAdESTimeStampType> getArchiveTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ArchiveTimeStampList extends AbstractList<XAdESTimeStampType> {
        public XAdESTimeStampType get(int param1Int) {
          return UnsignedSignaturePropertiesTypeImpl.this.getArchiveTimeStampArray(param1Int);
        }
        
        public XAdESTimeStampType set(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getArchiveTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.setArchiveTimeStampArray(param1Int, param1XAdESTimeStampType);
          return xAdESTimeStampType;
        }
        
        public void add(int param1Int, XAdESTimeStampType param1XAdESTimeStampType) {
          UnsignedSignaturePropertiesTypeImpl.this.insertNewArchiveTimeStamp(param1Int).set((XmlObject)param1XAdESTimeStampType);
        }
        
        public XAdESTimeStampType remove(int param1Int) {
          XAdESTimeStampType xAdESTimeStampType = UnsignedSignaturePropertiesTypeImpl.this.getArchiveTimeStampArray(param1Int);
          UnsignedSignaturePropertiesTypeImpl.this.removeArchiveTimeStamp(param1Int);
          return xAdESTimeStampType;
        }
        
        public int size() {
          return UnsignedSignaturePropertiesTypeImpl.this.sizeOfArchiveTimeStampArray();
        }
      };
      return new ArchiveTimeStampList();
    } 
  }
  
  @Deprecated
  public XAdESTimeStampType[] getArchiveTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ARCHIVETIMESTAMP$24, arrayList);
      XAdESTimeStampType[] arrayOfXAdESTimeStampType = new XAdESTimeStampType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfXAdESTimeStampType);
      return arrayOfXAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType getArchiveTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().find_element_user(ARCHIVETIMESTAMP$24, paramInt);
      if (xAdESTimeStampType == null)
        throw new IndexOutOfBoundsException(); 
      return xAdESTimeStampType;
    } 
  }
  
  public int sizeOfArchiveTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ARCHIVETIMESTAMP$24);
    } 
  }
  
  public void setArchiveTimeStampArray(XAdESTimeStampType[] paramArrayOfXAdESTimeStampType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfXAdESTimeStampType, ARCHIVETIMESTAMP$24);
  }
  
  public void setArchiveTimeStampArray(int paramInt, XAdESTimeStampType paramXAdESTimeStampType) {
    generatedSetterHelperImpl((XmlObject)paramXAdESTimeStampType, ARCHIVETIMESTAMP$24, paramInt, (short)2);
  }
  
  public XAdESTimeStampType insertNewArchiveTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().insert_element_user(ARCHIVETIMESTAMP$24, paramInt);
      return xAdESTimeStampType;
    } 
  }
  
  public XAdESTimeStampType addNewArchiveTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      XAdESTimeStampType xAdESTimeStampType = null;
      xAdESTimeStampType = (XAdESTimeStampType)get_store().add_element_user(ARCHIVETIMESTAMP$24);
      return xAdESTimeStampType;
    } 
  }
  
  public void removeArchiveTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ARCHIVETIMESTAMP$24, paramInt);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$26);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$26);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$26) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$26);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$26); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$26);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$26); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$26);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\UnsignedSignaturePropertiesTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */