package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.AnyType;
import org.etsi.uri.x01903.v13.ClaimedRolesListType;

public class ClaimedRolesListTypeImpl extends XmlComplexContentImpl implements ClaimedRolesListType {
  private static final long serialVersionUID = 1L;
  
  private static final QName CLAIMEDROLE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ClaimedRole");
  
  public ClaimedRolesListTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<AnyType> getClaimedRoleList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ClaimedRoleList extends AbstractList<AnyType> {
        public AnyType get(int param1Int) {
          return ClaimedRolesListTypeImpl.this.getClaimedRoleArray(param1Int);
        }
        
        public AnyType set(int param1Int, AnyType param1AnyType) {
          AnyType anyType = ClaimedRolesListTypeImpl.this.getClaimedRoleArray(param1Int);
          ClaimedRolesListTypeImpl.this.setClaimedRoleArray(param1Int, param1AnyType);
          return anyType;
        }
        
        public void add(int param1Int, AnyType param1AnyType) {
          ClaimedRolesListTypeImpl.this.insertNewClaimedRole(param1Int).set((XmlObject)param1AnyType);
        }
        
        public AnyType remove(int param1Int) {
          AnyType anyType = ClaimedRolesListTypeImpl.this.getClaimedRoleArray(param1Int);
          ClaimedRolesListTypeImpl.this.removeClaimedRole(param1Int);
          return anyType;
        }
        
        public int size() {
          return ClaimedRolesListTypeImpl.this.sizeOfClaimedRoleArray();
        }
      };
      return new ClaimedRoleList();
    } 
  }
  
  @Deprecated
  public AnyType[] getClaimedRoleArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CLAIMEDROLE$0, arrayList);
      AnyType[] arrayOfAnyType = new AnyType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfAnyType);
      return arrayOfAnyType;
    } 
  }
  
  public AnyType getClaimedRoleArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().find_element_user(CLAIMEDROLE$0, paramInt);
      if (anyType == null)
        throw new IndexOutOfBoundsException(); 
      return anyType;
    } 
  }
  
  public int sizeOfClaimedRoleArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CLAIMEDROLE$0);
    } 
  }
  
  public void setClaimedRoleArray(AnyType[] paramArrayOfAnyType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfAnyType, CLAIMEDROLE$0);
  }
  
  public void setClaimedRoleArray(int paramInt, AnyType paramAnyType) {
    generatedSetterHelperImpl((XmlObject)paramAnyType, CLAIMEDROLE$0, paramInt, (short)2);
  }
  
  public AnyType insertNewClaimedRole(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().insert_element_user(CLAIMEDROLE$0, paramInt);
      return anyType;
    } 
  }
  
  public AnyType addNewClaimedRole() {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().add_element_user(CLAIMEDROLE$0);
      return anyType;
    } 
  }
  
  public void removeClaimedRole(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CLAIMEDROLE$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\ClaimedRolesListTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */