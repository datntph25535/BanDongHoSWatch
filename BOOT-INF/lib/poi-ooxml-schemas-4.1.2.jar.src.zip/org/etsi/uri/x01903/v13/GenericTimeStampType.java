package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3.x2000.x09.xmldsig.CanonicalizationMethodType;
import org.w3c.dom.Node;

public interface GenericTimeStampType extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(GenericTimeStampType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s8C3F193EE11A2F798ACF65489B9E6078").resolveHandle("generictimestamptypecdadtype");
  
  List<IncludeType> getIncludeList();
  
  @Deprecated
  IncludeType[] getIncludeArray();
  
  IncludeType getIncludeArray(int paramInt);
  
  int sizeOfIncludeArray();
  
  void setIncludeArray(IncludeType[] paramArrayOfIncludeType);
  
  void setIncludeArray(int paramInt, IncludeType paramIncludeType);
  
  IncludeType insertNewInclude(int paramInt);
  
  IncludeType addNewInclude();
  
  void removeInclude(int paramInt);
  
  List<ReferenceInfoType> getReferenceInfoList();
  
  @Deprecated
  ReferenceInfoType[] getReferenceInfoArray();
  
  ReferenceInfoType getReferenceInfoArray(int paramInt);
  
  int sizeOfReferenceInfoArray();
  
  void setReferenceInfoArray(ReferenceInfoType[] paramArrayOfReferenceInfoType);
  
  void setReferenceInfoArray(int paramInt, ReferenceInfoType paramReferenceInfoType);
  
  ReferenceInfoType insertNewReferenceInfo(int paramInt);
  
  ReferenceInfoType addNewReferenceInfo();
  
  void removeReferenceInfo(int paramInt);
  
  CanonicalizationMethodType getCanonicalizationMethod();
  
  boolean isSetCanonicalizationMethod();
  
  void setCanonicalizationMethod(CanonicalizationMethodType paramCanonicalizationMethodType);
  
  CanonicalizationMethodType addNewCanonicalizationMethod();
  
  void unsetCanonicalizationMethod();
  
  List<EncapsulatedPKIDataType> getEncapsulatedTimeStampList();
  
  @Deprecated
  EncapsulatedPKIDataType[] getEncapsulatedTimeStampArray();
  
  EncapsulatedPKIDataType getEncapsulatedTimeStampArray(int paramInt);
  
  int sizeOfEncapsulatedTimeStampArray();
  
  void setEncapsulatedTimeStampArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType);
  
  void setEncapsulatedTimeStampArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType);
  
  EncapsulatedPKIDataType insertNewEncapsulatedTimeStamp(int paramInt);
  
  EncapsulatedPKIDataType addNewEncapsulatedTimeStamp();
  
  void removeEncapsulatedTimeStamp(int paramInt);
  
  List<AnyType> getXMLTimeStampList();
  
  @Deprecated
  AnyType[] getXMLTimeStampArray();
  
  AnyType getXMLTimeStampArray(int paramInt);
  
  int sizeOfXMLTimeStampArray();
  
  void setXMLTimeStampArray(AnyType[] paramArrayOfAnyType);
  
  void setXMLTimeStampArray(int paramInt, AnyType paramAnyType);
  
  AnyType insertNewXMLTimeStamp(int paramInt);
  
  AnyType addNewXMLTimeStamp();
  
  void removeXMLTimeStamp(int paramInt);
  
  String getId();
  
  XmlID xgetId();
  
  boolean isSetId();
  
  void setId(String paramString);
  
  void xsetId(XmlID paramXmlID);
  
  void unsetId();
  
  public static final class Factory {
    @Deprecated
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(GenericTimeStampType.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static GenericTimeStampType newInstance() {
      return (GenericTimeStampType)getTypeLoader().newInstance(GenericTimeStampType.type, null);
    }
    
    @Deprecated
    public static GenericTimeStampType newInstance(XmlOptions param1XmlOptions) {
      return (GenericTimeStampType)getTypeLoader().newInstance(GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(String param1String) throws XmlException {
      return (GenericTimeStampType)getTypeLoader().parse(param1String, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (GenericTimeStampType)getTypeLoader().parse(param1String, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(File param1File) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1File, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1File, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(URL param1URL) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1URL, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1URL, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1InputStream, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1InputStream, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(Reader param1Reader) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1Reader, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (GenericTimeStampType)getTypeLoader().parse(param1Reader, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (GenericTimeStampType)getTypeLoader().parse(param1XMLStreamReader, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (GenericTimeStampType)getTypeLoader().parse(param1XMLStreamReader, GenericTimeStampType.type, param1XmlOptions);
    }
    
    public static GenericTimeStampType parse(Node param1Node) throws XmlException {
      return (GenericTimeStampType)getTypeLoader().parse(param1Node, GenericTimeStampType.type, null);
    }
    
    public static GenericTimeStampType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (GenericTimeStampType)getTypeLoader().parse(param1Node, GenericTimeStampType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static GenericTimeStampType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (GenericTimeStampType)getTypeLoader().parse(param1XMLInputStream, GenericTimeStampType.type, null);
    }
    
    @Deprecated
    public static GenericTimeStampType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (GenericTimeStampType)getTypeLoader().parse(param1XMLInputStream, GenericTimeStampType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, GenericTimeStampType.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, GenericTimeStampType.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\GenericTimeStampType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */