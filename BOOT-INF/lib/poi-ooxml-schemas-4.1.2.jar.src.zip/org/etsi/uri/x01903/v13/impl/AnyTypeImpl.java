package org.etsi.uri.x01903.v13.impl;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.AnyType;

public class AnyTypeImpl extends XmlComplexContentImpl implements AnyType {
  private static final long serialVersionUID = 1L;
  
  public AnyTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\AnyTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */