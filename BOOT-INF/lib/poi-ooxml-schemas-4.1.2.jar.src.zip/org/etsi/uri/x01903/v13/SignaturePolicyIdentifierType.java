package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface SignaturePolicyIdentifierType extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(SignaturePolicyIdentifierType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s8C3F193EE11A2F798ACF65489B9E6078").resolveHandle("signaturepolicyidentifiertype80aftype");
  
  SignaturePolicyIdType getSignaturePolicyId();
  
  boolean isSetSignaturePolicyId();
  
  void setSignaturePolicyId(SignaturePolicyIdType paramSignaturePolicyIdType);
  
  SignaturePolicyIdType addNewSignaturePolicyId();
  
  void unsetSignaturePolicyId();
  
  XmlObject getSignaturePolicyImplied();
  
  boolean isSetSignaturePolicyImplied();
  
  void setSignaturePolicyImplied(XmlObject paramXmlObject);
  
  XmlObject addNewSignaturePolicyImplied();
  
  void unsetSignaturePolicyImplied();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(SignaturePolicyIdentifierType.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static SignaturePolicyIdentifierType newInstance() {
      return (SignaturePolicyIdentifierType)getTypeLoader().newInstance(SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType newInstance(XmlOptions param1XmlOptions) {
      return (SignaturePolicyIdentifierType)getTypeLoader().newInstance(SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    public static SignaturePolicyIdentifierType parse(String param1String) throws XmlException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1String, SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1String, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    public static SignaturePolicyIdentifierType parse(File param1File) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1File, SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1File, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    public static SignaturePolicyIdentifierType parse(URL param1URL) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1URL, SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1URL, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    public static SignaturePolicyIdentifierType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1InputStream, SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1InputStream, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    public static SignaturePolicyIdentifierType parse(Reader param1Reader) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1Reader, SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1Reader, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    public static SignaturePolicyIdentifierType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1XMLStreamReader, SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1XMLStreamReader, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    public static SignaturePolicyIdentifierType parse(Node param1Node) throws XmlException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1Node, SignaturePolicyIdentifierType.type, null);
    }
    
    public static SignaturePolicyIdentifierType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1Node, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static SignaturePolicyIdentifierType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1XMLInputStream, SignaturePolicyIdentifierType.type, null);
    }
    
    @Deprecated
    public static SignaturePolicyIdentifierType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (SignaturePolicyIdentifierType)getTypeLoader().parse(param1XMLInputStream, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, SignaturePolicyIdentifierType.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, SignaturePolicyIdentifierType.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\SignaturePolicyIdentifierType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */