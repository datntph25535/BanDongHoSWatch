package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.EncapsulatedPKIDataType;
import org.etsi.uri.x01903.v13.OCSPValuesType;

public class OCSPValuesTypeImpl extends XmlComplexContentImpl implements OCSPValuesType {
  private static final long serialVersionUID = 1L;
  
  private static final QName ENCAPSULATEDOCSPVALUE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "EncapsulatedOCSPValue");
  
  public OCSPValuesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<EncapsulatedPKIDataType> getEncapsulatedOCSPValueList() {
    synchronized (monitor()) {
      check_orphaned();
      final class EncapsulatedOCSPValueList extends AbstractList<EncapsulatedPKIDataType> {
        public EncapsulatedPKIDataType get(int param1Int) {
          return OCSPValuesTypeImpl.this.getEncapsulatedOCSPValueArray(param1Int);
        }
        
        public EncapsulatedPKIDataType set(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = OCSPValuesTypeImpl.this.getEncapsulatedOCSPValueArray(param1Int);
          OCSPValuesTypeImpl.this.setEncapsulatedOCSPValueArray(param1Int, param1EncapsulatedPKIDataType);
          return encapsulatedPKIDataType;
        }
        
        public void add(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          OCSPValuesTypeImpl.this.insertNewEncapsulatedOCSPValue(param1Int).set((XmlObject)param1EncapsulatedPKIDataType);
        }
        
        public EncapsulatedPKIDataType remove(int param1Int) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = OCSPValuesTypeImpl.this.getEncapsulatedOCSPValueArray(param1Int);
          OCSPValuesTypeImpl.this.removeEncapsulatedOCSPValue(param1Int);
          return encapsulatedPKIDataType;
        }
        
        public int size() {
          return OCSPValuesTypeImpl.this.sizeOfEncapsulatedOCSPValueArray();
        }
      };
      return new EncapsulatedOCSPValueList();
    } 
  }
  
  @Deprecated
  public EncapsulatedPKIDataType[] getEncapsulatedOCSPValueArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ENCAPSULATEDOCSPVALUE$0, arrayList);
      EncapsulatedPKIDataType[] arrayOfEncapsulatedPKIDataType = new EncapsulatedPKIDataType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfEncapsulatedPKIDataType);
      return arrayOfEncapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType getEncapsulatedOCSPValueArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDOCSPVALUE$0, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      return encapsulatedPKIDataType;
    } 
  }
  
  public int sizeOfEncapsulatedOCSPValueArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ENCAPSULATEDOCSPVALUE$0);
    } 
  }
  
  public void setEncapsulatedOCSPValueArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfEncapsulatedPKIDataType, ENCAPSULATEDOCSPVALUE$0);
  }
  
  public void setEncapsulatedOCSPValueArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType) {
    generatedSetterHelperImpl((XmlObject)paramEncapsulatedPKIDataType, ENCAPSULATEDOCSPVALUE$0, paramInt, (short)2);
  }
  
  public EncapsulatedPKIDataType insertNewEncapsulatedOCSPValue(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().insert_element_user(ENCAPSULATEDOCSPVALUE$0, paramInt);
      return encapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType addNewEncapsulatedOCSPValue() {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().add_element_user(ENCAPSULATEDOCSPVALUE$0);
      return encapsulatedPKIDataType;
    } 
  }
  
  public void removeEncapsulatedOCSPValue(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ENCAPSULATEDOCSPVALUE$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\OCSPValuesTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */