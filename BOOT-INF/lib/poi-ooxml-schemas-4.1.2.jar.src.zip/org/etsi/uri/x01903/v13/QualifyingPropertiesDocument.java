package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface QualifyingPropertiesDocument extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(QualifyingPropertiesDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s8C3F193EE11A2F798ACF65489B9E6078").resolveHandle("qualifyingproperties53ccdoctype");
  
  QualifyingPropertiesType getQualifyingProperties();
  
  void setQualifyingProperties(QualifyingPropertiesType paramQualifyingPropertiesType);
  
  QualifyingPropertiesType addNewQualifyingProperties();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(QualifyingPropertiesDocument.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static QualifyingPropertiesDocument newInstance() {
      return (QualifyingPropertiesDocument)getTypeLoader().newInstance(QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument newInstance(XmlOptions param1XmlOptions) {
      return (QualifyingPropertiesDocument)getTypeLoader().newInstance(QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    public static QualifyingPropertiesDocument parse(String param1String) throws XmlException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1String, QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1String, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    public static QualifyingPropertiesDocument parse(File param1File) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1File, QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1File, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    public static QualifyingPropertiesDocument parse(URL param1URL) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1URL, QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1URL, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    public static QualifyingPropertiesDocument parse(InputStream param1InputStream) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1InputStream, QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1InputStream, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    public static QualifyingPropertiesDocument parse(Reader param1Reader) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1Reader, QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1Reader, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    public static QualifyingPropertiesDocument parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1XMLStreamReader, QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1XMLStreamReader, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    public static QualifyingPropertiesDocument parse(Node param1Node) throws XmlException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1Node, QualifyingPropertiesDocument.type, null);
    }
    
    public static QualifyingPropertiesDocument parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1Node, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    @Deprecated
    public static QualifyingPropertiesDocument parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1XMLInputStream, QualifyingPropertiesDocument.type, null);
    }
    
    @Deprecated
    public static QualifyingPropertiesDocument parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (QualifyingPropertiesDocument)getTypeLoader().parse(param1XMLInputStream, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, QualifyingPropertiesDocument.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, QualifyingPropertiesDocument.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\QualifyingPropertiesDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */