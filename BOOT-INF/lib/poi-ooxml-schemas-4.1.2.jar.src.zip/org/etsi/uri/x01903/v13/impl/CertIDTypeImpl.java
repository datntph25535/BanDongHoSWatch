package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlAnyURI;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CertIDType;
import org.etsi.uri.x01903.v13.DigestAlgAndValueType;
import org.w3.x2000.x09.xmldsig.X509IssuerSerialType;

public class CertIDTypeImpl extends XmlComplexContentImpl implements CertIDType {
  private static final long serialVersionUID = 1L;
  
  private static final QName CERTDIGEST$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CertDigest");
  
  private static final QName ISSUERSERIAL$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "IssuerSerial");
  
  private static final QName URI$4 = new QName("", "URI");
  
  public CertIDTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public DigestAlgAndValueType getCertDigest() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().find_element_user(CERTDIGEST$0, 0);
      if (digestAlgAndValueType == null)
        return null; 
      return digestAlgAndValueType;
    } 
  }
  
  public void setCertDigest(DigestAlgAndValueType paramDigestAlgAndValueType) {
    generatedSetterHelperImpl((XmlObject)paramDigestAlgAndValueType, CERTDIGEST$0, 0, (short)1);
  }
  
  public DigestAlgAndValueType addNewCertDigest() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().add_element_user(CERTDIGEST$0);
      return digestAlgAndValueType;
    } 
  }
  
  public X509IssuerSerialType getIssuerSerial() {
    synchronized (monitor()) {
      check_orphaned();
      X509IssuerSerialType x509IssuerSerialType = null;
      x509IssuerSerialType = (X509IssuerSerialType)get_store().find_element_user(ISSUERSERIAL$2, 0);
      if (x509IssuerSerialType == null)
        return null; 
      return x509IssuerSerialType;
    } 
  }
  
  public void setIssuerSerial(X509IssuerSerialType paramX509IssuerSerialType) {
    generatedSetterHelperImpl((XmlObject)paramX509IssuerSerialType, ISSUERSERIAL$2, 0, (short)1);
  }
  
  public X509IssuerSerialType addNewIssuerSerial() {
    synchronized (monitor()) {
      check_orphaned();
      X509IssuerSerialType x509IssuerSerialType = null;
      x509IssuerSerialType = (X509IssuerSerialType)get_store().add_element_user(ISSUERSERIAL$2);
      return x509IssuerSerialType;
    } 
  }
  
  public String getURI() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$4);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlAnyURI xgetURI() {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(URI$4);
      return xmlAnyURI;
    } 
  }
  
  public boolean isSetURI() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(URI$4) != null);
    } 
  }
  
  public void setURI(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(URI$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(URI$4); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetURI(XmlAnyURI paramXmlAnyURI) {
    synchronized (monitor()) {
      check_orphaned();
      XmlAnyURI xmlAnyURI = null;
      xmlAnyURI = (XmlAnyURI)get_store().find_attribute_user(URI$4);
      if (xmlAnyURI == null)
        xmlAnyURI = (XmlAnyURI)get_store().add_attribute_user(URI$4); 
      xmlAnyURI.set((XmlObject)paramXmlAnyURI);
    } 
  }
  
  public void unsetURI() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(URI$4);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\CertIDTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */