package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.OCSPRefType;
import org.etsi.uri.x01903.v13.OCSPRefsType;

public class OCSPRefsTypeImpl extends XmlComplexContentImpl implements OCSPRefsType {
  private static final long serialVersionUID = 1L;
  
  private static final QName OCSPREF$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "OCSPRef");
  
  public OCSPRefsTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<OCSPRefType> getOCSPRefList() {
    synchronized (monitor()) {
      check_orphaned();
      final class OCSPRefList extends AbstractList<OCSPRefType> {
        public OCSPRefType get(int param1Int) {
          return OCSPRefsTypeImpl.this.getOCSPRefArray(param1Int);
        }
        
        public OCSPRefType set(int param1Int, OCSPRefType param1OCSPRefType) {
          OCSPRefType oCSPRefType = OCSPRefsTypeImpl.this.getOCSPRefArray(param1Int);
          OCSPRefsTypeImpl.this.setOCSPRefArray(param1Int, param1OCSPRefType);
          return oCSPRefType;
        }
        
        public void add(int param1Int, OCSPRefType param1OCSPRefType) {
          OCSPRefsTypeImpl.this.insertNewOCSPRef(param1Int).set((XmlObject)param1OCSPRefType);
        }
        
        public OCSPRefType remove(int param1Int) {
          OCSPRefType oCSPRefType = OCSPRefsTypeImpl.this.getOCSPRefArray(param1Int);
          OCSPRefsTypeImpl.this.removeOCSPRef(param1Int);
          return oCSPRefType;
        }
        
        public int size() {
          return OCSPRefsTypeImpl.this.sizeOfOCSPRefArray();
        }
      };
      return new OCSPRefList();
    } 
  }
  
  @Deprecated
  public OCSPRefType[] getOCSPRefArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(OCSPREF$0, arrayList);
      OCSPRefType[] arrayOfOCSPRefType = new OCSPRefType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfOCSPRefType);
      return arrayOfOCSPRefType;
    } 
  }
  
  public OCSPRefType getOCSPRefArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      OCSPRefType oCSPRefType = null;
      oCSPRefType = (OCSPRefType)get_store().find_element_user(OCSPREF$0, paramInt);
      if (oCSPRefType == null)
        throw new IndexOutOfBoundsException(); 
      return oCSPRefType;
    } 
  }
  
  public int sizeOfOCSPRefArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(OCSPREF$0);
    } 
  }
  
  public void setOCSPRefArray(OCSPRefType[] paramArrayOfOCSPRefType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfOCSPRefType, OCSPREF$0);
  }
  
  public void setOCSPRefArray(int paramInt, OCSPRefType paramOCSPRefType) {
    generatedSetterHelperImpl((XmlObject)paramOCSPRefType, OCSPREF$0, paramInt, (short)2);
  }
  
  public OCSPRefType insertNewOCSPRef(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      OCSPRefType oCSPRefType = null;
      oCSPRefType = (OCSPRefType)get_store().insert_element_user(OCSPREF$0, paramInt);
      return oCSPRefType;
    } 
  }
  
  public OCSPRefType addNewOCSPRef() {
    synchronized (monitor()) {
      check_orphaned();
      OCSPRefType oCSPRefType = null;
      oCSPRefType = (OCSPRefType)get_store().add_element_user(OCSPREF$0);
      return oCSPRefType;
    } 
  }
  
  public void removeOCSPRef(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OCSPREF$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\OCSPRefsTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */