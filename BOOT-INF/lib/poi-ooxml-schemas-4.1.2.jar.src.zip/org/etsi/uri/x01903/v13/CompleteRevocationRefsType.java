package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface CompleteRevocationRefsType extends XmlObject {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CompleteRevocationRefsType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s8C3F193EE11A2F798ACF65489B9E6078").resolveHandle("completerevocationrefstyped8a5type");
  
  CRLRefsType getCRLRefs();
  
  boolean isSetCRLRefs();
  
  void setCRLRefs(CRLRefsType paramCRLRefsType);
  
  CRLRefsType addNewCRLRefs();
  
  void unsetCRLRefs();
  
  OCSPRefsType getOCSPRefs();
  
  boolean isSetOCSPRefs();
  
  void setOCSPRefs(OCSPRefsType paramOCSPRefsType);
  
  OCSPRefsType addNewOCSPRefs();
  
  void unsetOCSPRefs();
  
  OtherCertStatusRefsType getOtherRefs();
  
  boolean isSetOtherRefs();
  
  void setOtherRefs(OtherCertStatusRefsType paramOtherCertStatusRefsType);
  
  OtherCertStatusRefsType addNewOtherRefs();
  
  void unsetOtherRefs();
  
  String getId();
  
  XmlID xgetId();
  
  boolean isSetId();
  
  void setId(String paramString);
  
  void xsetId(XmlID paramXmlID);
  
  void unsetId();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(CompleteRevocationRefsType.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static CompleteRevocationRefsType newInstance() {
      return (CompleteRevocationRefsType)getTypeLoader().newInstance(CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType newInstance(XmlOptions param1XmlOptions) {
      return (CompleteRevocationRefsType)getTypeLoader().newInstance(CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    public static CompleteRevocationRefsType parse(String param1String) throws XmlException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1String, CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1String, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    public static CompleteRevocationRefsType parse(File param1File) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1File, CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1File, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    public static CompleteRevocationRefsType parse(URL param1URL) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1URL, CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1URL, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    public static CompleteRevocationRefsType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1InputStream, CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1InputStream, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    public static CompleteRevocationRefsType parse(Reader param1Reader) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1Reader, CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1Reader, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    public static CompleteRevocationRefsType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1XMLStreamReader, CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1XMLStreamReader, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    public static CompleteRevocationRefsType parse(Node param1Node) throws XmlException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1Node, CompleteRevocationRefsType.type, null);
    }
    
    public static CompleteRevocationRefsType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1Node, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static CompleteRevocationRefsType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1XMLInputStream, CompleteRevocationRefsType.type, null);
    }
    
    @Deprecated
    public static CompleteRevocationRefsType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (CompleteRevocationRefsType)getTypeLoader().parse(param1XMLInputStream, CompleteRevocationRefsType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CompleteRevocationRefsType.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, CompleteRevocationRefsType.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\CompleteRevocationRefsType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */