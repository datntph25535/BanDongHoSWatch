package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLValuesType;
import org.etsi.uri.x01903.v13.EncapsulatedPKIDataType;

public class CRLValuesTypeImpl extends XmlComplexContentImpl implements CRLValuesType {
  private static final long serialVersionUID = 1L;
  
  private static final QName ENCAPSULATEDCRLVALUE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "EncapsulatedCRLValue");
  
  public CRLValuesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<EncapsulatedPKIDataType> getEncapsulatedCRLValueList() {
    synchronized (monitor()) {
      check_orphaned();
      final class EncapsulatedCRLValueList extends AbstractList<EncapsulatedPKIDataType> {
        public EncapsulatedPKIDataType get(int param1Int) {
          return CRLValuesTypeImpl.this.getEncapsulatedCRLValueArray(param1Int);
        }
        
        public EncapsulatedPKIDataType set(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = CRLValuesTypeImpl.this.getEncapsulatedCRLValueArray(param1Int);
          CRLValuesTypeImpl.this.setEncapsulatedCRLValueArray(param1Int, param1EncapsulatedPKIDataType);
          return encapsulatedPKIDataType;
        }
        
        public void add(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          CRLValuesTypeImpl.this.insertNewEncapsulatedCRLValue(param1Int).set((XmlObject)param1EncapsulatedPKIDataType);
        }
        
        public EncapsulatedPKIDataType remove(int param1Int) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = CRLValuesTypeImpl.this.getEncapsulatedCRLValueArray(param1Int);
          CRLValuesTypeImpl.this.removeEncapsulatedCRLValue(param1Int);
          return encapsulatedPKIDataType;
        }
        
        public int size() {
          return CRLValuesTypeImpl.this.sizeOfEncapsulatedCRLValueArray();
        }
      };
      return new EncapsulatedCRLValueList();
    } 
  }
  
  @Deprecated
  public EncapsulatedPKIDataType[] getEncapsulatedCRLValueArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ENCAPSULATEDCRLVALUE$0, arrayList);
      EncapsulatedPKIDataType[] arrayOfEncapsulatedPKIDataType = new EncapsulatedPKIDataType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfEncapsulatedPKIDataType);
      return arrayOfEncapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType getEncapsulatedCRLValueArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDCRLVALUE$0, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      return encapsulatedPKIDataType;
    } 
  }
  
  public int sizeOfEncapsulatedCRLValueArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ENCAPSULATEDCRLVALUE$0);
    } 
  }
  
  public void setEncapsulatedCRLValueArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfEncapsulatedPKIDataType, ENCAPSULATEDCRLVALUE$0);
  }
  
  public void setEncapsulatedCRLValueArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType) {
    generatedSetterHelperImpl((XmlObject)paramEncapsulatedPKIDataType, ENCAPSULATEDCRLVALUE$0, paramInt, (short)2);
  }
  
  public EncapsulatedPKIDataType insertNewEncapsulatedCRLValue(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().insert_element_user(ENCAPSULATEDCRLVALUE$0, paramInt);
      return encapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType addNewEncapsulatedCRLValue() {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().add_element_user(ENCAPSULATEDCRLVALUE$0);
      return encapsulatedPKIDataType;
    } 
  }
  
  public void removeEncapsulatedCRLValue(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ENCAPSULATEDCRLVALUE$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\CRLValuesTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */