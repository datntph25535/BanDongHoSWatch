package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.UnsignedDataObjectPropertiesType;
import org.etsi.uri.x01903.v13.UnsignedPropertiesType;
import org.etsi.uri.x01903.v13.UnsignedSignaturePropertiesType;

public class UnsignedPropertiesTypeImpl extends XmlComplexContentImpl implements UnsignedPropertiesType {
  private static final long serialVersionUID = 1L;
  
  private static final QName UNSIGNEDSIGNATUREPROPERTIES$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "UnsignedSignatureProperties");
  
  private static final QName UNSIGNEDDATAOBJECTPROPERTIES$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "UnsignedDataObjectProperties");
  
  private static final QName ID$4 = new QName("", "Id");
  
  public UnsignedPropertiesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public UnsignedSignaturePropertiesType getUnsignedSignatureProperties() {
    synchronized (monitor()) {
      check_orphaned();
      UnsignedSignaturePropertiesType unsignedSignaturePropertiesType = null;
      unsignedSignaturePropertiesType = (UnsignedSignaturePropertiesType)get_store().find_element_user(UNSIGNEDSIGNATUREPROPERTIES$0, 0);
      if (unsignedSignaturePropertiesType == null)
        return null; 
      return unsignedSignaturePropertiesType;
    } 
  }
  
  public boolean isSetUnsignedSignatureProperties() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(UNSIGNEDSIGNATUREPROPERTIES$0) != 0);
    } 
  }
  
  public void setUnsignedSignatureProperties(UnsignedSignaturePropertiesType paramUnsignedSignaturePropertiesType) {
    generatedSetterHelperImpl((XmlObject)paramUnsignedSignaturePropertiesType, UNSIGNEDSIGNATUREPROPERTIES$0, 0, (short)1);
  }
  
  public UnsignedSignaturePropertiesType addNewUnsignedSignatureProperties() {
    synchronized (monitor()) {
      check_orphaned();
      UnsignedSignaturePropertiesType unsignedSignaturePropertiesType = null;
      unsignedSignaturePropertiesType = (UnsignedSignaturePropertiesType)get_store().add_element_user(UNSIGNEDSIGNATUREPROPERTIES$0);
      return unsignedSignaturePropertiesType;
    } 
  }
  
  public void unsetUnsignedSignatureProperties() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(UNSIGNEDSIGNATUREPROPERTIES$0, 0);
    } 
  }
  
  public UnsignedDataObjectPropertiesType getUnsignedDataObjectProperties() {
    synchronized (monitor()) {
      check_orphaned();
      UnsignedDataObjectPropertiesType unsignedDataObjectPropertiesType = null;
      unsignedDataObjectPropertiesType = (UnsignedDataObjectPropertiesType)get_store().find_element_user(UNSIGNEDDATAOBJECTPROPERTIES$2, 0);
      if (unsignedDataObjectPropertiesType == null)
        return null; 
      return unsignedDataObjectPropertiesType;
    } 
  }
  
  public boolean isSetUnsignedDataObjectProperties() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(UNSIGNEDDATAOBJECTPROPERTIES$2) != 0);
    } 
  }
  
  public void setUnsignedDataObjectProperties(UnsignedDataObjectPropertiesType paramUnsignedDataObjectPropertiesType) {
    generatedSetterHelperImpl((XmlObject)paramUnsignedDataObjectPropertiesType, UNSIGNEDDATAOBJECTPROPERTIES$2, 0, (short)1);
  }
  
  public UnsignedDataObjectPropertiesType addNewUnsignedDataObjectProperties() {
    synchronized (monitor()) {
      check_orphaned();
      UnsignedDataObjectPropertiesType unsignedDataObjectPropertiesType = null;
      unsignedDataObjectPropertiesType = (UnsignedDataObjectPropertiesType)get_store().add_element_user(UNSIGNEDDATAOBJECTPROPERTIES$2);
      return unsignedDataObjectPropertiesType;
    } 
  }
  
  public void unsetUnsignedDataObjectProperties() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(UNSIGNEDDATAOBJECTPROPERTIES$2, 0);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$4);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$4);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$4) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$4); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$4);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$4); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$4);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\UnsignedPropertiesTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */