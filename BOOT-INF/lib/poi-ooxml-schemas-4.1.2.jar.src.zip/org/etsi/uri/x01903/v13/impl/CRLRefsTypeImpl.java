package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLRefType;
import org.etsi.uri.x01903.v13.CRLRefsType;

public class CRLRefsTypeImpl extends XmlComplexContentImpl implements CRLRefsType {
  private static final long serialVersionUID = 1L;
  
  private static final QName CRLREF$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CRLRef");
  
  public CRLRefsTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<CRLRefType> getCRLRefList() {
    synchronized (monitor()) {
      check_orphaned();
      final class CRLRefList extends AbstractList<CRLRefType> {
        public CRLRefType get(int param1Int) {
          return CRLRefsTypeImpl.this.getCRLRefArray(param1Int);
        }
        
        public CRLRefType set(int param1Int, CRLRefType param1CRLRefType) {
          CRLRefType cRLRefType = CRLRefsTypeImpl.this.getCRLRefArray(param1Int);
          CRLRefsTypeImpl.this.setCRLRefArray(param1Int, param1CRLRefType);
          return cRLRefType;
        }
        
        public void add(int param1Int, CRLRefType param1CRLRefType) {
          CRLRefsTypeImpl.this.insertNewCRLRef(param1Int).set((XmlObject)param1CRLRefType);
        }
        
        public CRLRefType remove(int param1Int) {
          CRLRefType cRLRefType = CRLRefsTypeImpl.this.getCRLRefArray(param1Int);
          CRLRefsTypeImpl.this.removeCRLRef(param1Int);
          return cRLRefType;
        }
        
        public int size() {
          return CRLRefsTypeImpl.this.sizeOfCRLRefArray();
        }
      };
      return new CRLRefList();
    } 
  }
  
  @Deprecated
  public CRLRefType[] getCRLRefArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(CRLREF$0, arrayList);
      CRLRefType[] arrayOfCRLRefType = new CRLRefType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfCRLRefType);
      return arrayOfCRLRefType;
    } 
  }
  
  public CRLRefType getCRLRefArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefType cRLRefType = null;
      cRLRefType = (CRLRefType)get_store().find_element_user(CRLREF$0, paramInt);
      if (cRLRefType == null)
        throw new IndexOutOfBoundsException(); 
      return cRLRefType;
    } 
  }
  
  public int sizeOfCRLRefArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(CRLREF$0);
    } 
  }
  
  public void setCRLRefArray(CRLRefType[] paramArrayOfCRLRefType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfCRLRefType, CRLREF$0);
  }
  
  public void setCRLRefArray(int paramInt, CRLRefType paramCRLRefType) {
    generatedSetterHelperImpl((XmlObject)paramCRLRefType, CRLREF$0, paramInt, (short)2);
  }
  
  public CRLRefType insertNewCRLRef(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefType cRLRefType = null;
      cRLRefType = (CRLRefType)get_store().insert_element_user(CRLREF$0, paramInt);
      return cRLRefType;
    } 
  }
  
  public CRLRefType addNewCRLRef() {
    synchronized (monitor()) {
      check_orphaned();
      CRLRefType cRLRefType = null;
      cRLRefType = (CRLRefType)get_store().add_element_user(CRLREF$0);
      return cRLRefType;
    } 
  }
  
  public void removeCRLRef(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CRLREF$0, paramInt);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\CRLRefsTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */