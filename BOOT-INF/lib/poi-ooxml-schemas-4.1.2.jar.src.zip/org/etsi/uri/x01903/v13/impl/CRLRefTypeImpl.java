package org.etsi.uri.x01903.v13.impl;

import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.CRLIdentifierType;
import org.etsi.uri.x01903.v13.CRLRefType;
import org.etsi.uri.x01903.v13.DigestAlgAndValueType;

public class CRLRefTypeImpl extends XmlComplexContentImpl implements CRLRefType {
  private static final long serialVersionUID = 1L;
  
  private static final QName DIGESTALGANDVALUE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "DigestAlgAndValue");
  
  private static final QName CRLIDENTIFIER$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "CRLIdentifier");
  
  public CRLRefTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public DigestAlgAndValueType getDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().find_element_user(DIGESTALGANDVALUE$0, 0);
      if (digestAlgAndValueType == null)
        return null; 
      return digestAlgAndValueType;
    } 
  }
  
  public void setDigestAlgAndValue(DigestAlgAndValueType paramDigestAlgAndValueType) {
    generatedSetterHelperImpl((XmlObject)paramDigestAlgAndValueType, DIGESTALGANDVALUE$0, 0, (short)1);
  }
  
  public DigestAlgAndValueType addNewDigestAlgAndValue() {
    synchronized (monitor()) {
      check_orphaned();
      DigestAlgAndValueType digestAlgAndValueType = null;
      digestAlgAndValueType = (DigestAlgAndValueType)get_store().add_element_user(DIGESTALGANDVALUE$0);
      return digestAlgAndValueType;
    } 
  }
  
  public CRLIdentifierType getCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      CRLIdentifierType cRLIdentifierType = null;
      cRLIdentifierType = (CRLIdentifierType)get_store().find_element_user(CRLIDENTIFIER$2, 0);
      if (cRLIdentifierType == null)
        return null; 
      return cRLIdentifierType;
    } 
  }
  
  public boolean isSetCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CRLIDENTIFIER$2) != 0);
    } 
  }
  
  public void setCRLIdentifier(CRLIdentifierType paramCRLIdentifierType) {
    generatedSetterHelperImpl((XmlObject)paramCRLIdentifierType, CRLIDENTIFIER$2, 0, (short)1);
  }
  
  public CRLIdentifierType addNewCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      CRLIdentifierType cRLIdentifierType = null;
      cRLIdentifierType = (CRLIdentifierType)get_store().add_element_user(CRLIDENTIFIER$2);
      return cRLIdentifierType;
    } 
  }
  
  public void unsetCRLIdentifier() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CRLIDENTIFIER$2, 0);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\CRLRefTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */