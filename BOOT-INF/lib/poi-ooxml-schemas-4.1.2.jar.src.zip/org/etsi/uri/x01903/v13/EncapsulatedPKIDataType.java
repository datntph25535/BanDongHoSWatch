package org.etsi.uri.x01903.v13;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.ref.SoftReference;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.XmlAnyURI;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public interface EncapsulatedPKIDataType extends XmlBase64Binary {
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(EncapsulatedPKIDataType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s8C3F193EE11A2F798ACF65489B9E6078").resolveHandle("encapsulatedpkidatatype4081type");
  
  String getId();
  
  XmlID xgetId();
  
  boolean isSetId();
  
  void setId(String paramString);
  
  void xsetId(XmlID paramXmlID);
  
  void unsetId();
  
  String getEncoding();
  
  XmlAnyURI xgetEncoding();
  
  boolean isSetEncoding();
  
  void setEncoding(String paramString);
  
  void xsetEncoding(XmlAnyURI paramXmlAnyURI);
  
  void unsetEncoding();
  
  public static final class Factory {
    private static SoftReference<SchemaTypeLoader> typeLoader;
    
    private static synchronized SchemaTypeLoader getTypeLoader() {
      SchemaTypeLoader schemaTypeLoader = (typeLoader == null) ? null : typeLoader.get();
      if (schemaTypeLoader == null) {
        schemaTypeLoader = XmlBeans.typeLoaderForClassLoader(EncapsulatedPKIDataType.class.getClassLoader());
        typeLoader = new SoftReference<>(schemaTypeLoader);
      } 
      return schemaTypeLoader;
    }
    
    public static EncapsulatedPKIDataType newInstance() {
      return (EncapsulatedPKIDataType)getTypeLoader().newInstance(EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType newInstance(XmlOptions param1XmlOptions) {
      return (EncapsulatedPKIDataType)getTypeLoader().newInstance(EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    public static EncapsulatedPKIDataType parse(String param1String) throws XmlException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1String, EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType parse(String param1String, XmlOptions param1XmlOptions) throws XmlException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1String, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    public static EncapsulatedPKIDataType parse(File param1File) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1File, EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType parse(File param1File, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1File, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    public static EncapsulatedPKIDataType parse(URL param1URL) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1URL, EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType parse(URL param1URL, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1URL, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    public static EncapsulatedPKIDataType parse(InputStream param1InputStream) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1InputStream, EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType parse(InputStream param1InputStream, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1InputStream, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    public static EncapsulatedPKIDataType parse(Reader param1Reader) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1Reader, EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType parse(Reader param1Reader, XmlOptions param1XmlOptions) throws XmlException, IOException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1Reader, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    public static EncapsulatedPKIDataType parse(XMLStreamReader param1XMLStreamReader) throws XmlException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1XMLStreamReader, EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType parse(XMLStreamReader param1XMLStreamReader, XmlOptions param1XmlOptions) throws XmlException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1XMLStreamReader, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    public static EncapsulatedPKIDataType parse(Node param1Node) throws XmlException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1Node, EncapsulatedPKIDataType.type, null);
    }
    
    public static EncapsulatedPKIDataType parse(Node param1Node, XmlOptions param1XmlOptions) throws XmlException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1Node, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static EncapsulatedPKIDataType parse(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1XMLInputStream, EncapsulatedPKIDataType.type, null);
    }
    
    @Deprecated
    public static EncapsulatedPKIDataType parse(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return (EncapsulatedPKIDataType)getTypeLoader().parse(param1XMLInputStream, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, EncapsulatedPKIDataType.type, null);
    }
    
    @Deprecated
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream param1XMLInputStream, XmlOptions param1XmlOptions) throws XmlException, XMLStreamException {
      return getTypeLoader().newValidatingXMLInputStream(param1XMLInputStream, EncapsulatedPKIDataType.type, param1XmlOptions);
    }
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\EncapsulatedPKIDataType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */