package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.AnyType;
import org.etsi.uri.x01903.v13.EncapsulatedPKIDataType;
import org.etsi.uri.x01903.v13.GenericTimeStampType;
import org.etsi.uri.x01903.v13.IncludeType;
import org.etsi.uri.x01903.v13.ReferenceInfoType;
import org.w3.x2000.x09.xmldsig.CanonicalizationMethodType;

public class GenericTimeStampTypeImpl extends XmlComplexContentImpl implements GenericTimeStampType {
  private static final long serialVersionUID = 1L;
  
  private static final QName INCLUDE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "Include");
  
  private static final QName REFERENCEINFO$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "ReferenceInfo");
  
  private static final QName CANONICALIZATIONMETHOD$4 = new QName("http://www.w3.org/2000/09/xmldsig#", "CanonicalizationMethod");
  
  private static final QName ENCAPSULATEDTIMESTAMP$6 = new QName("http://uri.etsi.org/01903/v1.3.2#", "EncapsulatedTimeStamp");
  
  private static final QName XMLTIMESTAMP$8 = new QName("http://uri.etsi.org/01903/v1.3.2#", "XMLTimeStamp");
  
  private static final QName ID$10 = new QName("", "Id");
  
  public GenericTimeStampTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<IncludeType> getIncludeList() {
    synchronized (monitor()) {
      check_orphaned();
      final class IncludeList extends AbstractList<IncludeType> {
        public IncludeType get(int param1Int) {
          return GenericTimeStampTypeImpl.this.getIncludeArray(param1Int);
        }
        
        public IncludeType set(int param1Int, IncludeType param1IncludeType) {
          IncludeType includeType = GenericTimeStampTypeImpl.this.getIncludeArray(param1Int);
          GenericTimeStampTypeImpl.this.setIncludeArray(param1Int, param1IncludeType);
          return includeType;
        }
        
        public void add(int param1Int, IncludeType param1IncludeType) {
          GenericTimeStampTypeImpl.this.insertNewInclude(param1Int).set((XmlObject)param1IncludeType);
        }
        
        public IncludeType remove(int param1Int) {
          IncludeType includeType = GenericTimeStampTypeImpl.this.getIncludeArray(param1Int);
          GenericTimeStampTypeImpl.this.removeInclude(param1Int);
          return includeType;
        }
        
        public int size() {
          return GenericTimeStampTypeImpl.this.sizeOfIncludeArray();
        }
      };
      return new IncludeList();
    } 
  }
  
  @Deprecated
  public IncludeType[] getIncludeArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(INCLUDE$0, arrayList);
      IncludeType[] arrayOfIncludeType = new IncludeType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfIncludeType);
      return arrayOfIncludeType;
    } 
  }
  
  public IncludeType getIncludeArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      IncludeType includeType = null;
      includeType = (IncludeType)get_store().find_element_user(INCLUDE$0, paramInt);
      if (includeType == null)
        throw new IndexOutOfBoundsException(); 
      return includeType;
    } 
  }
  
  public int sizeOfIncludeArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(INCLUDE$0);
    } 
  }
  
  public void setIncludeArray(IncludeType[] paramArrayOfIncludeType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfIncludeType, INCLUDE$0);
  }
  
  public void setIncludeArray(int paramInt, IncludeType paramIncludeType) {
    generatedSetterHelperImpl((XmlObject)paramIncludeType, INCLUDE$0, paramInt, (short)2);
  }
  
  public IncludeType insertNewInclude(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      IncludeType includeType = null;
      includeType = (IncludeType)get_store().insert_element_user(INCLUDE$0, paramInt);
      return includeType;
    } 
  }
  
  public IncludeType addNewInclude() {
    synchronized (monitor()) {
      check_orphaned();
      IncludeType includeType = null;
      includeType = (IncludeType)get_store().add_element_user(INCLUDE$0);
      return includeType;
    } 
  }
  
  public void removeInclude(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(INCLUDE$0, paramInt);
    } 
  }
  
  public List<ReferenceInfoType> getReferenceInfoList() {
    synchronized (monitor()) {
      check_orphaned();
      final class ReferenceInfoList extends AbstractList<ReferenceInfoType> {
        public ReferenceInfoType get(int param1Int) {
          return GenericTimeStampTypeImpl.this.getReferenceInfoArray(param1Int);
        }
        
        public ReferenceInfoType set(int param1Int, ReferenceInfoType param1ReferenceInfoType) {
          ReferenceInfoType referenceInfoType = GenericTimeStampTypeImpl.this.getReferenceInfoArray(param1Int);
          GenericTimeStampTypeImpl.this.setReferenceInfoArray(param1Int, param1ReferenceInfoType);
          return referenceInfoType;
        }
        
        public void add(int param1Int, ReferenceInfoType param1ReferenceInfoType) {
          GenericTimeStampTypeImpl.this.insertNewReferenceInfo(param1Int).set((XmlObject)param1ReferenceInfoType);
        }
        
        public ReferenceInfoType remove(int param1Int) {
          ReferenceInfoType referenceInfoType = GenericTimeStampTypeImpl.this.getReferenceInfoArray(param1Int);
          GenericTimeStampTypeImpl.this.removeReferenceInfo(param1Int);
          return referenceInfoType;
        }
        
        public int size() {
          return GenericTimeStampTypeImpl.this.sizeOfReferenceInfoArray();
        }
      };
      return new ReferenceInfoList();
    } 
  }
  
  @Deprecated
  public ReferenceInfoType[] getReferenceInfoArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(REFERENCEINFO$2, arrayList);
      ReferenceInfoType[] arrayOfReferenceInfoType = new ReferenceInfoType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfReferenceInfoType);
      return arrayOfReferenceInfoType;
    } 
  }
  
  public ReferenceInfoType getReferenceInfoArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      ReferenceInfoType referenceInfoType = null;
      referenceInfoType = (ReferenceInfoType)get_store().find_element_user(REFERENCEINFO$2, paramInt);
      if (referenceInfoType == null)
        throw new IndexOutOfBoundsException(); 
      return referenceInfoType;
    } 
  }
  
  public int sizeOfReferenceInfoArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(REFERENCEINFO$2);
    } 
  }
  
  public void setReferenceInfoArray(ReferenceInfoType[] paramArrayOfReferenceInfoType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfReferenceInfoType, REFERENCEINFO$2);
  }
  
  public void setReferenceInfoArray(int paramInt, ReferenceInfoType paramReferenceInfoType) {
    generatedSetterHelperImpl((XmlObject)paramReferenceInfoType, REFERENCEINFO$2, paramInt, (short)2);
  }
  
  public ReferenceInfoType insertNewReferenceInfo(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      ReferenceInfoType referenceInfoType = null;
      referenceInfoType = (ReferenceInfoType)get_store().insert_element_user(REFERENCEINFO$2, paramInt);
      return referenceInfoType;
    } 
  }
  
  public ReferenceInfoType addNewReferenceInfo() {
    synchronized (monitor()) {
      check_orphaned();
      ReferenceInfoType referenceInfoType = null;
      referenceInfoType = (ReferenceInfoType)get_store().add_element_user(REFERENCEINFO$2);
      return referenceInfoType;
    } 
  }
  
  public void removeReferenceInfo(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(REFERENCEINFO$2, paramInt);
    } 
  }
  
  public CanonicalizationMethodType getCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      CanonicalizationMethodType canonicalizationMethodType = null;
      canonicalizationMethodType = (CanonicalizationMethodType)get_store().find_element_user(CANONICALIZATIONMETHOD$4, 0);
      if (canonicalizationMethodType == null)
        return null; 
      return canonicalizationMethodType;
    } 
  }
  
  public boolean isSetCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().count_elements(CANONICALIZATIONMETHOD$4) != 0);
    } 
  }
  
  public void setCanonicalizationMethod(CanonicalizationMethodType paramCanonicalizationMethodType) {
    generatedSetterHelperImpl((XmlObject)paramCanonicalizationMethodType, CANONICALIZATIONMETHOD$4, 0, (short)1);
  }
  
  public CanonicalizationMethodType addNewCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      CanonicalizationMethodType canonicalizationMethodType = null;
      canonicalizationMethodType = (CanonicalizationMethodType)get_store().add_element_user(CANONICALIZATIONMETHOD$4);
      return canonicalizationMethodType;
    } 
  }
  
  public void unsetCanonicalizationMethod() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(CANONICALIZATIONMETHOD$4, 0);
    } 
  }
  
  public List<EncapsulatedPKIDataType> getEncapsulatedTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      final class EncapsulatedTimeStampList extends AbstractList<EncapsulatedPKIDataType> {
        public EncapsulatedPKIDataType get(int param1Int) {
          return GenericTimeStampTypeImpl.this.getEncapsulatedTimeStampArray(param1Int);
        }
        
        public EncapsulatedPKIDataType set(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = GenericTimeStampTypeImpl.this.getEncapsulatedTimeStampArray(param1Int);
          GenericTimeStampTypeImpl.this.setEncapsulatedTimeStampArray(param1Int, param1EncapsulatedPKIDataType);
          return encapsulatedPKIDataType;
        }
        
        public void add(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          GenericTimeStampTypeImpl.this.insertNewEncapsulatedTimeStamp(param1Int).set((XmlObject)param1EncapsulatedPKIDataType);
        }
        
        public EncapsulatedPKIDataType remove(int param1Int) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = GenericTimeStampTypeImpl.this.getEncapsulatedTimeStampArray(param1Int);
          GenericTimeStampTypeImpl.this.removeEncapsulatedTimeStamp(param1Int);
          return encapsulatedPKIDataType;
        }
        
        public int size() {
          return GenericTimeStampTypeImpl.this.sizeOfEncapsulatedTimeStampArray();
        }
      };
      return new EncapsulatedTimeStampList();
    } 
  }
  
  @Deprecated
  public EncapsulatedPKIDataType[] getEncapsulatedTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ENCAPSULATEDTIMESTAMP$6, arrayList);
      EncapsulatedPKIDataType[] arrayOfEncapsulatedPKIDataType = new EncapsulatedPKIDataType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfEncapsulatedPKIDataType);
      return arrayOfEncapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType getEncapsulatedTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDTIMESTAMP$6, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      return encapsulatedPKIDataType;
    } 
  }
  
  public int sizeOfEncapsulatedTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ENCAPSULATEDTIMESTAMP$6);
    } 
  }
  
  public void setEncapsulatedTimeStampArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfEncapsulatedPKIDataType, ENCAPSULATEDTIMESTAMP$6);
  }
  
  public void setEncapsulatedTimeStampArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType) {
    generatedSetterHelperImpl((XmlObject)paramEncapsulatedPKIDataType, ENCAPSULATEDTIMESTAMP$6, paramInt, (short)2);
  }
  
  public EncapsulatedPKIDataType insertNewEncapsulatedTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().insert_element_user(ENCAPSULATEDTIMESTAMP$6, paramInt);
      return encapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType addNewEncapsulatedTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().add_element_user(ENCAPSULATEDTIMESTAMP$6);
      return encapsulatedPKIDataType;
    } 
  }
  
  public void removeEncapsulatedTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ENCAPSULATEDTIMESTAMP$6, paramInt);
    } 
  }
  
  public List<AnyType> getXMLTimeStampList() {
    synchronized (monitor()) {
      check_orphaned();
      final class XMLTimeStampList extends AbstractList<AnyType> {
        public AnyType get(int param1Int) {
          return GenericTimeStampTypeImpl.this.getXMLTimeStampArray(param1Int);
        }
        
        public AnyType set(int param1Int, AnyType param1AnyType) {
          AnyType anyType = GenericTimeStampTypeImpl.this.getXMLTimeStampArray(param1Int);
          GenericTimeStampTypeImpl.this.setXMLTimeStampArray(param1Int, param1AnyType);
          return anyType;
        }
        
        public void add(int param1Int, AnyType param1AnyType) {
          GenericTimeStampTypeImpl.this.insertNewXMLTimeStamp(param1Int).set((XmlObject)param1AnyType);
        }
        
        public AnyType remove(int param1Int) {
          AnyType anyType = GenericTimeStampTypeImpl.this.getXMLTimeStampArray(param1Int);
          GenericTimeStampTypeImpl.this.removeXMLTimeStamp(param1Int);
          return anyType;
        }
        
        public int size() {
          return GenericTimeStampTypeImpl.this.sizeOfXMLTimeStampArray();
        }
      };
      return new XMLTimeStampList();
    } 
  }
  
  @Deprecated
  public AnyType[] getXMLTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(XMLTIMESTAMP$8, arrayList);
      AnyType[] arrayOfAnyType = new AnyType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfAnyType);
      return arrayOfAnyType;
    } 
  }
  
  public AnyType getXMLTimeStampArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().find_element_user(XMLTIMESTAMP$8, paramInt);
      if (anyType == null)
        throw new IndexOutOfBoundsException(); 
      return anyType;
    } 
  }
  
  public int sizeOfXMLTimeStampArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(XMLTIMESTAMP$8);
    } 
  }
  
  public void setXMLTimeStampArray(AnyType[] paramArrayOfAnyType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfAnyType, XMLTIMESTAMP$8);
  }
  
  public void setXMLTimeStampArray(int paramInt, AnyType paramAnyType) {
    generatedSetterHelperImpl((XmlObject)paramAnyType, XMLTIMESTAMP$8, paramInt, (short)2);
  }
  
  public AnyType insertNewXMLTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().insert_element_user(XMLTIMESTAMP$8, paramInt);
      return anyType;
    } 
  }
  
  public AnyType addNewXMLTimeStamp() {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().add_element_user(XMLTIMESTAMP$8);
      return anyType;
    } 
  }
  
  public void removeXMLTimeStamp(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(XMLTIMESTAMP$8, paramInt);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$10);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$10);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$10) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$10);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$10); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$10);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$10); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$10);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\GenericTimeStampTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */