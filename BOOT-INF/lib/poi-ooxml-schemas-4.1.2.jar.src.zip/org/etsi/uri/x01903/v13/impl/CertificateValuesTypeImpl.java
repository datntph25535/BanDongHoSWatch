package org.etsi.uri.x01903.v13.impl;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlID;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;
import org.etsi.uri.x01903.v13.AnyType;
import org.etsi.uri.x01903.v13.CertificateValuesType;
import org.etsi.uri.x01903.v13.EncapsulatedPKIDataType;

public class CertificateValuesTypeImpl extends XmlComplexContentImpl implements CertificateValuesType {
  private static final long serialVersionUID = 1L;
  
  private static final QName ENCAPSULATEDX509CERTIFICATE$0 = new QName("http://uri.etsi.org/01903/v1.3.2#", "EncapsulatedX509Certificate");
  
  private static final QName OTHERCERTIFICATE$2 = new QName("http://uri.etsi.org/01903/v1.3.2#", "OtherCertificate");
  
  private static final QName ID$4 = new QName("", "Id");
  
  public CertificateValuesTypeImpl(SchemaType paramSchemaType) {
    super(paramSchemaType);
  }
  
  public List<EncapsulatedPKIDataType> getEncapsulatedX509CertificateList() {
    synchronized (monitor()) {
      check_orphaned();
      final class EncapsulatedX509CertificateList extends AbstractList<EncapsulatedPKIDataType> {
        public EncapsulatedPKIDataType get(int param1Int) {
          return CertificateValuesTypeImpl.this.getEncapsulatedX509CertificateArray(param1Int);
        }
        
        public EncapsulatedPKIDataType set(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = CertificateValuesTypeImpl.this.getEncapsulatedX509CertificateArray(param1Int);
          CertificateValuesTypeImpl.this.setEncapsulatedX509CertificateArray(param1Int, param1EncapsulatedPKIDataType);
          return encapsulatedPKIDataType;
        }
        
        public void add(int param1Int, EncapsulatedPKIDataType param1EncapsulatedPKIDataType) {
          CertificateValuesTypeImpl.this.insertNewEncapsulatedX509Certificate(param1Int).set((XmlObject)param1EncapsulatedPKIDataType);
        }
        
        public EncapsulatedPKIDataType remove(int param1Int) {
          EncapsulatedPKIDataType encapsulatedPKIDataType = CertificateValuesTypeImpl.this.getEncapsulatedX509CertificateArray(param1Int);
          CertificateValuesTypeImpl.this.removeEncapsulatedX509Certificate(param1Int);
          return encapsulatedPKIDataType;
        }
        
        public int size() {
          return CertificateValuesTypeImpl.this.sizeOfEncapsulatedX509CertificateArray();
        }
      };
      return new EncapsulatedX509CertificateList();
    } 
  }
  
  @Deprecated
  public EncapsulatedPKIDataType[] getEncapsulatedX509CertificateArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(ENCAPSULATEDX509CERTIFICATE$0, arrayList);
      EncapsulatedPKIDataType[] arrayOfEncapsulatedPKIDataType = new EncapsulatedPKIDataType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfEncapsulatedPKIDataType);
      return arrayOfEncapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType getEncapsulatedX509CertificateArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().find_element_user(ENCAPSULATEDX509CERTIFICATE$0, paramInt);
      if (encapsulatedPKIDataType == null)
        throw new IndexOutOfBoundsException(); 
      return encapsulatedPKIDataType;
    } 
  }
  
  public int sizeOfEncapsulatedX509CertificateArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(ENCAPSULATEDX509CERTIFICATE$0);
    } 
  }
  
  public void setEncapsulatedX509CertificateArray(EncapsulatedPKIDataType[] paramArrayOfEncapsulatedPKIDataType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfEncapsulatedPKIDataType, ENCAPSULATEDX509CERTIFICATE$0);
  }
  
  public void setEncapsulatedX509CertificateArray(int paramInt, EncapsulatedPKIDataType paramEncapsulatedPKIDataType) {
    generatedSetterHelperImpl((XmlObject)paramEncapsulatedPKIDataType, ENCAPSULATEDX509CERTIFICATE$0, paramInt, (short)2);
  }
  
  public EncapsulatedPKIDataType insertNewEncapsulatedX509Certificate(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().insert_element_user(ENCAPSULATEDX509CERTIFICATE$0, paramInt);
      return encapsulatedPKIDataType;
    } 
  }
  
  public EncapsulatedPKIDataType addNewEncapsulatedX509Certificate() {
    synchronized (monitor()) {
      check_orphaned();
      EncapsulatedPKIDataType encapsulatedPKIDataType = null;
      encapsulatedPKIDataType = (EncapsulatedPKIDataType)get_store().add_element_user(ENCAPSULATEDX509CERTIFICATE$0);
      return encapsulatedPKIDataType;
    } 
  }
  
  public void removeEncapsulatedX509Certificate(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(ENCAPSULATEDX509CERTIFICATE$0, paramInt);
    } 
  }
  
  public List<AnyType> getOtherCertificateList() {
    synchronized (monitor()) {
      check_orphaned();
      final class OtherCertificateList extends AbstractList<AnyType> {
        public AnyType get(int param1Int) {
          return CertificateValuesTypeImpl.this.getOtherCertificateArray(param1Int);
        }
        
        public AnyType set(int param1Int, AnyType param1AnyType) {
          AnyType anyType = CertificateValuesTypeImpl.this.getOtherCertificateArray(param1Int);
          CertificateValuesTypeImpl.this.setOtherCertificateArray(param1Int, param1AnyType);
          return anyType;
        }
        
        public void add(int param1Int, AnyType param1AnyType) {
          CertificateValuesTypeImpl.this.insertNewOtherCertificate(param1Int).set((XmlObject)param1AnyType);
        }
        
        public AnyType remove(int param1Int) {
          AnyType anyType = CertificateValuesTypeImpl.this.getOtherCertificateArray(param1Int);
          CertificateValuesTypeImpl.this.removeOtherCertificate(param1Int);
          return anyType;
        }
        
        public int size() {
          return CertificateValuesTypeImpl.this.sizeOfOtherCertificateArray();
        }
      };
      return new OtherCertificateList();
    } 
  }
  
  @Deprecated
  public AnyType[] getOtherCertificateArray() {
    synchronized (monitor()) {
      check_orphaned();
      ArrayList arrayList = new ArrayList();
      get_store().find_all_element_users(OTHERCERTIFICATE$2, arrayList);
      AnyType[] arrayOfAnyType = new AnyType[arrayList.size()];
      arrayList.toArray((Object[])arrayOfAnyType);
      return arrayOfAnyType;
    } 
  }
  
  public AnyType getOtherCertificateArray(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().find_element_user(OTHERCERTIFICATE$2, paramInt);
      if (anyType == null)
        throw new IndexOutOfBoundsException(); 
      return anyType;
    } 
  }
  
  public int sizeOfOtherCertificateArray() {
    synchronized (monitor()) {
      check_orphaned();
      return get_store().count_elements(OTHERCERTIFICATE$2);
    } 
  }
  
  public void setOtherCertificateArray(AnyType[] paramArrayOfAnyType) {
    check_orphaned();
    arraySetterHelper((XmlObject[])paramArrayOfAnyType, OTHERCERTIFICATE$2);
  }
  
  public void setOtherCertificateArray(int paramInt, AnyType paramAnyType) {
    generatedSetterHelperImpl((XmlObject)paramAnyType, OTHERCERTIFICATE$2, paramInt, (short)2);
  }
  
  public AnyType insertNewOtherCertificate(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().insert_element_user(OTHERCERTIFICATE$2, paramInt);
      return anyType;
    } 
  }
  
  public AnyType addNewOtherCertificate() {
    synchronized (monitor()) {
      check_orphaned();
      AnyType anyType = null;
      anyType = (AnyType)get_store().add_element_user(OTHERCERTIFICATE$2);
      return anyType;
    } 
  }
  
  public void removeOtherCertificate(int paramInt) {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_element(OTHERCERTIFICATE$2, paramInt);
    } 
  }
  
  public String getId() {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$4);
      if (simpleValue == null)
        return null; 
      return simpleValue.getStringValue();
    } 
  }
  
  public XmlID xgetId() {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$4);
      return xmlID;
    } 
  }
  
  public boolean isSetId() {
    synchronized (monitor()) {
      check_orphaned();
      return (get_store().find_attribute_user(ID$4) != null);
    } 
  }
  
  public void setId(String paramString) {
    synchronized (monitor()) {
      check_orphaned();
      SimpleValue simpleValue = null;
      simpleValue = (SimpleValue)get_store().find_attribute_user(ID$4);
      if (simpleValue == null)
        simpleValue = (SimpleValue)get_store().add_attribute_user(ID$4); 
      simpleValue.setStringValue(paramString);
    } 
  }
  
  public void xsetId(XmlID paramXmlID) {
    synchronized (monitor()) {
      check_orphaned();
      XmlID xmlID = null;
      xmlID = (XmlID)get_store().find_attribute_user(ID$4);
      if (xmlID == null)
        xmlID = (XmlID)get_store().add_attribute_user(ID$4); 
      xmlID.set((XmlObject)paramXmlID);
    } 
  }
  
  public void unsetId() {
    synchronized (monitor()) {
      check_orphaned();
      get_store().remove_attribute(ID$4);
    } 
  }
}


/* Location:              C:\Users\Huy PC\Downloads\WebBanHang-20230821T142944Z-001\WebBanHang\app\app.jar!\BOOT-INF\lib\poi-ooxml-schemas-4.1.2.jar!\org\ets\\uri\x01903\v13\impl\CertificateValuesTypeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */