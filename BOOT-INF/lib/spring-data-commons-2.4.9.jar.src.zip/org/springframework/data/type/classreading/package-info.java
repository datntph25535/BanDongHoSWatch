/**
 * Support classes for reading annotation and class-level metadata.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.data.type.classreading;
