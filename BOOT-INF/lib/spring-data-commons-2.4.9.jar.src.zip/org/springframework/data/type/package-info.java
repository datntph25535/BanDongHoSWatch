/**
 * Core support package for type introspection.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.type;
