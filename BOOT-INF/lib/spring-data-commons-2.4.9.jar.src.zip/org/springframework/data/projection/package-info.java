/**
 * Projection subsystem.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.projection;
