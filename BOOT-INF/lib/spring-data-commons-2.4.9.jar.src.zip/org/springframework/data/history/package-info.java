/**
 * Basic interfaces and value objects for histography API.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.history;
