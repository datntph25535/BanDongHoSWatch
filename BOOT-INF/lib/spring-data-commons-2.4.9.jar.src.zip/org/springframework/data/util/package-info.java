/**
 * Core utility APIs such as a type information framework to resolve generic types.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.util;
