/**
 * Base classes to implement CDI support for repositories.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.querydsl.binding;
