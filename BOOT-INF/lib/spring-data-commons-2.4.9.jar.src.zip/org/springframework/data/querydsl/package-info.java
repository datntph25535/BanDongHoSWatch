/**
 * Querydsl integration support classes.
 * 
 * @see <a href="http://www.querydsl.com">http://www.querydsl.com</a>
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.querydsl;
