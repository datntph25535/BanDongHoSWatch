/**
 * General support for entity auditing.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.auditing;
