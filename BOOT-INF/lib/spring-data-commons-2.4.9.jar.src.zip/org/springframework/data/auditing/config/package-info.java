/**
 * Types to abstract authentication concepts.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.auditing.config;
