/**
 * Spring Data web configuration.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.web.config;
