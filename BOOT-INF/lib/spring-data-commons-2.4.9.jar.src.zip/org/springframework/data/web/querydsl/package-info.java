/**
 * Querydsl-specific web support.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.web.querydsl;
