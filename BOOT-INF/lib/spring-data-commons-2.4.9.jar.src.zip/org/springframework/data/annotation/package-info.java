/**
 * Core annotations being used by Spring Data.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.annotation;
