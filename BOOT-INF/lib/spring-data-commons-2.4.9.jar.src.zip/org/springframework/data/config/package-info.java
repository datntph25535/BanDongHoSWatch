/**
 * Basic support for creating custom Spring namespaces and JavaConfig.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.config;
