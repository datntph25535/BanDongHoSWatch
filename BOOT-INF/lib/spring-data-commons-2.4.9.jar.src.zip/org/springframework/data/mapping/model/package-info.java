/**
 * Core implementation of the mapping subsystem's model.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.mapping.model;
