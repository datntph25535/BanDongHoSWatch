/**
 * Mapping callback API and implementation base classes.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.mapping.callback;
