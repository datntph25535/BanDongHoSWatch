/**
 * Base package for the mapping subsystem.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.mapping;
