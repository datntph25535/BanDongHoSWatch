/**
 * Support for repository initialization using XML and JSON.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.init;
