/**
 * Support classes for integration of the repository programming model with 3rd party frameworks.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.support;
