/**
 * Support for reactive repositories.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.reactive;
