/**
 * Support for Kotlin Coroutines repositories.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.kotlin;
