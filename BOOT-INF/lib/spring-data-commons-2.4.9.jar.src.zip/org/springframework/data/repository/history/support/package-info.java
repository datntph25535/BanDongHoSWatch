/**
 * Value objects to implement core repository interfaces for historiography.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.history.support;
