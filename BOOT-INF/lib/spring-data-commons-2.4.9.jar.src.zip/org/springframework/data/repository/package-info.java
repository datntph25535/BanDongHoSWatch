/**
 * Central interfaces for repository abstraction.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository;
