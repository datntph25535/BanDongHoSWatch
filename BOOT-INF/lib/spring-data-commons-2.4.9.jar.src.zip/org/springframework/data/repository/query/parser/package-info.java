/**
 * Support classes for parsing queries from method names.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.query.parser;
