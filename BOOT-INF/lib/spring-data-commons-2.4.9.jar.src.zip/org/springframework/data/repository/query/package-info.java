/**
 * Support classes to work with query methods.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.query;
