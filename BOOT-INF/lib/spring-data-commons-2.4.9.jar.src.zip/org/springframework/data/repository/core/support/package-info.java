/**
 * Base classes to implement repositories for various data stores.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.core.support;
