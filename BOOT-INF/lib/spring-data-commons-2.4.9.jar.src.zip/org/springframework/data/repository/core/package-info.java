/**
 * Core abstractions for repository implementation.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.core;
