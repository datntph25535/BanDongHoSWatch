/**
 * Utility classes for repository implementations.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.util;
