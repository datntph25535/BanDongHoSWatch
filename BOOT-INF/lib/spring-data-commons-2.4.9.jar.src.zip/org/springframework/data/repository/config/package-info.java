/**
 * Support classes for repository namespace and JavaConfig integration.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.repository.config;
