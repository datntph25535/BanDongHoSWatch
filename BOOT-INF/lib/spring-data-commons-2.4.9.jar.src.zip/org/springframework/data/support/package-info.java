/**
 * Core support classes.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.support;
