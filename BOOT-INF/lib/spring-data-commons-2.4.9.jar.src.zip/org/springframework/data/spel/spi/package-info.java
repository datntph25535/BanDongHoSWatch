/**
 * Service provider interfaces to extend the query execution mechanism.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.spel.spi;
