/**
 * Support for cross-store persistence.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.crossstore;
