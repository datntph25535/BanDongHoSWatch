Spring Data Commons is released under the terms of the Apache Software License Version 2.0 (see license.txt).


DISTRIBUTION CONTENTS:

The JARs are available in the 'dist' directory, and the source JARs are in the 'src' directory.

The reference manual and javadoc are located in the 'docs' directory.


ADDITIONAL RESOURCES:

Spring Data Homepage: https://projects.spring.io/spring-data
Spring Data on Stackoverflow: https://stackoverflow.com/questions/tagged/spring-data
