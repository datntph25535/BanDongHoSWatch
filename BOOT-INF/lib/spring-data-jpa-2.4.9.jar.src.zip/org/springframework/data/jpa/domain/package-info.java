/**
 * JPA specific support classes to implement domain classes.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.domain;
