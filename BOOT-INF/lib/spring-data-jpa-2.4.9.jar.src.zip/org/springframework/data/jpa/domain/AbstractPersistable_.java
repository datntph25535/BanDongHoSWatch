package org.springframework.data.jpa.domain;

import java.io.Serializable;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(AbstractPersistable.class)
public abstract class AbstractPersistable_ {

	public static volatile SingularAttribute<AbstractPersistable, Serializable> id;

	public static final String ID = "id";

}

