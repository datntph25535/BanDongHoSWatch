/**
 * Interfaces and annotations for JPA specific repositories.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.repository;
