/**
 * JPA specific utility functions.
 */
package org.springframework.data.jpa.repository.utils;

